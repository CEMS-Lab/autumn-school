"""Registry utilities for the Paper 4 unstructured operator tournament."""

from __future__ import annotations

from typing import Any


__all__ = [
    "ArchitectureSpec",
    "ContractError",
    "FoldSpec",
    "ProblemSpec",
    "RunSpec",
    "StageSpec",
    "TournamentContract",
    "build_run_matrix",
    "load_contract",
    "validate_contract",
    "write_run_matrices",
    "write_run_matrix_json",
    "write_run_matrix_tsv",
]


def __getattr__(name: str) -> Any:
    if name not in __all__:
        raise AttributeError(name)
    from . import contract

    return getattr(contract, name)

