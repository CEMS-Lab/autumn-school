"""Radius-kernel graph neural operator with explicit topology preparation."""

from __future__ import annotations

from dataclasses import dataclass
import weakref

import numpy as np
from scipy.spatial import cKDTree
import torch
from torch import nn

from .common import (
    DirectDamageModel,
    MLP,
    deterministic_initialisation,
    node_causal_features,
    project_element_mean_to_nodes,
    validate_causal_batch,
)
from ..mesh_data import MeshBatch, MeshTopology


__all__ = ["PreparedRadiusGraph", "RadiusGNO"]


@dataclass(frozen=True)
class PreparedRadiusGraph:
    """Deterministic radius edges and dimensionless quadrature weights."""

    edge_index: torch.Tensor
    relative_geometry: torch.Tensor
    quadrature_weight: torch.Tensor


class KernelIntegralBlock(nn.Module):
    """One dual-volume-weighted local kernel integral update."""

    def __init__(self, latent_dim: int) -> None:
        super().__init__()
        kernel_dim = 2 * latent_dim + 3
        self.kernel_norm = nn.LayerNorm(kernel_dim)
        self.kernel = MLP(
            kernel_dim,
            latent_dim,
            latent_dim,
            hidden_layers=2,
        )
        self.update_norm = nn.LayerNorm(2 * latent_dim)
        self.update = MLP(
            2 * latent_dim,
            latent_dim,
            latent_dim,
            hidden_layers=2,
        )

    def forward(
        self,
        node_latent: torch.Tensor,
        graph: PreparedRadiusGraph,
        *,
        message_chunk_size: int,
    ) -> torch.Tensor:
        source, target = graph.edge_index
        aggregate = node_latent.new_zeros(node_latent.shape)
        for start in range(0, source.numel(), message_chunk_size):
            stop = min(start + message_chunk_size, source.numel())
            source_chunk = source[start:stop]
            target_chunk = target[start:stop]
            kernel_input = torch.cat(
                [
                    node_latent[source_chunk],
                    node_latent[target_chunk],
                    graph.relative_geometry[start:stop],
                ],
                dim=1,
            )
            message = self.kernel(self.kernel_norm(kernel_input))
            weighted_message = (
                message * graph.quadrature_weight[start:stop].unsqueeze(1)
            )
            aggregate.index_add_(0, target_chunk, weighted_message)
        update = self.update(
            self.update_norm(torch.cat([node_latent, aggregate], dim=1))
        )
        return node_latent + update


class RadiusGNO(DirectDamageModel):
    """Mesh-independent radius GNO over relative geometry and dual volumes."""

    model_id = "radius_gno"
    neighbor_backend = "scipy_ckdtree"

    def __init__(
        self,
        *,
        latent_dim: int = 61,
        seed: int = 260619378,
        boundary_features: int = 5,
        load_features: int = 2,
        radius_over_ell: float = 3.0,
        message_chunk_size: int = 65_536,
    ) -> None:
        super().__init__()
        if latent_dim <= 0:
            raise ValueError("latent_dim must be positive")
        if radius_over_ell <= 0.0:
            raise ValueError("radius_over_ell must be positive")
        if (
            isinstance(message_chunk_size, bool)
            or not isinstance(message_chunk_size, int)
            or message_chunk_size <= 0
        ):
            raise ValueError("message_chunk_size must be a positive integer")
        self.latent_dim = int(latent_dim)
        self.boundary_features = int(boundary_features)
        self.load_features = int(load_features)
        self.radius_over_ell = float(radius_over_ell)
        self.message_chunk_size = message_chunk_size
        self.kernel_layers = 6
        node_input_dim = 5 + self.boundary_features + self.load_features
        with deterministic_initialisation(seed):
            self.node_encoder = nn.Sequential(
                MLP(
                    node_input_dim,
                    self.latent_dim,
                    self.latent_dim,
                    hidden_layers=2,
                ),
                nn.LayerNorm(self.latent_dim),
            )
            self.processor = nn.ModuleList(
                KernelIntegralBlock(self.latent_dim)
                for _ in range(self.kernel_layers)
            )
            self.decoder = MLP(
                self.latent_dim,
                1,
                self.latent_dim,
                hidden_layers=2,
            )
        self._graph_cache: dict[
            int,
            tuple[weakref.ReferenceType[MeshTopology], PreparedRadiusGraph],
        ] = {}
        self._cache_hits = 0
        self._cache_misses = 0

    def clear_prepared_graphs(self) -> None:
        self._graph_cache.clear()
        self._cache_hits = 0
        self._cache_misses = 0

    def graph_cache_info(self) -> dict[str, int]:
        stale = [
            key
            for key, (reference, _) in self._graph_cache.items()
            if reference() is None
        ]
        for key in stale:
            del self._graph_cache[key]
        return {
            "entries": len(self._graph_cache),
            "hits": self._cache_hits,
            "misses": self._cache_misses,
        }

    def prepare_graph(self, batch: MeshBatch) -> PreparedRadiusGraph:
        """Build or fetch radius edges outside the timed forward region."""

        validate_causal_batch(batch)
        topology = batch.topology
        key = id(topology)
        cached = self._graph_cache.get(key)
        if cached is not None and cached[0]() is topology:
            self._cache_hits += 1
            return cached[1]

        node_ell = project_element_mean_to_nodes(
            topology.element_ell,
            topology,
        )
        edge_parts: list[torch.Tensor] = []
        geometry_parts: list[torch.Tensor] = []
        for graph_id in range(batch.num_graphs):
            node_ids = torch.nonzero(
                batch.node_graph_ids == graph_id,
                as_tuple=False,
            ).squeeze(1)
            coordinates = topology.nodes[node_ids]
            local_ell = node_ell[node_ids]
            coordinates_cpu = coordinates.detach().cpu().numpy()
            ell_cpu = local_ell.detach().cpu().numpy()
            maximum_physical_radius = self.radius_over_ell * float(ell_cpu.max())
            candidate_pairs = cKDTree(coordinates_cpu).query_pairs(
                maximum_physical_radius,
                output_type="ndarray",
            )
            if candidate_pairs.size == 0:
                continue
            candidate_pairs = np.asarray(candidate_pairs, dtype=np.int64).reshape(-1, 2)
            candidate_pairs = candidate_pairs[
                np.lexsort((candidate_pairs[:, 1], candidate_pairs[:, 0]))
            ]
            low_np = candidate_pairs[:, 0]
            high_np = candidate_pairs[:, 1]
            relative_forward_np = (
                coordinates_cpu[high_np] - coordinates_cpu[low_np]
            ) / (0.5 * (ell_cpu[low_np] + ell_cpu[high_np]))[:, None]
            distance_np = np.linalg.norm(relative_forward_np, axis=1)
            within = distance_np <= self.radius_over_ell
            low_np = low_np[within]
            high_np = high_np[within]
            relative_forward_np = relative_forward_np[within]
            if low_np.size == 0:
                continue

            source_local_np = np.concatenate([low_np, high_np])
            target_local_np = np.concatenate([high_np, low_np])
            pair_relative_np = np.concatenate(
                [relative_forward_np, -relative_forward_np],
                axis=0,
            )
            deterministic_order = np.lexsort(
                (target_local_np, source_local_np)
            )
            source_local_np = source_local_np[deterministic_order]
            target_local_np = target_local_np[deterministic_order]
            pair_relative_np = pair_relative_np[deterministic_order]
            source_local = torch.as_tensor(
                source_local_np,
                dtype=torch.long,
                device=node_ids.device,
            )
            target_local = torch.as_tensor(
                target_local_np,
                dtype=torch.long,
                device=node_ids.device,
            )
            pair_relative = torch.as_tensor(
                pair_relative_np,
                dtype=coordinates.dtype,
                device=coordinates.device,
            )
            source = node_ids[source_local]
            target = node_ids[target_local]
            edge_parts.append(torch.stack([source, target], dim=0))
            geometry_parts.append(
                torch.cat(
                    [
                        pair_relative,
                        torch.linalg.vector_norm(
                            pair_relative,
                            dim=1,
                            keepdim=True,
                        ),
                    ],
                    dim=1,
                )
            )
        if not edge_parts:
            raise ValueError(
                "radius graph has no edges; increase radius_over_ell for "
                "this topology"
            )
        edge_index = torch.cat(edge_parts, dim=1)
        relative_geometry = torch.cat(geometry_parts, dim=0)
        source, target = edge_index
        source_measure = (
            topology.node_dual_volumes[source]
            / node_ell[source]
            .square()
            .clamp_min(torch.finfo(node_ell.dtype).eps)
        )
        prepared = PreparedRadiusGraph(
            edge_index=edge_index.detach(),
            relative_geometry=relative_geometry.detach(),
            quadrature_weight=source_measure.detach(),
        )
        self._graph_cache[key] = (weakref.ref(topology), prepared)
        self._cache_misses += 1
        return prepared

    def predict_raw(self, batch: MeshBatch) -> torch.Tensor:
        validate_causal_batch(
            batch,
            boundary_features=self.boundary_features,
            load_features=self.load_features,
        )
        graph = self.prepare_graph(batch)
        node_features = node_causal_features(
            batch,
            boundary_features=self.boundary_features,
            load_features=self.load_features,
            include_history=True,
        )
        node_latent = self.node_encoder(node_features)
        for block in self.processor:
            node_latent = block(
                node_latent,
                graph,
                message_chunk_size=self.message_chunk_size,
            )
        return self.decoder(node_latent).squeeze(1)
