"""Literal source-style Moon local MeshGraphNet baseline."""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from .common import (
    DirectDamageModel,
    MLP,
    deterministic_initialisation,
    moon_assembled_history_feature,
    segment_mean,
    topological_boundary_mask,
    validate_causal_batch,
)
from ..mesh_data import MeshBatch


__all__ = ["LiteralMoonMeshGraphNet", "MoonFeatures"]


@dataclass(frozen=True)
class MoonFeatures:
    """The literal two-node-feature and scalar-edge-feature contract."""

    node: torch.Tensor
    edge: torch.Tensor


class SymmetricProcessorBlock(nn.Module):
    """One source-style symmetric edge/node processor iteration."""

    def __init__(self, latent_dim: int, hidden_layers: int) -> None:
        super().__init__()
        triple = 3 * latent_dim
        self.edge_update = MLP(
            triple,
            latent_dim,
            latent_dim,
            hidden_layers,
        )
        self.message_norm = nn.LayerNorm(triple)
        self.message = MLP(
            triple,
            latent_dim,
            latent_dim,
            hidden_layers,
        )
        self.node_norm = nn.LayerNorm(2 * latent_dim)
        self.node_update = MLP(
            2 * latent_dim,
            latent_dim,
            latent_dim,
            hidden_layers,
        )

    def forward(
        self,
        node_latent: torch.Tensor,
        edge_latent: torch.Tensor,
        edge_index: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        source, target = edge_index
        symmetric = torch.cat(
            [
                node_latent[source] + node_latent[target],
                torch.abs(node_latent[source] - node_latent[target]),
                edge_latent,
            ],
            dim=1,
        )
        edge_latent = edge_latent + self.edge_update(symmetric)
        symmetric = torch.cat(
            [
                node_latent[source] + node_latent[target],
                torch.abs(node_latent[source] - node_latent[target]),
                edge_latent,
            ],
            dim=1,
        )
        messages = self.message(self.message_norm(symmetric))
        aggregate = segment_mean(messages, target, node_latent.shape[0])
        node_input = self.node_norm(torch.cat([node_latent, aggregate], dim=1))
        node_latent = node_latent + self.node_update(node_input)
        return node_latent, edge_latent


class LiteralMoonMeshGraphNet(DirectDamageModel):
    """Moon encoder/processor/decoder with its narrow published feature set."""

    model_id = "literal_moon_meshgraphnet"

    def __init__(
        self,
        *,
        latent_dim: int = 32,
        seed: int = 260619378,
    ) -> None:
        super().__init__()
        if latent_dim <= 0:
            raise ValueError("latent_dim must be positive")
        self.latent_dim = int(latent_dim)
        self.hidden_layers = 3
        self.message_passing_steps = 10
        with deterministic_initialisation(seed):
            self.node_encoder = nn.Sequential(
                MLP(
                    2,
                    self.latent_dim,
                    self.latent_dim,
                    self.hidden_layers,
                ),
                nn.LayerNorm(self.latent_dim),
            )
            self.edge_encoder = nn.Sequential(
                MLP(
                    1,
                    self.latent_dim,
                    self.latent_dim,
                    self.hidden_layers,
                ),
                nn.LayerNorm(self.latent_dim),
            )
            self.processor = nn.ModuleList(
                SymmetricProcessorBlock(self.latent_dim, self.hidden_layers)
                for _ in range(self.message_passing_steps)
            )
            self.decoder = MLP(
                self.latent_dim,
                1,
                self.latent_dim,
                self.hidden_layers,
            )

    def prepare_features(self, batch: MeshBatch) -> MoonFeatures:
        validate_causal_batch(batch)
        assembled_history = moon_assembled_history_feature(batch)
        node = torch.stack(
            [assembled_history, topological_boundary_mask(batch.topology)],
            dim=1,
        )
        edge = batch.topology.edge_relative_geometry[:, 2:3]
        return MoonFeatures(node=node, edge=edge)

    def predict_raw(self, batch: MeshBatch) -> torch.Tensor:
        features = self.prepare_features(batch)
        node_features = features.node.clone()
        node_features[:, 0] = torch.log10(
            1.0 + node_features[:, 0].clamp_min(0.0)
        )
        node_latent = self.node_encoder(node_features)
        edge_latent = self.edge_encoder(features.edge)
        for block in self.processor:
            node_latent, edge_latent = block(
                node_latent,
                edge_latent,
                batch.topology.edge_index,
            )
        return self.decoder(node_latent).squeeze(1)
