"""Common unstructured mesh and causal-transition data for the tournament.

The canonical cell representation is a flattened node-incidence array plus a
CSR-style pointer.  Dense T3 and Q4 connectivity are converted to that form so
all downstream models see the same topology contract, including mixed meshes.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import torch


__all__ = [
    "MeshBatch",
    "MeshTopology",
    "TransitionSample",
    "build_mesh_topology",
    "collate_mesh_samples",
    "dense_to_incidence",
    "load_moon_trajectory",
    "load_moon_transition",
    "load_workstream23_transition",
    "split_mesh_batch",
]


def _torch_dtype(nodes: Any, requested: torch.dtype | None) -> torch.dtype:
    if requested is not None:
        if requested not in (torch.float32, torch.float64):
            raise ValueError("mesh floating dtype must be torch.float32 or torch.float64")
        return requested
    if isinstance(nodes, torch.Tensor) and nodes.dtype in (
        torch.float32,
        torch.float64,
    ):
        return nodes.dtype
    array = np.asarray(nodes)
    return torch.float64 if array.dtype == np.float64 else torch.float32


def _float_tensor(value: Any, *, dtype: torch.dtype, name: str) -> torch.Tensor:
    tensor = torch.as_tensor(value, dtype=dtype, device="cpu").detach().clone()
    if not torch.isfinite(tensor).all():
        raise ValueError(f"{name} must contain only finite values")
    return tensor.contiguous()


def _long_tensor(value: Any, *, name: str) -> torch.Tensor:
    tensor = torch.as_tensor(value, dtype=torch.long, device="cpu").detach().clone()
    return tensor.contiguous()


def _element_field(
    value: Any,
    count: int,
    *,
    dtype: torch.dtype,
    name: str,
    positive: bool = False,
) -> torch.Tensor:
    tensor = _float_tensor(value, dtype=dtype, name=name).reshape(-1)
    if tensor.numel() == 1:
        tensor = tensor.expand(count).clone()
    if tensor.shape != (count,):
        raise ValueError(f"{name} must be scalar or have shape ({count},)")
    if positive and bool(torch.any(tensor <= 0.0)):
        raise ValueError(f"{name} must be strictly positive")
    return tensor.contiguous()


def _node_field(
    value: Any,
    count: int,
    *,
    dtype: torch.dtype,
    name: str,
) -> torch.Tensor:
    tensor = _float_tensor(value, dtype=dtype, name=name).reshape(-1)
    if tensor.shape != (count,):
        raise ValueError(f"{name} must have shape ({count},)")
    return tensor


def dense_to_incidence(elements: Any) -> tuple[torch.Tensor, torch.Tensor]:
    """Convert homogeneous dense T3 or Q4 connectivity to flattened incidence."""

    dense = _long_tensor(elements, name="elements")
    if dense.ndim != 2 or dense.shape[0] == 0 or dense.shape[1] not in (3, 4):
        raise ValueError("elements must have shape (n_elements, 3) or (n_elements, 4)")
    width = int(dense.shape[1])
    flattened = dense.reshape(-1).clone()
    pointer = torch.arange(
        0,
        flattened.numel() + 1,
        width,
        dtype=torch.long,
    )
    return flattened, pointer


@dataclass(frozen=True)
class MeshTopology:
    """Static T3/Q4 mesh topology and geometry in tensor form."""

    nodes: torch.Tensor
    cell_nodes: torch.Tensor
    cell_ptr: torch.Tensor
    cell_sizes: torch.Tensor
    edge_index: torch.Tensor
    node_element_index: torch.Tensor
    element_areas: torch.Tensor
    element_centroids: torch.Tensor
    node_dual_volumes: torch.Tensor
    element_ell: torch.Tensor
    edge_relative_geometry: torch.Tensor
    incidence_relative_geometry: torch.Tensor
    quadrature_reference_coordinates: torch.Tensor
    quadrature_shape_values: torch.Tensor
    quadrature_wdetJ: torch.Tensor

    @property
    def num_nodes(self) -> int:
        return int(self.nodes.shape[0])

    @property
    def num_elements(self) -> int:
        return int(self.cell_sizes.numel())

    @property
    def elements(self) -> torch.Tensor | None:
        """Return dense connectivity for homogeneous meshes, else ``None``."""

        if self.num_elements == 0 or not bool(torch.all(self.cell_sizes == self.cell_sizes[0])):
            return None
        return self.cell_nodes.reshape(self.num_elements, int(self.cell_sizes[0])).clone()

    @property
    def incidence_index(self) -> torch.Tensor:
        return self.node_element_index

    @property
    def edge_features(self) -> torch.Tensor:
        return self.edge_relative_geometry

    @property
    def incidence_features(self) -> torch.Tensor:
        return self.incidence_relative_geometry

    def to(
        self,
        device: torch.device | str,
        *,
        dtype: torch.dtype | None = None,
    ) -> "MeshTopology":
        """Move geometry and topology while preserving index tensor dtypes."""

        floating_dtype = self.nodes.dtype if dtype is None else dtype
        if floating_dtype not in (torch.float32, torch.float64):
            raise ValueError("mesh floating dtype must be torch.float32 or torch.float64")
        return MeshTopology(
            nodes=self.nodes.to(device=device, dtype=floating_dtype),
            cell_nodes=self.cell_nodes.to(device=device),
            cell_ptr=self.cell_ptr.to(device=device),
            cell_sizes=self.cell_sizes.to(device=device),
            edge_index=self.edge_index.to(device=device),
            node_element_index=self.node_element_index.to(device=device),
            element_areas=self.element_areas.to(
                device=device, dtype=floating_dtype
            ),
            element_centroids=self.element_centroids.to(
                device=device, dtype=floating_dtype
            ),
            node_dual_volumes=self.node_dual_volumes.to(
                device=device, dtype=floating_dtype
            ),
            element_ell=self.element_ell.to(device=device, dtype=floating_dtype),
            edge_relative_geometry=self.edge_relative_geometry.to(
                device=device, dtype=floating_dtype
            ),
            incidence_relative_geometry=self.incidence_relative_geometry.to(
                device=device, dtype=floating_dtype
            ),
            quadrature_reference_coordinates=(
                self.quadrature_reference_coordinates.to(
                    device=device, dtype=floating_dtype
                )
            ),
            quadrature_shape_values=self.quadrature_shape_values.to(
                device=device, dtype=floating_dtype
            ),
            quadrature_wdetJ=self.quadrature_wdetJ.to(
                device=device, dtype=floating_dtype
            ),
        )

    @classmethod
    def from_dense(
        cls,
        nodes: Any,
        elements: Any,
        *,
        ell: Any,
        dtype: torch.dtype | None = None,
    ) -> "MeshTopology":
        return build_mesh_topology(
            nodes,
            elements=elements,
            ell=ell,
            dtype=dtype,
        )

    @classmethod
    def from_incidence(
        cls,
        nodes: Any,
        cell_nodes: Any,
        cell_ptr: Any,
        *,
        ell: Any,
        dtype: torch.dtype | None = None,
    ) -> "MeshTopology":
        return build_mesh_topology(
            nodes,
            cell_nodes=cell_nodes,
            cell_ptr=cell_ptr,
            ell=ell,
            dtype=dtype,
        )


def _normalise_connectivity(
    *,
    elements: Any | None,
    cell_nodes: Any | None,
    cell_ptr: Any | None,
    num_nodes: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    if elements is not None:
        if cell_nodes is not None or cell_ptr is not None:
            raise ValueError("provide dense elements or flattened incidence, not both")
        flattened, pointer = dense_to_incidence(elements)
    else:
        if cell_nodes is None or cell_ptr is None:
            raise ValueError("flattened incidence requires both cell_nodes and cell_ptr")
        flattened = _long_tensor(cell_nodes, name="cell_nodes")
        pointer = _long_tensor(cell_ptr, name="cell_ptr")
        if flattened.ndim != 1:
            raise ValueError("cell_nodes must be one-dimensional")
        if pointer.ndim != 1 or pointer.numel() < 2:
            raise ValueError("cell_ptr must be one-dimensional with at least two entries")
    if int(pointer[0]) != 0 or int(pointer[-1]) != flattened.numel():
        raise ValueError("cell_ptr must start at zero and end at len(cell_nodes)")
    sizes = pointer[1:] - pointer[:-1]
    if bool(torch.any(sizes <= 0)):
        raise ValueError("cell_ptr entries must be strictly increasing")
    if not bool(torch.all((sizes == 3) | (sizes == 4))):
        raise ValueError("only T3 and Q4 cells are supported")
    if flattened.numel() == 0:
        raise ValueError("mesh must contain at least one cell")
    if int(flattened.min()) < 0 or int(flattened.max()) >= num_nodes:
        raise ValueError("cell connectivity contains an out-of-range node id")
    return flattened, pointer, sizes


def _polygon_geometry(
    nodes: np.ndarray,
    cells: Sequence[np.ndarray],
) -> tuple[np.ndarray, np.ndarray]:
    areas = np.empty(len(cells), dtype=np.float64)
    centroids = np.empty((len(cells), 2), dtype=np.float64)
    for element_id, node_ids in enumerate(cells):
        if len(set(map(int, node_ids))) != len(node_ids):
            raise ValueError(f"element {element_id} repeats a node id")
        coordinates = nodes[node_ids]
        following = np.roll(coordinates, -1, axis=0)
        cross = coordinates[:, 0] * following[:, 1] - following[:, 0] * coordinates[:, 1]
        signed_twice_area = float(cross.sum())
        if abs(signed_twice_area) <= 1.0e-15:
            raise ValueError(f"element {element_id} has zero polygon area")
        areas[element_id] = 0.5 * abs(signed_twice_area)
        centroids[element_id, 0] = float(((coordinates[:, 0] + following[:, 0]) * cross).sum()) / (
            3.0 * signed_twice_area
        )
        centroids[element_id, 1] = float(((coordinates[:, 1] + following[:, 1]) * cross).sum()) / (
            3.0 * signed_twice_area
        )
    return areas, centroids


def _q4_quadrature_data(
    nodes: torch.Tensor,
    elements: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Return Torch-PF's ordered 2x2 Q4 points, shape values, and ``w detJ``."""

    a = nodes.new_tensor(1.0 / np.sqrt(3.0))
    points = torch.stack(
        [
            torch.stack([-a, -a]),
            torch.stack([a, -a]),
            torch.stack([-a, a]),
            torch.stack([a, a]),
        ]
    )
    xi = points[:, 0]
    eta = points[:, 1]
    shape = 0.25 * torch.stack(
        [
            (1.0 - xi) * (1.0 - eta),
            (1.0 + xi) * (1.0 - eta),
            (1.0 + xi) * (1.0 + eta),
            (1.0 - xi) * (1.0 + eta),
        ],
        dim=1,
    )
    derivatives = nodes.new_empty((4, 4, 2))
    derivatives[:, :, 0] = 0.25 * torch.stack(
        [
            -(1.0 - eta),
            1.0 - eta,
            1.0 + eta,
            -(1.0 + eta),
        ],
        dim=1,
    )
    derivatives[:, :, 1] = 0.25 * torch.stack(
        [
            -(1.0 - xi),
            -(1.0 + xi),
            1.0 + xi,
            1.0 - xi,
        ],
        dim=1,
    )
    coordinates = nodes[elements]
    jacobian = torch.einsum("qai,eaj->eqij", derivatives, coordinates)
    wdetJ = torch.linalg.det(jacobian)
    if bool(torch.any(wdetJ <= 0.0)):
        raise ValueError("Q4 element has non-positive quadrature Jacobian")
    return points.contiguous(), shape.contiguous(), wdetJ.contiguous()


def build_mesh_topology(
    nodes: Any,
    *,
    elements: Any | None = None,
    cell_nodes: Any | None = None,
    cell_ptr: Any | None = None,
    ell: Any,
    dtype: torch.dtype | None = None,
) -> MeshTopology:
    """Build topology and ell-normalised geometry from dense or mixed cells."""

    floating_dtype = _torch_dtype(nodes, dtype)
    node_tensor = _float_tensor(nodes, dtype=floating_dtype, name="nodes")
    if node_tensor.ndim != 2 or node_tensor.shape[0] == 0 or node_tensor.shape[1] != 2:
        raise ValueError("nodes must have shape (n_nodes, 2)")
    flattened, pointer, sizes = _normalise_connectivity(
        elements=elements,
        cell_nodes=cell_nodes,
        cell_ptr=cell_ptr,
        num_nodes=len(node_tensor),
    )
    num_elements = int(sizes.numel())
    element_ell = _element_field(
        ell,
        num_elements,
        dtype=floating_dtype,
        name="ell",
        positive=True,
    )

    flattened_np = flattened.numpy()
    pointer_np = pointer.numpy()
    cells = [
        flattened_np[pointer_np[index] : pointer_np[index + 1]]
        for index in range(num_elements)
    ]
    areas_np, centroids_np = _polygon_geometry(node_tensor.numpy(), cells)

    undirected_edges: set[tuple[int, int]] = set()
    dual_np = np.zeros(len(node_tensor), dtype=np.float64)
    ell_numerator_np = np.zeros(len(node_tensor), dtype=np.float64)
    element_ell_np = element_ell.numpy().astype(np.float64, copy=False)
    for element_id, node_ids in enumerate(cells):
        contribution = areas_np[element_id] / len(node_ids)
        np.add.at(dual_np, node_ids, contribution)
        np.add.at(
            ell_numerator_np,
            node_ids,
            contribution * element_ell_np[element_id],
        )
        for local_id, source in enumerate(node_ids):
            target = int(node_ids[(local_id + 1) % len(node_ids)])
            source = int(source)
            undirected_edges.add((min(source, target), max(source, target)))

    directed_edges = sorted(
        (source, target)
        for low, high in undirected_edges
        for source, target in ((low, high), (high, low))
    )
    edge_index = torch.tensor(directed_edges, dtype=torch.long).t().contiguous()
    element_ids = torch.repeat_interleave(
        torch.arange(num_elements, dtype=torch.long),
        sizes,
    )
    node_element_index = torch.stack([flattened, element_ids], dim=0)

    areas = torch.as_tensor(areas_np, dtype=floating_dtype).contiguous()
    centroids = torch.as_tensor(centroids_np, dtype=floating_dtype).contiguous()
    dual = torch.as_tensor(dual_np, dtype=floating_dtype).contiguous()
    fallback_ell = float(element_ell_np.mean())
    node_ell_np = np.full(len(node_tensor), fallback_ell, dtype=np.float64)
    used = dual_np > 0.0
    node_ell_np[used] = ell_numerator_np[used] / dual_np[used]
    node_ell = torch.as_tensor(node_ell_np, dtype=floating_dtype)

    source, target = edge_index
    edge_delta = node_tensor[target] - node_tensor[source]
    edge_scale = 0.5 * (node_ell[source] + node_ell[target])
    edge_relative = edge_delta / edge_scale.unsqueeze(1)
    edge_relative = torch.column_stack(
        [edge_relative, torch.linalg.vector_norm(edge_relative, dim=1)]
    ).contiguous()

    incidence_delta = node_tensor[flattened] - centroids[element_ids]
    incidence_relative = incidence_delta / element_ell[element_ids].unsqueeze(1)
    incidence_relative = torch.column_stack(
        [
            incidence_relative,
            torch.linalg.vector_norm(incidence_relative, dim=1),
        ]
    ).contiguous()

    quadrature_points = node_tensor.new_empty((0, 2))
    quadrature_shape = node_tensor.new_empty((0, 0))
    quadrature_wdetJ = node_tensor.new_empty((num_elements, 0))
    q4_element_ids = torch.where(sizes == 4)[0]
    if q4_element_ids.numel():
        dense_q4 = torch.stack(
            [
                flattened[pointer[element_id] : pointer[element_id + 1]]
                for element_id in q4_element_ids.tolist()
            ]
        )
        (
            q4_points,
            q4_shape,
            q4_wdetJ,
        ) = _q4_quadrature_data(node_tensor, dense_q4)
        local_mass = torch.einsum(
            "qa,eq->ea", q4_shape, q4_wdetJ
        )
        q4_areas = areas[q4_element_ids]
        dual.index_add_(
            0,
            dense_q4.reshape(-1),
            (
                local_mass
                - q4_areas.unsqueeze(1) / 4.0
            ).reshape(-1),
        )
        if q4_element_ids.numel() == num_elements:
            quadrature_points = q4_points
            quadrature_shape = q4_shape
            quadrature_wdetJ = q4_wdetJ

    return MeshTopology(
        nodes=node_tensor,
        cell_nodes=flattened,
        cell_ptr=pointer,
        cell_sizes=sizes,
        edge_index=edge_index,
        node_element_index=node_element_index,
        element_areas=areas,
        element_centroids=centroids,
        node_dual_volumes=dual,
        element_ell=element_ell,
        edge_relative_geometry=edge_relative,
        incidence_relative_geometry=incidence_relative,
        quadrature_reference_coordinates=quadrature_points,
        quadrature_shape_values=quadrature_shape,
        quadrature_wdetJ=quadrature_wdetJ,
    )


@dataclass(frozen=True)
class TransitionSample:
    """One direct-damage target with only past/current causal driver fields."""

    topology: MeshTopology
    d_prev: torch.Tensor
    H: torch.Tensor
    boundary_context: torch.Tensor
    load_direction: torch.Tensor
    Gc: torch.Tensor
    ell: torch.Tensor
    d_target: torch.Tensor
    d_prevprev: torch.Tensor | None = None
    transition_id: str | None = None

    def __post_init__(self) -> None:
        dtype = self.topology.nodes.dtype
        num_nodes = self.topology.num_nodes
        num_elements = self.topology.num_elements
        d_prev = _node_field(
            self.d_prev,
            num_nodes,
            dtype=dtype,
            name="d_prev",
        )
        d_target = _node_field(
            self.d_target,
            num_nodes,
            dtype=dtype,
            name="d_target",
        )
        d_prevprev = None
        if self.d_prevprev is not None:
            d_prevprev = _node_field(
                self.d_prevprev,
                num_nodes,
                dtype=dtype,
                name="d_prevprev",
            )
        history = _float_tensor(self.H, dtype=dtype, name="H")
        if history.ndim == 0:
            history = history.reshape(1)
        if history.shape[0] != num_elements:
            raise ValueError(f"H must have first dimension {num_elements}")
        boundary = _float_tensor(
            self.boundary_context,
            dtype=dtype,
            name="boundary_context",
        )
        if boundary.ndim == 1:
            boundary = boundary.unsqueeze(1)
        if boundary.ndim != 2 or boundary.shape[0] != num_nodes:
            raise ValueError(
                f"boundary_context must have shape ({num_nodes}, n_context)"
            )
        load_direction = _float_tensor(
            self.load_direction,
            dtype=dtype,
            name="load_direction",
        ).reshape(-1)
        if load_direction.numel() == 0:
            raise ValueError("load_direction must not be empty")
        toughness = _element_field(
            self.Gc,
            num_elements,
            dtype=dtype,
            name="Gc",
            positive=True,
        )
        length_scale = _element_field(
            self.ell,
            num_elements,
            dtype=dtype,
            name="ell",
            positive=True,
        )
        if not torch.allclose(length_scale, self.topology.element_ell):
            raise ValueError("sample ell must match topology geometry normalisation")

        object.__setattr__(self, "d_prev", d_prev)
        object.__setattr__(self, "d_prevprev", d_prevprev)
        object.__setattr__(self, "H", history)
        object.__setattr__(self, "boundary_context", boundary.contiguous())
        object.__setattr__(self, "load_direction", load_direction)
        object.__setattr__(self, "Gc", toughness)
        object.__setattr__(self, "ell", length_scale)
        object.__setattr__(self, "d_target", d_target)

    @property
    def target(self) -> torch.Tensor:
        return self.d_target

    def causal_inputs(self) -> dict[str, torch.Tensor]:
        inputs = {
            "d_prev": self.d_prev,
            "H": self.H,
            "boundary_context": self.boundary_context,
            "load_direction": self.load_direction,
            "Gc": self.Gc,
            "ell": self.ell,
        }
        if self.d_prevprev is not None:
            inputs["d_prevprev"] = self.d_prevprev
        return inputs

    def to(
        self,
        device: torch.device | str,
        *,
        dtype: torch.dtype | None = None,
    ) -> "TransitionSample":
        """Move a validated sample without rebuilding its mesh on the CPU."""

        floating_dtype = self.topology.nodes.dtype if dtype is None else dtype
        return _validated_transition_sample(
            topology=self.topology.to(device, dtype=floating_dtype),
            d_prev=self.d_prev.to(device=device, dtype=floating_dtype),
            d_prevprev=None
            if self.d_prevprev is None
            else self.d_prevprev.to(device=device, dtype=floating_dtype),
            H=self.H.to(device=device, dtype=floating_dtype),
            boundary_context=self.boundary_context.to(
                device=device, dtype=floating_dtype
            ),
            load_direction=self.load_direction.to(
                device=device, dtype=floating_dtype
            ),
            Gc=self.Gc.to(device=device, dtype=floating_dtype),
            ell=self.ell.to(device=device, dtype=floating_dtype),
            d_target=self.d_target.to(device=device, dtype=floating_dtype),
            transition_id=self.transition_id,
        )


@dataclass(frozen=True)
class MeshBatch:
    """Disjoint-union collation of variable-size transition graphs."""

    topology: MeshTopology
    d_prev: torch.Tensor
    H: torch.Tensor
    boundary_context: torch.Tensor
    load_direction: torch.Tensor
    Gc: torch.Tensor
    ell: torch.Tensor
    d_target: torch.Tensor
    d_prevprev: torch.Tensor | None
    d_prevprev_mask: torch.Tensor
    node_graph_ids: torch.Tensor
    element_graph_ids: torch.Tensor
    edge_graph_ids: torch.Tensor
    incidence_graph_ids: torch.Tensor
    node_ptr: torch.Tensor
    element_ptr: torch.Tensor
    transition_ids: tuple[str | None, ...]

    @property
    def num_graphs(self) -> int:
        return len(self.transition_ids)

    @classmethod
    def from_samples(cls, samples: Sequence[TransitionSample]) -> "MeshBatch":
        return collate_mesh_samples(samples)

    def causal_inputs(self) -> dict[str, torch.Tensor]:
        inputs = {
            "d_prev": self.d_prev,
            "H": self.H,
            "boundary_context": self.boundary_context,
            "load_direction": self.load_direction,
            "Gc": self.Gc,
            "ell": self.ell,
        }
        if self.d_prevprev is not None:
            inputs["d_prevprev"] = self.d_prevprev
            inputs["d_prevprev_mask"] = self.d_prevprev_mask
        return inputs

    def to(
        self,
        device: torch.device | str,
        *,
        dtype: torch.dtype | None = None,
    ) -> "MeshBatch":
        """Move a ragged batch to CPU, MPS, or CUDA for model execution."""

        floating_dtype = self.topology.nodes.dtype if dtype is None else dtype
        topology = self.topology.to(device, dtype=floating_dtype)
        return MeshBatch(
            topology=topology,
            d_prev=self.d_prev.to(device=device, dtype=floating_dtype),
            H=self.H.to(device=device, dtype=floating_dtype),
            boundary_context=self.boundary_context.to(
                device=device, dtype=floating_dtype
            ),
            load_direction=self.load_direction.to(
                device=device, dtype=floating_dtype
            ),
            Gc=self.Gc.to(device=device, dtype=floating_dtype),
            ell=self.ell.to(device=device, dtype=floating_dtype),
            d_target=self.d_target.to(device=device, dtype=floating_dtype),
            d_prevprev=None
            if self.d_prevprev is None
            else self.d_prevprev.to(device=device, dtype=floating_dtype),
            d_prevprev_mask=self.d_prevprev_mask.to(device=device),
            node_graph_ids=self.node_graph_ids.to(device=device),
            element_graph_ids=self.element_graph_ids.to(device=device),
            edge_graph_ids=self.edge_graph_ids.to(device=device),
            incidence_graph_ids=self.incidence_graph_ids.to(device=device),
            node_ptr=self.node_ptr.to(device=device),
            element_ptr=self.element_ptr.to(device=device),
            transition_ids=self.transition_ids,
        )


def _validated_transition_sample(**values: Any) -> TransitionSample:
    """Construct from tensors that already satisfy ``TransitionSample`` rules."""

    sample = object.__new__(TransitionSample)
    for field_name, value in values.items():
        object.__setattr__(sample, field_name, value)
    return sample


def split_mesh_batch(batch: MeshBatch) -> tuple[TransitionSample, ...]:
    """Recover graph-local samples from a disjoint-union batch.

    This is used by exact FEM physics losses, which operate one native mesh at
    a time. No geometry is recomputed and no tensor is copied back to CPU.
    """

    recovered: list[TransitionSample] = []
    for graph_id in range(batch.num_graphs):
        node_start = int(batch.node_ptr[graph_id])
        node_stop = int(batch.node_ptr[graph_id + 1])
        element_start = int(batch.element_ptr[graph_id])
        element_stop = int(batch.element_ptr[graph_id + 1])
        incidence_start = int(batch.topology.cell_ptr[element_start])
        incidence_stop = int(batch.topology.cell_ptr[element_stop])
        edge_mask = batch.edge_graph_ids == graph_id
        incidence_mask = batch.incidence_graph_ids == graph_id
        local_incidence = batch.topology.node_element_index[:, incidence_mask].clone()
        local_incidence[0] -= node_start
        local_incidence[1] -= element_start
        topology = MeshTopology(
            nodes=batch.topology.nodes[node_start:node_stop],
            cell_nodes=(
                batch.topology.cell_nodes[incidence_start:incidence_stop]
                - node_start
            ),
            cell_ptr=(
                batch.topology.cell_ptr[element_start : element_stop + 1]
                - incidence_start
            ),
            cell_sizes=batch.topology.cell_sizes[element_start:element_stop],
            edge_index=batch.topology.edge_index[:, edge_mask] - node_start,
            node_element_index=local_incidence,
            element_areas=batch.topology.element_areas[
                element_start:element_stop
            ],
            element_centroids=batch.topology.element_centroids[
                element_start:element_stop
            ],
            node_dual_volumes=batch.topology.node_dual_volumes[
                node_start:node_stop
            ],
            element_ell=batch.topology.element_ell[element_start:element_stop],
            edge_relative_geometry=batch.topology.edge_relative_geometry[edge_mask],
            incidence_relative_geometry=(
                batch.topology.incidence_relative_geometry[incidence_mask]
            ),
            quadrature_reference_coordinates=(
                batch.topology.quadrature_reference_coordinates
            ),
            quadrature_shape_values=batch.topology.quadrature_shape_values,
            quadrature_wdetJ=batch.topology.quadrature_wdetJ[
                element_start:element_stop
            ],
        )
        previous_previous = None
        previous_mask = batch.d_prevprev_mask[node_start:node_stop]
        if batch.d_prevprev is not None and bool(torch.all(previous_mask)):
            previous_previous = batch.d_prevprev[node_start:node_stop]
        recovered.append(
            _validated_transition_sample(
                topology=topology,
                d_prev=batch.d_prev[node_start:node_stop],
                d_prevprev=previous_previous,
                H=batch.H[element_start:element_stop],
                boundary_context=batch.boundary_context[node_start:node_stop],
                load_direction=batch.load_direction[graph_id],
                Gc=batch.Gc[element_start:element_stop],
                ell=batch.ell[element_start:element_stop],
                d_target=batch.d_target[node_start:node_stop],
                transition_id=batch.transition_ids[graph_id],
            )
        )
    return tuple(recovered)


def _same_trailing_shape(
    samples: Sequence[TransitionSample],
    attribute: str,
) -> None:
    expected = getattr(samples[0], attribute).shape[1:]
    if any(getattr(sample, attribute).shape[1:] != expected for sample in samples[1:]):
        raise ValueError(f"all {attribute} tensors must have the same trailing shape")


def collate_mesh_samples(samples: Sequence[TransitionSample]) -> MeshBatch:
    """Collate transitions without introducing cross-graph edges or incidence."""

    samples = tuple(samples)
    if not samples:
        raise ValueError("cannot collate an empty sample sequence")
    if len(samples) == 1:
        sample = samples[0]
        topology = sample.topology
        has_previous_previous = sample.d_prevprev is not None
        return MeshBatch(
            topology=topology,
            d_prev=sample.d_prev,
            H=sample.H,
            boundary_context=sample.boundary_context,
            load_direction=sample.load_direction.unsqueeze(0),
            Gc=sample.Gc,
            ell=sample.ell,
            d_target=sample.d_target,
            d_prevprev=sample.d_prevprev,
            d_prevprev_mask=torch.full(
                (topology.num_nodes,),
                has_previous_previous,
                dtype=torch.bool,
                device=topology.nodes.device,
            ),
            node_graph_ids=torch.zeros(
                topology.num_nodes,
                dtype=torch.long,
                device=topology.nodes.device,
            ),
            element_graph_ids=torch.zeros(
                topology.num_elements,
                dtype=torch.long,
                device=topology.nodes.device,
            ),
            edge_graph_ids=torch.zeros(
                topology.edge_index.shape[1],
                dtype=torch.long,
                device=topology.nodes.device,
            ),
            incidence_graph_ids=torch.zeros(
                topology.cell_nodes.numel(),
                dtype=torch.long,
                device=topology.nodes.device,
            ),
            node_ptr=torch.tensor(
                [0, topology.num_nodes],
                dtype=torch.long,
                device=topology.nodes.device,
            ),
            element_ptr=torch.tensor(
                [0, topology.num_elements],
                dtype=torch.long,
                device=topology.nodes.device,
            ),
            transition_ids=(sample.transition_id,),
        )
    dtype = samples[0].topology.nodes.dtype
    if any(sample.topology.nodes.dtype != dtype for sample in samples[1:]):
        raise ValueError("all sample topologies must use the same floating dtype")
    if any(sample.topology.nodes.shape[1] != 2 for sample in samples):
        raise ValueError("all sample topologies must be two-dimensional")
    _same_trailing_shape(samples, "H")
    _same_trailing_shape(samples, "boundary_context")
    if any(
        sample.load_direction.shape != samples[0].load_direction.shape
        for sample in samples[1:]
    ):
        raise ValueError("all load_direction tensors must have the same shape")

    node_counts = [sample.topology.num_nodes for sample in samples]
    element_counts = [sample.topology.num_elements for sample in samples]
    incidence_counts = [sample.topology.cell_nodes.numel() for sample in samples]
    node_ptr = torch.tensor(
        [0, *np.cumsum(node_counts).tolist()],
        dtype=torch.long,
    )
    element_ptr = torch.tensor(
        [0, *np.cumsum(element_counts).tolist()],
        dtype=torch.long,
    )
    node_graph_ids = torch.repeat_interleave(
        torch.arange(len(samples), dtype=torch.long),
        torch.tensor(node_counts, dtype=torch.long),
    )
    element_graph_ids = torch.repeat_interleave(
        torch.arange(len(samples), dtype=torch.long),
        torch.tensor(element_counts, dtype=torch.long),
    )

    combined_cell_nodes = torch.cat(
        [
            sample.topology.cell_nodes + int(node_ptr[graph_id])
            for graph_id, sample in enumerate(samples)
        ]
    )
    pointer_parts = [torch.zeros(1, dtype=torch.long)]
    incidence_offset = 0
    for sample, incidence_count in zip(samples, incidence_counts, strict=True):
        pointer_parts.append(sample.topology.cell_ptr[1:] + incidence_offset)
        incidence_offset += int(incidence_count)
    combined_cell_ptr = torch.cat(pointer_parts)
    combined_ell = torch.cat([sample.ell for sample in samples])
    topology = build_mesh_topology(
        torch.cat([sample.topology.nodes for sample in samples]),
        cell_nodes=combined_cell_nodes,
        cell_ptr=combined_cell_ptr,
        ell=combined_ell,
        dtype=dtype,
    )
    edge_graph_ids = node_graph_ids[topology.edge_index[0]]
    incidence_graph_ids = element_graph_ids[topology.node_element_index[1]]

    previous_previous_parts: list[torch.Tensor] = []
    previous_previous_masks: list[torch.Tensor] = []
    has_previous_previous = False
    for sample in samples:
        if sample.d_prevprev is None:
            previous_previous_parts.append(torch.zeros_like(sample.d_prev))
            previous_previous_masks.append(
                torch.zeros(sample.topology.num_nodes, dtype=torch.bool)
            )
        else:
            has_previous_previous = True
            previous_previous_parts.append(sample.d_prevprev)
            previous_previous_masks.append(
                torch.ones(sample.topology.num_nodes, dtype=torch.bool)
            )

    return MeshBatch(
        topology=topology,
        d_prev=torch.cat([sample.d_prev for sample in samples]),
        d_prevprev=torch.cat(previous_previous_parts)
        if has_previous_previous
        else None,
        d_prevprev_mask=torch.cat(previous_previous_masks),
        H=torch.cat([sample.H for sample in samples]),
        boundary_context=torch.cat(
            [sample.boundary_context for sample in samples]
        ),
        load_direction=torch.stack(
            [sample.load_direction for sample in samples]
        ),
        Gc=torch.cat([sample.Gc for sample in samples]),
        ell=combined_ell,
        d_target=torch.cat([sample.d_target for sample in samples]),
        node_graph_ids=node_graph_ids,
        element_graph_ids=element_graph_ids,
        edge_graph_ids=edge_graph_ids,
        incidence_graph_ids=incidence_graph_ids,
        node_ptr=node_ptr,
        element_ptr=element_ptr,
        transition_ids=tuple(sample.transition_id for sample in samples),
    )


def load_workstream23_transition(
    path: str | Path,
    target_index: int,
    *,
    include_d_prevprev: bool = True,
    dtype: torch.dtype = torch.float32,
) -> TransitionSample:
    """Load one causal ``d[i-1], H[i] -> d[i]`` Workstream-23 transition."""

    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=False) as data:
        required = {
            "nodes",
            "elements",
            "boundary_context",
            "load_direction",
            "snapshot_steps",
            "damage",
            "damage_input_history_elem",
            "Gc_elem",
            "length_scale",
        }
        missing = required.difference(data.files)
        if missing:
            raise ValueError(f"{path} lacks fields: {sorted(missing)}")
        index = int(target_index)
        snapshot_steps = data["snapshot_steps"]
        if index < 1 or index >= len(snapshot_steps):
            raise IndexError(target_index)
        topology = build_mesh_topology(
            data["nodes"],
            elements=data["elements"],
            ell=data["length_scale"],
            dtype=dtype,
        )
        previous_previous = None
        if include_d_prevprev and index >= 2:
            previous_previous = data["damage"][index - 2]
        transition_id = (
            f"{path.parent.name}:{int(snapshot_steps[index - 1])}"
            f"->{int(snapshot_steps[index])}"
        )
        return TransitionSample(
            topology=topology,
            d_prev=data["damage"][index - 1],
            d_prevprev=previous_previous,
            H=data["damage_input_history_elem"][index],
            boundary_context=data["boundary_context"],
            load_direction=data["load_direction"],
            Gc=data["Gc_elem"],
            ell=data["length_scale"],
            d_target=data["damage"][index],
            transition_id=transition_id,
        )


def load_moon_transition(
    path: str | Path,
    target_index: int,
    *,
    summary_path: str | Path | None = None,
    include_d_prevprev: bool = True,
    dtype: torch.dtype = torch.float32,
) -> TransitionSample:
    """Load one frozen Moon-reference transition with reconstructed context.

    The independently generated Moon trajectories intentionally store a lean
    source-style schema. Boundary/load channels and material arrays are
    reconstructed from the trajectory, its adjacent run receipt, and the same
    heterogeneous-material function used by the exact FEM generator.
    """

    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    receipt_path = path.parent / "summary.json" if summary_path is None else Path(
        summary_path
    )
    if not receipt_path.is_file():
        raise FileNotFoundError(receipt_path)
    with receipt_path.open("r", encoding="utf-8") as handle:
        receipt = json.load(handle)
    configuration = receipt.get("configuration")
    if not isinstance(configuration, dict):
        raise ValueError(f"{receipt_path} lacks a configuration mapping")
    case = str(configuration.get("case", "")).strip().lower()
    if case not in {"training", "diagonal", "hole", "shear", "heterogeneous"}:
        raise ValueError(f"unsupported Moon case {case!r}")
    length_scale = float(configuration.get("length_scale", 0.0))
    if not np.isfinite(length_scale) or length_scale <= 0.0:
        raise ValueError("Moon length_scale must be finite and positive")

    with np.load(path, allow_pickle=False) as data:
        required = {
            "nodes",
            "elements",
            "boundary_indicator",
            "snapshot_steps",
            "damage",
            "damage_input_history_elem",
        }
        missing = required.difference(data.files)
        if missing:
            raise ValueError(f"{path} lacks fields: {sorted(missing)}")
        index = int(target_index)
        snapshot_steps = data["snapshot_steps"]
        if index < 1 or index >= len(snapshot_steps):
            raise IndexError(target_index)
        nodes = np.asarray(data["nodes"], dtype=np.float64)
        elements = np.asarray(data["elements"], dtype=np.int64)
        topology = build_mesh_topology(
            nodes,
            elements=elements,
            ell=length_scale,
            dtype=dtype,
        )

        topological = np.asarray(data["boundary_indicator"]).reshape(-1) > 0.5
        if topological.shape != (len(nodes),):
            raise ValueError("boundary_indicator must contain one value per node")
        extent = np.ptp(nodes, axis=0)
        tolerance = 1.0e-6 * max(float(extent.max()), 1.0)
        outer = (
            np.isclose(nodes[:, 0], nodes[:, 0].min(), atol=tolerance)
            | np.isclose(nodes[:, 0], nodes[:, 0].max(), atol=tolerance)
            | np.isclose(nodes[:, 1], nodes[:, 1].min(), atol=tolerance)
            | np.isclose(nodes[:, 1], nodes[:, 1].max(), atol=tolerance)
        )
        bottom = np.isclose(nodes[:, 1], nodes[:, 1].min(), atol=tolerance)
        top = np.isclose(nodes[:, 1], nodes[:, 1].max(), atol=tolerance)
        boundary_context = np.stack(
            [topological, outer, topological & ~outer, bottom, top],
            axis=1,
        ).astype(np.float32)

        if "Gc_elem" in data.files:
            toughness = np.asarray(data["Gc_elem"], dtype=np.float64)
        elif case == "heterogeneous":
            from scripts.paper4.run_moon_full_fem_baseline import (
                heterogeneous_material_fields,
            )

            toughness = heterogeneous_material_fields(nodes, elements)["Gc_elem"]
        else:
            toughness = np.full(len(elements), 2.7, dtype=np.float64)
        previous_previous = None
        if include_d_prevprev and index >= 2:
            previous_previous = data["damage"][index - 2]
        load_direction = np.asarray(
            [1.0, 0.0] if case == "shear" else [0.0, 1.0],
            dtype=np.float64,
        )
        transition_id = (
            f"{case}:{int(snapshot_steps[index - 1])}"
            f"->{int(snapshot_steps[index])}"
        )
        return TransitionSample(
            topology=topology,
            d_prev=data["damage"][index - 1],
            d_prevprev=previous_previous,
            H=data["damage_input_history_elem"][index],
            boundary_context=boundary_context,
            load_direction=load_direction,
            Gc=toughness,
            ell=length_scale,
            d_target=data["damage"][index],
            transition_id=transition_id,
        )


def load_moon_trajectory(
    path: str | Path,
    *,
    summary_path: str | Path | None = None,
    include_d_prevprev: bool = True,
    dtype: torch.dtype = torch.float32,
) -> tuple[TransitionSample, ...]:
    """Load a complete Moon trajectory while sharing one static topology.

    Frozen Moon meshes contain roughly 45,000 nodes, so rebuilding topology
    for every stored transition is needlessly expensive and also prevents the
    graph operators from reusing their topology-dependent caches.  The first
    transition establishes the reconstructed boundary/material context; the
    remaining causal samples alias that immutable topology and context.
    """

    path = Path(path)
    first = load_moon_transition(
        path,
        1,
        summary_path=summary_path,
        include_d_prevprev=include_d_prevprev,
        dtype=dtype,
    )
    case = str(first.transition_id).split(":", 1)[0]
    with np.load(path, allow_pickle=False) as data:
        snapshot_steps = np.asarray(data["snapshot_steps"])
        damage = np.asarray(data["damage"])
        history = np.asarray(data["damage_input_history_elem"])
        if damage.ndim != 2 or damage.shape[0] != len(snapshot_steps):
            raise ValueError("damage must have shape (n_steps, n_nodes)")
        if history.shape[0] != len(snapshot_steps):
            raise ValueError(
                "damage_input_history_elem first dimension must match snapshot_steps"
            )
        if damage.shape[1] != first.topology.num_nodes:
            raise ValueError("damage node count does not match Moon topology")
        if history.shape[1] != first.topology.num_elements:
            raise ValueError("history element count does not match Moon topology")

        samples: list[TransitionSample] = []
        for index in range(1, len(snapshot_steps)):
            previous_previous = None
            if include_d_prevprev and index >= 2:
                previous_previous = damage[index - 2]
            samples.append(
                TransitionSample(
                    topology=first.topology,
                    d_prev=damage[index - 1],
                    d_prevprev=previous_previous,
                    H=history[index],
                    boundary_context=first.boundary_context,
                    load_direction=first.load_direction,
                    Gc=first.Gc,
                    ell=first.ell,
                    d_target=damage[index],
                    transition_id=(
                        f"{case}:{int(snapshot_steps[index - 1])}"
                        f"->{int(snapshot_steps[index])}"
                    ),
                )
            )
    return tuple(samples)
