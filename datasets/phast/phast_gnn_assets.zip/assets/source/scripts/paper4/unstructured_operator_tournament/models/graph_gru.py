"""Causal two-state node GRU followed by local spatial message passing."""

from __future__ import annotations

import torch
from torch import nn

from .common import (
    DirectDamageModel,
    MLP,
    deterministic_initialisation,
    dimensionless_element_history,
    node_causal_features,
    project_native_history_to_nodes,
    segment_mean,
    validate_causal_batch,
)
from ..mesh_data import MeshBatch


__all__ = ["GraphGRU"]


class SpatialMessageBlock(nn.Module):
    """One residual update on the native topological node graph."""

    def __init__(self, latent_dim: int) -> None:
        super().__init__()
        message_dim = 2 * latent_dim + 3
        self.message_norm = nn.LayerNorm(message_dim)
        self.message = MLP(
            message_dim,
            latent_dim,
            latent_dim,
            hidden_layers=2,
        )
        self.update_norm = nn.LayerNorm(2 * latent_dim)
        self.update = MLP(
            2 * latent_dim,
            latent_dim,
            latent_dim,
            hidden_layers=2,
        )

    def forward(
        self,
        node_latent: torch.Tensor,
        edge_index: torch.Tensor,
        relative_geometry: torch.Tensor,
    ) -> torch.Tensor:
        source, target = edge_index
        message_input = torch.cat(
            [node_latent[source], node_latent[target], relative_geometry],
            dim=1,
        )
        message = self.message(self.message_norm(message_input))
        aggregate = segment_mean(message, target, node_latent.shape[0])
        update = self.update(
            self.update_norm(torch.cat([node_latent, aggregate], dim=1))
        )
        return node_latent + update


class GraphGRU(DirectDamageModel):
    """Stateless two-frame GRU encoder followed by spatial propagation."""

    model_id = "graph_gru"

    def __init__(
        self,
        *,
        latent_dim: int = 61,
        seed: int = 260619378,
        boundary_features: int = 5,
        load_features: int = 2,
    ) -> None:
        super().__init__()
        if latent_dim <= 0:
            raise ValueError("latent_dim must be positive")
        self.latent_dim = int(latent_dim)
        self.boundary_features = int(boundary_features)
        self.load_features = int(load_features)
        self.spatial_steps = 5
        context_dim = 4 + self.boundary_features + self.load_features
        with deterministic_initialisation(seed):
            self.temporal_cell = nn.GRUCell(3, self.latent_dim)
            self.node_encoder = nn.Sequential(
                MLP(
                    self.latent_dim + context_dim,
                    self.latent_dim,
                    self.latent_dim,
                    hidden_layers=2,
                ),
                nn.LayerNorm(self.latent_dim),
            )
            self.processor = nn.ModuleList(
                SpatialMessageBlock(self.latent_dim)
                for _ in range(self.spatial_steps)
            )
            self.decoder = MLP(
                self.latent_dim,
                1,
                self.latent_dim,
                hidden_layers=2,
            )

    def _temporal_state(self, batch: MeshBatch) -> torch.Tensor:
        current_driver = project_native_history_to_nodes(
            dimensionless_element_history(batch), batch.topology
        )
        mask = batch.d_prevprev_mask
        if batch.d_prevprev is None:
            previous_previous = batch.d_prev
        else:
            previous_previous = torch.where(
                mask,
                batch.d_prevprev,
                batch.d_prev,
            )
        initial_hidden = batch.d_prev.new_zeros(
            (batch.topology.num_nodes, self.latent_dim)
        )
        old_state = torch.stack(
            [
                previous_previous,
                torch.zeros_like(current_driver),
                mask.to(batch.d_prev.dtype),
            ],
            dim=1,
        )
        current_state = torch.stack(
            [
                batch.d_prev,
                current_driver,
                torch.ones_like(current_driver),
            ],
            dim=1,
        )
        hidden = self.temporal_cell(old_state, initial_hidden)
        return self.temporal_cell(current_state, hidden)

    def predict_raw(self, batch: MeshBatch) -> torch.Tensor:
        validate_causal_batch(
            batch,
            boundary_features=self.boundary_features,
            load_features=self.load_features,
        )
        temporal = self._temporal_state(batch)
        context = node_causal_features(
            batch,
            boundary_features=self.boundary_features,
            load_features=self.load_features,
            include_history=False,
        )
        node_latent = self.node_encoder(torch.cat([temporal, context], dim=1))
        for block in self.processor:
            node_latent = block(
                node_latent,
                batch.topology.edge_index,
                batch.topology.edge_relative_geometry,
            )
        return self.decoder(node_latent).squeeze(1)
