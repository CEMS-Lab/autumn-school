"""Shared causal features and direct-damage interface for tournament models."""

from __future__ import annotations

from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterator

import torch
from torch import nn

from ..mesh_data import MeshBatch, MeshTopology


__all__ = [
    "DirectDamageModel",
    "DirectDamagePrediction",
    "MLP",
    "assemble_element_integral_to_nodes",
    "deterministic_initialisation",
    "dimensionless_element_history",
    "element_property_ratios",
    "hard_project_damage",
    "moon_assembled_history_feature",
    "node_causal_features",
    "project_element_mean_to_nodes",
    "project_native_history_to_nodes",
    "segment_mean",
    "segment_sum",
    "segment_weighted_mean",
    "topological_boundary_mask",
    "validate_causal_batch",
]


@dataclass(frozen=True)
class DirectDamagePrediction:
    """Unconstrained model output and its installed irreversible damage."""

    raw: torch.Tensor
    damage: torch.Tensor


def hard_project_damage(
    raw: torch.Tensor,
    d_prev: torch.Tensor,
) -> torch.Tensor:
    """Project an absolute proposal onto the hard interval ``[d_prev, 1]``."""

    if raw.shape != d_prev.shape:
        raise ValueError("raw damage and d_prev must have the same shape")
    if not torch.isfinite(d_prev).all():
        raise ValueError("d_prev must contain only finite values")
    if bool(torch.any((d_prev < 0.0) | (d_prev > 1.0))):
        raise ValueError("d_prev must lie in [0, 1]")
    return torch.maximum(raw, d_prev).clamp_max(1.0)


class DirectDamageModel(nn.Module, ABC):
    """Common target-blind ``MeshBatch`` direct-damage model contract."""

    model_id: str
    latent_dim: int

    @abstractmethod
    def predict_raw(self, batch: MeshBatch) -> torch.Tensor:
        """Return one unconstrained absolute damage value per node."""

    def install_irreversible(
        self,
        raw: torch.Tensor,
        d_prev: torch.Tensor,
    ) -> torch.Tensor:
        return hard_project_damage(raw, d_prev)

    def forward(self, batch: MeshBatch) -> DirectDamagePrediction:
        validate_causal_batch(batch)
        raw = self.predict_raw(batch)
        if raw.shape != batch.d_prev.shape:
            raise ValueError(
                f"{self.model_id} returned shape {tuple(raw.shape)}, expected "
                f"{tuple(batch.d_prev.shape)}"
            )
        return DirectDamagePrediction(
            raw=raw,
            damage=self.install_irreversible(raw, batch.d_prev),
        )


@contextmanager
def deterministic_initialisation(seed: int) -> Iterator[None]:
    """Seed construction without advancing the process-global CPU RNG."""

    if isinstance(seed, bool) or not isinstance(seed, int):
        raise TypeError("seed must be an integer")
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(seed)
        yield


class MLP(nn.Sequential):
    """Small ReLU MLP with an explicit hidden-layer count."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        width: int,
        hidden_layers: int,
        *,
        final_layer_norm: bool = False,
    ) -> None:
        if min(input_dim, output_dim, width) <= 0:
            raise ValueError("MLP dimensions must be positive")
        if hidden_layers < 0:
            raise ValueError("hidden_layers must be non-negative")
        layers: list[nn.Module] = []
        current = input_dim
        for _ in range(hidden_layers):
            layers.extend([nn.Linear(current, width), nn.ReLU()])
            current = width
        layers.append(nn.Linear(current, output_dim))
        if final_layer_norm:
            layers.append(nn.LayerNorm(output_dim))
        super().__init__(*layers)


def validate_causal_batch(
    batch: MeshBatch,
    *,
    boundary_features: int | None = None,
    load_features: int | None = None,
) -> None:
    """Validate only fields models are permitted to read."""

    num_nodes = batch.topology.num_nodes
    num_elements = batch.topology.num_elements
    if batch.d_prev.shape != (num_nodes,):
        raise ValueError(f"d_prev must have shape ({num_nodes},)")
    if batch.H.shape[0] != num_elements:
        raise ValueError(f"H must have first dimension {num_elements}")
    if (
        batch.Gc.shape != (num_elements,)
        or batch.ell.shape != (num_elements,)
    ):
        raise ValueError("Gc and ell must have one value per element")
    if (
        batch.boundary_context.ndim != 2
        or batch.boundary_context.shape[0] != num_nodes
    ):
        raise ValueError("boundary_context must have one row per node")
    if (
        batch.load_direction.ndim != 2
        or batch.load_direction.shape[0] != batch.num_graphs
    ):
        raise ValueError("load_direction must have one row per graph")
    if (
        boundary_features is not None
        and batch.boundary_context.shape[1] != boundary_features
    ):
        raise ValueError(
            f"boundary_context has {batch.boundary_context.shape[1]} columns; "
            f"model expects {boundary_features}"
        )
    if (
        load_features is not None
        and batch.load_direction.shape[1] != load_features
    ):
        raise ValueError(
            f"load_direction has {batch.load_direction.shape[1]} columns; "
            f"model expects {load_features}"
        )
    causal_tensors = (
        batch.d_prev,
        batch.H,
        batch.boundary_context,
        batch.load_direction,
        batch.Gc,
        batch.ell,
    )
    if not all(torch.isfinite(value).all() for value in causal_tensors):
        raise ValueError("causal model inputs must contain only finite values")
    if (
        bool(torch.any(batch.Gc <= 0.0))
        or bool(torch.any(batch.ell <= 0.0))
    ):
        raise ValueError("Gc and ell must be strictly positive")


def segment_sum(
    values: torch.Tensor,
    index: torch.Tensor,
    count: int,
) -> torch.Tensor:
    """Sum rows into ``count`` permutation-invariant segments."""

    if index.ndim != 1 or index.shape[0] != values.shape[0]:
        raise ValueError("segment index must have one entry per value row")
    output = values.new_zeros((count, *values.shape[1:]))
    output.index_add_(0, index, values)
    return output


def segment_mean(
    values: torch.Tensor,
    index: torch.Tensor,
    count: int,
) -> torch.Tensor:
    """Mean rows within permutation-invariant segments."""

    summed = segment_sum(values, index, count)
    one_shape = (values.shape[0],) + (1,) * (values.ndim - 1)
    denominator = segment_sum(
        values.new_ones(one_shape),
        index,
        count,
    )
    return summed / denominator.clamp_min(1.0)


def segment_weighted_mean(
    values: torch.Tensor,
    index: torch.Tensor,
    weights: torch.Tensor,
    count: int,
) -> torch.Tensor:
    """Weighted mean rows within segments, with scalar row weights."""

    if weights.shape != (values.shape[0],):
        raise ValueError("weights must have one scalar per value row")
    expanded = weights.reshape((-1,) + (1,) * (values.ndim - 1))
    numerator = segment_sum(values * expanded, index, count)
    denominator = segment_sum(weights, index, count).reshape(
        (count,) + (1,) * (values.ndim - 1)
    )
    return numerator / denominator.clamp_min(torch.finfo(values.dtype).eps)


def dimensionless_element_history(batch: MeshBatch) -> torch.Tensor:
    """Return native element/Gauss history as the local ratio ``H*ell/Gc``."""

    history = batch.H.reshape(batch.H.shape[0], -1)
    return history * (batch.ell / batch.Gc).unsqueeze(1)


def _incidence_element_ids(topology: MeshTopology) -> torch.Tensor:
    return topology.node_element_index[1]


def assemble_element_integral_to_nodes(
    element_values: torch.Tensor,
    topology: MeshTopology,
) -> torch.Tensor:
    """Assemble ``sum_e int N_i value_e dOmega`` without mass inversion."""

    squeeze = element_values.ndim == 1
    values = element_values.unsqueeze(1) if squeeze else element_values
    if values.ndim != 2 or values.shape[0] != topology.num_elements:
        raise ValueError("element_values must have one row per element")
    element_ids = _incidence_element_ids(topology)
    node_ids = topology.node_element_index[0]
    local_measure = (
        topology.element_areas / topology.cell_sizes.to(values.dtype)
    )
    contribution = (
        values[element_ids] * local_measure[element_ids].unsqueeze(1)
    )
    assembled = segment_sum(contribution, node_ids, topology.num_nodes)
    return assembled.squeeze(1) if squeeze else assembled


def project_element_mean_to_nodes(
    element_values: torch.Tensor,
    topology: MeshTopology,
) -> torch.Tensor:
    """Mass-lumped element-to-node projection of dimensionless fields."""

    integral = assemble_element_integral_to_nodes(element_values, topology)
    denominator = topology.node_dual_volumes.clamp_min(
        torch.finfo(topology.nodes.dtype).eps
    )
    if integral.ndim == 2:
        denominator = denominator.unsqueeze(1)
    return integral / denominator


def project_native_history_to_nodes(
    element_values: torch.Tensor,
    topology: MeshTopology,
) -> torch.Tensor:
    """Project native element or ordered Q4 Gauss fields to FEM mesh nodes.

    Q4 values use the same shape functions and ``w detJ`` factors as
    :meth:`phast.core.mesh.FEMMesh.elem_to_node`. Other native signatures keep
    the established element-mean projection because no quadrature orientation
    is declared for them.
    """

    values = element_values.reshape(element_values.shape[0], -1)
    if values.shape[0] != topology.num_elements:
        raise ValueError("element_values must have one row per element")
    shape = topology.quadrature_shape_values
    wdetJ = topology.quadrature_wdetJ
    if (
        shape.shape == (values.shape[1], 4)
        and wdetJ.shape == values.shape
        and bool(torch.all(topology.cell_sizes == 4))
    ):
        local = torch.einsum("qa,eq,eq->ea", shape, values, wdetJ)
        assembled = values.new_zeros(topology.num_nodes)
        assembled.index_add_(0, topology.cell_nodes, local.reshape(-1))
        return assembled / topology.node_dual_volumes.clamp_min(
            torch.finfo(values.dtype).eps
        )
    return project_element_mean_to_nodes(values.mean(dim=1), topology)


def moon_assembled_history_feature(batch: MeshBatch) -> torch.Tensor:
    """Return Moon's assembled ``integral N_i H/(Gc ell) dOmega`` feature.

    This deliberately is an assembled integral, not a mass-inverted nodal
    average.  Keeping the implementation shared by the literal MeshGraphNet
    and the narrow FEM-incidence operator prevents the headline comparison
    from changing the information presented to the two architectures.
    """

    validate_causal_batch(batch)
    native_history = batch.H.reshape(batch.H.shape[0], -1)
    normalized = native_history / (batch.Gc * batch.ell).unsqueeze(1)
    return (
        project_native_history_to_nodes(normalized, batch.topology)
        * batch.topology.node_dual_volumes
    )


def element_property_ratios(
    batch: MeshBatch,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Area-weighted per-graph ``Gc`` and ``ell`` ratios for each element."""

    areas = batch.topology.element_areas
    gc_reference = segment_weighted_mean(
        batch.Gc,
        batch.element_graph_ids,
        areas,
        batch.num_graphs,
    )
    ell_reference = segment_weighted_mean(
        batch.ell,
        batch.element_graph_ids,
        areas,
        batch.num_graphs,
    )
    return (
        batch.Gc / gc_reference[batch.element_graph_ids],
        batch.ell / ell_reference[batch.element_graph_ids],
    )


def topological_boundary_mask(topology: MeshTopology) -> torch.Tensor:
    """Mark nodes incident to a cell edge appearing in exactly one element."""

    counts: dict[tuple[int, int], int] = {}
    cells: list[list[int]] = []
    for element_id in range(topology.num_elements):
        start = int(topology.cell_ptr[element_id])
        stop = int(topology.cell_ptr[element_id + 1])
        cell = topology.cell_nodes[start:stop].tolist()
        cells.append(cell)
        for local_id, source in enumerate(cell):
            target = cell[(local_id + 1) % len(cell)]
            edge = (min(source, target), max(source, target))
            counts[edge] = counts.get(edge, 0) + 1
    boundary = topology.nodes.new_zeros(topology.num_nodes)
    for cell in cells:
        for local_id, source in enumerate(cell):
            target = cell[(local_id + 1) % len(cell)]
            edge = (min(source, target), max(source, target))
            if counts[edge] == 1:
                boundary[source] = 1.0
                boundary[target] = 1.0
    return boundary


def node_causal_features(
    batch: MeshBatch,
    *,
    boundary_features: int = 5,
    load_features: int = 2,
    include_history: bool,
) -> torch.Tensor:
    """Build fixed-width causal node fields with no absolute coordinates."""

    validate_causal_batch(
        batch,
        boundary_features=boundary_features,
        load_features=load_features,
    )
    gc_ratio, ell_ratio = element_property_ratios(batch)
    node_gc = project_element_mean_to_nodes(gc_ratio, batch.topology)
    node_ell = project_element_mean_to_nodes(ell_ratio, batch.topology)
    pieces: list[torch.Tensor] = [
        batch.d_prev.unsqueeze(1),
        topological_boundary_mask(batch.topology).unsqueeze(1),
        batch.boundary_context,
        batch.load_direction[batch.node_graph_ids],
    ]
    if include_history:
        node_history = project_native_history_to_nodes(
            dimensionless_element_history(batch), batch.topology
        )
        pieces.append(node_history.unsqueeze(1))
    pieces.extend([node_gc.unsqueeze(1), node_ell.unsqueeze(1)])
    return torch.cat(pieces, dim=1)
