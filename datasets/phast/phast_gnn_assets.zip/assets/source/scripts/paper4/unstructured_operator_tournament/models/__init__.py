"""Frozen model registry for the unstructured direct-operator tournament."""

from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .common import DirectDamageModel, DirectDamagePrediction
from .fem_incidence import FEMIncidenceMultilevel
from .graph_gru import GraphGRU
from .moon_mgn import LiteralMoonMeshGraphNet
from .radius_gno import RadiusGNO


ARCHITECTURE_IDS = (
    "literal_moon_meshgraphnet",
    "fem_incidence_multilevel",
    "radius_gno",
    "graph_gru",
)

MODEL_REGISTRY = MappingProxyType(
    {
        "literal_moon_meshgraphnet": LiteralMoonMeshGraphNet,
        "fem_incidence_multilevel": FEMIncidenceMultilevel,
        "radius_gno": RadiusGNO,
        "graph_gru": GraphGRU,
    }
)

DEFAULT_LATENT_WIDTHS = MappingProxyType(
    {
        "literal_moon_meshgraphnet": 32,
        "fem_incidence_multilevel": 52,
        "radius_gno": 61,
        "graph_gru": 61,
    }
)


@dataclass(frozen=True)
class ParameterCountReceipt:
    """Exact default model-size receipt stored with tournament results."""

    architecture_id: str
    latent_dim: int
    parameters: int


def build_model(
    architecture_id: str,
    *,
    seed: int = 260619378,
    latent_dim: int | None = None,
    **overrides: Any,
) -> DirectDamageModel:
    """Construct a registered model with deterministic local initialisation."""

    try:
        model_type = MODEL_REGISTRY[architecture_id]
    except KeyError as exc:
        raise KeyError(
            f"unknown architecture {architecture_id!r}; expected one of "
            f"{ARCHITECTURE_IDS}"
        ) from exc
    width = (
        DEFAULT_LATENT_WIDTHS[architecture_id]
        if latent_dim is None
        else latent_dim
    )
    return model_type(latent_dim=width, seed=seed, **overrides)


def parameter_count_receipts(
    *,
    seed: int = 260619378,
) -> dict[str, ParameterCountReceipt]:
    """Return exact trainable counts for the four frozen default widths."""

    receipts: dict[str, ParameterCountReceipt] = {}
    for architecture_id in ARCHITECTURE_IDS:
        model = build_model(architecture_id, seed=seed)
        receipts[architecture_id] = ParameterCountReceipt(
            architecture_id=architecture_id,
            latent_dim=model.latent_dim,
            parameters=sum(
                parameter.numel()
                for parameter in model.parameters()
                if parameter.requires_grad
            ),
        )
    return receipts


__all__ = [
    "ARCHITECTURE_IDS",
    "DEFAULT_LATENT_WIDTHS",
    "MODEL_REGISTRY",
    "DirectDamageModel",
    "DirectDamagePrediction",
    "FEMIncidenceMultilevel",
    "GraphGRU",
    "LiteralMoonMeshGraphNet",
    "ParameterCountReceipt",
    "RadiusGNO",
    "build_model",
    "parameter_count_receipts",
]
