"""Native node-element incidence multilevel direct-damage operator."""

from __future__ import annotations

import torch
from torch import nn

from .common import (
    DirectDamageModel,
    MLP,
    deterministic_initialisation,
    dimensionless_element_history,
    element_property_ratios,
    moon_assembled_history_feature,
    node_causal_features,
    segment_mean,
    segment_weighted_mean,
    validate_causal_batch,
)
from ..mesh_data import MeshBatch


__all__ = ["FEMIncidenceMultilevel", "FEM_INCIDENCE_FEATURE_MODES"]


FEM_INCIDENCE_FEATURE_MODES = ("moon_narrow", "rich_ablation")


class IncidenceCycle(nn.Module):
    """One node-to-element then element-to-node residual message cycle."""

    def __init__(self, latent_dim: int) -> None:
        super().__init__()
        message_dim = 2 * latent_dim + 3
        update_dim = 2 * latent_dim
        self.node_to_element_norm = nn.LayerNorm(message_dim)
        self.node_to_element = MLP(
            message_dim,
            latent_dim,
            latent_dim,
            hidden_layers=2,
        )
        self.element_update_norm = nn.LayerNorm(update_dim)
        self.element_update = MLP(
            update_dim,
            latent_dim,
            latent_dim,
            hidden_layers=2,
        )
        self.element_to_node_norm = nn.LayerNorm(message_dim)
        self.element_to_node = MLP(
            message_dim,
            latent_dim,
            latent_dim,
            hidden_layers=2,
        )
        self.node_update_norm = nn.LayerNorm(update_dim)
        self.node_update = MLP(
            update_dim,
            latent_dim,
            latent_dim,
            hidden_layers=2,
        )

    def forward(
        self,
        node_latent: torch.Tensor,
        element_latent: torch.Tensor,
        batch: MeshBatch,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        node_ids, element_ids = batch.topology.node_element_index
        geometry = batch.topology.incidence_relative_geometry

        node_to_element = torch.cat(
            [node_latent[node_ids], element_latent[element_ids], geometry],
            dim=1,
        )
        node_messages = self.node_to_element(
            self.node_to_element_norm(node_to_element)
        )
        element_aggregate = segment_mean(
            node_messages,
            element_ids,
            batch.topology.num_elements,
        )
        element_latent = element_latent + self.element_update(
            self.element_update_norm(
                torch.cat([element_latent, element_aggregate], dim=1)
            )
        )

        reverse_geometry = torch.cat(
            [-geometry[:, :2], geometry[:, 2:3]],
            dim=1,
        )
        element_to_node = torch.cat(
            [
                element_latent[element_ids],
                node_latent[node_ids],
                reverse_geometry,
            ],
            dim=1,
        )
        element_messages = self.element_to_node(
            self.element_to_node_norm(element_to_node)
        )
        local_measure = (
            batch.topology.element_areas
            / batch.topology.cell_sizes.to(element_messages.dtype)
        )
        node_aggregate = segment_weighted_mean(
            element_messages,
            node_ids,
            local_measure[element_ids],
            batch.topology.num_nodes,
        )
        node_latent = node_latent + self.node_update(
            self.node_update_norm(
                torch.cat([node_latent, node_aggregate], dim=1)
            )
        )
        return node_latent, element_latent


class FEMIncidenceMultilevel(DirectDamageModel):
    """Use native cells as a permutation-equivariant coarse message level."""

    model_id = "fem_incidence_multilevel"
    preserves_native_element_history = False

    def __init__(
        self,
        *,
        latent_dim: int = 52,
        seed: int = 260619378,
        boundary_features: int = 5,
        load_features: int = 2,
        feature_mode: str = "moon_narrow",
    ) -> None:
        super().__init__()
        if latent_dim <= 0:
            raise ValueError("latent_dim must be positive")
        if feature_mode not in FEM_INCIDENCE_FEATURE_MODES:
            raise ValueError(
                f"feature_mode must be one of {FEM_INCIDENCE_FEATURE_MODES}, "
                f"got {feature_mode!r}"
            )
        self.latent_dim = int(latent_dim)
        self.boundary_features = int(boundary_features)
        self.load_features = int(load_features)
        self.feature_mode = feature_mode
        self.preserves_native_element_history = feature_mode == "rich_ablation"
        self.uses_moon_assembled_history = feature_mode == "moon_narrow"
        self.cycles = 4
        node_input_dim = (
            2
            if self.feature_mode == "moon_narrow"
            else 5 + self.boundary_features + self.load_features
        )
        with deterministic_initialisation(seed):
            self.node_encoder = nn.Sequential(
                MLP(
                    node_input_dim,
                    self.latent_dim,
                    self.latent_dim,
                    hidden_layers=2,
                ),
                nn.LayerNorm(self.latent_dim),
            )
            if self.feature_mode == "moon_narrow":
                self.element_history_encoder = None
                self.element_encoder = nn.Sequential(
                    MLP(1, self.latent_dim, self.latent_dim, hidden_layers=2),
                    nn.LayerNorm(self.latent_dim),
                )
            else:
                self.element_history_encoder = MLP(
                    1,
                    self.latent_dim,
                    self.latent_dim,
                    hidden_layers=2,
                )
                self.element_encoder = nn.Sequential(
                    MLP(
                        self.latent_dim + 2,
                        self.latent_dim,
                        self.latent_dim,
                        hidden_layers=2,
                    ),
                    nn.LayerNorm(self.latent_dim),
                )
            self.processor = nn.ModuleList(
                IncidenceCycle(self.latent_dim) for _ in range(self.cycles)
            )
            self.decoder = MLP(
                self.latent_dim,
                1,
                self.latent_dim,
                hidden_layers=2,
            )

    def prepare_element_features(self, batch: MeshBatch) -> torch.Tensor:
        if self.feature_mode == "moon_narrow":
            nondimensional_area = (
                batch.topology.element_areas / batch.ell.square()
            )
            return self.element_encoder(nondimensional_area.unsqueeze(1))

        assert self.element_history_encoder is not None
        history = dimensionless_element_history(batch)
        encoded_history = self.element_history_encoder(
            history.unsqueeze(2)
        ).mean(dim=1)
        gc_ratio, ell_ratio = element_property_ratios(batch)
        return self.element_encoder(
            torch.cat(
                [
                    encoded_history,
                    gc_ratio.unsqueeze(1),
                    ell_ratio.unsqueeze(1),
                ],
                dim=1,
            )
        )

    def prepare_node_features(self, batch: MeshBatch) -> torch.Tensor:
        if self.feature_mode == "moon_narrow":
            assembled_history = moon_assembled_history_feature(batch)
            history = torch.log10(1.0 + assembled_history.clamp_min(0.0))
            # The first boundary-context channel is the exact source boundary
            # indicator reconstructed by the Moon trajectory loader.
            boundary = batch.boundary_context[:, 0]
            return torch.stack([history, boundary], dim=1)
        return node_causal_features(
            batch,
            boundary_features=self.boundary_features,
            load_features=self.load_features,
            include_history=True,
        )

    def predict_raw(self, batch: MeshBatch) -> torch.Tensor:
        validate_causal_batch(
            batch,
            boundary_features=self.boundary_features,
            load_features=self.load_features,
        )
        node_features = self.prepare_node_features(batch)
        node_latent = self.node_encoder(node_features)
        element_latent = self.prepare_element_features(batch)
        for cycle in self.processor:
            node_latent, element_latent = cycle(
                node_latent,
                element_latent,
                batch,
            )
        return self.decoder(node_latent).squeeze(1)
