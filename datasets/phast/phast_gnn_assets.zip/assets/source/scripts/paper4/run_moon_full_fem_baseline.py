#!/usr/bin/env python3
"""Independent Torch-PF baseline for Moon, Choi & Ryu (2026).

This runner deliberately exposes the paper's unresolved choices instead of
silently guessing them:

* ``--history-order lagged`` follows Algorithm 1 (H_(n-1) -> d_n);
* ``--history-order fresh`` follows Section 3.1 (H_n -> d_n);
* a narrow traction-free slot approximates the visually inferred internal
  slit because exact crack endpoints/meshing code were not released;
* first-order triangles and the Torch-PF reduced 2-D plane-stress spectral
  history are declared implementation assumptions, not author metadata.

The conventional baseline performs exactly one mechanics solve and one
nonlinear rational-AT2 damage solve per load increment. It does not use the
production inner stagger loop.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.tri as mtri  # noqa: E402
from matplotlib.patches import Circle  # noqa: E402
import numpy as np  # noqa: E402
import torch  # noqa: E402


REPO_ROOT = Path(__file__).resolve().parents[2]
for import_root in (REPO_ROOT / "src", REPO_ROOT):
    if str(import_root) not in sys.path:
        sys.path.insert(0, str(import_root))

from phast.boundary_conditions import BoundaryConditions  # noqa: E402
from phast.material import Material  # noqa: E402
from phast.mesh import FEMMesh  # noqa: E402
from phast.solvers.damage_solver import damage_kkt_metrics  # noqa: E402
from phast.staggered_solver import SolverConfig, StaggeredSolver  # noqa: E402


HETEROGENEOUS_INCLUSION_CENTERS = np.asarray([
    (3.806, 9.060), (6.144, 8.982), (1.248, 8.787), (8.061, 8.455),
    (2.638, 8.023), (4.737, 7.819), (6.653, 7.300), (1.439, 6.905),
    (3.097, 6.432), (8.798, 6.039), (4.878, 5.872), (7.185, 5.100),
    (8.834, 4.423), (4.596, 4.281), (1.612, 3.963), (8.116, 3.064),
    (5.818, 2.986), (0.953, 2.459), (3.251, 2.341), (7.657, 1.570),
    (5.882, 1.324), (1.921, 1.222), (9.120, 1.118), (3.861, 0.859),
], dtype=np.float64)
HETEROGENEOUS_INCLUSION_RADIUS = 0.5
HETEROGENEOUS_MATRIX = {"E": 69.0, "nu": 0.30, "Gc": 15.0}
HETEROGENEOUS_INCLUSION = {"E": 2100.0, "nu": 0.35, "Gc": 50.0}


@dataclass(frozen=True)
class BaselineConfig:
    out_dir: Path
    case: str = "training"
    num_steps: int = 500
    mesh_size: float = 0.2
    length_scale: float = 0.4
    final_displacement: float = 0.03
    history_order: str = "lagged"
    crack_center_x: float = 5.0
    crack_center_y: float = 5.0
    crack_length: float = 3.0
    crack_angle_deg: float = 45.0
    crack_width: float = 0.02
    backend: str = "scipy"
    mechanics_tol: float = 1.0e-8
    mechanics_max_iter: int = 60
    damage_tol: float = 1.0e-8
    damage_max_iter: int = 1000
    snapshot_every: int = 1
    seed: int = 260619378
    live_damage_route: str | None = None
    operator_checkpoint: Path | None = None
    operator_checkpoint_sha256: str | None = None
    operator_device: str = "cpu"
    active_front_low: float = 0.02
    active_front_high: float = 0.98
    active_history_quantile: float = 0.995
    active_halo_hops: int = 10


def generate_slotted_square_mesh(config: BaselineConfig, path: Path) -> None:
    """Generate one Appendix-B geometry with an inferred narrow crack slot."""
    import gmsh

    path.parent.mkdir(parents=True, exist_ok=True)
    if gmsh.isInitialized():
        gmsh.finalize()
    gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Verbosity", 2)
        gmsh.model.add(f"moon_{config.case}_square")
        occ = gmsh.model.occ
        plate = occ.addRectangle(0.0, 0.0, 0.0, 10.0, 10.0)
        tools: list[tuple[int, int]] = []
        if config.case in {"training", "diagonal"}:
            slot = occ.addRectangle(
                config.crack_center_x - 0.5 * config.crack_length,
                config.crack_center_y - 0.5 * config.crack_width,
                0.0,
                config.crack_length,
                config.crack_width,
            )
            occ.rotate(
                [(2, slot)],
                config.crack_center_x,
                config.crack_center_y,
                0.0,
                0.0,
                0.0,
                1.0,
                math.radians(config.crack_angle_deg),
            )
            tools.append((2, slot))
        elif config.case == "hole":
            # Appendix B: edge crack x=0..3 at y=6; hole r=1 centered at (5.5,4).
            slot = occ.addRectangle(
                -config.crack_width,
                6.0 - 0.5 * config.crack_width,
                0.0,
                3.0 + config.crack_width,
                config.crack_width,
            )
            hole = occ.addDisk(5.5, 4.0, 0.0, 1.0, 1.0)
            tools.extend([(2, slot), (2, hole)])
        elif config.case == "shear":
            # Appendix B: edge crack x=0..5 on the midline y=5.
            slot = occ.addRectangle(
                -config.crack_width,
                5.0 - 0.5 * config.crack_width,
                0.0,
                5.0 + config.crack_width,
                config.crack_width,
            )
            tools.append((2, slot))
        elif config.case == "heterogeneous":
            # Appendix B: edge crack x=0..3 at y=5. Inclusion coordinates are
            # digitised from the official author figure because no table or
            # mesh was released; the declared circle diameter is 1 mm.
            slot = occ.addRectangle(
                -config.crack_width,
                5.0 - 0.5 * config.crack_width,
                0.0,
                3.0 + config.crack_width,
                config.crack_width,
            )
            tools.append((2, slot))
        else:
            raise ValueError(
                "case must be one of 'training', 'diagonal', 'hole', "
                "'shear', or 'heterogeneous'")
        cut, _mapping = occ.cut([(2, plate)], tools,
                                removeObject=True, removeTool=True)
        if config.case == "heterogeneous":
            inclusions = [
                (2, occ.addDisk(float(x), float(y), 0.0,
                                HETEROGENEOUS_INCLUSION_RADIUS,
                                HETEROGENEOUS_INCLUSION_RADIUS))
                for x, y in HETEROGENEOUS_INCLUSION_CENTERS
            ]
            cut, _mapping = occ.fragment(
                cut, inclusions, removeObject=True, removeTool=True)
        occ.synchronize()
        surfaces = [tag for dim, tag in cut if dim == 2]
        expected_surfaces = 25 if config.case == "heterogeneous" else 1
        if len(surfaces) != expected_surfaces:
            raise RuntimeError(
                f"Expected {expected_surfaces} plate surfaces, got "
                f"{len(surfaces)}")
        gmsh.model.addPhysicalGroup(2, surfaces, name="plate")

        points = gmsh.model.getEntities(0)
        gmsh.model.mesh.setSize(points, config.mesh_size)
        gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", 0)
        gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary", 0)
        gmsh.option.setNumber("Mesh.MeshSizeMin", min(
            config.mesh_size, max(config.crack_width, 1.0e-4)))
        gmsh.option.setNumber("Mesh.MeshSizeMax", config.mesh_size)
        gmsh.option.setNumber("Mesh.Algorithm", 6)
        gmsh.model.mesh.generate(2)
        gmsh.option.setNumber("Mesh.MshFileVersion", 2.2)
        gmsh.write(str(path))
    finally:
        gmsh.finalize()


def topology_boundary_indicator(elements: np.ndarray, n_nodes: int) -> np.ndarray:
    """Return one on nodes belonging to any one-sided mesh edge."""
    counts: dict[tuple[int, int], int] = {}
    for triangle in np.asarray(elements, dtype=np.int64):
        for a, b in ((triangle[0], triangle[1]),
                     (triangle[1], triangle[2]),
                     (triangle[2], triangle[0])):
            edge = tuple(sorted((int(a), int(b))))
            counts[edge] = counts.get(edge, 0) + 1
    indicator = np.zeros(n_nodes, dtype=np.float32)
    for (a, b), count in counts.items():
        if count == 1:
            indicator[a] = 1.0
            indicator[b] = 1.0
    return indicator


def heterogeneous_material_fields(
        nodes: np.ndarray, elements: np.ndarray) -> dict[str, np.ndarray]:
    """Return centroid-classified material fields for the reconstructed case."""
    centroids = np.asarray(nodes, dtype=np.float64)[
        np.asarray(elements, dtype=np.int64)].mean(axis=1)
    distance = np.linalg.norm(
        centroids[:, None, :] - HETEROGENEOUS_INCLUSION_CENTERS[None, :, :],
        axis=2)
    inclusion = np.any(
        distance <= HETEROGENEOUS_INCLUSION_RADIUS + 1.0e-10, axis=1)
    return {
        "phase_id": inclusion.astype(np.int8),
        "E_elem": np.where(
            inclusion, HETEROGENEOUS_INCLUSION["E"],
            HETEROGENEOUS_MATRIX["E"]).astype(np.float64),
        "nu_elem": np.where(
            inclusion, HETEROGENEOUS_INCLUSION["nu"],
            HETEROGENEOUS_MATRIX["nu"]).astype(np.float64),
        "Gc_elem": np.where(
            inclusion, HETEROGENEOUS_INCLUSION["Gc"],
            HETEROGENEOUS_MATRIX["Gc"]).astype(np.float64),
    }


def raw_history_feature(
        history_elem: np.ndarray, elements: np.ndarray,
        areas: np.ndarray, *, Gc: float | np.ndarray, length_scale: float,
        n_nodes: int) -> np.ndarray:
    """Literal assembled node feature sum_e int N_i H/(Gc*l_c) dOmega."""
    history = np.asarray(history_elem)
    Gc_array = np.asarray(Gc)
    if Gc_array.ndim > 0 and Gc_array.shape != history.shape:
        raise ValueError(
            f"Gc field shape {Gc_array.shape} must match history "
            f"shape {history.shape}")
    normalized = history / (Gc_array * length_scale)
    contribution = normalized * np.asarray(areas) / 3.0
    result = np.zeros(n_nodes, dtype=np.float64)
    np.add.at(result, elements.reshape(-1), np.repeat(contribution, 3))
    return result


def _node_sets(mesh: FEMMesh) -> tuple[torch.Tensor, torch.Tensor]:
    y = mesh.nodes[:, 1]
    tolerance = max(1.0e-8, 1.0e-6 * float(y.max() - y.min()))
    bottom = torch.where(torch.abs(y - y.min()) <= tolerance)[0]
    top = torch.where(torch.abs(y - y.max()) <= tolerance)[0]
    if bottom.numel() == 0 or top.numel() == 0:
        raise RuntimeError("Could not identify top/bottom boundary nodes")
    return bottom, top


def _plot_run(
        config: BaselineConfig, nodes: np.ndarray, elements: np.ndarray,
        displacement: np.ndarray, reaction: np.ndarray,
        snapshots: np.ndarray, snapshot_steps: np.ndarray,
        material_fields: dict[str, np.ndarray] | None = None) -> dict[str, str]:
    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)
    config.out_dir.mkdir(parents=True, exist_ok=True)
    curve_path = config.out_dir / "force_displacement.png"
    fig, ax = plt.subplots(figsize=(5.8, 4.2), constrained_layout=True)
    ax.plot(displacement, np.abs(reaction) / 1000.0, lw=1.8)
    ax.set_xlabel("top displacement [mm]")
    ax.set_ylabel("|reaction| [kN]")
    ax.grid(alpha=0.25)
    ax.set_title(
        f"Moon {config.case} Full-FEM baseline ({config.history_order} H)")
    fig.savefig(curve_path, dpi=180)
    plt.close(fig)

    stage_path = config.out_dir / "damage_stages.png"
    ids = np.unique(np.linspace(
        0, max(len(snapshots) - 1, 0), min(5, len(snapshots))).astype(int))
    fig, axes = plt.subplots(
        1, len(ids), figsize=(3.1 * len(ids), 3.2), constrained_layout=True)
    axes = np.atleast_1d(axes)
    for ax, idx in zip(axes, ids, strict=True):
        image = ax.tripcolor(
            tri, snapshots[idx], shading="gouraud", cmap="RdBu_r",
            vmin=0.0, vmax=1.0)
        ax.set_title(f"step {int(snapshot_steps[idx])}")
        ax.set_aspect("equal")
        ax.set_xticks([])
        ax.set_yticks([])
        if config.case == "heterogeneous":
            for x, y in HETEROGENEOUS_INCLUSION_CENTERS:
                ax.add_patch(Circle(
                    (float(x), float(y)), HETEROGENEOUS_INCLUSION_RADIUS,
                    fill=False, edgecolor="black", linewidth=0.35, alpha=0.45))
    fig.colorbar(image, ax=axes.tolist(), fraction=0.025, pad=0.02, label="d")
    fig.savefig(stage_path, dpi=180)
    plt.close(fig)
    paths = {
        "force_displacement": str(curve_path),
        "damage_stages": str(stage_path),
    }
    if material_fields is not None:
        material_path = config.out_dir / "material_layout.png"
        fig, ax = plt.subplots(figsize=(4.7, 4.2), constrained_layout=True)
        image = ax.tripcolor(
            tri, facecolors=material_fields["E_elem"], shading="flat",
            cmap="viridis")
        ax.set_aspect("equal")
        ax.set(xlabel="x [mm]", ylabel="y [mm]",
               title="Reconstructed matrix and inclusion layout")
        fig.colorbar(image, ax=ax, label="Young's modulus [MPa]")
        fig.savefig(material_path, dpi=200)
        plt.close(fig)
        paths["material_layout"] = str(material_path)
    return paths


def run(config: BaselineConfig) -> dict[str, Any]:
    if config.case not in {
            "training", "diagonal", "hole", "shear", "heterogeneous"}:
        raise ValueError(
            "case must be 'training', 'diagonal', 'hole', 'shear', or "
            "'heterogeneous'")
    if config.history_order not in {"lagged", "fresh"}:
        raise ValueError("history_order must be 'lagged' or 'fresh'")
    if config.num_steps <= 0:
        raise ValueError("num_steps must be positive")
    torch.manual_seed(config.seed)
    np.random.seed(config.seed % (2**32 - 1))
    config.out_dir.mkdir(parents=True, exist_ok=True)

    mesh_path = config.out_dir / "moon_slotted_square.msh"
    generate_slotted_square_mesh(config, mesh_path)
    mesh = FEMMesh(str(mesh_path), device="cpu", dtype=torch.float64)
    bottom, top = _node_sets(mesh)
    bcs = BoundaryConditions(mesh.n_nodes, mesh.device, mesh.dtype)
    bcs.fix(bottom, 0).fix(bottom, 1)
    if config.case == "shear":
        bcs.fix(top, 1).add(top, 0, config.final_displacement)
        reaction_component = 0
    else:
        bcs.fix(top, 0).add(top, 1, config.final_displacement)
        reaction_component = 1

    base_material = (
        HETEROGENEOUS_MATRIX if config.case == "heterogeneous"
        else {"E": 210000.0, "nu": 0.3, "Gc": 2.7})
    material = Material(
        E=base_material["E"],
        nu=base_material["nu"],
        Gc=base_material["Gc"],
        l0=config.length_scale,
        rho=7.8e-9,
        eta_residual=1.0e-7,
        energy_split="spectral",
        stress_degradation="full",
        pf_model="AT2",
        degradation_type="moon_rational",
        plane_stress=True,
    )
    solver_config = SolverConfig(
        solver_type="quasi_static",
        num_steps=config.num_steps,
        static_tol=config.mechanics_tol,
        static_max_iter=config.mechanics_max_iter,
        damage_tol=config.damage_tol,
        damage_max_iter=config.damage_max_iter,
        bounds_method="projected_cg",
        use_multigrid=False,
        preconditioner="jacobi",
        backend=config.backend,
        newton_line_search=True,
        fail_on_mechanics_nonconvergence=True,
    )
    solver = StaggeredSolver(mesh, material, bcs, solver_config)

    nodes_np = mesh.nodes.detach().cpu().numpy()
    elements_np = mesh.elements.detach().cpu().numpy()
    areas_np = mesh.areas.detach().cpu().numpy()
    material_fields = (
        heterogeneous_material_fields(nodes_np, elements_np)
        if config.case == "heterogeneous" else None)
    if material_fields is not None:
        solver.install_diff_E_field(
            torch.as_tensor(
                material_fields["E_elem"], device=mesh.device,
                dtype=mesh.dtype),
            torch.as_tensor(
                material_fields["nu_elem"], device=mesh.device,
                dtype=mesh.dtype))
        solver.diff_Gc_field = torch.as_tensor(
            material_fields["Gc_elem"], device=mesh.device, dtype=mesh.dtype)
    Gc_feature = (
        material_fields["Gc_elem"] if material_fields is not None
        else material.Gc)
    boundary = topology_boundary_indicator(elements_np, mesh.n_nodes)
    live_hook = None
    if config.live_damage_route is not None:
        from scripts.paper4.live_quasistatic_replacement import (
            LIVE_REPLACEMENT_ROUTES,
            LiveDamageReplacementHook,
            build_live_adapter,
            moon_boundary_context,
        )
        from scripts.paper4.moon_active_neighbourhood import ActiveMaskConfig

        if config.live_damage_route not in LIVE_REPLACEMENT_ROUTES:
            raise ValueError(
                f"live_damage_route must be one of {LIVE_REPLACEMENT_ROUTES}"
            )
        if config.operator_checkpoint is None:
            raise ValueError("live damage replacement requires a checkpoint")
        if (
            config.operator_checkpoint_sha256 is None
            or len(config.operator_checkpoint_sha256) != 64
        ):
            raise ValueError(
                "live damage replacement requires an exact checkpoint SHA-256"
            )
        boundary_context = moon_boundary_context(nodes_np, elements_np)
        load_direction = np.asarray(
            [1.0, 0.0] if config.case == "shear" else [0.0, 1.0],
            dtype=np.float32,
        )
        adapter_kwargs: dict[str, Any] = {
            "checkpoint_path": config.operator_checkpoint,
            "checkpoint_sha256": config.operator_checkpoint_sha256,
            "device": config.operator_device,
            "nodes": nodes_np,
            "elements": elements_np,
            "boundary_context": boundary_context,
            "load_direction": load_direction,
            "Gc_elem": Gc_feature,
            "length_scale": config.length_scale,
        }
        if config.live_damage_route in {
            "active_neighbourhood", "active_patch_unet",
        }:
            adapter_kwargs["mask_config"] = ActiveMaskConfig(
                front_low=config.active_front_low,
                front_high=config.active_front_high,
                history_quantile=config.active_history_quantile,
                halo_hops=config.active_halo_hops,
            )
        adapter = build_live_adapter(config.live_damage_route, **adapter_kwargs)
        live_hook = LiveDamageReplacementHook(solver, adapter).install()
    snapshots: list[np.ndarray] = []
    snapshot_steps: list[int] = []
    u_states: list[np.ndarray] = []
    H_states: list[np.ndarray] = []
    H_inputs: list[np.ndarray] = []
    history_features: list[np.ndarray] = []
    rows: list[dict[str, float | int | bool]] = []
    wall_start = time.perf_counter()

    for step in range(1, config.num_steps + 1):
        bcs.load_factor = step / config.num_steps
        d_prev = solver.d.detach().clone()
        H_prev = solver.H_elem.detach().clone()

        mechanics_start = time.perf_counter()
        solver.step_mechanics()
        mechanics_wall = time.perf_counter() - mechanics_start
        reaction_mechanics = solver.fem.compute_reaction_force(
            solver.u, d_prev, top, component=reaction_component)
        strain = solver.fem.compute_strain(solver.u)
        psi = solver.fem.compute_driving_force(
            solver.u, strain=strain, d=d_prev)
        H_fresh = torch.maximum(H_prev, psi)
        H_for_damage = H_prev if config.history_order == "lagged" else H_fresh

        solver.H_elem = H_for_damage
        damage_start = time.perf_counter()
        solver.step_solve_damage(d_prev_step=d_prev)
        damage_wall = time.perf_counter() - damage_start
        if not solver.damage_solver.last_converged:
            raise RuntimeError(
                f"Damage solve did not converge at step {step}: "
                f"iterations={solver.damage_solver.last_iter}")
        damage_input = H_for_damage.detach().cpu().numpy().copy()
        solver.H_elem = H_fresh
        solver.H_nodal = mesh.elem_to_node(solver.H_elem)
        solver.advance_step()

        reaction_post = solver.fem.compute_reaction_force(
            solver.u, solver.d, top, component=reaction_component)
        damage_residual = solver.damage_solver.compute_residual(
            H_for_damage, solver.d,
            Gc_field=getattr(solver, "diff_Gc_field", None))
        kkt = damage_kkt_metrics(damage_residual, solver.d, d_prev)
        applied = config.final_displacement * bcs.load_factor
        row = {
            "step": step,
            "applied_displacement": applied,
            "reaction_mechanics_state": reaction_mechanics,
            "reaction_post_damage": reaction_post,
            "max_damage": float(solver.d.max().item()),
            "max_history": float(solver.H_elem.max().item()),
            "mechanics_wall_s": mechanics_wall,
            "damage_wall_s": damage_wall,
            "mechanics_iterations": int(solver._last_mechanics_iter),
            "damage_iterations": int(solver.damage_solver.last_iter),
            "mechanics_converged": bool(solver._last_mechanics_converged),
            "damage_converged": bool(solver.damage_solver.last_converged),
            "damage_kkt_l2": float(kkt["kkt_projected_l2"]),
            "damage_kkt_linf": float(kkt["kkt_projected_linf"]),
        }
        if live_hook is not None:
            row.update({
                "live_replacement": True,
                "live_route": config.live_damage_route,
                **{
                    f"live_{key}": value
                    for key, value in live_hook.last_record.items()
                    if key != "route"
                },
            })
        else:
            row.update({
                "live_replacement": False,
                "live_route": "exact_damage_solver",
            })
        rows.append(row)

        if step % config.snapshot_every == 0 or step == config.num_steps:
            snapshots.append(solver.d.detach().cpu().numpy().copy())
            snapshot_steps.append(step)
            u_states.append(solver.u.detach().cpu().numpy().copy())
            H_states.append(solver.H_elem.detach().cpu().numpy().copy())
            H_inputs.append(damage_input)
            history_features.append(raw_history_feature(
                damage_input, elements_np, areas_np,
                Gc=Gc_feature, length_scale=material.l0,
                n_nodes=mesh.n_nodes))

        if step <= 3 or step % max(config.num_steps // 10, 1) == 0:
            print(
                f"step={step:4d}/{config.num_steps} "
                f"uy={applied:.6f} F={abs(reaction_mechanics)/1000.0:.4f}kN "
                f"dmax={row['max_damage']:.4f} "
                f"it_u={row['mechanics_iterations']} "
                f"it_d={row['damage_iterations']}",
                flush=True,
            )

    total_wall = time.perf_counter() - wall_start
    field_path = config.out_dir / "trajectory.npz"
    trajectory_payload: dict[str, np.ndarray] = {
        "nodes": nodes_np,
        "elements": elements_np,
        "boundary_indicator": boundary,
        "snapshot_steps": np.asarray(snapshot_steps),
        "displacement": np.stack(u_states),
        "damage": np.stack(snapshots),
        "history_elem": np.stack(H_states),
        "damage_input_history_elem": np.stack(H_inputs),
        "assembled_history_feature": np.stack(history_features),
    }
    if material_fields is not None:
        trajectory_payload.update(material_fields)
        trajectory_payload["inclusion_centers"] = (
            HETEROGENEOUS_INCLUSION_CENTERS.copy())
        trajectory_payload["inclusion_radius"] = np.asarray(
            HETEROGENEOUS_INCLUSION_RADIUS)
    np.savez_compressed(field_path, **trajectory_payload)
    history_path = config.out_dir / "history.csv"
    with history_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    displacement = np.asarray([row["applied_displacement"] for row in rows])
    reaction = np.asarray([row["reaction_mechanics_state"] for row in rows])
    plot_paths = _plot_run(
        config, nodes_np, elements_np, displacement, reaction,
        np.stack(snapshots), np.asarray(snapshot_steps), material_fields)
    replacement_summary = (
        live_hook.summary() if live_hook is not None else {
            "route": "exact_damage_solver",
            "model_calls": 0,
            "exact_damage_solve_calls": config.num_steps,
            "total_inference_wall_s": 0.0,
        }
    )
    summary: dict[str, Any] = {
        "paper_id": "arXiv:2606.19378v1",
        "evidence_class": (
            "live_closed_loop_direct_damage_replacement"
            if live_hook is not None
            else "independent_full_fem_reimplementation"
        ),
        "claim_allowed": False,
        "claim_boundary": (
            "Independent Torch-PF reproduction with inferred narrow-slot geometry, "
            "first-order triangles, reduced-2D plane-stress spectral history, and "
            f"explicit {config.history_order} history ordering; not author code/data. "
            + (
                "The frozen model replaces every damage solve and feeds the next "
                "mechanics/history state; recorded KKT values are diagnostics, not "
                "proof that the learned field solves the damage equation."
                if live_hook is not None else ""
            )
        ),
        "configuration": {**asdict(config), "out_dir": str(config.out_dir)},
        "mesh": {
            "nodes": mesh.n_nodes,
            "elements": mesh.n_elems,
            "boundary_nodes": int(boundary.sum()),
            "element_type": getattr(mesh, "element_type", "unknown"),
        },
        "material_regions": (
            {
                "matrix": HETEROGENEOUS_MATRIX,
                "inclusion": HETEROGENEOUS_INCLUSION,
                "inclusion_count": int(len(HETEROGENEOUS_INCLUSION_CENTERS)),
                "inclusion_radius_mm": HETEROGENEOUS_INCLUSION_RADIUS,
                "inclusion_element_count": int(
                    material_fields["phase_id"].sum()),
                "coordinate_provenance": (
                    "Digitised from the official Appendix-B author figure; "
                    "not author-supplied coordinates."),
            }
            if material_fields is not None else None),
        "completion": {
            "requested_steps": config.num_steps,
            "completed_steps": len(rows),
            "all_mechanics_converged": all(
                bool(row["mechanics_converged"]) for row in rows),
            "all_damage_converged": all(
                bool(row["damage_converged"]) for row in rows),
            "max_damage": max(float(row["max_damage"]) for row in rows),
            "max_damage_kkt_linf": max(
                float(row["damage_kkt_linf"]) for row in rows),
        },
        "timing": {
            "total_wall_s": total_wall,
            "mechanics_wall_s": sum(
                float(row["mechanics_wall_s"]) for row in rows),
            "damage_wall_s": sum(float(row["damage_wall_s"]) for row in rows),
        },
        "live_damage_replacement": replacement_summary,
        "paper_contract_assumptions": [
            "FEM package and triangular polynomial order are undisclosed",
            "zero-width pre-crack meshing is approximated by a declared narrow slot",
            *( ["diagonal crack center is inferred from the paper figure"]
               if config.case in {"training", "diagonal"} else [] ),
            *( ["inclusion centers are digitised from the official author figure"]
               if config.case == "heterogeneous" else [] ),
            "history ordering conflicts between Algorithm 1 and Section 3.1",
            "plane-stress spectral implementation details are undisclosed",
            "Newton tolerances, quadrature, output activation, and hardware are undisclosed",
        ],
        "paths": {
            "mesh": str(mesh_path),
            "trajectory": str(field_path),
            "history": str(history_path),
            **plot_paths,
        },
    }
    (config.out_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, default=str) + "\n", encoding="utf-8")
    return summary


def parse_args() -> BaselineConfig:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument(
        "--case", choices=[
            "training", "diagonal", "hole", "shear", "heterogeneous"],
        default="training")
    parser.add_argument("--num-steps", type=int)
    parser.add_argument("--mesh-size", type=float)
    parser.add_argument("--length-scale", type=float)
    parser.add_argument("--final-displacement", type=float)
    parser.add_argument("--history-order", choices=["lagged", "fresh"],
                        default="lagged")
    parser.add_argument("--crack-center-x", type=float, default=5.0)
    parser.add_argument("--crack-center-y", type=float, default=5.0)
    parser.add_argument("--crack-length", type=float, default=3.0)
    parser.add_argument("--crack-angle-deg", type=float, default=45.0)
    parser.add_argument("--crack-width", type=float, default=0.02)
    parser.add_argument("--backend", choices=["scipy", "mumps", "auto", "cg"],
                        default="scipy")
    parser.add_argument("--mechanics-tol", type=float, default=1.0e-8)
    parser.add_argument("--mechanics-max-iter", type=int, default=60)
    parser.add_argument("--damage-tol", type=float, default=1.0e-8)
    parser.add_argument("--damage-max-iter", type=int, default=1000)
    parser.add_argument("--snapshot-every", type=int, default=1)
    parser.add_argument("--seed", type=int, default=260619378)
    parser.add_argument(
        "--live-damage-route",
        choices=[
            "fem_incidence", "literal_moon", "active_neighbourhood", "raster_unet",
            "raster_fno", "raster_deeponet", "active_patch_unet",
        ],
    )
    parser.add_argument("--operator-checkpoint", type=Path)
    parser.add_argument("--operator-checkpoint-sha256")
    parser.add_argument("--operator-device", default="cpu")
    parser.add_argument("--active-front-low", type=float, default=0.02)
    parser.add_argument("--active-front-high", type=float, default=0.98)
    parser.add_argument("--active-history-quantile", type=float, default=0.995)
    parser.add_argument("--active-halo-hops", type=int, default=10)
    values = vars(parser.parse_args())
    paper_defaults = {
        "training": {
            "num_steps": 500, "mesh_size": 0.2,
            "length_scale": 0.4, "final_displacement": 0.03,
        },
        "diagonal": {
            "num_steps": 1000, "mesh_size": 0.05,
            "length_scale": 0.1, "final_displacement": 0.03,
        },
        "hole": {
            "num_steps": 1000, "mesh_size": 0.05,
            "length_scale": 0.1, "final_displacement": 0.04,
        },
        "shear": {
            "num_steps": 1000, "mesh_size": 0.05,
            "length_scale": 0.1, "final_displacement": 0.1,
        },
        "heterogeneous": {
            "num_steps": 1000, "mesh_size": 0.05,
            "length_scale": 0.1, "final_displacement": 4.0,
        },
    }[values["case"]]
    for key, value in paper_defaults.items():
        if values[key] is None:
            values[key] = value
    return BaselineConfig(**values)


if __name__ == "__main__":
    result = run(parse_args())
    print(json.dumps(result, indent=2, default=str))
