#!/usr/bin/env python3
"""Non-graph damage operators on a regular view of an unstructured FEM mesh."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import matplotlib.tri as mtri
import numpy as np
from scipy.spatial import cKDTree
import torch
from torch import nn
import torch.nn.functional as F


NONGRAPH_ARCHITECTURES = (
    "raster_unet",
    "raster_fno",
    "raster_deeponet",
    "active_patch_unet",
)


@dataclass(frozen=True)
class RasterContract:
    height: int = 128
    width: int = 128
    input_channels: int = 3
    align_corners: bool = True


class RasterMeshProjector:
    """Deterministic full-domain FEM-node/raster interpolation contract."""

    def __init__(
        self,
        nodes: np.ndarray,
        elements: np.ndarray,
        *,
        height: int,
        width: int,
        device: torch.device | str,
    ) -> None:
        self.nodes_np = np.asarray(nodes, dtype=np.float64)
        self.elements_np = np.asarray(elements, dtype=np.int64)
        if self.nodes_np.ndim != 2 or self.nodes_np.shape[1] != 2:
            raise ValueError("nodes must have shape (N,2)")
        if self.elements_np.ndim != 2 or self.elements_np.shape[1] != 3:
            raise ValueError("raster operators currently require T3 elements")
        self.height = int(height)
        self.width = int(width)
        self.device = torch.device(device)
        self.minimum = self.nodes_np.min(axis=0)
        self.maximum = self.nodes_np.max(axis=0)
        span = self.maximum - self.minimum
        if np.any(span <= 0.0):
            raise ValueError("mesh domain must have positive x/y extent")
        self.span = span

        x = np.linspace(self.minimum[0], self.maximum[0], self.width)
        y = np.linspace(self.minimum[1], self.maximum[1], self.height)
        xx, yy = np.meshgrid(x, y)
        points = np.column_stack([xx.reshape(-1), yy.reshape(-1)])
        triangulation = mtri.Triangulation(
            self.nodes_np[:, 0], self.nodes_np[:, 1], self.elements_np
        )
        triangle_ids = triangulation.get_trifinder()(points[:, 0], points[:, 1])
        valid = triangle_ids >= 0
        nearest = cKDTree(self.nodes_np).query(points, k=1)[1].astype(np.int64)
        self.grid_nearest_node = torch.as_tensor(
            nearest, dtype=torch.long, device=self.device
        )
        self.domain_mask = torch.as_tensor(
            valid.reshape(self.height, self.width),
            dtype=torch.float32,
            device=self.device,
        )

        normalized = 2.0 * (self.nodes_np - self.minimum) / span - 1.0
        self.node_coordinates = torch.as_tensor(
            normalized, dtype=torch.float32, device=self.device
        )
        self.node_sample_grid = self.node_coordinates.reshape(
            1, len(self.nodes_np), 1, 2
        )
        # Precompute the align_corners=True bilinear stencil explicitly.  This
        # is mathematically the same map as grid_sample for in-domain points,
        # while avoiding the missing grid_sampler_2d_backward kernel on MPS.
        x_index = (self.node_coordinates[:, 0] + 1.0) * (self.width - 1) / 2.0
        y_index = (self.node_coordinates[:, 1] + 1.0) * (self.height - 1) / 2.0
        x_index = x_index.clamp(0.0, float(self.width - 1))
        y_index = y_index.clamp(0.0, float(self.height - 1))
        x0 = torch.floor(x_index).to(torch.long)
        y0 = torch.floor(y_index).to(torch.long)
        x1 = torch.clamp(x0 + 1, max=self.width - 1)
        y1 = torch.clamp(y0 + 1, max=self.height - 1)
        wx = x_index - x0.to(x_index.dtype)
        wy = y_index - y0.to(y_index.dtype)
        self.node_bilinear_indices = torch.stack(
            [
                y0 * self.width + x0,
                y0 * self.width + x1,
                y1 * self.width + x0,
                y1 * self.width + x1,
            ],
            dim=1,
        )
        self.node_bilinear_weights = torch.stack(
            [
                (1.0 - wx) * (1.0 - wy),
                wx * (1.0 - wy),
                (1.0 - wx) * wy,
                wx * wy,
            ],
            dim=1,
        )

    def nodal_to_grid(self, values: torch.Tensor) -> torch.Tensor:
        values = values.to(
            device=self.device, dtype=torch.float32
        ).reshape(-1)
        if values.shape != (len(self.nodes_np),):
            raise ValueError("nodal field does not match projector mesh")
        dense = values[self.grid_nearest_node].reshape(self.height, self.width)
        return dense * self.domain_mask

    def grid_to_nodes(self, values: torch.Tensor) -> torch.Tensor:
        if values.ndim == 2:
            values = values[None, None]
        elif values.ndim == 3:
            values = values[:, None]
        if values.ndim != 4 or values.shape[1] != 1:
            raise ValueError("grid output must have shape (B,1,H,W)")
        if values.shape[-2:] != (self.height, self.width):
            raise ValueError(
                "grid output spatial shape does not match projector raster"
            )
        flattened = values[:, 0].reshape(values.shape[0], -1)
        stencil = flattened[:, self.node_bilinear_indices]
        return torch.sum(stencil * self.node_bilinear_weights.unsqueeze(0), dim=2)

    def make_input(
        self,
        normalized_history_node: torch.Tensor,
        boundary_indicator: torch.Tensor,
    ) -> torch.Tensor:
        history = self.nodal_to_grid(normalized_history_node)
        boundary = self.nodal_to_grid(boundary_indicator)
        return torch.stack([history, boundary, self.domain_mask], dim=0).unsqueeze(0)


class DoubleConv(nn.Module):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__()
        groups = min(8, out_channels)
        self.layers = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1),
            nn.GroupNorm(groups, out_channels),
            nn.SiLU(),
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.GroupNorm(groups, out_channels),
            nn.SiLU(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.layers(x)


class RasterUNet(nn.Module):
    """Compact deterministic U-Net damage field operator."""

    def __init__(self, in_channels: int = 3, width: int = 24) -> None:
        super().__init__()
        self.enc1 = DoubleConv(in_channels, width)
        self.enc2 = DoubleConv(width, 2 * width)
        self.enc3 = DoubleConv(2 * width, 4 * width)
        self.bottleneck = DoubleConv(4 * width, 8 * width)
        self.dec3 = DoubleConv(12 * width, 4 * width)
        self.dec2 = DoubleConv(6 * width, 2 * width)
        self.dec1 = DoubleConv(3 * width, width)
        self.out = nn.Conv2d(width, 1, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        e1 = self.enc1(x)
        e2 = self.enc2(F.max_pool2d(e1, 2))
        e3 = self.enc3(F.max_pool2d(e2, 2))
        b = self.bottleneck(F.max_pool2d(e3, 2))
        d3 = F.interpolate(b, size=e3.shape[-2:], mode="bilinear", align_corners=True)
        d3 = self.dec3(torch.cat([d3, e3], dim=1))
        d2 = F.interpolate(d3, size=e2.shape[-2:], mode="bilinear", align_corners=True)
        d2 = self.dec2(torch.cat([d2, e2], dim=1))
        d1 = F.interpolate(d2, size=e1.shape[-2:], mode="bilinear", align_corners=True)
        return self.out(self.dec1(torch.cat([d1, e1], dim=1)))


class SpectralConv2d(nn.Module):
    def __init__(self, channels: int, modes: int) -> None:
        super().__init__()
        self.channels = int(channels)
        self.modes = int(modes)
        scale = 1.0 / max(channels * channels, 1)
        self.weight_low = nn.Parameter(
            scale * torch.randn(channels, channels, modes, modes, 2)
        )
        self.weight_high = nn.Parameter(
            scale * torch.randn(channels, channels, modes, modes, 2)
        )

    @staticmethod
    def multiply(values: torch.Tensor, weights: torch.Tensor) -> torch.Tensor:
        return torch.einsum("bixy,ioxy->boxy", values, weights)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        _, _, height, width = x.shape
        transformed = torch.fft.rfft2(x, norm="ortho")
        output = torch.zeros(
            x.shape[0], self.channels, height, width // 2 + 1,
            dtype=torch.complex64, device=x.device,
        )
        low = torch.view_as_complex(self.weight_low.contiguous())
        high = torch.view_as_complex(self.weight_high.contiguous())
        modes_y = min(self.modes, height)
        modes_x = min(self.modes, width // 2 + 1)
        output[:, :, :modes_y, :modes_x] = self.multiply(
            transformed[:, :, :modes_y, :modes_x], low[:, :, :modes_y, :modes_x]
        )
        output[:, :, -modes_y:, :modes_x] = self.multiply(
            transformed[:, :, -modes_y:, :modes_x], high[:, :, :modes_y, :modes_x]
        )
        return torch.fft.irfft2(output, s=(height, width), norm="ortho")


class RasterFNO(nn.Module):
    def __init__(
        self,
        in_channels: int = 3,
        width: int = 32,
        modes: int = 16,
        blocks: int = 4,
    ) -> None:
        super().__init__()
        self.lift = nn.Conv2d(in_channels, width, 1)
        self.spectral = nn.ModuleList(SpectralConv2d(width, modes) for _ in range(blocks))
        self.local = nn.ModuleList(nn.Conv2d(width, width, 1) for _ in range(blocks))
        self.out = nn.Sequential(
            nn.Conv2d(width, 2 * width, 1), nn.GELU(), nn.Conv2d(2 * width, 1, 1)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.lift(x)
        for spectral, local in zip(self.spectral, self.local, strict=True):
            x = F.gelu(spectral(x) + local(x))
        return self.out(x)


class RasterDeepONet(nn.Module):
    """CNN branch plus coordinate trunk, with no mesh adjacency input."""

    def __init__(self, in_channels: int = 3, latent_dim: int = 128) -> None:
        super().__init__()
        self.branch = nn.Sequential(
            nn.Conv2d(in_channels, 32, 5, stride=2, padding=2), nn.SiLU(),
            nn.Conv2d(32, 64, 3, stride=2, padding=1), nn.SiLU(),
            nn.Conv2d(64, 96, 3, stride=2, padding=1), nn.SiLU(),
            nn.Conv2d(96, 128, 3, stride=2, padding=1), nn.SiLU(),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(128, latent_dim),
        )
        self.trunk = nn.Sequential(
            nn.Linear(2, 128), nn.SiLU(),
            nn.Linear(128, 128), nn.SiLU(),
            nn.Linear(128, latent_dim),
        )
        self.bias = nn.Parameter(torch.zeros(()))
        self.scale = latent_dim ** -0.5

    def forward(self, x: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        branch = self.branch(x)
        trunk = self.trunk(coordinates)
        return torch.einsum("bp,np->bn", branch, trunk) * self.scale + self.bias


class LocalResidualBlock(nn.Module):
    def __init__(self, channels: int, dilation: int) -> None:
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=dilation, dilation=dilation),
            nn.GroupNorm(8, channels),
            nn.SiLU(),
            nn.Conv2d(channels, channels, 3, padding=dilation, dilation=dilation),
            nn.GroupNorm(8, channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.silu(x + self.layers(x))


class ActivePatchUNet(nn.Module):
    """Strictly local fully-convolutional operator suitable for cropped inference."""

    receptive_radius_cells = 44

    def __init__(self, in_channels: int = 3, width: int = 48) -> None:
        super().__init__()
        self.lift = nn.Conv2d(in_channels, width, 3, padding=1)
        self.blocks = nn.Sequential(*[
            LocalResidualBlock(width, dilation)
            for dilation in (1, 2, 4, 4, 4, 4, 2, 1)
        ])
        self.out = nn.Conv2d(width, 1, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.out(self.blocks(F.silu(self.lift(x))))


def build_nongraph_operator(
    architecture: str,
    *,
    input_channels: int = 3,
) -> nn.Module:
    if architecture == "raster_unet":
        return RasterUNet(input_channels)
    if architecture == "raster_fno":
        return RasterFNO(input_channels)
    if architecture == "raster_deeponet":
        return RasterDeepONet(input_channels)
    if architecture == "active_patch_unet":
        return ActivePatchUNet(input_channels)
    raise ValueError(f"unsupported non-graph architecture: {architecture!r}")


def predict_nodal(
    model: nn.Module,
    architecture: str,
    input_grid: torch.Tensor,
    projector: RasterMeshProjector,
) -> tuple[torch.Tensor, torch.Tensor | None]:
    if architecture == "raster_deeponet":
        nodal = model(input_grid, projector.node_coordinates)
        return nodal.squeeze(0), None
    output_grid = model(input_grid)
    nodal = projector.grid_to_nodes(output_grid).squeeze(0)
    return nodal, output_grid


def checkpoint_architecture(payload: dict[str, Any]) -> str:
    architecture = str(payload.get("architecture", ""))
    if architecture not in NONGRAPH_ARCHITECTURES:
        raise ValueError(f"checkpoint has unsupported architecture {architecture!r}")
    return architecture
