#!/usr/bin/env python3
"""Evaluate one frozen Moon-narrow FEM-incidence checkpoint without fine-tuning.

This is a teacher-forced field diagnostic: every prediction receives the exact
Torch-PF history field for that stored state.  Target damage is used only after
inference for metrics and figures.  It is not a closed-loop hybrid solve.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import time
from typing import Any, Mapping

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.tri as mtri  # noqa: E402
import numpy as np  # noqa: E402
import torch  # noqa: E402

from scripts.paper4.unstructured_operator_tournament.mesh_data import (
    MeshBatch,
    TransitionSample,
    load_moon_trajectory,
    load_workstream23_transition,
)
from scripts.paper4.unstructured_operator_tournament.models.fem_incidence import (
    FEMIncidenceMultilevel,
)


SCHEMA = "paper4_fem_incidence_frozen_transfer_v1"
REQUIRED_CHECKPOINT = {
    "architecture": "fem_incidence",
    "feature_mode": "moon_narrow",
    "variant": "pi_dd",
    "epochs": 40000,
    "seed": 260619378,
    "first_training_step": 251,
    "last_training_step": 450,
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _resolve(base: Path, value: str) -> Path:
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def load_contract(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema") != SCHEMA:
        raise ValueError(f"unsupported contract schema: {payload.get('schema')!r}")
    cases = payload.get("cases")
    if not isinstance(cases, list) or len(cases) != 8:
        raise ValueError("contract must declare exactly eight transfer cases")
    ids = [row.get("id") for row in cases]
    if len(set(ids)) != 8:
        raise ValueError("transfer case ids must be unique")
    for row in cases:
        if row.get("role") != "test_only_no_target_fine_tuning":
            raise ValueError(f"case {row.get('id')} is not frozen test-only")
        if row.get("loader") not in {"moon", "workstream23"}:
            raise ValueError(f"unsupported loader for {row.get('id')}")
        digest = str(row.get("sha256", ""))
        if len(digest) != 64:
            raise ValueError(f"case {row.get('id')} lacks a SHA-256 digest")
    if payload.get("training_case_ids") != ["moon_training_trajectory"]:
        raise ValueError("the checkpoint must have exactly one declared training case")
    return payload


def load_frozen_checkpoint(
    path: Path, *, expected_sha256: str | None, device: torch.device
) -> tuple[FEMIncidenceMultilevel, dict[str, Any]]:
    actual_sha256 = sha256_file(path)
    if expected_sha256 and actual_sha256 != expected_sha256:
        raise ValueError("checkpoint SHA-256 does not match the supplied receipt")
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(payload, Mapping):
        raise ValueError("checkpoint root must be a mapping")
    configuration = payload.get("configuration")
    if not isinstance(configuration, Mapping):
        raise ValueError("checkpoint lacks configuration metadata")
    checks = {
        "architecture": payload.get("architecture"),
        "feature_mode": payload.get("feature_mode"),
        "variant": configuration.get("variant"),
        "epochs": int(configuration.get("epochs", -1)),
        "seed": int(configuration.get("seed", -1)),
        "first_training_step": int(configuration.get("first_training_step", -1)),
        "last_training_step": int(configuration.get("last_training_step", -1)),
    }
    if checks != REQUIRED_CHECKPOINT:
        raise ValueError(f"checkpoint contract mismatch: {checks}")
    if int(payload.get("completed_epochs", -1)) != 40000:
        raise ValueError("checkpoint is not a completed 40,000-epoch state")
    expected_steps = np.arange(251, 451, dtype=np.int64)
    if not np.array_equal(np.asarray(payload.get("training_steps")), expected_steps):
        raise ValueError("checkpoint training steps are not exactly 251..450")
    model = FEMIncidenceMultilevel(
        latent_dim=int(configuration.get("fem_incidence_latent_dim", 52)),
        seed=int(configuration["seed"]),
        feature_mode="moon_narrow",
    )
    model.load_state_dict(payload["model_state_dict"], strict=True)
    model.to(device).eval()
    return model, {
        "path": str(path.resolve()),
        "sha256": actual_sha256,
        "contract": checks,
        "completed_epochs": int(payload["completed_epochs"]),
        "training_trajectory": str(configuration.get("trajectory")),
        "model_state_load_verified": True,
    }


def load_case(contract_path: Path, specification: Mapping[str, Any]):
    path = _resolve(contract_path.parent, str(specification["path"]))
    actual = sha256_file(path)
    if actual != specification["sha256"]:
        raise ValueError(f"trajectory digest mismatch for {specification['id']}")
    if specification["loader"] == "moon":
        samples = load_moon_trajectory(path)
    else:
        first = load_workstream23_transition(path, 1)
        with np.load(path, allow_pickle=False) as archive:
            count = len(archive["snapshot_steps"])
            steps = np.asarray(archive["snapshot_steps"])
            damage = np.asarray(archive["damage"])
            history = np.asarray(archive["damage_input_history_elem"])
            samples = tuple(
                TransitionSample(
                    topology=first.topology,
                    d_prev=damage[index - 1],
                    d_prevprev=None if index < 2 else damage[index - 2],
                    H=history[index],
                    boundary_context=first.boundary_context,
                    load_direction=first.load_direction,
                    Gc=first.Gc,
                    ell=first.ell,
                    d_target=damage[index],
                    transition_id=(
                        f"{path.parent.name}:{int(steps[index - 1])}"
                        f"->{int(steps[index])}"
                    ),
                )
                for index in range(1, count)
            )
    if not samples:
        raise ValueError(f"case {specification['id']} contains no causal transitions")
    return path, samples


def preflight_cases(contract_path: Path) -> list[dict[str, Any]]:
    """Hash and load one transition from every target without model inference."""

    contract_path = contract_path.resolve()
    contract = load_contract(contract_path)
    rows: list[dict[str, Any]] = []
    for specification in contract["cases"]:
        path = _resolve(contract_path.parent, specification["path"])
        actual = sha256_file(path)
        if actual != specification["sha256"]:
            raise ValueError(f"trajectory digest mismatch for {specification['id']}")
        if specification["loader"] == "moon":
            samples = load_moon_trajectory(path)
            sample = samples[0]
            transition_count = len(samples)
        else:
            sample = load_workstream23_transition(path, 1)
            with np.load(path, allow_pickle=False) as archive:
                transition_count = len(archive["snapshot_steps"]) - 1
        cell_sizes = torch.unique(sample.topology.cell_sizes).tolist()
        if cell_sizes not in ([3], [4]):
            raise ValueError(f"unsupported cell sizes for {specification['id']}: {cell_sizes}")
        batch = MeshBatch.from_samples([sample])
        rows.append({
            "case_id": specification["id"],
            "sha256": actual,
            "transition_count": transition_count,
            "nodes": batch.topology.num_nodes,
            "elements": batch.topology.num_elements,
            "cell_sizes": cell_sizes,
            "finite_causal_inputs": all(
                bool(torch.isfinite(value).all()) for value in batch.causal_inputs().values()
            ),
        })
    return rows


def _metrics(exact: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    physical = np.clip(prediction, 0.0, 1.0)
    error = physical - exact
    exact_crack = exact >= 0.5
    predicted_crack = physical >= 0.5
    union = int(np.count_nonzero(exact_crack | predicted_crack))
    return {
        "rmse": float(np.sqrt(np.mean(error * error))),
        "mae": float(np.mean(np.abs(error))),
        "relative_l2": float(np.linalg.norm(error) / max(np.linalg.norm(exact), 1e-30)),
        "crack_iou_d050": 1.0 if union == 0 else float(
            np.count_nonzero(exact_crack & predicted_crack) / union
        ),
        "raw_min": float(np.min(prediction)),
        "raw_max": float(np.max(prediction)),
    }


def _render_final(path: Path, nodes, elements, exact, prediction, title: str) -> None:
    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)
    physical = np.clip(prediction, 0.0, 1.0)
    fields = (
        (exact, "Torch-PF exact", 1.0),
        (physical, "Frozen FEM-incidence", 1.0),
        (np.abs(physical - exact), "Absolute error", 0.30),
    )
    fig, axes = plt.subplots(1, 3, figsize=(10.2, 3.4), constrained_layout=True)
    for ax, (field, label, vmax) in zip(axes, fields, strict=True):
        image = ax.tripcolor(tri, field, shading="gouraud", cmap="inferno", vmin=0, vmax=vmax)
        ax.set_title(label)
        ax.set_aspect("equal")
        ax.set_xticks([])
        ax.set_yticks([])
        fig.colorbar(image, ax=ax, fraction=0.045, pad=0.02)
    fig.suptitle(title, fontweight="bold")
    fig.savefig(path, dpi=180)
    plt.close(fig)


def run(
    *, contract_path: Path, checkpoint_path: Path, checkpoint_sha256: str | None,
    case_id: str, out_dir: Path, device_name: str
) -> dict[str, Any]:
    contract_path = contract_path.resolve()
    contract = load_contract(contract_path)
    matches = [row for row in contract["cases"] if row["id"] == case_id]
    if len(matches) != 1:
        raise ValueError(f"case id is not uniquely declared: {case_id}")
    specification = matches[0]
    device = torch.device(device_name)
    trajectory_path, samples = load_case(contract_path, specification)
    model, checkpoint = load_frozen_checkpoint(
        checkpoint_path.resolve(), expected_sha256=checkpoint_sha256, device=device
    )
    if out_dir.exists():
        raise FileExistsError(out_dir)
    pending = out_dir.with_name(f".{out_dir.name}.pending-{os.getpid()}")
    pending.mkdir(parents=True)
    rows: list[dict[str, Any]] = []
    predictions: list[np.ndarray] = []
    exact_fields: list[np.ndarray] = []
    started = time.perf_counter()
    try:
        with torch.inference_mode():
            for index, sample in enumerate(samples):
                batch = MeshBatch.from_samples([sample]).to(device)
                t0 = time.perf_counter()
                raw = model.predict_raw(batch)
                if device.type == "cuda":
                    torch.cuda.synchronize(device)
                elapsed = time.perf_counter() - t0
                prediction = raw.detach().cpu().numpy()
                exact = sample.d_target.detach().cpu().numpy()
                row = {
                    "transition_index": index,
                    "transition_id": sample.transition_id,
                    "inference_seconds": elapsed,
                    **_metrics(exact, prediction),
                }
                rows.append(row)
                predictions.append(prediction)
                exact_fields.append(exact)
        prediction_array = np.stack(predictions)
        exact_array = np.stack(exact_fields)
        np.savez_compressed(
            pending / "predictions.npz",
            raw_prediction=prediction_array,
            physical_prediction=np.clip(prediction_array, 0.0, 1.0),
            exact_damage=exact_array,
        )
        with (pending / "per_transition_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        topology = samples[-1].topology
        elements = topology.cell_nodes.reshape(-1, int(topology.cell_sizes[0])).numpy()
        _render_final(
            pending / "final_damage_comparison.png",
            topology.nodes.numpy(), elements, exact_array[-1], prediction_array[-1],
            f"{case_id}: frozen checkpoint, no target fine-tuning",
        )
        summary = {
            "schema": SCHEMA,
            "case_id": case_id,
            "role": specification["role"],
            "evaluation_mode": "teacher_forced_exact_history",
            "claim_boundary": contract["claim_boundary"],
            "trajectory": {"path": str(trajectory_path), "sha256": specification["sha256"]},
            "checkpoint": checkpoint,
            "transition_count": len(rows),
            "metrics": {
                "mean_rmse": float(np.mean([row["rmse"] for row in rows])),
                "mean_mae": float(np.mean([row["mae"] for row in rows])),
                "final_rmse": rows[-1]["rmse"],
                "final_iou_d050": rows[-1]["crack_iou_d050"],
            },
            "wall_seconds": time.perf_counter() - started,
        }
        (pending / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
        manifest = {
            p.name: sha256_file(p) for p in sorted(pending.iterdir()) if p.is_file()
        }
        (pending / "artifact_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        pending.replace(out_dir)
        return summary
    except Exception:
        import shutil
        shutil.rmtree(pending, ignore_errors=True)
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--checkpoint-sha256")
    parser.add_argument("--case-id")
    parser.add_argument("--out-dir", type=Path)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    if args.preflight_only:
        print(json.dumps(preflight_cases(args.contract), indent=2))
        return
    if args.checkpoint is None or args.case_id is None or args.out_dir is None:
        parser.error("--checkpoint, --case-id, and --out-dir are required for evaluation")
    result = run(
        contract_path=args.contract,
        checkpoint_path=args.checkpoint,
        checkpoint_sha256=args.checkpoint_sha256,
        case_id=args.case_id,
        out_dir=args.out_dir,
        device_name=args.device,
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
