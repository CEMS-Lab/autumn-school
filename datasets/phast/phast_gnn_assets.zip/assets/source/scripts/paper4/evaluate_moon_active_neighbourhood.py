#!/usr/bin/env python3
"""Offline full-graph versus active-neighbourhood Moon evaluation.

This is a teacher-forced transition diagnostic, not a live rollout.  The mask
is nevertheless causal: it sees the current history produced by mechanics and
the previous accepted damage, exactly the information available immediately
before an online phase-field update.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch

from scripts.paper4.moon_active_neighbourhood import (
    ActiveMaskConfig,
    assembled_history_feature,
    causal_active_core,
    infer_full_and_active,
    install_active_prediction,
    topology_boundary_indicator,
    triangle_areas,
)
from scripts.paper4.moon_gnn_fem_reproduction import (
    MoonGNNFEM,
    edge_length_feature,
)


def render_active_neighbourhood_diagnostic(
    fields_path: Path,
    output_path: Path,
    *,
    previous_label: str = "Previous accepted damage",
    target_label: str = "Exact target damage",
) -> Path:
    """Render the publication diagnostic from one saved evaluator NPZ.

    Damage uses Torch-PF's ``inferno`` default and absolute error uses
    ``magma``. Predictions are clipped to the physical display interval only
    for plotting; the NPZ and numerical metrics retain the unchanged raw
    linear-decoder values.
    """

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.tri as mtri
    from matplotlib.lines import Line2D

    with np.load(fields_path) as fields:
        required = {
            "nodes", "elements", "previous_damage", "exact_damage",
            "core_mask", "context_mask", "full_candidate", "active_candidate",
        }
        missing = required.difference(fields.files)
        if missing:
            raise KeyError(f"active-neighbourhood NPZ is missing {sorted(missing)}")
        nodes = np.asarray(fields["nodes"], dtype=np.float64)
        elements = np.asarray(fields["elements"], dtype=np.int64)
        previous = np.asarray(fields["previous_damage"], dtype=np.float64)
        exact = np.asarray(fields["exact_damage"], dtype=np.float64)
        core = np.asarray(fields["core_mask"], dtype=bool)
        context = np.asarray(fields["context_mask"], dtype=bool)
        full = np.asarray(fields["full_candidate"], dtype=np.float64)
        active = np.asarray(fields["active_candidate"], dtype=np.float64)

    n_nodes = len(nodes)
    for name, values in {
        "previous_damage": previous,
        "exact_damage": exact,
        "core_mask": core,
        "context_mask": context,
        "full_candidate": full,
        "active_candidate": active,
    }.items():
        if values.shape != (n_nodes,):
            raise ValueError(f"{name} must contain one value per node")
    if elements.ndim != 2 or elements.shape[1] != 3:
        raise ValueError("diagnostic renderer currently requires T3 elements")

    full_display = np.clip(full, 0.0, 1.0)
    active_display = np.clip(active, 0.0, 1.0)
    error = np.abs(active_display - exact)
    positive_error = error[error > 0.0]
    error_vmax = (
        max(1.0e-3, float(np.quantile(positive_error, 0.995)))
        if positive_error.size else 1.0e-3
    )
    triangulation = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)
    figure, axes = plt.subplots(2, 3, figsize=(16.0, 6.9), facecolor="white")
    figure.subplots_adjust(
        left=0.025, right=0.915, bottom=0.10, top=0.86,
        wspace=0.12, hspace=0.39,
    )
    axes_flat = axes.ravel()

    damage_panels = (
        (0, previous, previous_label),
        (2, exact, target_label),
        (3, full_display, "Frozen Moon — full mesh\n(display clipped to [0, 1])"),
        (4, active_display, "Frozen Moon — active neighbourhood\n(display clipped to [0, 1])"),
    )
    damage_artists = []
    for index, values, title in damage_panels:
        axis = axes_flat[index]
        artist = axis.tripcolor(
            triangulation, values, shading="gouraud", cmap="inferno",
            vmin=0.0, vmax=1.0, rasterized=True,
        )
        damage_artists.append(artist)
        axis.set_title(title, fontsize=11, fontweight="semibold")

    mask_axis = axes_flat[1]
    mask_axis.tripcolor(
        triangulation, previous, shading="gouraud", cmap="inferno",
        vmin=0.0, vmax=1.0, alpha=0.42, rasterized=True,
    )
    context_only = context & ~core
    if context_only.any():
        mask_axis.scatter(
            nodes[context_only, 0], nodes[context_only, 1],
            s=0.45, c=[plt.get_cmap("magma")(0.42)], alpha=0.68,
            linewidths=0.0, rasterized=True,
        )
    if core.any():
        mask_axis.scatter(
            nodes[core, 0], nodes[core, 1],
            s=0.55, c=[plt.get_cmap("inferno")(0.88)], alpha=0.92,
            linewidths=0.0, rasterized=True,
        )
    mask_axis.set_title(
        "Causal active core and 10-hop context\nselected before target damage is observed",
        fontsize=11, fontweight="semibold",
    )
    mask_axis.legend(
        handles=[
            Line2D([0], [0], marker="o", linestyle="", markersize=6,
                   color=plt.get_cmap("inferno")(0.88), label="causal core"),
            Line2D([0], [0], marker="o", linestyle="", markersize=6,
                   color=plt.get_cmap("magma")(0.42), label="10-hop context"),
        ],
        loc="lower right", fontsize=8, frameon=True, framealpha=0.92,
    )

    error_axis = axes_flat[5]
    error_artist = error_axis.tripcolor(
        triangulation, error, shading="gouraud", cmap="magma",
        vmin=0.0, vmax=error_vmax, rasterized=True,
    )
    error_axis.set_title(
        "Active prediction absolute error\n"
        f"magma scale capped at 99.5th percentile ({error_vmax:.3g})",
        fontsize=11, fontweight="semibold",
    )

    for axis in axes_flat:
        axis.set_aspect("equal")
        axis.set_axis_off()
    damage_cax = figure.add_axes([0.935, 0.545, 0.012, 0.30])
    damage_colorbar = figure.colorbar(damage_artists[0], cax=damage_cax)
    damage_colorbar.set_label("damage d", fontsize=10)
    error_cax = figure.add_axes([0.935, 0.145, 0.012, 0.30])
    error_colorbar = figure.colorbar(error_artist, cax=error_cax)
    error_colorbar.set_label(r"$|d_{active}-d_{exact}|$", fontsize=10)
    figure.suptitle(
        "Frozen Moon model: active fracture-neighbourhood diagnostic",
        fontsize=16, fontweight="bold", y=0.97,
    )
    figure.text(
        0.5, 0.006,
        "Offline teacher-forced transition • frozen checkpoint • no fine-tuning • "
        "not a closed-loop or acceleration result",
        ha="center", va="bottom", fontsize=9.5, color="#4a4a4a",
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(output_path, dpi=220, bbox_inches="tight", facecolor="white")
    plt.close(figure)
    return output_path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_model(path: Path, device: torch.device) -> tuple[MoonGNNFEM, dict[str, Any]]:
    payload = torch.load(path, map_location="cpu", weights_only=False)
    configuration = dict(payload["configuration"])
    model = MoonGNNFEM(
        latent_dim=int(configuration["latent_dim"]),
        hidden_layers=int(configuration["hidden_layers"]),
        message_passing_steps=int(configuration["message_passing_steps"]),
    )
    model.load_state_dict(payload["model_state_dict"], strict=True)
    model.to(device).eval()
    return model, {
        "path": str(path.resolve()),
        "sha256": _sha256(path),
        "variant": str(configuration["variant"]),
        "epochs": int(payload["completed_epochs"]),
        "seed": int(configuration["seed"]),
        "training_Gc": float(configuration["Gc"]),
        "training_length_scale": float(configuration["length_scale"]),
        "message_passing_steps": int(configuration["message_passing_steps"]),
    }


def _sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elif device.type == "mps":
        torch.mps.synchronize()


def _damage_metrics(exact: np.ndarray, candidate: np.ndarray) -> dict[str, float]:
    physical = np.clip(candidate, 0.0, 1.0)
    error = physical - exact
    exact_set = exact >= 0.5
    candidate_set = physical >= 0.5
    union = int(np.count_nonzero(exact_set | candidate_set))
    return {
        "rmse_clipped_for_comparison": float(np.sqrt(np.mean(error * error))),
        "mae_clipped_for_comparison": float(np.mean(np.abs(error))),
        "iou_d_ge_0p5_clipped_for_comparison": float(
            1.0 if union == 0
            else np.count_nonzero(exact_set & candidate_set) / union
        ),
        "raw_min": float(np.min(candidate)),
        "raw_max": float(np.max(candidate)),
        "raw_out_of_bounds_fraction": float(
            np.mean((candidate < 0.0) | (candidate > 1.0))
        ),
    }


def _increment_recall(
    exact: torch.Tensor, previous: torch.Tensor, mask: torch.Tensor
) -> float:
    increment = torch.clamp(exact - previous, min=0.0)
    total = float(increment.sum())
    if total <= torch.finfo(increment.dtype).tiny:
        return 1.0
    return float(increment[mask].sum() / total)


def _step_group(root: Any, step: int) -> Any:
    steps = root["simulation_data"]["steps"]
    direct = f"step_{step:04d}"
    if direct in steps:
        return steps[direct]
    matches = [key for key in steps.group_keys()
               if key.startswith("step_") and int(key.split("_")[-1]) == step]
    if not matches:
        raise KeyError(f"trajectory has no stored step {step}")
    return steps[sorted(matches)[-1]]


def run(args: argparse.Namespace) -> dict[str, Any]:
    import zarr

    if args.target_step <= args.previous_step:
        raise ValueError("target_step must be later than previous_step")
    device = torch.device(args.device)
    trajectory = zarr.open_group(str(args.trajectory), mode="r")
    simulation = trajectory["simulation_data"]
    mesh = simulation["mesh"]
    nodes = np.asarray(mesh["node_coordinates"], dtype=np.float64)
    elements = np.asarray(mesh["element_connectivity"], dtype=np.int64)
    edges_np = np.asarray(mesh["edge_index"], dtype=np.int64)
    previous_group = _step_group(trajectory, args.previous_step)
    target_group = _step_group(trajectory, args.target_step)
    history_elem = np.asarray(target_group["H_elem"], dtype=np.float32)
    damage_previous_np = np.asarray(
        previous_group["damage_nodal"], dtype=np.float32)
    exact_np = np.asarray(target_group["damage_nodal"], dtype=np.float32)
    if damage_previous_np.shape != (len(nodes),) or exact_np.shape != (len(nodes),):
        raise ValueError("stored damage does not match the stored mesh")

    model, checkpoint = _load_model(args.checkpoint, device)
    if checkpoint["message_passing_steps"] != 10:
        raise ValueError("the Moon-faithful route requires the frozen 10-block checkpoint")
    if args.halo_hops < checkpoint["message_passing_steps"]:
        raise ValueError("halo_hops cannot be smaller than the model receptive depth")

    areas = triangle_areas(nodes, elements)
    history_feature = assembled_history_feature(
        history_elem, elements, areas,
        n_nodes=len(nodes), Gc=args.Gc, length_scale=args.length_scale,
        device=device,
    )
    boundary = torch.as_tensor(
        topology_boundary_indicator(elements, len(nodes)),
        dtype=torch.float32, device=device,
    )
    node_features = torch.stack([history_feature, boundary], dim=1)
    edges = torch.as_tensor(edges_np, dtype=torch.long, device=device)
    edge_features = torch.as_tensor(
        edge_length_feature(nodes, edges_np, args.length_scale),
        dtype=torch.float32, device=device,
    )
    damage_previous = torch.as_tensor(
        damage_previous_np, dtype=torch.float32, device=device)
    exact = torch.as_tensor(exact_np, dtype=torch.float32, device=device)
    mask_config = ActiveMaskConfig(
        front_low=args.front_low,
        front_high=args.front_high,
        history_quantile=args.history_quantile,
        history_positive_eps=args.history_positive_eps,
        halo_hops=args.halo_hops,
    )
    core = causal_active_core(history_feature, damage_previous, mask_config)
    if not bool(core.any()):
        raise RuntimeError("causal active mask is empty for this transition")

    _sync(device)
    started = time.perf_counter()
    full_raw, local_raw, subgraph = infer_full_and_active(
        model, node_features, edges, edge_features, core,
        halo_hops=args.halo_hops,
    )
    _sync(device)
    combined_wall = time.perf_counter() - started

    core_nodes = subgraph.global_nodes[subgraph.core_local]
    core_difference = local_raw[subgraph.core_local] - full_raw[core_nodes]
    full_candidate = torch.maximum(full_raw, damage_previous)
    active_candidate = install_active_prediction(
        local_raw, damage_previous, subgraph)

    args.out_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        args.out_dir / "active_neighbourhood_fields.npz",
        nodes=nodes,
        elements=elements,
        previous_damage=damage_previous_np,
        exact_damage=exact_np,
        history_node_feature=history_feature.detach().cpu().numpy(),
        core_mask=core.detach().cpu().numpy(),
        context_mask=subgraph.context_global.detach().cpu().numpy(),
        full_candidate=full_candidate.detach().cpu().numpy(),
        active_candidate=active_candidate.detach().cpu().numpy(),
    )
    diagnostic_visual = render_active_neighbourhood_diagnostic(
        args.out_dir / "active_neighbourhood_fields.npz",
        args.out_dir / "active_neighbourhood_diagnostic.png",
        previous_label=f"Previous accepted damage\nstep {args.previous_step}",
        target_label=f"Exact target damage\nstep {args.target_step}",
    )
    summary = {
        "schema": "paper4_moon_active_neighbourhood_offline_v1",
        "evidence_class": "offline_teacher_forced_full_vs_masked_equivalence",
        "claim_boundary": (
            "The current exact history and previous stored damage select a causal mask. "
            "This is not a closed-loop rollout or an acceleration measurement."
        ),
        "trajectory": str(args.trajectory),
        "checkpoint": checkpoint,
        "transition": {
            "previous_step": args.previous_step,
            "target_step": args.target_step,
            "stored_step_gap": args.target_step - args.previous_step,
            "previous_time_s": (
                None if previous_group.attrs.get("time_s") is None
                else float(previous_group.attrs["time_s"])
            ),
            "target_time_s": (
                None if target_group.attrs.get("time_s") is None
                else float(target_group.attrs["time_s"])
            ),
        },
        "target_normalization": {"Gc": args.Gc, "length_scale": args.length_scale},
        "fixed_contract": {
            "history_feature": "sum_e area_e*H_e/(3*Gc*length_scale)",
            "boundary_feature": "full_mesh_one_sided_topology_edges_only",
            "edge_feature": "edge_length/length_scale",
            "model_message_passing_steps": 10,
            "loss_changed": False,
            "inputs_changed": False,
            "fine_tuned": False,
            "runtime_projection": "max(raw_prediction,damage_previous); no upper clip",
            "phase_field_dirichlet": (
                "not applied in this offline utility; live caller must repin existing values"
            ),
        },
        "mask": {
            "front_low": args.front_low,
            "front_high": args.front_high,
            "history_quantile_over_positive_nodes": args.history_quantile,
            "history_positive_eps": args.history_positive_eps,
            "halo_hops": args.halo_hops,
            "core_nodes": int(core.sum()),
            "context_nodes": int(subgraph.context_global.sum()),
            "total_nodes": len(nodes),
            "core_node_fraction": float(core.float().mean()),
            "context_node_fraction": float(subgraph.context_global.float().mean()),
            "context_edges": int(subgraph.edge_ids.numel()),
            "total_edges": int(edges.shape[1]),
            "context_edge_fraction": float(subgraph.edge_ids.numel() / edges.shape[1]),
            "exact_increment_mass_recall_core": _increment_recall(
                exact, damage_previous, core),
            "exact_increment_mass_recall_context": _increment_recall(
                exact, damage_previous, subgraph.context_global),
        },
        "full_vs_masked_core_equivalence": {
            "l2": float(torch.linalg.vector_norm(core_difference)),
            "linf": float(core_difference.abs().max()),
            "rmse": float(torch.sqrt(torch.mean(core_difference.square()))),
            "finite": bool(torch.isfinite(core_difference).all()),
        },
        "full_candidate_metrics": _damage_metrics(
            exact_np, full_candidate.detach().cpu().numpy()),
        "active_candidate_metrics": _damage_metrics(
            exact_np, active_candidate.detach().cpu().numpy()),
        "diagnostic_timing": {
            "combined_full_plus_masked_inference_wall_s": combined_wall,
            "timing_claim_allowed": False,
        },
        "outputs": {
            "fields": "active_neighbourhood_fields.npz",
            "diagnostic_visual": diagnostic_visual.name,
        },
    }
    if not math.isfinite(summary["full_vs_masked_core_equivalence"]["linf"]):
        raise RuntimeError("full-vs-masked equivalence is non-finite")
    (args.out_dir / "summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trajectory", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--previous-step", type=int, required=True)
    parser.add_argument("--target-step", type=int, required=True)
    parser.add_argument("--Gc", type=float, required=True)
    parser.add_argument("--length-scale", type=float, required=True)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--front-low", type=float, default=0.02)
    parser.add_argument("--front-high", type=float, default=0.98)
    parser.add_argument("--history-quantile", type=float, default=0.995)
    parser.add_argument("--history-positive-eps", type=float, default=0.0)
    parser.add_argument("--halo-hops", type=int, default=10)
    return parser.parse_args()


if __name__ == "__main__":
    print(json.dumps(run(parse_args()), indent=2))
