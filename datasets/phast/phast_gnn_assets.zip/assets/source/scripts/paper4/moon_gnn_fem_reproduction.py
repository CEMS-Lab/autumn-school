#!/usr/bin/env python3
"""Reproduction scaffold for Moon, Choi & Ryu (arXiv:2606.19378).

This module implements the parts of the paper that are fully specified:

* mesh-to-graph conversion with scalar node and edge features;
* the symmetric encoder/processor/decoder GNN;
* Appendix-A spatially correlated random history fields; and
* a differentiable T3 weak residual for the paper's AT2 energy with
  ``g(d)=(1-d)^2 / ((1-d)^2+d)``.

The CLI deliberately runs a small contract smoke, not a claimed paper
replication.  It uses synthetic crack-like history fields because the paper's
500-step FEM trajectory and source code have not been released.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.tri as mtri  # noqa: E402
import numpy as np  # noqa: E402
import torch  # noqa: E402
from torch import nn  # noqa: E402


REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = (
    REPO_ROOT
    / "papers/paper4/workstreams/19_moon_gnn_fem_reproduction/runs/local/contract_smoke"
)
PAPER_ID = "arXiv:2606.19378v1"


def _mlp(in_dim: int, out_dim: int, hidden: int, hidden_layers: int) -> nn.Sequential:
    layers: list[nn.Module] = []
    width = in_dim
    for _ in range(hidden_layers):
        layers.extend([nn.Linear(width, hidden), nn.ReLU()])
        width = hidden
    layers.append(nn.Linear(width, out_dim))
    return nn.Sequential(*layers)


class SymmetricProcessorBlock(nn.Module):
    """One paper-style symmetric message-passing iteration."""

    def __init__(self, latent_dim: int, hidden_layers: int) -> None:
        super().__init__()
        triple = 3 * latent_dim
        self.edge_update = _mlp(triple, latent_dim, latent_dim, hidden_layers)
        self.message_norm = nn.LayerNorm(triple)
        self.message = _mlp(triple, latent_dim, latent_dim, hidden_layers)
        self.node_norm = nn.LayerNorm(2 * latent_dim)
        self.node_update = _mlp(
            2 * latent_dim, latent_dim, latent_dim, hidden_layers
        )

    def forward(
        self,
        node_latent: torch.Tensor,
        edge_latent: torch.Tensor,
        edge_index: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        src, dst = edge_index
        symmetric = torch.cat(
            [
                node_latent[src] + node_latent[dst],
                torch.abs(node_latent[src] - node_latent[dst]),
                edge_latent,
            ],
            dim=-1,
        )
        edge_latent = edge_latent + self.edge_update(symmetric)
        symmetric = torch.cat(
            [
                node_latent[src] + node_latent[dst],
                torch.abs(node_latent[src] - node_latent[dst]),
                edge_latent,
            ],
            dim=-1,
        )
        messages = self.message(self.message_norm(symmetric))
        aggregate = torch.zeros_like(node_latent)
        aggregate.index_add_(0, dst, messages)
        degree = torch.zeros(
            (node_latent.shape[0], 1),
            dtype=node_latent.dtype,
            device=node_latent.device,
        )
        degree.index_add_(
            0,
            dst,
            torch.ones((dst.numel(), 1), dtype=node_latent.dtype, device=dst.device),
        )
        aggregate = aggregate / degree.clamp_min(1.0)
        node_input = self.node_norm(torch.cat([node_latent, aggregate], dim=-1))
        node_latent = node_latent + self.node_update(node_input)
        return node_latent, edge_latent


class MoonGNNFEM(nn.Module):
    """Encoder-processor-decoder surrogate matching Table 3 and Eqs. 23-28."""

    def __init__(
        self,
        *,
        latent_dim: int = 32,
        hidden_layers: int = 3,
        message_passing_steps: int = 10,
    ) -> None:
        super().__init__()
        self.node_encoder = nn.Sequential(
            _mlp(2, latent_dim, latent_dim, hidden_layers),
            nn.LayerNorm(latent_dim),
        )
        self.edge_encoder = nn.Sequential(
            _mlp(1, latent_dim, latent_dim, hidden_layers),
            nn.LayerNorm(latent_dim),
        )
        self.processor = nn.ModuleList(
            SymmetricProcessorBlock(latent_dim, hidden_layers)
            for _ in range(message_passing_steps)
        )
        self.decoder = _mlp(latent_dim, 1, latent_dim, hidden_layers)

    def forward(
        self,
        node_features: torch.Tensor,
        edge_index: torch.Tensor,
        edge_features: torch.Tensor,
    ) -> torch.Tensor:
        transformed = node_features.clone()
        transformed[:, 0] = torch.log10(1.0 + transformed[:, 0].clamp_min(0.0))
        node_latent = self.node_encoder(transformed)
        edge_latent = self.edge_encoder(edge_features)
        for block in self.processor:
            node_latent, edge_latent = block(node_latent, edge_latent, edge_index)
        # The paper specifies a decoder MLP but does not document a sigmoid or
        # any other output activation. Keep the literal linear decoder here;
        # box/irreversibility handling belongs to the runtime coupling.
        return self.decoder(node_latent).squeeze(-1)


def structured_tri_mesh(n: int, side: float = 10.0) -> tuple[np.ndarray, np.ndarray]:
    if n < 2:
        raise ValueError("n must be at least 2")
    axis = np.linspace(0.0, side, n, dtype=np.float64)
    xx, yy = np.meshgrid(axis, axis, indexing="xy")
    nodes = np.column_stack([xx.ravel(), yy.ravel()])
    tris: list[tuple[int, int, int]] = []
    for j in range(n - 1):
        for i in range(n - 1):
            a = j * n + i
            b = a + 1
            c = a + n
            d = c + 1
            tris.extend([(a, b, d), (a, d, c)])
    return nodes, np.asarray(tris, dtype=np.int64)


def node_edge_index(elements: np.ndarray) -> np.ndarray:
    edges: set[tuple[int, int]] = set()
    for elem in np.asarray(elements, dtype=np.int64):
        for i in range(len(elem)):
            for j in range(i + 1, len(elem)):
                a, b = int(elem[i]), int(elem[j])
                edges.add((a, b))
                edges.add((b, a))
    return np.asarray(sorted(edges), dtype=np.int64).T


def boundary_indicator(nodes: np.ndarray, *, atol: float = 1.0e-10) -> np.ndarray:
    x, y = nodes[:, 0], nodes[:, 1]
    return (
        np.isclose(x, x.min(), atol=atol)
        | np.isclose(x, x.max(), atol=atol)
        | np.isclose(y, y.min(), atol=atol)
        | np.isclose(y, y.max(), atol=atol)
    ).astype(np.float32)


def edge_length_feature(
    nodes: np.ndarray, edge_index: np.ndarray, length_scale: float
) -> np.ndarray:
    if length_scale <= 0.0:
        raise ValueError("length_scale must be positive")
    delta = nodes[edge_index[0]] - nodes[edge_index[1]]
    return (np.linalg.norm(delta, axis=1) / length_scale)[:, None].astype(np.float32)


def triangle_geometry(
    nodes: torch.Tensor, elements: torch.Tensor
) -> tuple[torch.Tensor, torch.Tensor]:
    xy = nodes[elements]
    x0, x1, x2 = xy[:, 0], xy[:, 1], xy[:, 2]
    twice_area = (
        (x1[:, 0] - x0[:, 0]) * (x2[:, 1] - x0[:, 1])
        - (x2[:, 0] - x0[:, 0]) * (x1[:, 1] - x0[:, 1])
    )
    area = 0.5 * torch.abs(twice_area)
    grad = torch.stack(
        [
            torch.stack([x1[:, 1] - x2[:, 1], x2[:, 0] - x1[:, 0]], dim=1),
            torch.stack([x2[:, 1] - x0[:, 1], x0[:, 0] - x2[:, 0]], dim=1),
            torch.stack([x0[:, 1] - x1[:, 1], x1[:, 0] - x0[:, 0]], dim=1),
        ],
        dim=1,
    ) / twice_area[:, None, None]
    return area, grad


def project_element_to_nodes(
    values: np.ndarray,
    elements: np.ndarray,
    areas: np.ndarray,
    n_nodes: int,
) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    accum = np.zeros(n_nodes, dtype=np.float64)
    mass = np.zeros(n_nodes, dtype=np.float64)
    local_weight = np.asarray(areas, dtype=np.float64) / elements.shape[1]
    np.add.at(accum, elements.reshape(-1), np.repeat(values * local_weight, elements.shape[1]))
    np.add.at(mass, elements.reshape(-1), np.repeat(local_weight, elements.shape[1]))
    return accum / np.maximum(mass, 1.0e-30)


def assemble_element_to_nodes(
    values: np.ndarray,
    elements: np.ndarray,
    areas: np.ndarray,
    n_nodes: int,
) -> np.ndarray:
    """Assemble ``sum_e int N_i value_e dOmega`` without mass inversion.

    This is the literal node-feature expression printed in Moon et al.  The
    paper prose calls the operation a projection, so the mass-lumped average
    remains available through :func:`project_element_to_nodes` as an ablation.
    """
    values = np.asarray(values, dtype=np.float64)
    accum = np.zeros(n_nodes, dtype=np.float64)
    local_weight = np.asarray(areas, dtype=np.float64) / elements.shape[1]
    np.add.at(
        accum,
        elements.reshape(-1),
        np.repeat(values * local_weight, elements.shape[1]),
    )
    return accum


def correlated_random_field(
    element_coordinates: np.ndarray,
    *,
    seed: int,
    k: int = 15,
    sigmoid_sharpness: float = 50.0,
    high_fraction: float = 0.01,
    scale: float = 30.0,
) -> np.ndarray:
    """Generate Appendix-A ``H/(Gc*l_c)`` values on elements."""
    coordinates = np.asarray(element_coordinates, dtype=np.float64)
    n = coordinates.shape[0]
    if not (0.0 < high_fraction < 1.0):
        raise ValueError("high_fraction must lie in (0, 1)")
    if n < 2:
        raise ValueError("at least two element coordinates are required")
    neighbours = min(max(int(k), 1), n - 1)
    rng = np.random.default_rng(seed)
    z = rng.standard_normal(n)
    delta = coordinates[:, None, :] - coordinates[None, :, :]
    distance = np.linalg.norm(delta, axis=2)
    np.fill_diagonal(distance, np.inf)
    ids = np.argpartition(distance, neighbours - 1, axis=1)[:, :neighbours]
    local_distance = np.take_along_axis(distance, ids, axis=1)
    corr_length = float(np.median(local_distance[:, -1]))
    corr_length = max(corr_length, 1.0e-12)
    weights = np.exp(-((local_distance / corr_length) ** 2))
    weights /= np.maximum(weights.sum(axis=1, keepdims=True), 1.0e-30)
    smooth = np.sum(weights * z[ids], axis=1)
    threshold = float(np.quantile(smooth, 1.0 - high_fraction))
    logits = np.clip(sigmoid_sharpness * (smooth - threshold), -60.0, 60.0)
    return scale / (1.0 + np.exp(-logits))


def rational_degradation(damage: torch.Tensor) -> torch.Tensor:
    intact = 1.0 - damage
    numerator = intact * intact
    return numerator / (numerator + damage).clamp_min(1.0e-12)


def rational_at2_energy(
    damage: torch.Tensor,
    history_elem: torch.Tensor,
    elements: torch.Tensor,
    areas: torch.Tensor,
    grad_phi: torch.Tensor,
    *,
    Gc: float,
    length_scale: float,
) -> torch.Tensor:
    d_elem = damage[elements]
    shape = torch.as_tensor(
        [[2.0 / 3.0, 1.0 / 6.0, 1.0 / 6.0],
         [1.0 / 6.0, 2.0 / 3.0, 1.0 / 6.0],
         [1.0 / 6.0, 1.0 / 6.0, 2.0 / 3.0]],
        dtype=damage.dtype,
        device=damage.device,
    )
    d_quad = torch.einsum("qa,ea->eq", shape, d_elem)
    grad_d = torch.einsum("eai,ea->ei", grad_phi, d_elem)
    local = (
        history_elem.unsqueeze(1) * rational_degradation(d_quad)
        + 0.5 * Gc / length_scale * d_quad.square()
    )
    reaction_energy = torch.sum((areas / 3.0).unsqueeze(1) * local)
    gradient_energy = torch.sum(
        0.5 * Gc * length_scale * areas * grad_d.square().sum(dim=1))
    return reaction_energy + gradient_energy


def rational_at2_residual(
    damage: torch.Tensor,
    history_elem: torch.Tensor,
    elements: torch.Tensor,
    areas: torch.Tensor,
    grad_phi: torch.Tensor,
    *,
    Gc: float,
    length_scale: float,
    create_graph: bool,
) -> torch.Tensor:
    if not damage.requires_grad:
        damage = damage.requires_grad_(True)
    energy = rational_at2_energy(
        damage,
        history_elem,
        elements,
        areas,
        grad_phi,
        Gc=Gc,
        length_scale=length_scale,
    )
    return torch.autograd.grad(energy, damage, create_graph=create_graph)[0]


def _crack_like_history(
    centroids: np.ndarray,
    fraction: float,
    *,
    angle_deg: float = 0.0,
    peak: float = 30.0,
    width: float = 0.35,
) -> np.ndarray:
    theta = math.radians(angle_deg)
    direction = np.asarray([math.cos(theta), math.sin(theta)])
    normal = np.asarray([-direction[1], direction[0]])
    start = np.asarray([2.0, 5.0])
    length = 1.0 + 6.5 * float(fraction)
    relative = centroids - start
    along = relative @ direction
    across = relative @ normal
    active = (along >= -0.25) & (along <= length)
    tip = np.maximum(along - length, 0.0)
    distance = np.sqrt(across * across + tip * tip)
    return peak * np.exp(-((distance / width) ** 2)) * active


def _solve_teacher(
    history_elem: torch.Tensor,
    previous: torch.Tensor,
    elements: torch.Tensor,
    areas: torch.Tensor,
    grad_phi: torch.Tensor,
    *,
    Gc: float,
    length_scale: float,
    iterations: int,
) -> torch.Tensor:
    eps = 1.0e-5
    initial_fraction = ((previous + eps) / (1.0 - previous + eps)).clamp(1.0e-5, 1.0e5)
    raw = torch.log(initial_fraction).detach().clone().requires_grad_(True)
    optimizer = torch.optim.Adam([raw], lr=5.0e-2)
    for _ in range(iterations):
        optimizer.zero_grad(set_to_none=True)
        damage = previous + (1.0 - previous) * torch.sigmoid(raw)
        energy = rational_at2_energy(
            damage,
            history_elem,
            elements,
            areas,
            grad_phi,
            Gc=Gc,
            length_scale=length_scale,
        )
        energy.backward()
        optimizer.step()
    return (previous + (1.0 - previous) * torch.sigmoid(raw)).detach()


@dataclass(frozen=True)
class SmokeConfig:
    out_dir: Path = DEFAULT_OUT
    mesh_n: int = 7
    data_samples: int = 8
    physics_samples: int = 8
    teacher_iterations: int = 160
    epochs: int = 8
    learning_rate: float = 1.0e-3
    latent_dim: int = 32
    hidden_layers: int = 3
    message_passing_steps: int = 10
    Gc: float = 2.7
    length_scale: float = 0.4
    seed: int = 260619378
    history_feature_mode: str = "raw_integral"


def run_contract_smoke(config: SmokeConfig) -> dict[str, Any]:
    torch.manual_seed(config.seed)
    np.random.seed(config.seed % (2**32 - 1))
    config.out_dir.mkdir(parents=True, exist_ok=True)
    nodes_np, elements_np = structured_tri_mesh(config.mesh_n)
    edge_index_np = node_edge_index(elements_np)
    boundary_np = boundary_indicator(nodes_np)
    edge_features_np = edge_length_feature(nodes_np, edge_index_np, config.length_scale)
    nodes = torch.as_tensor(nodes_np, dtype=torch.float64)
    elements = torch.as_tensor(elements_np, dtype=torch.long)
    edge_index = torch.as_tensor(edge_index_np, dtype=torch.long)
    edge_features = torch.as_tensor(edge_features_np, dtype=torch.float32)
    areas, grad_phi = triangle_geometry(nodes, elements)
    centroids = nodes_np[elements_np].mean(axis=1)

    data_history: list[torch.Tensor] = []
    data_targets: list[torch.Tensor] = []
    previous = torch.zeros(nodes.shape[0], dtype=torch.float64)
    for idx in range(config.data_samples):
        fraction = idx / max(config.data_samples - 1, 1)
        h_norm = _crack_like_history(centroids, fraction)
        history = torch.as_tensor(
            h_norm * config.Gc * config.length_scale, dtype=torch.float64
        )
        target = _solve_teacher(
            history,
            previous,
            elements,
            areas,
            grad_phi,
            Gc=config.Gc,
            length_scale=config.length_scale,
            iterations=config.teacher_iterations,
        )
        data_history.append(history)
        data_targets.append(target)
        previous = target

    physics_history: list[torch.Tensor] = []
    for idx in range(config.physics_samples):
        h_norm = correlated_random_field(centroids, seed=config.seed + idx)
        physics_history.append(
            torch.as_tensor(h_norm * config.Gc * config.length_scale, dtype=torch.float64)
        )

    model = MoonGNNFEM(
        latent_dim=config.latent_dim,
        hidden_layers=config.hidden_layers,
        message_passing_steps=config.message_passing_steps,
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=config.learning_rate)

    def features(history: torch.Tensor) -> torch.Tensor:
        normalized = (
            history.detach().cpu().numpy() / (config.Gc * config.length_scale))
        if config.history_feature_mode == "raw_integral":
            nodal = assemble_element_to_nodes(
                normalized, elements_np, areas.detach().cpu().numpy(),
                nodes_np.shape[0])
        elif config.history_feature_mode == "lumped_average":
            nodal = project_element_to_nodes(
                normalized, elements_np, areas.detach().cpu().numpy(),
                nodes_np.shape[0])
        else:
            raise ValueError(
                "history_feature_mode must be 'raw_integral' or "
                f"'lumped_average', got {config.history_feature_mode!r}")
        return torch.as_tensor(
            np.column_stack([nodal, boundary_np]), dtype=torch.float32
        )

    start = time.perf_counter()
    loss_rows: list[dict[str, float | int]] = []
    for epoch in range(1, config.epochs + 1):
        optimizer.zero_grad(set_to_none=True)
        data_loss = torch.zeros((), dtype=torch.float32)
        for history, target in zip(data_history, data_targets, strict=True):
            pred = model(features(history), edge_index, edge_features)
            data_loss = data_loss + torch.mean((pred - target.float()) ** 2)
        data_loss = data_loss / len(data_history)

        physics_loss = torch.zeros((), dtype=torch.float32)
        for history in physics_history:
            pred = model(features(history), edge_index, edge_features)
            residual = rational_at2_residual(
                pred.double(),
                history,
                elements,
                areas,
                grad_phi,
                Gc=config.Gc,
                length_scale=config.length_scale,
                create_graph=True,
            )
            physics_loss = physics_loss + torch.mean(residual.square()).float()
        physics_loss = physics_loss / len(physics_history)
        loss = data_loss + physics_loss
        loss.backward()
        optimizer.step()
        loss_rows.append(
            {
                "epoch": epoch,
                "loss": float(loss.detach()),
                "data_loss": float(data_loss.detach()),
                "physics_loss": float(physics_loss.detach()),
            }
        )
    wall = time.perf_counter() - start

    with torch.no_grad():
        predictions = [
            model(features(history), edge_index, edge_features).double()
            for history in data_history
        ]
    rmse = [
        float(torch.sqrt(torch.mean((pred - target) ** 2)))
        for pred, target in zip(predictions, data_targets, strict=True)
    ]
    irreversibility_violations = 0
    for idx in range(1, len(predictions)):
        irreversibility_violations += int(
            torch.count_nonzero(predictions[idx] + 1.0e-7 < predictions[idx - 1]).item()
        )

    tri = mtri.Triangulation(nodes_np[:, 0], nodes_np[:, 1], elements_np)
    target = data_targets[-1].numpy()
    pred = predictions[-1].numpy()
    fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.6), constrained_layout=True)
    for ax, title, field, cmap, vmax in [
        (axes[0], "synthetic teacher", target, "magma", 1.0),
        (axes[1], "GNN prediction", pred, "magma", 1.0),
        (axes[2], "absolute error", np.abs(pred - target), "viridis", None),
    ]:
        image = ax.tripcolor(tri, field, shading="gouraud", cmap=cmap, vmin=0.0, vmax=vmax)
        ax.set_title(title)
        ax.set_aspect("equal")
        ax.set_xticks([])
        ax.set_yticks([])
        fig.colorbar(image, ax=ax, fraction=0.046, pad=0.02)
    figure_path = config.out_dir / "contract_smoke_final_field.png"
    fig.suptitle("Moon GNN-FEM reproduction contract smoke (not paper data)")
    fig.savefig(figure_path, dpi=180)
    plt.close(fig)

    checkpoint_path = config.out_dir / "moon_gnn_fem_contract_smoke.pt"
    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "config": {**asdict(config), "out_dir": str(config.out_dir)},
            "paper_id": PAPER_ID,
        },
        checkpoint_path,
    )
    np.savez_compressed(
        config.out_dir / "contract_smoke_data.npz",
        nodes=nodes_np,
        elements=elements_np,
        edge_index=edge_index_np,
        history_elem=np.stack([h.numpy() for h in data_history]),
        target_damage=np.stack([d.numpy() for d in data_targets]),
        predicted_damage=np.stack([d.numpy() for d in predictions]),
    )
    summary: dict[str, Any] = {
        "paper_id": PAPER_ID,
        "evidence_class": "method_contract_smoke",
        "claim_allowed": False,
        "claim_boundary": (
            "Architecture/random-field/residual smoke on synthetic crack-like history; "
            "not the authors' FEM data, coupled rollout, generalization result, or timing result."
        ),
        "configuration": {**asdict(config), "out_dir": str(config.out_dir)},
        "mesh": {
            "nodes": int(nodes_np.shape[0]),
            "elements": int(elements_np.shape[0]),
            "directed_edges": int(edge_index_np.shape[1]),
        },
        "training_wall_s": wall,
        "initial_loss": loss_rows[0],
        "final_loss": loss_rows[-1],
        "mean_data_rmse": float(np.mean(rmse)),
        "final_data_rmse": float(rmse[-1]),
        "irreversibility_violations_before_postprocess": irreversibility_violations,
        "prediction_range": {
            "minimum": float(min(pred.min().item() for pred in predictions)),
            "maximum": float(max(pred.max().item() for pred in predictions)),
        },
        "paper_hyperparameters_implemented": {
            "latent_dim": config.latent_dim,
            "hidden_layers_per_mlp": config.hidden_layers,
            "message_passing_steps": config.message_passing_steps,
            "activation": "ReLU",
            "node_features": [
                "log10(1 + assembled integral of H/(Gc*l_c))",
                "boundary indicator",
            ],
            "edge_features": ["edge length/l_c"],
            "loss": "data MSE + raw weak residual MSE",
            "decoder_output_activation": "none (paper does not specify one)",
        },
        "paths": {
            "figure": str(figure_path),
            "checkpoint": str(checkpoint_path),
            "data": str(config.out_dir / "contract_smoke_data.npz"),
        },
    }
    (config.out_dir / "loss_history.json").write_text(
        json.dumps(loss_rows, indent=2) + "\n", encoding="utf-8"
    )
    (config.out_dir / "summary.json").write_text(
        json.dumps(summary, indent=2, default=str) + "\n", encoding="utf-8"
    )
    return summary


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--mesh-n", type=int, default=7)
    parser.add_argument("--data-samples", type=int, default=8)
    parser.add_argument("--physics-samples", type=int, default=8)
    parser.add_argument("--teacher-iterations", type=int, default=160)
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--seed", type=int, default=260619378)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    summary = run_contract_smoke(
        SmokeConfig(
            out_dir=args.out_dir,
            mesh_n=args.mesh_n,
            data_samples=args.data_samples,
            physics_samples=args.physics_samples,
            teacher_iterations=args.teacher_iterations,
            epochs=args.epochs,
            seed=args.seed,
        )
    )
    print(json.dumps(summary, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
