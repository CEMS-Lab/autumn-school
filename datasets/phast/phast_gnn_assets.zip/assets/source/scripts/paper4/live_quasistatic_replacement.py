#!/usr/bin/env python3
"""Frozen direct-damage replacements for live implicit-quasistatic solves.

The adapters in this module are deliberately small.  They receive the
history field assembled by the *current* mechanics state and the previous
accepted damage field.  Their returned field is installed as the damage
solution without calling Torch-PF's nonlinear damage solver.

Two routes are supported:

``fem_incidence``
    The frozen Workstream-27 node/element-incidence operator.  Its hard
    projection installs an absolute prediction in ``[d_previous, 1]``.

``literal_moon``
    The frozen ten-block Moon GNN evaluated on the complete FEM node graph.
    This is the matched full-mesh route for the literal Moon checkpoint.

``active_neighbourhood``
    The frozen ten-block Moon GNN evaluated only on a causal active core plus
    its exact ten-hop dependency halo.  Only core predictions are installed;
    all other nodes retain their previous accepted damage.

This is a live-deployment mechanism, not an accuracy certificate.  Callers
must compare the resulting closed-loop trajectory with an independent exact
Torch-PF trajectory.
"""

from __future__ import annotations

from dataclasses import replace
import hashlib
from pathlib import Path
import time
import types
from typing import Any, Mapping

import numpy as np
import torch

from scripts.paper4.evaluate_fem_incidence_frozen_transfer import (
    load_frozen_checkpoint,
)
from scripts.paper4.evaluate_moon_active_neighbourhood import _load_model
from scripts.paper4.moon_active_neighbourhood import (
    ActiveMaskConfig,
    causal_active_core,
    induced_active_subgraph,
    install_active_prediction,
)
from scripts.paper4.moon_gnn_fem_reproduction import (
    edge_length_feature,
    node_edge_index,
)
from scripts.paper4.unstructured_operator_tournament.mesh_data import (
    MeshBatch,
    TransitionSample,
    build_mesh_topology,
)


LIVE_REPLACEMENT_ROUTES = (
    "fem_incidence",
    "literal_moon",
    "active_neighbourhood",
    "raster_unet",
    "raster_fno",
    "raster_deeponet",
    "active_patch_unet",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_device(requested: str) -> torch.device:
    if requested != "auto":
        return torch.device(requested)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def synchronise(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elif device.type == "mps":
        torch.mps.synchronize()


def moon_boundary_context(
    nodes: np.ndarray,
    elements: np.ndarray,
) -> np.ndarray:
    """Rebuild the five-channel boundary contract used by Workstream 27."""

    from scripts.paper4.moon_active_neighbourhood import (
        topology_boundary_indicator,
    )

    nodes = np.asarray(nodes, dtype=np.float64)
    topological = topology_boundary_indicator(elements, len(nodes)) > 0.5
    extent = np.ptp(nodes, axis=0)
    tolerance = 1.0e-6 * max(float(extent.max()), 1.0)
    outer = (
        np.isclose(nodes[:, 0], nodes[:, 0].min(), atol=tolerance)
        | np.isclose(nodes[:, 0], nodes[:, 0].max(), atol=tolerance)
        | np.isclose(nodes[:, 1], nodes[:, 1].min(), atol=tolerance)
        | np.isclose(nodes[:, 1], nodes[:, 1].max(), atol=tolerance)
    )
    bottom = np.isclose(nodes[:, 1], nodes[:, 1].min(), atol=tolerance)
    top = np.isclose(nodes[:, 1], nodes[:, 1].max(), atol=tolerance)
    return np.stack(
        [topological, outer, topological & ~outer, bottom, top], axis=1
    ).astype(np.float32)


def _normalise_element_field(
    value: float | np.ndarray,
    count: int,
    *,
    name: str,
) -> np.ndarray:
    field = np.asarray(value, dtype=np.float64).reshape(-1)
    if field.size == 1:
        field = np.full(count, float(field[0]), dtype=np.float64)
    if field.shape != (count,) or not np.all(np.isfinite(field) & (field > 0.0)):
        raise ValueError(f"{name} must be positive scalar or shape ({count},)")
    return field


class FEMIncidenceLiveAdapter:
    """Frozen FEM-incidence absolute-damage inference on a fixed mesh."""

    route = "fem_incidence"

    def __init__(
        self,
        *,
        checkpoint_path: Path,
        checkpoint_sha256: str,
        device: str,
        nodes: np.ndarray,
        elements: np.ndarray,
        boundary_context: np.ndarray,
        load_direction: np.ndarray,
        Gc_elem: float | np.ndarray,
        length_scale: float | np.ndarray,
    ) -> None:
        self.device = resolve_device(device)
        actual = sha256_file(checkpoint_path)
        if actual != checkpoint_sha256:
            raise ValueError("FEM-incidence checkpoint SHA-256 mismatch")
        self.model, self.metadata = load_frozen_checkpoint(
            checkpoint_path,
            expected_sha256=checkpoint_sha256,
            device=self.device,
        )
        nodes = np.asarray(nodes, dtype=np.float64)
        elements = np.asarray(elements, dtype=np.int64)
        count = len(elements)
        Gc = _normalise_element_field(Gc_elem, count, name="Gc_elem")
        ell = _normalise_element_field(length_scale, count, name="length_scale")
        topology = build_mesh_topology(
            nodes, elements=elements, ell=ell, dtype=torch.float32
        )
        zeros = np.zeros(len(nodes), dtype=np.float32)
        sample = TransitionSample(
            topology=topology,
            d_prev=zeros,
            d_prevprev=None,
            H=np.zeros(count, dtype=np.float32),
            boundary_context=np.asarray(boundary_context, dtype=np.float32),
            load_direction=np.asarray(load_direction, dtype=np.float32),
            Gc=Gc,
            ell=ell,
            d_target=zeros,
            transition_id="live",
        )
        self.template = MeshBatch.from_samples([sample]).to(
            self.device, dtype=torch.float32
        )
        self.metadata = {
            **self.metadata,
            "adapter_schema": "paper4_fem_incidence_live_adapter_v1",
            "route": self.route,
            "target_field_available_to_model": False,
            "projection": "max(raw,d_previous)_clamp_max_1",
        }

    def propose(
        self,
        history_elem: torch.Tensor,
        damage_previous: torch.Tensor,
    ) -> tuple[torch.Tensor, dict[str, Any]]:
        previous_reference = damage_previous.detach().cpu().to(torch.float64)
        previous = damage_previous.detach().to(
            device=self.device, dtype=torch.float32
        )
        history = history_elem.detach().to(
            device=self.device, dtype=torch.float32
        )
        if history.shape[0] != self.template.topology.num_elements:
            raise ValueError("live history does not match the fixed FEM topology")
        # d_target is a required storage field but is target-blind: the model's
        # validated causal interface never reads it.  Reusing previous damage
        # also makes accidental future-target access impossible.
        batch = replace(
            self.template,
            d_prev=previous,
            H=history,
            d_target=previous,
        )
        synchronise(self.device)
        started = time.perf_counter()
        with torch.inference_mode():
            prediction = self.model(batch)
        synchronise(self.device)
        elapsed = time.perf_counter() - started
        raw = prediction.raw.detach()
        damage = prediction.damage.detach()
        if damage.shape != previous.shape or not bool(torch.isfinite(damage).all()):
            raise RuntimeError("FEM-incidence returned an invalid damage field")
        damage_out = torch.maximum(
            damage.cpu().to(torch.float64), previous_reference
        ).clamp_max(1.0)
        return damage_out, {
            "route": self.route,
            "inference_wall_s": elapsed,
            "raw_min": float(raw.min()),
            "raw_max": float(raw.max()),
            "candidate_min": float(damage.min()),
            "candidate_max": float(damage.max()),
            "core_node_fraction": 1.0,
            "context_node_fraction": 1.0,
            "context_edge_fraction": 1.0,
        }


class ActiveNeighbourhoodLiveAdapter:
    """Frozen Moon GNN on a causal core and exact message-passing halo."""

    route = "active_neighbourhood"

    def __init__(
        self,
        *,
        checkpoint_path: Path,
        checkpoint_sha256: str,
        device: str,
        nodes: np.ndarray,
        elements: np.ndarray,
        boundary_context: np.ndarray,
        Gc_elem: float | np.ndarray,
        length_scale: float | np.ndarray,
        mask_config: ActiveMaskConfig | None = None,
    ) -> None:
        self.device = resolve_device(device)
        actual = sha256_file(checkpoint_path)
        if actual != checkpoint_sha256:
            raise ValueError("active-neighbourhood checkpoint SHA-256 mismatch")
        self.model, self.metadata = _load_model(checkpoint_path, self.device)
        self.mask_config = mask_config or ActiveMaskConfig()
        if self.mask_config.halo_hops < int(self.metadata["message_passing_steps"]):
            raise ValueError("active halo must cover every message-passing block")
        self.nodes = np.asarray(nodes, dtype=np.float64)
        self.elements = np.asarray(elements, dtype=np.int64)
        if self.elements.ndim != 2 or self.elements.shape[1] != 3:
            raise ValueError("active-neighbourhood route requires T3 elements")
        count = len(self.elements)
        self.Gc = torch.as_tensor(
            _normalise_element_field(Gc_elem, count, name="Gc_elem"),
            dtype=torch.float32,
            device=self.device,
        )
        self.ell = torch.as_tensor(
            _normalise_element_field(length_scale, count, name="length_scale"),
            dtype=torch.float32,
            device=self.device,
        )
        topology = build_mesh_topology(
            self.nodes,
            elements=self.elements,
            ell=self.ell.detach().cpu().numpy(),
            dtype=torch.float32,
        ).to(self.device, dtype=torch.float32)
        self.areas = topology.element_areas
        self.connectivity = torch.as_tensor(
            self.elements, dtype=torch.long, device=self.device
        )
        edges_np = node_edge_index(self.elements)
        self.edges = torch.as_tensor(edges_np, dtype=torch.long, device=self.device)
        # Edge length is normalised by the element-independent scalar used in
        # the eight-case Moon contract.  Element-wise ell is supported only
        # when uniform because Moon's edge feature has one scalar per edge.
        if not bool(torch.allclose(self.ell, self.ell[0])):
            raise ValueError("Moon edge normalisation requires uniform length_scale")
        self.edge_features = torch.as_tensor(
            edge_length_feature(self.nodes, edges_np, float(self.ell[0])),
            dtype=torch.float32,
            device=self.device,
        )
        boundary = np.asarray(boundary_context, dtype=np.float32)
        if boundary.ndim != 2 or boundary.shape[0] != len(self.nodes):
            raise ValueError("boundary_context must contain one row per node")
        self.boundary_indicator = torch.as_tensor(
            boundary[:, 0], dtype=torch.float32, device=self.device
        )
        self.metadata = {
            **self.metadata,
            "adapter_schema": "paper4_active_neighbourhood_live_adapter_v1",
            "route": self.route,
            "target_field_available_to_model_or_mask": False,
            "mask": self.mask_config.__dict__,
            "projection": "core=max(raw,d_previous); outside=d_previous",
        }

    def _history_feature(self, history_elem: torch.Tensor) -> torch.Tensor:
        history = history_elem.detach().to(
            device=self.device, dtype=torch.float32
        ).reshape(-1)
        if history.shape != self.Gc.shape:
            raise ValueError("live history does not match the fixed FEM topology")
        feature = torch.zeros(
            len(self.nodes), dtype=torch.float32, device=self.device
        )
        contribution = history * self.areas / (3.0 * self.Gc * self.ell)
        feature.index_add_(
            0,
            self.connectivity.reshape(-1),
            contribution.repeat_interleave(3),
        )
        return feature

    def propose(
        self,
        history_elem: torch.Tensor,
        damage_previous: torch.Tensor,
    ) -> tuple[torch.Tensor, dict[str, Any]]:
        previous_reference = damage_previous.detach().cpu().to(torch.float64)
        previous = damage_previous.detach().to(
            device=self.device, dtype=torch.float32
        )
        history_feature = self._history_feature(history_elem)
        core = causal_active_core(history_feature, previous, self.mask_config)
        if not bool(core.any()):
            return previous_reference, {
                "route": self.route,
                "inference_wall_s": 0.0,
                "raw_min": float("nan"),
                "raw_max": float("nan"),
                "candidate_min": float(previous.min()),
                "candidate_max": float(previous.max()),
                "core_nodes": 0,
                "context_nodes": 0,
                "context_edges": 0,
                "core_node_fraction": 0.0,
                "context_node_fraction": 0.0,
                "context_edge_fraction": 0.0,
                "empty_core": True,
            }
        subgraph = induced_active_subgraph(
            core, self.edges, halo_hops=self.mask_config.halo_hops
        )
        node_features = torch.stack((history_feature, self.boundary_indicator), dim=1)
        synchronise(self.device)
        started = time.perf_counter()
        with torch.inference_mode():
            raw_local = self.model(
                node_features[subgraph.global_nodes],
                subgraph.edge_index,
                self.edge_features[subgraph.edge_ids],
            )
        synchronise(self.device)
        elapsed = time.perf_counter() - started
        candidate = install_active_prediction(raw_local, previous, subgraph)
        if not bool(torch.isfinite(candidate).all()):
            raise RuntimeError("active-neighbourhood model returned a non-finite field")
        candidate_out = torch.maximum(
            candidate.cpu().to(torch.float64), previous_reference
        ).clamp_max(1.0)
        return candidate_out, {
            "route": self.route,
            "inference_wall_s": elapsed,
            "raw_min": float(raw_local.min()),
            "raw_max": float(raw_local.max()),
            "candidate_min": float(candidate.min()),
            "candidate_max": float(candidate.max()),
            "core_nodes": int(core.sum()),
            "context_nodes": int(subgraph.context_global.sum()),
            "context_edges": int(subgraph.edge_ids.numel()),
            "core_node_fraction": float(core.float().mean()),
            "context_node_fraction": float(subgraph.context_global.float().mean()),
            "context_edge_fraction": float(
                subgraph.edge_ids.numel() / self.edges.shape[1]
            ),
            "empty_core": False,
        }


class LiteralMoonFullLiveAdapter(ActiveNeighbourhoodLiveAdapter):
    """Frozen literal Moon GNN evaluated on the complete FEM node graph."""

    route = "literal_moon"

    def __init__(self, **kwargs: Any) -> None:
        # Reuse the checkpoint and mesh reconstruction from the active route;
        # only the evaluation domain differs.  Keeping one reconstruction
        # prevents the full and active Moon routes from silently drifting.
        super().__init__(**kwargs)
        self.metadata = {
            **self.metadata,
            "adapter_schema": "paper4_literal_moon_full_live_adapter_v1",
            "route": self.route,
            "evaluation_scope": "complete_fem_node_graph",
            "projection": "max(raw,d_previous)_clamp_max_1",
        }

    def propose(
        self,
        history_elem: torch.Tensor,
        damage_previous: torch.Tensor,
    ) -> tuple[torch.Tensor, dict[str, Any]]:
        previous_reference = damage_previous.detach().cpu().to(torch.float64)
        previous = damage_previous.detach().to(
            device=self.device, dtype=torch.float32
        )
        history_feature = self._history_feature(history_elem)
        node_features = torch.stack(
            (history_feature, self.boundary_indicator), dim=1
        )
        synchronise(self.device)
        started = time.perf_counter()
        with torch.inference_mode():
            raw = self.model(node_features, self.edges, self.edge_features)
        synchronise(self.device)
        elapsed = time.perf_counter() - started
        if raw.shape != previous.shape or not bool(torch.isfinite(raw).all()):
            raise RuntimeError("literal Moon model returned an invalid damage field")
        candidate = torch.maximum(raw, previous).clamp_max(1.0)
        candidate_out = torch.maximum(
            candidate.cpu().to(torch.float64), previous_reference
        ).clamp_max(1.0)
        return candidate_out, {
            "route": self.route,
            "inference_wall_s": elapsed,
            "raw_min": float(raw.min()),
            "raw_max": float(raw.max()),
            "candidate_min": float(candidate.min()),
            "candidate_max": float(candidate.max()),
            "core_nodes": int(previous.numel()),
            "context_nodes": int(previous.numel()),
            "context_edges": int(self.edges.shape[1]),
            "core_node_fraction": 1.0,
            "context_node_fraction": 1.0,
            "context_edge_fraction": 1.0,
            "empty_core": False,
        }


class NonGraphLiveAdapter:
    """Frozen raster/coordinate operator used as the live damage update."""

    def __init__(
        self,
        *,
        checkpoint_path: Path,
        checkpoint_sha256: str,
        device: str,
        nodes: np.ndarray,
        elements: np.ndarray,
        boundary_context: np.ndarray,
        Gc_elem: float | np.ndarray,
        length_scale: float | np.ndarray,
        mask_config: ActiveMaskConfig | None = None,
    ) -> None:
        from scripts.paper4.moon_nongraph_operators import (
            NONGRAPH_ARCHITECTURES,
            RasterMeshProjector,
            build_nongraph_operator,
        )

        self.device = resolve_device(device)
        actual = sha256_file(checkpoint_path)
        if actual != checkpoint_sha256:
            raise ValueError("non-graph checkpoint SHA-256 mismatch")
        payload = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        schema = payload.get("schema")
        if schema == "paper4_moon_nongraph_pi_dd_checkpoint_v1":
            training_variant = "pi_dd"
        elif schema == "paper4_moon_nongraph_checkpoint_v2":
            training_variant = str(payload.get("training_variant"))
        else:
            raise ValueError("unsupported non-graph checkpoint schema")
        if training_variant not in {"dd", "pi_dd"}:
            raise ValueError("unsupported non-graph training variant")
        self.route = str(payload.get("architecture"))
        if self.route not in NONGRAPH_ARCHITECTURES:
            raise ValueError("unsupported non-graph checkpoint architecture")
        configuration = dict(payload.get("configuration", {}))
        required = {
            "epochs": 40000,
            "physics_samples": 200,
            "physics_weight": 0.0 if training_variant == "dd" else 1.0,
            "first_training_step": 251,
            "last_training_step": 450,
            "seed": 260619378,
        }
        observed = {
            key: configuration.get(key) for key in required
        }
        if observed != required or int(payload.get("completed_epochs", -1)) != 40000:
            raise ValueError(f"non-graph Moon training contract mismatch: {observed}")
        self.model = build_nongraph_operator(self.route)
        self.model.load_state_dict(payload["model_state_dict"], strict=True)
        self.model.to(self.device).eval()
        self.nodes = np.asarray(nodes, dtype=np.float64)
        self.elements = np.asarray(elements, dtype=np.int64)
        if self.elements.ndim != 2 or self.elements.shape[1] != 3:
            raise ValueError("non-graph raster route requires T3 elements")
        count = len(self.elements)
        self.Gc = torch.as_tensor(
            _normalise_element_field(Gc_elem, count, name="Gc_elem"),
            dtype=torch.float32,
            device=self.device,
        )
        self.ell = torch.as_tensor(
            _normalise_element_field(length_scale, count, name="length_scale"),
            dtype=torch.float32,
            device=self.device,
        )
        topology = build_mesh_topology(
            self.nodes,
            elements=self.elements,
            ell=self.ell.detach().cpu().numpy(),
            dtype=torch.float32,
        ).to(self.device, dtype=torch.float32)
        self.areas = topology.element_areas
        self.connectivity = torch.as_tensor(
            self.elements, dtype=torch.long, device=self.device
        )
        self.projector = RasterMeshProjector(
            self.nodes,
            self.elements,
            height=int(configuration.get("grid_height", 128)),
            width=int(configuration.get("grid_width", 128)),
            device=self.device,
        )
        boundary = np.asarray(boundary_context, dtype=np.float32)
        if boundary.ndim != 2 or boundary.shape[0] != len(self.nodes):
            raise ValueError("boundary_context must contain one row per node")
        self.boundary_indicator = torch.as_tensor(
            boundary[:, 0], dtype=torch.float32, device=self.device
        )
        self.mask_config = mask_config or ActiveMaskConfig()
        self.metadata = {
            "path": str(checkpoint_path.resolve()),
            "sha256": actual,
            "adapter_schema": "paper4_moon_nongraph_live_adapter_v1",
            "route": self.route,
            "training_variant": training_variant,
            "training_contract": required,
            "input_channels": configuration.get("input_channels"),
            "target_field_available_to_model_or_mask": False,
            "projection": "max(raw,d_previous)_clamp_max_1",
        }

    def _history_feature(self, history_elem: torch.Tensor) -> torch.Tensor:
        history = history_elem.detach().to(
            device=self.device, dtype=torch.float32
        ).reshape(-1)
        if history.shape != self.Gc.shape:
            raise ValueError("live history does not match the fixed FEM topology")
        feature = torch.zeros(
            len(self.nodes), dtype=torch.float32, device=self.device
        )
        contribution = history * self.areas / (3.0 * self.Gc * self.ell)
        feature.index_add_(
            0,
            self.connectivity.reshape(-1),
            contribution.repeat_interleave(3),
        )
        return feature

    def _predict(
        self,
        input_grid: torch.Tensor,
        history_feature: torch.Tensor,
        previous: torch.Tensor,
    ) -> tuple[torch.Tensor, dict[str, Any]]:
        from scripts.paper4.moon_nongraph_operators import predict_nodal

        if self.route != "active_patch_unet":
            raw, _ = predict_nodal(
                self.model, self.route, input_grid, self.projector
            )
            return raw, {
                "core_node_fraction": 1.0,
                "context_node_fraction": 1.0,
                "context_edge_fraction": 1.0,
            }

        core = causal_active_core(history_feature, previous, self.mask_config)
        if not bool(core.any()):
            return previous, {
                "core_nodes": 0,
                "core_node_fraction": 0.0,
                "context_node_fraction": 0.0,
                "context_edge_fraction": 0.0,
                "active_grid_fraction": 0.0,
                "empty_core": True,
            }
        core_grid = self.projector.nodal_to_grid(core.to(torch.float32)) > 0.5
        locations = torch.nonzero(core_grid, as_tuple=False)
        radius = int(getattr(self.model, "receptive_radius_cells", 44))
        r0 = max(int(locations[:, 0].min()) - radius, 0)
        r1 = min(int(locations[:, 0].max()) + radius + 1, self.projector.height)
        c0 = max(int(locations[:, 1].min()) - radius, 0)
        c1 = min(int(locations[:, 1].max()) + radius + 1, self.projector.width)
        cropped = input_grid[:, :, r0:r1, c0:c1]
        crop_output = self.model(cropped)
        full_output = torch.zeros(
            (1, 1, self.projector.height, self.projector.width),
            dtype=crop_output.dtype,
            device=crop_output.device,
        )
        full_output[:, :, r0:r1, c0:c1] = crop_output
        raw_all = self.projector.grid_to_nodes(full_output).squeeze(0)
        raw = previous.clone()
        raw[core] = raw_all[core]
        return raw, {
            "core_nodes": int(core.sum()),
            "core_node_fraction": float(core.float().mean()),
            "context_node_fraction": float((r1 - r0) * (c1 - c0) / (
                self.projector.height * self.projector.width
            )),
            "context_edge_fraction": float((r1 - r0) * (c1 - c0) / (
                self.projector.height * self.projector.width
            )),
            "active_grid_fraction": float((r1 - r0) * (c1 - c0) / (
                self.projector.height * self.projector.width
            )),
            "empty_core": False,
        }

    def propose(
        self,
        history_elem: torch.Tensor,
        damage_previous: torch.Tensor,
    ) -> tuple[torch.Tensor, dict[str, Any]]:
        previous_reference = damage_previous.detach().cpu().to(torch.float64)
        previous = damage_previous.detach().to(
            device=self.device, dtype=torch.float32
        )
        history_feature = self._history_feature(history_elem)
        input_grid = self.projector.make_input(
            history_feature, self.boundary_indicator
        )
        synchronise(self.device)
        started = time.perf_counter()
        with torch.inference_mode():
            raw, locality = self._predict(input_grid, history_feature, previous)
        synchronise(self.device)
        elapsed = time.perf_counter() - started
        candidate = torch.maximum(raw, previous).clamp_max(1.0)
        if candidate.shape != previous.shape or not bool(torch.isfinite(candidate).all()):
            raise RuntimeError("non-graph operator returned an invalid damage field")
        candidate_out = torch.maximum(
            candidate.cpu().to(torch.float64), previous_reference
        ).clamp_max(1.0)
        return candidate_out, {
            "route": self.route,
            "inference_wall_s": elapsed,
            "raw_min": float(raw.min()),
            "raw_max": float(raw.max()),
            "candidate_min": float(candidate.min()),
            "candidate_max": float(candidate.max()),
            **locality,
        }


def build_live_adapter(
    route: str,
    **kwargs: Any,
) -> (
    FEMIncidenceLiveAdapter
    | LiteralMoonFullLiveAdapter
    | ActiveNeighbourhoodLiveAdapter
    | NonGraphLiveAdapter
):
    if route == "fem_incidence":
        return FEMIncidenceLiveAdapter(**kwargs)
    if route == "literal_moon":
        kwargs.pop("load_direction", None)
        return LiteralMoonFullLiveAdapter(**kwargs)
    if route == "active_neighbourhood":
        kwargs.pop("load_direction", None)
        return ActiveNeighbourhoodLiveAdapter(**kwargs)
    if route in {
        "raster_unet", "raster_fno", "raster_deeponet", "active_patch_unet",
    }:
        kwargs.pop("load_direction", None)
        return NonGraphLiveAdapter(**kwargs)
    raise ValueError(f"unsupported live replacement route: {route!r}")


class LiveDamageReplacementHook:
    """Install one adapter in place of ``StaggeredSolver.step_solve_damage``."""

    def __init__(self, solver: Any, adapter: Any) -> None:
        self.solver = solver
        self.adapter = adapter
        self.original = solver.step_solve_damage
        self.model_calls = 0
        self.exact_damage_solve_calls = 0
        self.records: list[dict[str, Any]] = []
        self._installed = False

    def install(self) -> "LiveDamageReplacementHook":
        if self._installed:
            raise RuntimeError("live damage hook is already installed")
        hook = self

        def replacement(
            solver_self: Any,
            d_prev_step: torch.Tensor | None = None,
            initial_guess: torch.Tensor | None = None,
        ) -> None:
            del initial_guess
            previous = (
                solver_self.d.detach().clone()
                if d_prev_step is None
                else d_prev_step.detach().clone()
            )
            candidate, diagnostics = hook.adapter.propose(
                solver_self.H_elem, previous
            )
            candidate = candidate.to(
                device=solver_self.device, dtype=solver_self.dtype
            )
            if candidate.shape != solver_self.d.shape:
                raise RuntimeError("live replacement shape does not match solver damage")
            solver_self.d = torch.maximum(candidate, previous)
            if hasattr(solver_self, "_apply_pf_dirichlet"):
                solver_self._apply_pf_dirichlet()
            if not bool(torch.isfinite(solver_self.d).all()):
                raise RuntimeError("live replacement installed non-finite damage")
            solver_self.damage_solver.last_converged = True
            solver_self.damage_solver.last_iter = 0
            hook.model_calls += 1
            hook.records.append({"model_call": hook.model_calls, **diagnostics})

        self.solver.step_solve_damage = types.MethodType(replacement, self.solver)
        self._installed = True
        return self

    def uninstall(self) -> None:
        if self._installed:
            self.solver.step_solve_damage = self.original
            self._installed = False

    @property
    def last_record(self) -> Mapping[str, Any]:
        return self.records[-1] if self.records else {}

    def summary(self) -> dict[str, Any]:
        inference = [float(row["inference_wall_s"]) for row in self.records]
        return {
            "route": self.adapter.route,
            "model_calls": self.model_calls,
            "exact_damage_solve_calls": self.exact_damage_solve_calls,
            "total_inference_wall_s": float(sum(inference)),
            "mean_inference_wall_s": (
                float(np.mean(inference)) if inference else 0.0
            ),
            "checkpoint": self.adapter.metadata,
        }
