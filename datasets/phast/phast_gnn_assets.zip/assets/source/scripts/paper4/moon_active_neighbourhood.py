#!/usr/bin/env python3
"""Moon-faithful active-neighbourhood inference on a fixed FEM mesh.

The frozen Moon model is local: its ten processor blocks communicate over
mesh edges and contain no global pooling.  Consequently, predictions on an
inner active core are identical to full-graph predictions when the induced
subgraph retains a ten-hop dependency halo.

This module deliberately leaves the learned contract unchanged:

* node input 0 is ``sum_e A_e H_e / (3 Gc ell)``;
* node input 1 is the physical topology-boundary indicator;
* the edge input is ``edge_length / ell``;
* the decoder remains linear; and
* runtime projection is only ``max(raw, d_previous)`` followed by any
  pre-existing phase-field Dirichlet values supplied by the caller.

The active core is causal.  It is selected from the current history field and
previous accepted damage only.  Exact future damage is never consulted.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch


@dataclass(frozen=True)
class ActiveMaskConfig:
    """Causal active-core policy for a diffuse fracture front."""

    front_low: float = 0.02
    front_high: float = 0.98
    history_quantile: float = 0.995
    history_positive_eps: float = 0.0
    halo_hops: int = 10

    def __post_init__(self) -> None:
        if not 0.0 <= self.front_low < self.front_high <= 1.0:
            raise ValueError("front thresholds must satisfy 0 <= low < high <= 1")
        if not 0.0 <= self.history_quantile <= 1.0:
            raise ValueError("history_quantile must lie in [0, 1]")
        if self.halo_hops < 0:
            raise ValueError("halo_hops must be non-negative")


@dataclass(frozen=True)
class ActiveSubgraph:
    """A sorted induced subgraph and its mapping to the global mesh."""

    global_nodes: torch.Tensor
    edge_index: torch.Tensor
    edge_ids: torch.Tensor
    core_local: torch.Tensor
    core_global: torch.Tensor
    context_global: torch.Tensor


def triangle_areas(nodes: np.ndarray, elements: np.ndarray) -> np.ndarray:
    """Return positive T3 element areas."""

    xy = np.asarray(nodes, dtype=np.float64)[np.asarray(elements, dtype=np.int64)]
    if xy.ndim != 3 or xy.shape[1:] != (3, 2):
        raise ValueError("Moon active-neighbourhood utility currently requires T3 elements")
    twice = (
        (xy[:, 1, 0] - xy[:, 0, 0]) * (xy[:, 2, 1] - xy[:, 0, 1])
        - (xy[:, 2, 0] - xy[:, 0, 0]) * (xy[:, 1, 1] - xy[:, 0, 1])
    )
    areas = 0.5 * np.abs(twice)
    if np.any(areas <= 0.0):
        raise ValueError("mesh contains a degenerate triangle")
    return areas


def assembled_history_feature(
    history_elem: np.ndarray | torch.Tensor,
    elements: np.ndarray | torch.Tensor,
    areas: np.ndarray | torch.Tensor,
    *,
    n_nodes: int,
    Gc: float,
    length_scale: float,
    device: torch.device | str = "cpu",
) -> torch.Tensor:
    """Assemble the exact history node feature used to train MoonGNNFEM."""

    if Gc <= 0.0 or length_scale <= 0.0:
        raise ValueError("Gc and length_scale must be positive")
    history = torch.as_tensor(history_elem, dtype=torch.float32, device=device).reshape(-1)
    connectivity = torch.as_tensor(elements, dtype=torch.long, device=device)
    area = torch.as_tensor(areas, dtype=torch.float32, device=device).reshape(-1)
    if connectivity.ndim != 2 or connectivity.shape[1] != 3:
        raise ValueError("assembled Moon history currently requires T3 elements")
    if history.numel() != connectivity.shape[0] or area.numel() != connectivity.shape[0]:
        raise ValueError("history and areas must contain one value per element")
    feature = torch.zeros(n_nodes, dtype=torch.float32, device=device)
    contribution = history * area / (3.0 * float(Gc) * float(length_scale))
    feature.index_add_(
        0, connectivity.reshape(-1), contribution.repeat_interleave(3)
    )
    return feature


def topology_boundary_indicator(elements: np.ndarray, n_nodes: int) -> np.ndarray:
    """Return one at nodes on physical one-sided mesh edges.

    This is computed on the full FEM topology.  Artificial active-subgraph
    cuts must never be marked as physical boundaries.
    """

    counts: dict[tuple[int, int], int] = {}
    for triangle in np.asarray(elements, dtype=np.int64):
        if len(triangle) != 3:
            raise ValueError("topology boundary indicator currently requires T3 elements")
        for a, b in ((triangle[0], triangle[1]), (triangle[1], triangle[2]),
                     (triangle[2], triangle[0])):
            key = tuple(sorted((int(a), int(b))))
            counts[key] = counts.get(key, 0) + 1
    result = np.zeros(int(n_nodes), dtype=np.float32)
    for (a, b), count in counts.items():
        if count == 1:
            result[a] = 1.0
            result[b] = 1.0
    return result


def causal_active_core(
    history_node_feature: torch.Tensor,
    damage_previous: torch.Tensor,
    config: ActiveMaskConfig,
) -> torch.Tensor:
    """Select an online core using current history and previous damage only."""

    history = history_node_feature.detach().reshape(-1)
    previous = damage_previous.detach().to(device=history.device).reshape(-1)
    if history.shape != previous.shape:
        raise ValueError("history feature and previous damage must share shape")
    if not bool(torch.isfinite(history).all()) or not bool(torch.isfinite(previous).all()):
        raise ValueError("active-mask inputs must be finite")

    front = (previous > config.front_low) & (previous < config.front_high)
    positive = history > config.history_positive_eps
    hot = torch.zeros_like(front)
    if bool(positive.any()):
        threshold = torch.quantile(history[positive], config.history_quantile)
        hot = positive & (history >= threshold)
    return front | hot


def dilate_mask(core: torch.Tensor, edge_index: torch.Tensor, hops: int) -> torch.Tensor:
    """Return the undirected graph ``hops``-neighbourhood of ``core``."""

    if hops < 0:
        raise ValueError("hops must be non-negative")
    mask = core.detach().bool().clone()
    edges = edge_index.detach().long()
    if edges.ndim != 2 or edges.shape[0] != 2:
        raise ValueError("edge_index must have shape (2, E)")
    if edges.numel() and (int(edges.min()) < 0 or int(edges.max()) >= mask.numel()):
        raise ValueError("edge_index contains an out-of-range node")
    src, dst = edges
    for _ in range(hops):
        previous = mask.clone()
        mask[dst[previous[src]]] = True
        mask[src[previous[dst]]] = True
    return mask


def induced_active_subgraph(
    core: torch.Tensor,
    edge_index: torch.Tensor,
    *,
    halo_hops: int = 10,
) -> ActiveSubgraph:
    """Build an induced, remapped subgraph around a global active core."""

    core_global = core.detach().bool().reshape(-1)
    context = dilate_mask(core_global, edge_index, halo_hops)
    global_nodes = torch.nonzero(context, as_tuple=False).squeeze(1)
    global_to_local = torch.full(
        (core_global.numel(),), -1, dtype=torch.long, device=edge_index.device
    )
    global_to_local[global_nodes] = torch.arange(
        global_nodes.numel(), device=edge_index.device
    )
    keep = context[edge_index[0]] & context[edge_index[1]]
    edge_ids = torch.nonzero(keep, as_tuple=False).squeeze(1)
    local_edges = global_to_local[edge_index[:, edge_ids]]
    return ActiveSubgraph(
        global_nodes=global_nodes,
        edge_index=local_edges,
        edge_ids=edge_ids,
        core_local=core_global[global_nodes],
        core_global=core_global,
        context_global=context,
    )


def infer_full_and_active(
    model: torch.nn.Module,
    node_features: torch.Tensor,
    edge_index: torch.Tensor,
    edge_features: torch.Tensor,
    core: torch.Tensor,
    *,
    halo_hops: int = 10,
) -> tuple[torch.Tensor, torch.Tensor, ActiveSubgraph]:
    """Run full and induced-graph inference without changing model semantics."""

    subgraph = induced_active_subgraph(core, edge_index, halo_hops=halo_hops)
    with torch.inference_mode():
        full = model(node_features, edge_index, edge_features)
        local = model(
            node_features[subgraph.global_nodes],
            subgraph.edge_index,
            edge_features[subgraph.edge_ids],
        )
    return full, local, subgraph


def install_active_prediction(
    raw_local: torch.Tensor,
    damage_previous: torch.Tensor,
    subgraph: ActiveSubgraph,
    *,
    fixed_mask: torch.Tensor | None = None,
    fixed_values: torch.Tensor | None = None,
) -> torch.Tensor:
    """Install only core outputs with Moon's unchanged irreversibility clamp."""

    previous = damage_previous.detach().clone()
    if raw_local.shape != subgraph.global_nodes.shape:
        raise ValueError("raw_local must contain one output per subgraph node")
    core_nodes = subgraph.global_nodes[subgraph.core_local]
    raw_core = raw_local[subgraph.core_local].to(previous)
    previous[core_nodes] = torch.maximum(raw_core, previous[core_nodes])
    if fixed_mask is not None or fixed_values is not None:
        if fixed_mask is None or fixed_values is None:
            raise ValueError("fixed_mask and fixed_values must be supplied together")
        fixed = fixed_mask.to(device=previous.device, dtype=torch.bool)
        values = fixed_values.to(previous)
        if fixed.shape != previous.shape or values.shape != previous.shape:
            raise ValueError("fixed mask and values must match the damage field")
        previous[fixed] = values[fixed]
    return previous
