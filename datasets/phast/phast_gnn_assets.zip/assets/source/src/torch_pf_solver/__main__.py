"""Compatibility entry point for ``python -m torch_pf_solver``."""

from phast.__main__ import main


if __name__ == "__main__":
    main()
