"""Compatibility namespace for the former ``torch_pf_solver`` package.

PhAST is the canonical package name. This module keeps existing notebooks,
HPC scripts, and downstream imports working while new code migrates to
``import phast``.
"""

from __future__ import annotations

from importlib import import_module as _import_module
from pathlib import Path as _Path
import sys as _sys

_phast = _import_module("phast")

__path__ = [str(_Path(__file__).parent), *list(_phast.__path__)]
__all__ = getattr(_phast, "__all__", [])
__doc__ = _phast.__doc__
__version__ = getattr(_phast, "__version__", None)

for _name in __all__:
    globals()[_name] = getattr(_phast, _name)

for _subpackage in (
    "cohesive_elements",
    "config",
    "core",
    "dataset_benchmark",
    "hybrid_switching",
    "inverse_problems",
    "physics",
    "plasticity",
    "research",
    "solvers",
    "surrogates",
    "training",
    "utils",
):
    try:
        _sys.modules[f"{__name__}.{_subpackage}"] = _import_module(
            f"phast.{_subpackage}"
        )
    except ImportError:
        pass


def __getattr__(name: str):
    return getattr(_phast, name)
