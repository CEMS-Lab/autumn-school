"""Utilities for optional external reference-solver artifacts.

The loader intentionally depends only on NumPy and the standard library.  This
keeps reference comparisons usable in normal PhAST environments while DOLFINx,
FEniCS, COMSOL, or other generators live in separate optional environments.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

import numpy as np


REFERENCE_ARTIFACT_SCHEMA_VERSION = 1

REQUIRED_REFERENCE_KEYS = (
    "schema_version",
    "backend",
    "backend_version",
    "case",
    "nodes",
    "elements",
    "displacement",
    "right_reaction_y",
    "metadata_json",
)


@dataclass(frozen=True)
class ReferenceArtifact:
    """Validated contents of a reference-solver ``.npz`` artifact."""

    path: Path
    schema_version: int
    backend: str
    backend_version: str
    case: str
    nodes: np.ndarray
    elements: np.ndarray
    displacement: np.ndarray
    right_reaction_y: float
    metadata: dict[str, Any]


def _scalar_text(value: np.ndarray, key: str) -> str:
    array = np.asarray(value)
    if array.shape != ():
        raise ValueError(f"{key} must be a scalar string field, got shape {array.shape}")
    return str(array.item())


def _copy_array(value: np.ndarray, key: str, *, ndim: int) -> np.ndarray:
    array = np.asarray(value)
    if array.ndim != ndim:
        raise ValueError(f"{key} must be {ndim}D, got shape {array.shape}")
    return np.array(array, copy=True)


def load_reference_artifact(path: str | Path) -> ReferenceArtifact:
    """Load and validate a PhAST external-reference ``.npz`` artifact.

    The schema is deliberately small: mesh coordinates/connectivity, nodal
    displacement, one scalar reaction check, and a JSON metadata payload.  A
    DOLFINx generator can run in its own Python environment and PhAST can still
    consume the saved artifact without importing DOLFINx.
    """

    artifact_path = Path(path)
    with np.load(artifact_path, allow_pickle=False) as data:
        keys = set(data.files)
        missing = [key for key in REQUIRED_REFERENCE_KEYS if key not in keys]
        if missing:
            joined = ", ".join(missing)
            raise ValueError(f"{artifact_path}: missing required keys: {joined}")

        schema_version = int(np.asarray(data["schema_version"]).item())
        if schema_version != REFERENCE_ARTIFACT_SCHEMA_VERSION:
            raise ValueError(
                f"{artifact_path}: unsupported schema_version={schema_version}; "
                f"expected {REFERENCE_ARTIFACT_SCHEMA_VERSION}"
            )

        nodes = _copy_array(data["nodes"], "nodes", ndim=2).astype(np.float64)
        elements = _copy_array(data["elements"], "elements", ndim=2).astype(np.int64)
        displacement = _copy_array(
            data["displacement"], "displacement", ndim=2
        ).astype(np.float64)

        if nodes.shape[1] != 2:
            raise ValueError(f"nodes must have shape (N, 2), got {nodes.shape}")
        if elements.shape[1] not in (3, 4):
            raise ValueError(
                f"elements must have 3 or 4 nodes per cell, got {elements.shape}"
            )
        if displacement.shape != nodes.shape:
            raise ValueError(
                f"displacement shape {displacement.shape} must match nodes {nodes.shape}"
            )

        metadata_text = _scalar_text(data["metadata_json"], "metadata_json")
        try:
            metadata = json.loads(metadata_text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"{artifact_path}: metadata_json is not valid JSON") from exc
        if not isinstance(metadata, dict):
            raise ValueError(f"{artifact_path}: metadata_json must decode to an object")

        return ReferenceArtifact(
            path=artifact_path,
            schema_version=schema_version,
            backend=_scalar_text(data["backend"], "backend"),
            backend_version=_scalar_text(data["backend_version"], "backend_version"),
            case=_scalar_text(data["case"], "case"),
            nodes=nodes,
            elements=elements,
            displacement=displacement,
            right_reaction_y=float(np.asarray(data["right_reaction_y"]).item()),
            metadata=metadata,
        )


def assert_reference_close(
    name: str,
    actual: np.ndarray,
    reference: np.ndarray,
    *,
    rtol: float = 1e-8,
    atol: float = 1e-10,
) -> None:
    """Raise a focused assertion if an array differs from a reference field."""

    actual_arr = np.asarray(actual)
    ref_arr = np.asarray(reference)
    if actual_arr.shape != ref_arr.shape:
        raise AssertionError(
            f"{name}: shape mismatch, actual={actual_arr.shape}, reference={ref_arr.shape}"
        )
    if not np.allclose(actual_arr, ref_arr, rtol=rtol, atol=atol):
        diff = np.abs(actual_arr - ref_arr)
        raise AssertionError(
            f"{name}: max_abs_error={float(diff.max()):.6e} exceeds "
            f"rtol={rtol:.3e}, atol={atol:.3e}"
        )
