"""Backward-compatible alias for :mod:`phast.core.problem`."""

from importlib import import_module as _import_module
import sys as _sys

_sys.modules[__name__] = _import_module("phast.core.problem")
