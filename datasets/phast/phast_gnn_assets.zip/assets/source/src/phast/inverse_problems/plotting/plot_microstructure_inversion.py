#!/usr/bin/env python
"""Paper-quality figure for the microstructure-inclusion inversion demo.

Reads `demo_inverse_microstructure.npz` and produces a four-panel figure:
  (a) target damage field with truth inclusion + initial guess + optimiser
      trajectory of (xh, yh) iterates overlaid in physical (x, y) space;
  (b) recovered damage field with the converged inclusion centre;
  (c) MSE loss vs L-BFGS outer iteration (semilog);
  (d) position error |(xh - xh*, yh - yh*)| vs iteration (semilog).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle


def plot_from_npz(npz_path: str, out_png: str) -> None:
    z = np.load(npz_path, allow_pickle=True)
    nodes    = z["nodes"]
    elements = z["elements"]
    d_target = z["d_target"]
    d_final  = z["d_final"]
    history  = list(z["history"])
    true_xh, true_yh = float(z["true_xh"]), float(z["true_yh"])
    init_xh, init_yh = float(z["init_xh"]), float(z["init_yh"])
    final_xh, final_yh = float(z["final_xh"]), float(z["final_yh"])
    sigma_inc = float(z["sigma_inc"])
    W = float(z["W_plate"]); H = float(z["H_plate"])
    a = float(z["a_notch"])

    its = np.array([h[0] for h in history])
    xhs = np.array([h[1] for h in history])
    yhs = np.array([h[2] for h in history])
    losses = np.array([h[3] for h in history])
    errs   = np.array([h[4] for h in history])

    # Panel widths balanced for a 2:1 damage panel + landscape convergence.
    fig = plt.figure(figsize=(11.0, 5.6))
    gs = fig.add_gridspec(
        2, 3, width_ratios=[1.0, 1.0, 0.05],
        height_ratios=[1.0, 1.05],
        hspace=0.45, wspace=0.28,
        left=0.07, right=0.93, top=0.93, bottom=0.10,
    )

    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    cax  = fig.add_subplot(gs[0, 2])
    ax_c = fig.add_subplot(gs[1, 0])
    ax_d = fig.add_subplot(gs[1, 1])

    # ------------------------------------------------- damage field maps --
    panel_data = (
        (ax_a, d_target, "(a)  Target damage  (truth inclusion)",
         true_xh, true_yh, "#d62728"),
        (ax_b, d_final,  "(b)  Recovered damage  (converged $(x_h, y_h)$)",
         final_xh, final_yh, "#2ca02c"),
    )
    for ax, d_field, title, hx, hy, hcol in panel_data:
        tpc = ax.tripcolor(nodes[:, 0], nodes[:, 1], elements, d_field,
                           shading="gouraud", cmap="inferno",
                           vmin=0.0, vmax=1.0, rasterized=True)
        ax.add_patch(Rectangle((0, 0), W, H, fill=False, ec="black", lw=0.9))
        ax.plot([0, a, a, 0],
                [H/2 - 0.05, H/2 - 0.05, H/2 + 0.05, H/2 + 0.05],
                "k-", lw=0.7)
        # inclusion 2σ disc
        circ = plt.Circle((hx, hy), 2 * sigma_inc, fill=False,
                           ec=hcol, lw=1.4, ls="--", zorder=5)
        ax.add_patch(circ)
        ax.plot(hx, hy, marker="*", ms=15, mec="black", mfc=hcol,
                mew=0.6, zorder=6)
        ax.set_xlim(-0.5, W + 0.5); ax.set_ylim(-0.8, H + 0.8)
        ax.set_aspect("equal")
        ax.set_xlabel("$x$ (mm)", fontsize=10)
        ax.set_ylabel("$y$ (mm)", fontsize=10)
        ax.set_title(title, fontsize=10, loc="left")
        ax.tick_params(labelsize=9)

    cbar = fig.colorbar(tpc, cax=cax)
    cbar.set_label("damage  $d$", fontsize=10)
    cbar.set_ticks([0.0, 0.5, 1.0])
    cbar.ax.tick_params(labelsize=9)

    # Optimiser trajectory on panel (a) — outlined for visibility.
    line_pe = [pe.Stroke(linewidth=3.0, foreground="black"),
               pe.Normal()]
    ax_a.plot(xhs, yhs, "-", color="white", lw=1.6, zorder=4,
              path_effects=line_pe)
    ax_a.plot(xhs, yhs, "o", mfc="white", mec="black", mew=0.7,
              ms=5.0, zorder=5)
    ax_a.plot(init_xh, init_yh, marker="s", ms=10,
              mec="black", mfc="#1f77b4", mew=0.8, zorder=6)

    leg_a = ax_a.legend(handles=[
        Line2D([0], [0], marker="*", color="white", mec="black",
               mfc="#d62728", ms=11, label="truth", linestyle="None"),
        Line2D([0], [0], marker="s", color="white", mec="black",
               mfc="#1f77b4", ms=8, label="init", linestyle="None"),
        Line2D([0], [0], marker="o", color="white", mec="black",
               mfc="white", ms=6, lw=1.6,
               label="L-BFGS iterates"),
    ], loc="lower right", fontsize=8, framealpha=0.85,
       handlelength=1.6, borderaxespad=0.5)
    leg_a.get_frame().set_edgecolor("0.6")

    leg_b = ax_b.legend(handles=[
        Line2D([0], [0], marker="*", color="white", mec="black",
               mfc="#2ca02c", ms=11, label="recovered", linestyle="None"),
    ], loc="lower right", fontsize=8, framealpha=0.85,
       handlelength=1.0, borderaxespad=0.5)
    leg_b.get_frame().set_edgecolor("0.6")

    # --------------------------------------------- convergence panels (c,d)
    ax_c.semilogy(its, losses, "o-", color="#1f77b4", lw=1.4, ms=5.5)
    ax_c.set_xlabel("L-BFGS outer iteration", fontsize=10)
    ax_c.set_ylabel("MSE loss", fontsize=10)
    ax_c.grid(True, which="both", alpha=0.25)
    ax_c.tick_params(labelsize=9)
    ax_c.set_title("(c)  Objective convergence", fontsize=10, loc="left")

    ax_d.semilogy(its, errs, "o-", color="#2ca02c", lw=1.4, ms=5.5)
    ax_d.axhline(0.05, color="grey", lw=0.9, ls="--")
    ax_d.text(its[-1], 0.052, "tolerance 0.05 mm",
              fontsize=8.5, color="grey", ha="right", va="bottom")
    n_fwd = int(history[-1][5]) if len(history[-1]) > 5 else None
    summary = rf"final $|\Delta(x_h, y_h)| = {errs[-1]:.3f}$ mm"
    if n_fwd is not None:
        summary += f"\n{n_fwd} forward evaluations"
    ax_d.text(0.04, 0.04, summary, transform=ax_d.transAxes,
              fontsize=8.5, ha="left", va="bottom",
              bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="0.6",
                        alpha=0.9))
    ax_d.set_xlabel("L-BFGS outer iteration", fontsize=10)
    ax_d.set_ylabel(r"$\|(x_h, y_h) - (x_h^\star, y_h^\star)\|$  (mm)",
                    fontsize=10)
    ax_d.grid(True, which="both", alpha=0.25)
    ax_d.tick_params(labelsize=9)
    ax_d.set_title("(d)  Position error", fontsize=10, loc="left")

    fig.savefig(out_png, dpi=200, bbox_inches="tight")
    pdf_path = str(Path(out_png).with_suffix(".pdf"))
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)


def main():
    if len(sys.argv) < 2:
        print("usage: plot_microstructure_inversion.py <npz> [out.png]")
        sys.exit(1)
    npz = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) >= 3 else (
        os.path.splitext(npz)[0] + ".png")
    plot_from_npz(npz, out)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
