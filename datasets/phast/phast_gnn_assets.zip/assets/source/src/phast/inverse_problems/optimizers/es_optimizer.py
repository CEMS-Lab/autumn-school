"""Evolutionary Strategies (ES) optimizer for gradient-free inversion.

Reference
---------
Salimans, T., Ho, J., Chen, X., Sidor, S., & Sutskever, I. (2017).
"Evolution Strategies as a Scalable Alternative to Reinforcement
Learning." arXiv:1703.03864. Algorithm 1.

Suh, H. T., Simchowitz, M., Zhang, K., & Tedrake, R. (2022).
"Do Differentiable Simulators Give Better Policy Gradients?" ICML 2022,
§5: ZoBGE (zeroth-order batched gradient estimator) is the same finite-
difference-along-random-directions construction used here, motivated by
chaotic-dynamics gradient amplification.

Estimator
---------
For loss ``L(theta)`` with parameters ``theta`` and Gaussian perturbation
scale ``sigma``,

    g_hat = (1 / (sigma * N)) * sum_i F_i * eps_i

where ``eps_i ~ N(0, I)``, and ``F_i`` is either the raw loss
``L(theta + sigma*eps_i)`` or, with ``fitness_shaping=True``, the
centered-rank transform of those losses (Salimans 2017, lines 8-10).

When ``antithetic=True`` we evaluate both ``+eps_i`` and ``-eps_i``
(``2N`` forward evaluations per step) and use the symmetric estimator
``(F_i_plus - F_i_minus) * eps_i / (2 * sigma * N)``. Antithetic sampling
is the standard ES variance-reduction trick.

The estimator is bounded by ``O(|L| / sigma)`` *regardless of any
chaotic eigenvalue blow-up in the unrolled forward map*. That is the
property exploited by the Paper 2 chaos-amplification diagnostic.

Vectorisation
-------------
Most phase-field forwards mutate solver state and cannot be batched
along a leading dimension; the closure interface therefore evaluates
the ``2N`` (or ``N``) samples in a Python loop. ``n_workers > 1`` is
declared in the API for future thread/process parallelism but is
currently ignored (single-worker only). Document this honestly in the
demo.

API
---
The ESOptimizer holds a flat parameter buffer (``self.theta``, a
:class:`torch.Tensor`). The user supplies a ``loss_fn(theta) -> scalar``
closure. ``step(loss_fn)`` returns the loss at the *pre-update* theta
(the natural "current loss" log entry, matching ``torch.optim`` LBFGS
closure semantics).
"""
from __future__ import annotations

from typing import Callable, Optional

import torch


def _centered_rank(values: torch.Tensor) -> torch.Tensor:
    """Centered-rank fitness shaping (Salimans 2017, Algorithm 1 §8-10).

    Maps a length-``M`` tensor of losses to ranks in ``[-0.5, 0.5]``.
    Lower loss -> more negative shaped value, which makes the ES
    update ``theta -= lr * sum F_i eps_i / (sigma N)`` descend
    correctly (smaller loss in direction ``eps_i`` -> negative weight
    -> ``theta`` moves along ``+eps_i``).

    Concretely: rank the losses ascending (smallest loss gets rank 0,
    largest gets rank ``M-1``), divide by ``M-1`` to map to
    ``[0, 1]``, then subtract ``0.5``.
    """
    M = values.numel()
    if M == 1:
        return torch.zeros_like(values)
    order = torch.argsort(values, descending=False)
    ranks = torch.empty(M, dtype=values.dtype, device=values.device)
    ranks[order] = torch.arange(0, M, dtype=values.dtype, device=values.device)
    return ranks / (M - 1) - 0.5


class ESOptimizer:
    """Salimans-2017-style evolutionary strategies optimizer.

    Parameters
    ----------
    params : torch.Tensor
        Initial parameter vector (1D). Cloned internally; the original
        is left untouched. Stored as float64 to match the rest of the
        phast inverse stack.
    lr : float
        Learning rate ``alpha`` for the update ``theta <- theta - lr * g_hat``.
    sigma : float
        Perturbation standard deviation. Too small -> dominated by
        forward-evaluation noise; too large -> finite-difference bias
        on a non-quadratic loss.
    n_samples : int
        Number of perturbation directions per step. With antithetic
        sampling this is the count of ``+eps`` directions; the actual
        forward count per step is ``2 * n_samples``.
    antithetic : bool
        If True, evaluate both ``L(theta + sigma*eps)`` and
        ``L(theta - sigma*eps)`` for variance reduction.
    fitness_shaping : bool
        If True, replace raw losses with centered-rank weights before
        forming the gradient estimate.
    n_workers : int
        Reserved for parallel evaluation. Currently must be 1; the
        closure-based API runs forwards sequentially because the
        underlying phase-field solvers mutate shared state.
    seed : int, optional
        Seed for the perturbation RNG. Reproducibility helper.
    device, dtype : torch device / dtype
        Where to keep ``theta`` and the perturbations. Defaults to CPU
        float64.
    """

    def __init__(
        self,
        params: torch.Tensor,
        lr: float = 1e-2,
        sigma: float = 1e-1,
        n_samples: int = 16,
        antithetic: bool = True,
        fitness_shaping: bool = True,
        n_workers: int = 1,
        seed: Optional[int] = None,
        device: Optional[torch.device] = None,
        dtype: torch.dtype = torch.float64,
    ) -> None:
        if n_workers != 1:
            raise NotImplementedError(
                "ESOptimizer.n_workers > 1 is reserved for future "
                "thread/process parallelism; the current closure-based "
                "API evaluates samples sequentially because typical "
                "phase-field forwards mutate shared solver state.")
        if n_samples < 1:
            raise ValueError("n_samples must be >= 1")
        if sigma <= 0:
            raise ValueError("sigma must be > 0")
        if lr <= 0:
            raise ValueError("lr must be > 0")

        if device is None:
            device = params.device if isinstance(params, torch.Tensor) else torch.device("cpu")
        params_t = torch.as_tensor(params, dtype=dtype, device=device).detach().clone()
        if params_t.dim() != 1:
            params_t = params_t.flatten()

        self.theta: torch.Tensor = params_t
        self.lr = float(lr)
        self.sigma = float(sigma)
        self.n_samples = int(n_samples)
        self.antithetic = bool(antithetic)
        self.fitness_shaping = bool(fitness_shaping)
        self.n_workers = int(n_workers)
        self.device = device
        self.dtype = dtype

        self._gen = torch.Generator(device="cpu")
        if seed is not None:
            self._gen.manual_seed(int(seed))

        self._iter = 0
        self.last_grad_norm: Optional[float] = None
        self.last_loss: Optional[float] = None

    # -- helpers -----------------------------------------------------------

    def _sample_eps(self) -> torch.Tensor:
        """Draw an ``(n_samples, dim)`` standard-normal perturbation matrix."""
        return torch.randn(
            self.n_samples, self.theta.numel(),
            generator=self._gen, dtype=self.dtype,
        ).to(self.device)

    def estimate_grad(
        self,
        loss_fn: Callable[[torch.Tensor], float],
        return_losses: bool = False,
    ):
        """Compute the ES gradient estimate at the current theta.

        Does NOT update theta. Useful for the chaos-amplification
        diagnostic figure where we want ``||g_hat||`` without stepping.
        """
        eps = self._sample_eps()                           # (N, dim)
        if self.antithetic:
            losses_plus = torch.empty(self.n_samples, dtype=self.dtype, device=self.device)
            losses_minus = torch.empty(self.n_samples, dtype=self.dtype, device=self.device)
            for i in range(self.n_samples):
                tp = self.theta + self.sigma * eps[i]
                tm = self.theta - self.sigma * eps[i]
                losses_plus[i] = float(loss_fn(tp))
                losses_minus[i] = float(loss_fn(tm))
            if self.fitness_shaping:
                # Rank the combined 2N losses, then split back.
                combined = torch.cat([losses_plus, losses_minus])
                shaped = _centered_rank(combined)
                f_plus = shaped[: self.n_samples]
                f_minus = shaped[self.n_samples:]
            else:
                f_plus = losses_plus
                f_minus = losses_minus
            # g_hat = (1 / (2 * sigma * N)) * sum (F_plus - F_minus) * eps
            weights = (f_plus - f_minus).unsqueeze(1)       # (N, 1)
            g_hat = (weights * eps).sum(dim=0) / (2.0 * self.sigma * self.n_samples)
            losses = torch.cat([losses_plus, losses_minus])
        else:
            losses = torch.empty(self.n_samples, dtype=self.dtype, device=self.device)
            for i in range(self.n_samples):
                tp = self.theta + self.sigma * eps[i]
                losses[i] = float(loss_fn(tp))
            if self.fitness_shaping:
                fitness = _centered_rank(losses)
            else:
                fitness = losses
            g_hat = (fitness.unsqueeze(1) * eps).sum(dim=0) / (self.sigma * self.n_samples)

        self.last_grad_norm = float(g_hat.norm().item())
        if return_losses:
            return g_hat, losses
        return g_hat

    # -- public step -------------------------------------------------------

    def step(self, loss_fn: Callable[[torch.Tensor], float]) -> float:
        """Run one ES step.

        Parameters
        ----------
        loss_fn : callable
            ``loss_fn(theta) -> scalar``. Receives a 1D tensor of the
            current parameter vector and returns the loss as a Python
            float (or 0-dim tensor). No autograd needed.

        Returns
        -------
        float
            The loss at the *pre-update* ``theta`` (one extra forward,
            useful for monotonic loss-curve logging). If you would
            rather avoid the extra eval, set ``loss_fn`` to cache.
        """
        # Loss at current theta -- one extra forward, but it gives a
        # clean monotonic loss curve for plotting.
        loss_here = float(loss_fn(self.theta))
        self.last_loss = loss_here

        g_hat = self.estimate_grad(loss_fn)
        # Gradient *descent* along estimate.
        self.theta = self.theta - self.lr * g_hat
        self._iter += 1
        return loss_here

    # -- introspection -----------------------------------------------------

    def state_dict(self) -> dict:
        return {
            "theta": self.theta.detach().clone(),
            "iter": self._iter,
            "lr": self.lr,
            "sigma": self.sigma,
            "n_samples": self.n_samples,
            "antithetic": self.antithetic,
            "fitness_shaping": self.fitness_shaping,
        }

    def __repr__(self) -> str:
        return (
            f"ESOptimizer(dim={self.theta.numel()}, lr={self.lr}, "
            f"sigma={self.sigma}, n_samples={self.n_samples}, "
            f"antithetic={self.antithetic}, "
            f"fitness_shaping={self.fitness_shaping}, "
            f"iter={self._iter})"
        )
