"""Hamiltonian Monte Carlo sampler using autograd-computed gradients.

Designed for expensive potential functions (e.g., a full phase-field
solver forward+backward), where each gradient evaluation costs O(100s).

Features
--------
- Leapfrog integrator with diagonal mass-matrix preconditioning
- Dual averaging step-size adaptation during warmup (Hoffman & Gelman 2014)
- Gelman-Rubin R-hat convergence diagnostic across chains
- Integrated-autocorrelation effective sample size (ESS)
- JSON-serialisable diagnostics for logging

Potential convention: ``potential_fn(theta)`` returns a *non-negative*
scalar that plays the role of U(θ) = -log p(θ|data).  A Gaussian prior
can be added via the ``prior_scale`` argument.
"""
from __future__ import annotations

import math
import time
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import torch
from torch import Tensor


# ---------------------------------------------------------------------------
# Core leapfrog integrator
# ---------------------------------------------------------------------------

def _potential_and_grad(
    potential_fn: Callable[[Tensor], Tensor],
    theta: Tensor,
) -> Tuple[Tensor, Tensor]:
    """Evaluate U(theta) and ∇U(theta) via autograd."""
    theta_leaf = theta.detach().requires_grad_(True)
    U = potential_fn(theta_leaf)
    grad = torch.autograd.grad(U, theta_leaf)[0]
    return U.detach(), grad.detach()


def leapfrog(
    theta: Tensor,
    r: Tensor,
    step_size: float,
    n_steps: int,
    potential_fn: Callable[[Tensor], Tensor],
    M_inv_diag: Tensor,
) -> Tuple[Tensor, Tensor, int]:
    """Single leapfrog trajectory.

    Parameters
    ----------
    theta       : current position, shape (d,)
    r           : current momentum, shape (d,)
    step_size   : leapfrog step ε
    n_steps     : number of leapfrog steps L
    potential_fn: U(θ) — callable, differentiable
    M_inv_diag  : diagonal of M^{-1}, shape (d,)

    Returns
    -------
    theta_new, r_new, n_grad_evals
    """
    _, grad = _potential_and_grad(potential_fn, theta)
    r = r - 0.5 * step_size * grad
    for _ in range(n_steps - 1):
        theta = theta + step_size * M_inv_diag * r
        _, grad = _potential_and_grad(potential_fn, theta)
        r = r - step_size * grad
    theta = theta + step_size * M_inv_diag * r
    _, grad = _potential_and_grad(potential_fn, theta)
    r = r - 0.5 * step_size * grad
    return theta, r, n_steps + 1  # n_steps inner + 1 half-step at start


# ---------------------------------------------------------------------------
# Kinetic energy
# ---------------------------------------------------------------------------

def _kinetic(r: Tensor, M_inv_diag: Tensor) -> float:
    return 0.5 * float((r * M_inv_diag * r).sum())


# ---------------------------------------------------------------------------
# Dual averaging step-size adaptation (Hoffman & Gelman 2014, Algorithm 5)
# ---------------------------------------------------------------------------

class _DualAverager:
    """Nesterov dual averaging for step-size adaptation toward target_accept."""

    def __init__(
        self,
        step_size_init: float,
        target_accept: float = 0.65,
        gamma: float = 0.05,
        t0: float = 10.0,
        kappa: float = 0.75,
    ) -> None:
        self.target = target_accept
        self.gamma = gamma
        self.t0 = t0
        self.kappa = kappa
        self.log_eps_bar = math.log(step_size_init)
        self.H_bar = 0.0
        self.m = 1
        self.mu = math.log(10 * step_size_init)

    def step(self, accept_prob: float) -> float:
        """Update and return the current adapted step size."""
        eta = 1.0 / (self.m + self.t0)
        self.H_bar = (1 - eta) * self.H_bar + eta * (self.target - accept_prob)
        log_eps = self.mu - (math.sqrt(self.m) / self.gamma) * self.H_bar
        eta_bar = self.m ** (-self.kappa)
        self.log_eps_bar = (1 - eta_bar) * self.log_eps_bar + eta_bar * log_eps
        self.m += 1
        return math.exp(log_eps)

    @property
    def final_step_size(self) -> float:
        return math.exp(self.log_eps_bar)


# ---------------------------------------------------------------------------
# HMC chain sampler
# ---------------------------------------------------------------------------

def hmc_sample(
    potential_fn: Callable[[Tensor], Tensor],
    theta_init: Tensor,
    n_samples: int = 50,
    n_warmup: int = 50,
    step_size: float = 0.1,
    n_leapfrog: int = 3,
    mass_diag: Optional[Tensor] = None,
    prior_scale: Optional[Tensor] = None,
    target_accept: float = 0.65,
    adapt_step_size: bool = True,
    rng_seed: Optional[int] = None,
    verbose: bool = True,
) -> Dict:
    """Draw HMC samples from exp(-potential_fn(theta)).

    Parameters
    ----------
    potential_fn  : U(θ) = -log p(θ|data), autograd-differentiable
    theta_init    : initial parameter vector, shape (d,)
    n_samples     : number of post-warmup samples to collect
    n_warmup      : warmup (adaptation) iterations
    step_size     : initial leapfrog step ε
    n_leapfrog    : number of leapfrog steps L per proposal
    mass_diag     : diagonal mass M; default ones (identity)
    prior_scale   : Gaussian std for each dim; None = flat prior
    target_accept : dual-averaging target acceptance rate
    adapt_step_size: whether to run dual averaging during warmup
    rng_seed      : for reproducibility
    verbose       : print per-iteration progress

    Returns
    -------
    dict with keys:
        samples   : np.ndarray (n_samples, d)
        warmup    : np.ndarray (n_warmup, d)
        accept_rate: float
        n_grad_evals: int
        step_size_final: float
        diagnostics: list of per-iter dicts
    """
    if rng_seed is not None:
        torch.manual_seed(rng_seed)
        np.random.seed(rng_seed)

    theta = theta_init.detach().clone().float() if theta_init.dtype == torch.float32 \
        else theta_init.detach().clone()
    d = theta.numel()
    dtype = theta.dtype
    device = theta.device

    if mass_diag is None:
        mass_diag = torch.ones(d, dtype=dtype, device=device)
    M_inv_diag = 1.0 / mass_diag

    def _U(th: Tensor) -> Tensor:
        U = potential_fn(th)
        if prior_scale is not None:
            U = U + 0.5 * ((th / prior_scale) ** 2).sum()
        return U

    dual_avg = _DualAverager(step_size, target_accept=target_accept) \
        if adapt_step_size else None

    samples_warmup: List[np.ndarray] = []
    samples_post: List[np.ndarray] = []
    diagnostics: List[dict] = []
    n_accepted = 0
    total_grad_evals = 0
    t_chain_start = time.time()

    U_curr, _ = _potential_and_grad(_U, theta)
    U_curr = float(U_curr)
    total_grad_evals += 1

    n_total = n_warmup + n_samples
    for i in range(n_total):
        t_iter = time.time()
        phase = "warmup" if i < n_warmup else "sample"

        # Sample momentum from N(0, M)
        r = torch.randn(d, dtype=dtype, device=device) * mass_diag.sqrt()

        K_curr = _kinetic(r, M_inv_diag)
        H_curr = U_curr + K_curr

        # Leapfrog proposal
        theta_prop, r_prop, n_g = leapfrog(
            theta.clone(), r, step_size, n_leapfrog, _U, M_inv_diag)
        total_grad_evals += n_g

        U_prop_t, _ = _potential_and_grad(_U, theta_prop)
        U_prop = float(U_prop_t)
        total_grad_evals += 1

        K_prop = _kinetic(-r_prop, M_inv_diag)
        H_prop = U_prop + K_prop

        log_accept = min(0.0, H_curr - H_prop)
        accept_prob = math.exp(log_accept)

        accepted = (torch.rand(1).item() < accept_prob)
        if accepted:
            theta = theta_prop
            U_curr = U_prop
            n_accepted += 1

        iter_time = time.time() - t_iter

        diag = {
            "iter": i,
            "phase": phase,
            "accepted": int(accepted),
            "accept_prob": round(accept_prob, 4),
            "U": round(U_curr, 6),
            "H_curr": round(H_curr, 6),
            "H_prop": round(H_prop, 6),
            "step_size": round(step_size, 6),
            "theta": theta.tolist(),
            "iter_s": round(iter_time, 1),
        }
        diagnostics.append(diag)

        if i < n_warmup:
            samples_warmup.append(theta.detach().cpu().numpy().copy())
            if adapt_step_size and dual_avg is not None:
                step_size = dual_avg.step(accept_prob)
        else:
            samples_post.append(theta.detach().cpu().numpy().copy())

        if verbose:
            theta_str = "  ".join(f"{v:.4f}" for v in theta.tolist())
            print(
                f"  [HMC {phase} {i+1}/{n_total}]  "
                f"accept={accepted}({accept_prob:.3f})  "
                f"U={U_curr:.4e}  eps={step_size:.4e}  "
                f"theta=[{theta_str}]  ({iter_time:.1f}s)",
                flush=True,
            )

    # Finalise step size after warmup
    if adapt_step_size and dual_avg is not None:
        step_size = dual_avg.final_step_size

    accept_rate = n_accepted / n_total
    samples_arr = np.array(samples_post)
    warmup_arr = np.array(samples_warmup)

    wall_s = time.time() - t_chain_start
    print(
        f"\n  HMC done: {n_samples} samples, accept={accept_rate:.3f}, "
        f"eps_final={step_size:.4e}, {total_grad_evals} grad evals, "
        f"{wall_s/60:.1f} min",
        flush=True,
    )

    return {
        "samples": samples_arr,
        "warmup": warmup_arr,
        "accept_rate": accept_rate,
        "n_grad_evals": total_grad_evals,
        "step_size_final": step_size,
        "n_samples": n_samples,
        "n_warmup": n_warmup,
        "n_leapfrog": n_leapfrog,
        "diagnostics": diagnostics,
        "wall_s": wall_s,
    }


# ---------------------------------------------------------------------------
# Diagnostics: R-hat and ESS
# ---------------------------------------------------------------------------

def gelman_rubin(chains: List[np.ndarray]) -> np.ndarray:
    """Compute Gelman-Rubin R-hat for each parameter.

    Parameters
    ----------
    chains : list of arrays, each shape (n_samples, d)

    Returns
    -------
    r_hat : np.ndarray, shape (d,)
    """
    m = len(chains)
    n = chains[0].shape[0]
    chains_arr = np.array(chains)  # (m, n, d)
    chain_means = chains_arr.mean(axis=1)          # (m, d)
    grand_mean = chain_means.mean(axis=0)          # (d,)
    B = n / (m - 1) * ((chain_means - grand_mean) ** 2).sum(axis=0)
    W = ((chains_arr - chain_means[:, None, :]) ** 2).mean(axis=(0, 1))
    var_hat = (n - 1) / n * W + B / n
    r_hat = np.sqrt(var_hat / (W + 1e-30))
    return r_hat


def effective_sample_size(chain: np.ndarray) -> np.ndarray:
    """Estimate ESS via integrated autocorrelation for each parameter.

    Parameters
    ----------
    chain : np.ndarray, shape (n_samples, d)

    Returns
    -------
    ess : np.ndarray, shape (d,)
    """
    n, d = chain.shape
    ess = np.zeros(d)
    for j in range(d):
        x = chain[:, j]
        mu = x.mean()
        acf_sum = 1.0
        for lag in range(1, n // 2):
            rho = np.corrcoef(x[:-lag], x[lag:])[0, 1]
            if np.isnan(rho) or rho <= 0:
                break
            acf_sum += 2 * rho
        ess[j] = n / max(acf_sum, 1.0)
    return ess


# ---------------------------------------------------------------------------
# Summary helper
# ---------------------------------------------------------------------------

def summarise_chain(result: Dict) -> Dict:
    """Compute posterior mean, std, ESS, and R-hat from a single-chain result.

    For multi-chain R-hat, use ``gelman_rubin`` directly.
    """
    s = result["samples"]  # (n_samples, d)
    ess = effective_sample_size(s)
    summary = {
        "mean": s.mean(axis=0).tolist(),
        "std": s.std(axis=0).tolist(),
        "ess": ess.tolist(),
        "accept_rate": result["accept_rate"],
        "n_grad_evals": result["n_grad_evals"],
        "step_size_final": result["step_size_final"],
        "wall_s": result["wall_s"],
    }
    return summary
