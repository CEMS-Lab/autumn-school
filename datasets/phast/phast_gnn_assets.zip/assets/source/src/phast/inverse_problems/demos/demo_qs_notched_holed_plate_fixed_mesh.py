#!/usr/bin/env python
"""Fixed-mesh differentiable refinement for the quasi-static holed plate.

This is the second stage of the holed-plate inverse plan:

1. use the archived COMSOL-validation H5 as the observation source;
2. start from the coarse circle-fit initializer;
3. refine hole centres/radii with a differentiable fixed-mesh smooth-void
   surrogate.

The key claim boundary is preserved:
- true Gmsh/COMSOL holes are forward-validation geometry;
- the differentiable stage uses a fixed-mesh surrogate only.

The optimisation target is the observed hole boundary points from the H5
archive. The smooth-void surrogate uses a sigmoid transition so the hole
parameters remain ordinary PyTorch variables and can be refined by autograd.
"""
from __future__ import annotations

import argparse
import csv
import json
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
import torch
from matplotlib.patches import Circle

from phast.inverse_problems.demos.demo_qs_notched_holed_plate_inverse import (
    DEFAULT_H5,
    load_boundary_observations,
    HOLE_NODESETS,
    recover_holes,
)


DEFAULT_OUT = Path("examples/inverse_problems/qs_comsol_hole_position/run1/results")


@dataclass(frozen=True)
class RefinementConfig:
    epsilon: float = 0.35
    n_iters: int = 80
    lr: float = 0.15
    radius_weight: float = 0.02
    boundary_weight: float = 1.0
    device: str = "cpu"


def smooth_hole_indicator(points: torch.Tensor,
                          centres: torch.Tensor,
                          radii: torch.Tensor,
                          epsilon: float) -> torch.Tensor:
    """Return a smooth fixed-mesh indicator for the hole interiors.

    ``points`` is ``(N, 2)``. ``centres`` is ``(H, 2)``. ``radii`` is ``(H,)``.
    The returned indicator is in ``(0, 1)`` with values near 1 inside the hole
    and near 0 in the matrix.
    """
    if epsilon <= 0.0:
        raise ValueError("epsilon must be positive")
    diff = points[:, None, :] - centres[None, :, :]
    dist = torch.linalg.vector_norm(diff, dim=-1)
    chi = torch.sigmoid((radii[None, :] - dist) / float(epsilon))
    return 1.0 - torch.prod(1.0 - chi, dim=1)


def hole_boundary_loss(boundary_points: list[torch.Tensor],
                       centres: torch.Tensor,
                       radii: torch.Tensor,
                       epsilon: float,
                       boundary_weight: float,
                       radius_weight: float) -> torch.Tensor:
    losses = []
    contour_losses = []
    for idx, pts in enumerate(boundary_points):
        diff = pts[:, None, :] - centres[None, :, :]
        dist = torch.linalg.vector_norm(diff, dim=-1)
        boundary_residual = dist[:, idx] - radii[idx]
        losses.append((boundary_residual ** 2).mean())
        indicator = smooth_hole_indicator(pts, centres, radii, epsilon)
        contour_losses.append(((indicator - 0.5) ** 2).mean())
    boundary_loss = torch.stack(losses).mean()
    contour_loss = torch.stack(contour_losses).mean()
    radius_reg = ((radii - radii.detach().mean()) ** 2).mean()
    return boundary_weight * (boundary_loss + 0.05 * contour_loss) + radius_weight * radius_reg


def prepare_boundary_points(boundaries: dict[str, np.ndarray]) -> list[torch.Tensor]:
    pts = []
    for nodeset, *_ in HOLE_NODESETS:
        if nodeset not in boundaries:
            raise RuntimeError(f"missing boundary node set: {nodeset}")
        pts.append(torch.tensor(boundaries[nodeset], dtype=torch.float64))
    return pts


def refine_holes(fields: dict,
                 init_rows: list[dict],
                 cfg: RefinementConfig) -> dict:
    boundary_points = prepare_boundary_points(fields["boundaries"])
    device = torch.device(cfg.device)
    centres0 = torch.tensor(
        [
            [
                row.get("recovered_x", row["init_x"]),
                row.get("recovered_y", row["init_y"]),
            ]
            for row in init_rows
        ],
        dtype=torch.float64,
        device=device,
    )
    radii0 = torch.tensor(
        [row.get("recovered_radius", row["truth_radius"]) for row in init_rows],
        dtype=torch.float64,
        device=device,
    )
    centres = torch.nn.Parameter(centres0.clone())
    radii = torch.nn.Parameter(radii0.clone())
    opt = torch.optim.Adam([centres, radii], lr=cfg.lr)
    history: list[dict[str, float]] = []

    for i in range(cfg.n_iters):
        opt.zero_grad()
        loss = hole_boundary_loss(
            boundary_points,
            centres,
            radii,
            cfg.epsilon,
            boundary_weight=cfg.boundary_weight,
            radius_weight=cfg.radius_weight,
        )
        loss.backward()
        opt.step()
        with torch.no_grad():
            radii.clamp_(min=1.0)
        history.append(
            {
                "iter": float(i),
                "loss": float(loss.detach().cpu()),
            }
        )

    rows = []
    for idx, row in enumerate(init_rows):
        recovered = centres.detach().cpu().numpy()[idx]
        rad = float(radii.detach().cpu().numpy()[idx])
        truth = np.array([row["truth_x"], row["truth_y"]], dtype=float)
        init = np.array([row["init_x"], row["init_y"]], dtype=float)
        refinement_start = centres0.detach().cpu().numpy()[idx]
        rows.append(
            {
                **row,
                "refinement_start_x": float(refinement_start[0]),
                "refinement_start_y": float(refinement_start[1]),
                "refinement_start_radius": float(radii0.detach().cpu().numpy()[idx]),
                "refinement_start_error_mm": float(np.linalg.norm(refinement_start - truth)),
                "refined_x": float(recovered[0]),
                "refined_y": float(recovered[1]),
                "refined_radius": rad,
                "refined_error_mm": float(np.linalg.norm(recovered - truth)),
                "init_error_mm": float(np.linalg.norm(init - truth)),
            }
        )
    return {
        "rows": rows,
        "history": history,
        "final_loss": history[-1]["loss"] if history else float("nan"),
        "initial_loss": history[0]["loss"] if history else float("nan"),
    }


def plot_result(fields: dict,
                stage1_rows: list[dict],
                stage2: dict,
                out_dir: Path) -> None:
    nodes = fields["nodes"]
    elements = fields["elements"]
    damage = fields["damage"]
    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)

    fig, axes = plt.subplots(1, 2, figsize=(12.8, 5.8), constrained_layout=True)

    for ax, title, rows, key_x, key_y, key_r in [
        (axes[0], "Stage 1: circle-fit initializer", stage1_rows, "init_x", "init_y", "truth_radius"),
        (axes[1], "Stage 2: smooth fixed-mesh surrogate diagnostic", stage2["rows"], "refined_x", "refined_y", "refined_radius"),
    ]:
        tpc = ax.tripcolor(tri, damage, shading="gouraud", cmap="magma", vmin=0.0, vmax=1.0)
        ax.set_aspect("equal")
        ax.set_xlim(-2, 68)
        ax.set_ylim(-2, 123)
        ax.set_xlabel("$x$ (mm)")
        ax.set_ylabel("$y$ (mm)")
        ax.set_title(title, fontsize=11)
        for row in rows:
            truth = (row["truth_x"], row["truth_y"])
            init = (row[key_x], row[key_y])
            rad = row[key_r]
            ax.add_patch(Circle(truth, row["truth_radius"], fill=False, ec="black", lw=1.2, ls=":"))
            ax.add_patch(Circle(init, rad, fill=False, ec="#2878b5", lw=1.8))
            ax.plot(*truth, marker="*", ms=8, color="black")
            ax.plot(*init, marker="o", ms=4, color="#2878b5")
        ax.grid(alpha=0.12)

    fig.colorbar(tpc, ax=axes, fraction=0.028, pad=0.015, label="damage $d$")
    fig.savefig(out_dir / "qs_comsol_hole_position_fixed_mesh.png", dpi=250)
    fig.savefig(out_dir / "qs_comsol_hole_position_fixed_mesh.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.0, 4.2), constrained_layout=True)
    ax.plot([r["iter"] for r in stage2["history"]],
            [r["loss"] for r in stage2["history"]],
            "-o", ms=3.5, lw=1.5, color="#1f77b4")
    ax.set_xlabel("Adam iteration")
    ax.set_ylabel("boundary loss")
    ax.set_yscale("log")
    ax.set_title("Stage 2 smooth-surrogate boundary diagnostic")
    ax.grid(True, which="both", alpha=0.25)
    rows = stage2["rows"]
    start_err = max(row["refinement_start_error_mm"] for row in rows)
    refined_err = max(row["refined_error_mm"] for row in rows)
    loss0 = float(stage2["history"][0]["loss"])
    loss1 = float(stage2["history"][-1]["loss"])
    loss_drop = 100.0 * (loss0 - loss1) / max(abs(loss0), 1.0e-30)
    ax.text(
        0.05,
        0.05,
        "Stage 1 circle fit is the primary geometry recovery.\n"
        f"Smooth surrogate diagnostic remains sub-grid: {start_err:.3f} -> {refined_err:.3f} mm\n"
        f"local boundary loss drop: {loss_drop:.1f}%",
        transform=ax.transAxes,
        fontsize=8,
        va="bottom",
        bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor="0.75", alpha=0.92),
    )
    fig.savefig(out_dir / "qs_comsol_hole_position_loss.png", dpi=220)
    plt.close(fig)


def write_outputs(stage1_rows: list[dict], stage2: dict, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    payload = {"stage1": stage1_rows, "stage2": stage2["rows"], "history": stage2["history"]}
    (out_dir / "qs_comsol_hole_position_refinement.json").write_text(
        json.dumps(payload, indent=2) + "\n"
    )
    with (out_dir / "qs_comsol_hole_position_refinement.csv").open("w", newline="") as fh:
        fieldnames = [
            "nodeset",
            "label",
            "truth_x",
            "truth_y",
            "truth_radius",
            "init_x",
            "init_y",
            "recovered_x",
            "recovered_y",
            "recovered_radius",
            "refinement_start_x",
            "refinement_start_y",
            "refinement_start_radius",
            "refined_x",
            "refined_y",
            "refined_radius",
            "init_error_mm",
            "recovered_error_mm",
            "refinement_start_error_mm",
            "refined_error_mm",
        ]
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for row in stage2["rows"]:
            writer.writerow({k: row.get(k) for k in fieldnames})


def run(h5: Path = DEFAULT_H5,
        out_dir: Path = DEFAULT_OUT,
        *,
        epsilon: float = 0.35,
        n_iters: int = 80,
        lr: float = 0.15,
        boundary_weight: float = 1.0,
        radius_weight: float = 0.02,
        device: str = "cpu",
        from_damage_contour: bool = False,
        contour_level: float = 0.5,
        damage_step: str | int | None = None,
        boundary_csv: Path | None = None) -> dict:
    boundaries, fields = load_boundary_observations(
        h5,
        from_damage_contour=from_damage_contour,
        contour_level=contour_level,
        damage_step=damage_step,
        boundary_csv=boundary_csv,
    )
    fields = dict(fields)
    fields["boundaries"] = boundaries
    stage1_rows = recover_holes(fields["boundaries"])
    cfg = RefinementConfig(
        epsilon=epsilon,
        n_iters=n_iters,
        lr=lr,
        boundary_weight=boundary_weight,
        radius_weight=radius_weight,
        device=device,
    )
    stage2 = refine_holes(fields, stage1_rows, cfg)
    out_dir.mkdir(parents=True, exist_ok=True)
    write_outputs(stage1_rows, stage2, out_dir)
    plot_result(fields, stage1_rows, stage2, out_dir)
    return {
        "h5": str(h5),
        "out_dir": str(out_dir),
        "stage1": stage1_rows,
        "stage2": stage2["rows"],
        "initial_loss": stage2["initial_loss"],
        "final_loss": stage2["final_loss"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Fixed-mesh differentiable refinement for the quasi-static holed plate."
    )
    parser.add_argument("--h5", type=Path, default=DEFAULT_H5)
    parser.add_argument("--out_dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--epsilon", type=float, default=0.35)
    parser.add_argument("--n_iters", type=int, default=80)
    parser.add_argument("--lr", type=float, default=0.15)
    parser.add_argument("--boundary_weight", type=float, default=1.0)
    parser.add_argument("--radius_weight", type=float, default=0.02)
    parser.add_argument(
        "--damage_step",
        type=str,
        default=None,
        help="Step key (name or index) in h5. Default is final step.",
    )
    parser.add_argument(
        "--from_damage_contour",
        action="store_true",
        help="Recover boundary loops from a damage isocontour instead of node sets.",
    )
    parser.add_argument(
        "--contour_level",
        type=float,
        default=0.5,
        help="Contour level in [0,1] for damage extraction mode.",
    )
    parser.add_argument(
        "--observed_boundary_csv",
        type=Path,
        default=None,
        help=(
            "Optional CSV with columns nodeset,x,y to run refinement from observed "
            "boundary points only."
        ),
    )
    parser.add_argument("--device", type=str, default="cpu")
    args = parser.parse_args()
    result = run(
        args.h5,
        args.out_dir,
        epsilon=args.epsilon,
        n_iters=args.n_iters,
        lr=args.lr,
        boundary_weight=args.boundary_weight,
        radius_weight=args.radius_weight,
        device=args.device,
        from_damage_contour=args.from_damage_contour,
        contour_level=args.contour_level,
        damage_step=args.damage_step,
        boundary_csv=args.observed_boundary_csv,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
