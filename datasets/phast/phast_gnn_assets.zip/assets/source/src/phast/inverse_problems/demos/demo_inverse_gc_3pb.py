#!/usr/bin/env python
"""Gc(x) recovery on a three-point bending (3PB) specimen.

Geometry: W x H rectangular beam, bottom-center notch of depth `a`.
Load:     downward displacement at top-center (load_point); rollers at
          bottom-left and bottom-right corners (support_left, support_right).
Crack:    propagates upward (+y) from the notch tip.
Gc(x):    horizontal Gaussian weak band — crack deflects left/right
          toward the zone of lower toughness.

Why 3PB instead of SENT
-----------------------
In SENT the loading applies tension across the FULL top/bottom boundaries,
creating a mode-I stress concentration that pins the crack to the notch
plane (y = H/2).  A Gc(y) variation cannot deflect the crack because the
notch-tip stress dominates.

In 3PB the notch is at the BOTTOM centre and the crack propagates in +y.
The bending stress is distributed across the full bottom span, so a Gc(x)
weak zone away from centre (x ≠ W/2) sees non-negligible elastic energy.
The phase-field driving force ψ_el / Gc can exceed the value at the notch
tip when the Gc reduction is strong enough, attracting damage toward the
weaker zone.  The resulting x-deflection of the crack path is the key
identifiable observable.

Observable
----------
Damage-weighted crack centroid x(y): at each y-bin compute the
damage-mass-weighted x-centroid.  This is the transpose of the SENT
path observable y(x).
"""
from __future__ import annotations
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.mesh_generator import three_point_bending as gen_mesh
from phast.mesh import FEMMesh
from phast.material import create_material
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.config import LoadingConfig, compute_load_factor
from phast.device import DeviceContext

# Bleyer PMMA constants (shared with all Paper-2 demos).
NU = 0.35
RHO = 1.18e-9          # tonne/mm³
GC = 0.3               # N/mm
L0 = 0.1               # mm
E_BULK = 3090.0        # MPa

# Default 3PB geometry at Bleyer scale.
# Span-to-height ratio 4:1; notch depth = H/4.
W_3PB, H_3PB, A_3PB = 64.0, 16.0, 4.0

DEFAULT_X0 = W_3PB / 2.0 - 8.0   # 24 mm  (8 mm left of centre)
DEFAULT_SIGMA = 2.0
DEFAULT_WEAK_FRACTION = 0.5


# ---------------------------------------------------------------------------
# Gc field
# ---------------------------------------------------------------------------

def horizontal_band_field(centroids, x0, sigma, weak_fraction,
                           Gc_nominal=GC):
    """Per-element Gc with a vertical weak band at x = x0 (same as SENT demo)."""
    x_c = centroids[:, 0]
    bump = torch.exp(-((x_c - x0) ** 2) / (2.0 * sigma ** 2))
    return Gc_nominal * (1.0 - weak_fraction * bump)


# ---------------------------------------------------------------------------
# Mesh & solver
# ---------------------------------------------------------------------------

def build_3pb_mesh(h_crack, h_coarse, device, dtype,
                   W=W_3PB, H=H_3PB, a=A_3PB):
    """Three-point bending beam: W x H with bottom-centre notch of depth a."""
    _tag = os.environ.get('SLURM_JOB_ID', f'pid{os.getpid()}')
    msh = f"/tmp/gc_3pb_bleyer_{_tag}.msh"
    gen_mesh(msh, W=W, H=H, a=a, l0=L0,
             h_crack=h_crack, h_coarse=h_coarse)
    mesh = FEMMesh(msh, device=device, dtype=dtype)
    mesh.identify_boundaries()
    print(f"[3PB] node_sets: {list(mesh.node_sets.keys())}", flush=True)
    return mesh, msh


def build_solver_3pb(mesh, dU, tau_ramp, damping_zeta, device, dtype,
                     H_update_method='custom_subgrad',
                     H_update_scale=None):
    mat = create_material(
        E=E_BULK, nu=NU, rho=RHO, Gc=GC, l0=L0,
        energy_split='amor', pf_model='AT1', plane_stress=True,
        gamma_correction=True,
    )
    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)

    # Downward load at top centre.
    if 'load_point' in mesh.node_sets and len(mesh.node_sets['load_point']) > 0:
        bcs.add(mesh.node_sets['load_point'], component=1, value=-dU)
    else:
        # Fallback: find top-centre node by coordinate.
        xc = mesh.nodes[:, 0]
        yc = mesh.nodes[:, 1]
        W_mesh = float(xc.max())
        H_mesh = float(yc.max())
        tol = 2.0 * float(mesh.nodes[mesh.elements].diff(dim=1).norm(dim=-1).max())
        top_centre = ((xc - W_mesh / 2.0).abs() < tol) & ((yc - H_mesh).abs() < tol)
        idx = torch.where(top_centre)[0]
        if len(idx) == 0:
            raise RuntimeError("Could not find load_point node.")
        bcs.add(idx, component=1, value=-dU)

    # Roller supports: fix u_y = 0 at both bottom corners.
    for key in ('support_left', 'support_right'):
        if key in mesh.node_sets and len(mesh.node_sets[key]) > 0:
            bcs.add(mesh.node_sets[key], component=1, value=0.0)
        else:
            raise RuntimeError(f"node_set '{key}' not found in mesh.")

    # Pin left support in x (prevent rigid-body translation).
    bcs.fix(mesh.node_sets['support_left'], component=0)

    cfg = SolverConfig(
        solver_type='explicit', differentiable=True,
        damage_every=1, preconditioner='jacobi',
        damping_ratio_max=damping_zeta,
        H_update_method=H_update_method,
        H_update_scale=H_update_scale,
    )
    return StaggeredSolver(mesh, mat, bcs, config=cfg,
                           ctx=DeviceContext(device, dtype))


# ---------------------------------------------------------------------------
# Observables
# ---------------------------------------------------------------------------

def differentiable_crack_path_x(d_node, node_x, node_y, y_bins, sigma_bin,
                                  p=4):
    """Damage-weighted crack centroid x(y) — transpose of SENT path y(x).

    For each y-bin centre y_b:
        x_b = Σ_n w_n * x_n / Σ_n w_n
    with w_n = d_n^p * exp(-(y_n - y_b)^2 / (2 σ²)).
    """
    diff = node_y.unsqueeze(0) - y_bins.unsqueeze(1)
    spatial_w = torch.exp(-(diff ** 2) / (2.0 * sigma_bin ** 2))
    damage_w = torch.clamp(d_node, min=0.0).pow(p)
    w = spatial_w * damage_w.unsqueeze(0)
    mass = w.sum(dim=1)
    x_pred = (w * node_x.unsqueeze(0)).sum(dim=1) / (mass + 1e-12)
    return x_pred, mass


def run_forward(solver, loading, Gc_field, n_steps,
                snapshot_steps=None, checkpoint_chunks=0,
                detach_snapshots=True):
    n_nodes = solver.mesh.n_nodes
    n_elem = solver.mesh.n_elems
    dt = solver.dtype
    dev = solver.device
    solver.u = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.v = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.a = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.d = torch.zeros(n_nodes, dtype=dt, device=dev)
    solver.H_elem = torch.zeros(n_elem, dtype=dt, device=dev)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dt, device=dev)
    solver._step_count = 0
    solver.diff_Gc_field = Gc_field
    snap_set = set(snapshot_steps) if snapshot_steps else set()
    snaps = [] if snapshot_steps else None
    solver_dt = solver.dt

    use_checkpoint = (
        checkpoint_chunks > 0 and torch.is_grad_enabled()
        and Gc_field.requires_grad
    )

    _progress_every = max(1, min(n_steps // 20, 1000))
    _t0 = time.time()

    if not use_checkpoint:
        for step in range(n_steps):
            solver.bcs.load_factor = compute_load_factor(
                step, solver_dt, loading)
            solver.step_full()
            if step + 1 in snap_set:
                snap = (solver.d.detach().cpu().numpy().copy()
                        if detach_snapshots else solver.d)
                snaps.append((step + 1, snap))
            if (step + 1) % _progress_every == 0:
                print(f"    step {step+1}/{n_steps}  "
                      f"max(d)={float(solver.d.max()):.3f}  "
                      f"({time.time()-_t0:.1f}s)", flush=True)
        return solver.d, snaps

    # Checkpoint path
    def _chunk(u_in, v_in, a_in, d_in, He_in, Hn_in, base_step, k_steps):
        solver.u, solver.v, solver.a = u_in, v_in, a_in
        solver.d = d_in
        solver.H_elem, solver.H_nodal = He_in, Hn_in
        solver._step_count = base_step
        for j in range(k_steps):
            solver.bcs.load_factor = compute_load_factor(
                base_step + j, solver_dt, loading)
            solver.step_full()
        return (solver.u, solver.v, solver.a, solver.d,
                solver.H_elem, solver.H_nodal)

    chunk_size = (n_steps + checkpoint_chunks - 1) // checkpoint_chunks
    u, v, a, d = solver.u, solver.v, solver.a, solver.d
    He, Hn = solver.H_elem, solver.H_nodal
    n_chunks = (n_steps + chunk_size - 1) // chunk_size
    base = 0
    ci = 0
    _prog = max(1, n_chunks // 20)
    while base < n_steps:
        k = min(chunk_size, n_steps - base)
        u, v, a, d, He, Hn = torch.utils.checkpoint.checkpoint(
            _chunk, u, v, a, d, He, Hn, base, k,
            use_reentrant=False,
        )
        ci += 1
        if ci % _prog == 0 or ci == n_chunks:
            mem_str = ""
            if torch.cuda.is_available():
                mb = torch.cuda.max_memory_allocated() / 1024 ** 2
                mem_str = f", cuda_peak={mb:.0f} MB"
                torch.cuda.reset_peak_memory_stats()
            print(f"    chunk {ci}/{n_chunks} (step {base+k}/{n_steps}, "
                  f"max(d)={float(d.detach().max()):.3f}, "
                  f"{time.time()-_t0:.1f}s{mem_str})", flush=True)
        base += k
    solver.u, solver.v, solver.a, solver.d = u, v, a, d
    solver.H_elem, solver.H_nodal = He, Hn
    return solver.d, snaps


# ---------------------------------------------------------------------------
# Visualisation
# ---------------------------------------------------------------------------

def _save_damage_png(d_np, node_x_np, node_y_np, elements_np,
                     out_path, title="", gc_band_x0=None, W=W_3PB):
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import matplotlib.tri as mtri
    except ImportError:
        return

    rc = {
        'font.family': 'STIXGeneral',
        'mathtext.fontset': 'stix',
        'font.size': 10,
    }
    with plt.rc_context(rc):
        fig, ax = plt.subplots(figsize=(6, 3))
        tri = mtri.Triangulation(node_x_np, node_y_np, elements_np)
        tc = ax.tripcolor(tri, d_np, vmin=0, vmax=1,
                          cmap='inferno', shading='gouraud')
        plt.colorbar(tc, ax=ax, label='d')
        if gc_band_x0 is not None:
            ax.axvline(gc_band_x0, color='cyan', lw=1.5, ls='--', label=f'x0={gc_band_x0:.1f}')
            ax.axvline(W / 2.0, color='white', lw=1.0, ls=':', label='centre')
            ax.legend(fontsize=8, loc='upper right')
        ax.set_aspect('equal')
        ax.set_xlabel('x (mm)')
        ax.set_ylabel('y (mm)')
        ax.set_title(title)
        fig.tight_layout()
        fig.savefig(out_path, dpi=150)
        plt.close(fig)


def _make_gif(snaps_list, node_x_np, node_y_np, elements_np,
              out_path, W=W_3PB):
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import matplotlib.tri as mtri
        from matplotlib.animation import PillowWriter
    except ImportError:
        return
    if not snaps_list:
        return

    rc = {
        'font.family': 'STIXGeneral',
        'mathtext.fontset': 'stix',
        'font.size': 9,
    }
    with plt.rc_context(rc):
        fig, ax = plt.subplots(figsize=(6, 3))
        tri = mtri.Triangulation(node_x_np, node_y_np, elements_np)
        tc = ax.tripcolor(tri, snaps_list[0][1], vmin=0, vmax=1,
                          cmap='inferno', shading='gouraud')
        plt.colorbar(tc, ax=ax, label='d')
        ax.set_aspect('equal')
        ax.set_xlabel('x (mm)')
        ax.set_ylabel('y (mm)')
        title_obj = ax.set_title('')
        writer = PillowWriter(fps=8)
        with writer.saving(fig, out_path, dpi=100):
            for step_id, d_snap in snaps_list:
                tc.set_array(d_snap)
                title_obj.set_text(f'step {step_id}  max(d)={d_snap.max():.3f}')
                writer.grab_frame()
        plt.close(fig)


# ---------------------------------------------------------------------------
# CLI & main
# ---------------------------------------------------------------------------

def build_parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--device', type=str, default='cpu')
    p.add_argument('--dtype', type=str, default='float64',
                   choices=['float32', 'float64'])
    p.add_argument('--h_crack', type=float, default=None)
    p.add_argument('--h_coarse', type=float, default=None)
    p.add_argument('--n_steps', type=int, default=None)
    p.add_argument('--n_iters', type=int, default=8)
    p.add_argument('--delta_U', type=float, default=0.05)
    p.add_argument('--tau_ramp_us', type=float, default=60.0)
    p.add_argument('--damping_zeta', type=float, default=0.05)
    p.add_argument('--H_update_method', type=str, default='custom_subgrad',
                   choices=['hard_max', 'softmax', 'smooth_max',
                            'log_smooth', 'custom_subgrad'])
    p.add_argument('--H_update_scale', type=float, default=None)
    # Geometry
    p.add_argument('--W', type=float, default=W_3PB,
                   help=f'Beam span (mm). Default {W_3PB}.')
    p.add_argument('--H_beam', type=float, default=H_3PB,
                   help=f'Beam height (mm). Default {H_3PB}.')
    p.add_argument('--notch_depth', type=float, default=A_3PB,
                   help=f'Notch depth a (mm). Default {A_3PB}.')
    # Gc band parameters
    p.add_argument('--x0_truth', type=float, default=DEFAULT_X0,
                   help='Truth band centre x (mm).')
    p.add_argument('--sigma_truth', type=float, default=DEFAULT_SIGMA)
    p.add_argument('--weak_fraction', type=float, default=DEFAULT_WEAK_FRACTION)
    p.add_argument('--x0_init', type=float, default=None,
                   help='Initial x0 guess. Default: W/2 (centred).')
    p.add_argument('--sigma_init', type=float, default=None)
    # Optimisation
    p.add_argument('--param', type=str, default='low_rank',
                   choices=['low_rank'])
    p.add_argument('--obs_mode', type=str, default='path',
                   choices=['path', 'full'],
                   help='path=crack centroid x(y); full=damage MSE.')
    p.add_argument('--n_path_bins', type=int, default=30,
                   help='y-bins for obs_mode=path.')
    p.add_argument('--path_sigma_factor', type=float, default=0.8)
    p.add_argument('--checkpoint_chunks', type=int, default=0,
                   help='Gradient-checkpointing chunks (0 = full BPTT).')
    # Gate
    p.add_argument('--observability_gate', action='store_true')
    p.add_argument('--gate_alphas', type=str, default='0.0,0.25,0.5,0.75,1.0')
    p.add_argument('--gate_fd_rel_step', type=float, default=1e-3)
    # Output
    p.add_argument('--save_snapshots', type=int, default=0)
    p.add_argument('--n_viz_frames', type=int, default=12)
    p.add_argument('--forward_only', action='store_true')
    p.add_argument('--save_forward_viz', dest='save_forward_viz',
                   action='store_true', default=True)
    p.add_argument('--no_save_forward_viz', dest='save_forward_viz',
                   action='store_false')
    p.add_argument('--output_dir', type=str, default='results_gc_3pb')
    # Presets
    p.add_argument('--smoke', action='store_true',
                   help='h_crack=0.4, h_coarse=2.0, n_steps=1500 (Mac CPU test).')
    return p


def main():
    args = build_parser().parse_args()

    if args.smoke:
        h_crack  = args.h_crack  or 0.4
        h_coarse = args.h_coarse or 2.0
        n_steps  = args.n_steps  or 1500
    else:
        h_crack  = args.h_crack  or 0.05
        h_coarse = args.h_coarse or 0.5
        n_steps  = args.n_steps  or 6000

    W = args.W
    H = args.H_beam
    A = args.notch_depth

    out_dir = (args.output_dir if os.path.isabs(args.output_dir)
               else os.path.join(THIS_DIR, args.output_dir))
    os.makedirs(out_dir, exist_ok=True)

    device = args.device
    dtype = torch.float64 if args.dtype == 'float64' else torch.float32
    tau_ramp = args.tau_ramp_us * 1e-6

    print("=" * 72)
    print("  Gc(x) recovery — 3-point bending (3PB) specimen")
    print("=" * 72)
    print(f"  Plate: {W} x {H} mm, notch a = {A} mm")
    print(f"  Truth band: x0 = {args.x0_truth} mm, "
          f"sigma = {args.sigma_truth} mm, wf = {args.weak_fraction}")
    print(f"  obs_mode={args.obs_mode}, param={args.param}")
    print(f"  h_crack={h_crack}, h_coarse={h_coarse}, n_steps={n_steps}")
    print(f"  device={device}, dtype={args.dtype}")

    mesh, msh_path = build_3pb_mesh(h_crack, h_coarse, device, dtype,
                                     W=W, H=H, a=A)
    solver = build_solver_3pb(mesh, args.delta_U, tau_ramp,
                               args.damping_zeta, device, dtype,
                               H_update_method=args.H_update_method,
                               H_update_scale=args.H_update_scale)

    centroids = mesh.nodes[mesh.elements].mean(dim=1)
    n_nodes = mesh.n_nodes
    n_elem = mesh.n_elems
    node_x = mesh.nodes[:, 0]
    node_y = mesh.nodes[:, 1]
    node_x_np = node_x.cpu().numpy()
    node_y_np = node_y.cpu().numpy()
    elem_np = mesh.elements.cpu().numpy()
    loading = LoadingConfig(ramp_type='smooth', t_ramp=tau_ramp)

    print(f"  Mesh: {n_nodes} nodes, {n_elem} elements")
    print(f"  dt = {solver.dt:.3e} s  total = {solver.dt * n_steps * 1e6:.1f} us")

    # Band parameters (always low_rank for now)
    wf = torch.tensor(args.weak_fraction, dtype=dtype, device=device)

    def _build_gc(x0_t, log_sigma_t):
        return horizontal_band_field(
            centroids, x0_t, torch.exp(log_sigma_t), wf)

    # Path observable: y-bins from just above notch to top
    y_bins_np = np.linspace(A + 0.5 * h_coarse, H - 0.5 * h_coarse,
                            args.n_path_bins)
    y_bins = torch.tensor(y_bins_np, dtype=dtype, device=device)
    sigma_bin = args.path_sigma_factor * float(y_bins[1] - y_bins[0])

    # -----------------------------------------------------------------------
    # Truth forward pass
    # -----------------------------------------------------------------------
    x0_truth = torch.tensor(args.x0_truth, dtype=dtype, device=device)
    log_sigma_truth = torch.tensor(math.log(args.sigma_truth),
                                   dtype=dtype, device=device)
    Gc_true = _build_gc(x0_truth, log_sigma_truth)

    snap_count = max(args.save_snapshots,
                     args.n_viz_frames if args.save_forward_viz else 0)
    snap_steps_viz = (
        list(np.linspace(max(int(0.05 * n_steps), 1), n_steps,
                         snap_count, dtype=int).tolist())
        if snap_count > 0 else None
    )

    print("\n--- Truth forward ---")
    t0 = time.time()
    with torch.no_grad():
        d_true, snaps_truth = run_forward(
            solver, loading, Gc_true, n_steps,
            snapshot_steps=snap_steps_viz)
    d_true_np = d_true.cpu().numpy()
    print(f"    done ({time.time()-t0:.1f}s)  max(d)={float(d_true.max()):.4f}")
    np.save(os.path.join(out_dir, 'truth.npy'), d_true_np)

    # Damage-weighted path observable from truth
    with torch.no_grad():
        x_path_true, mass_true = differentiable_crack_path_x(
            d_true, node_x, node_y, y_bins, sigma_bin)
        mass_mask = (mass_true / (mass_true.max() + 1e-12)) > 0.05

    if mass_mask.any():
        print(f"    path x-range: "
              f"{float(x_path_true[mass_mask].min()):.2f} … "
              f"{float(x_path_true[mass_mask].max()):.2f} mm")
        print(f"    x-centroid mean: {float(x_path_true[mass_mask].mean()):.2f} mm "
              f"(truth x0={args.x0_truth:.1f}, centre={W/2:.1f})")
    else:
        print("    WARNING: no significant crack damage detected — "
              "increase delta_U or n_steps")

    if args.save_forward_viz and snaps_truth:
        _save_damage_png(
            d_true_np, node_x_np, node_y_np, elem_np,
            os.path.join(out_dir, 'truth_damage_final.png'),
            title=f'Truth  x0={args.x0_truth:.1f} mm',
            gc_band_x0=args.x0_truth, W=W)
        _make_gif(
            snaps_truth, node_x_np, node_y_np, elem_np,
            os.path.join(out_dir, 'truth_damage_evolution.gif'), W=W)
        print("    saved truth viz")

    if args.forward_only:
        print("--forward_only  done.")
        return

    # -----------------------------------------------------------------------
    # Observability gate
    # -----------------------------------------------------------------------
    x0_init_val = args.x0_init if args.x0_init is not None else W / 2.0
    sigma_init_val = (args.sigma_init if args.sigma_init is not None
                      else args.sigma_truth)

    def _eval_loss(x0_val, sig_val):
        x0_t = torch.tensor(x0_val, dtype=dtype, device=device)
        ls_t = torch.tensor(math.log(sig_val), dtype=dtype, device=device)
        Gc_f = _build_gc(x0_t, ls_t)
        d_out, _ = run_forward(solver, loading, Gc_f, n_steps)
        if args.obs_mode == 'path':
            x_pred, _ = differentiable_crack_path_x(
                d_out, node_x, node_y, y_bins, sigma_bin)
            residual = (x_pred - x_path_true.detach())[mass_mask]
            return 0.5 * (residual ** 2).mean()
        else:
            return 0.5 * ((d_out - d_true.detach()) ** 2).mean()

    if args.observability_gate:
        print("\n=== Observability gate ===")
        alphas = [float(a) for a in args.gate_alphas.split(',')]
        step = args.gate_fd_rel_step * max(abs(args.x0_truth - x0_init_val),
                                           abs(args.x0_truth),
                                           1.0)

        losses = []
        for alpha in alphas:
            x0_a = x0_init_val + alpha * (args.x0_truth - x0_init_val)
            with torch.no_grad():
                L = float(_eval_loss(x0_a, sigma_init_val))
            print(f"  alpha={alpha:.2f}  x0={x0_a:.2f}  loss={L:.4e}")
            losses.append(L)

        # FD Jacobian wrt x0
        with torch.no_grad():
            Lp = float(_eval_loss(x0_init_val + step, sigma_init_val))
            Lm = float(_eval_loss(x0_init_val - step, sigma_init_val))
        fd_grad_x0 = (Lp - Lm) / (2 * step)

        # Truth direction: (x0_truth - x0_init, 0)
        delta = args.x0_truth - x0_init_val
        truth_dir_norm = abs(delta)
        cos_descent = (fd_grad_x0 * delta / (abs(fd_grad_x0) * truth_dir_norm + 1e-30)
                       if truth_dir_norm > 0 else 0.0)

        print(f"\n  FD dL/dx0 = {fd_grad_x0:.4e}")
        print(f"  loss_at_init = {losses[0]:.4e}")
        print(f"  col_norm_x0 = {abs(fd_grad_x0):.4e}")
        print(f"  cos(descent, truth) = {cos_descent:.4f}")

        gate_pass = (losses[0] > 1e-15 and abs(fd_grad_x0) > 1e-10
                     and cos_descent > 0.0)
        print(f"\n  Gate: {'PASS' if gate_pass else 'FAIL'}")

        gate_result = {
            'losses': dict(zip([str(a) for a in alphas], losses)),
            'fd_grad_x0': fd_grad_x0,
            'loss_at_init': losses[0],
            'col_norm_x0': abs(fd_grad_x0),
            'cos_descent_truth': cos_descent,
            'gate_pass': gate_pass,
        }
        with open(os.path.join(out_dir, 'gate_result.json'), 'w') as f:
            json.dump(gate_result, f, indent=2)
        print(f"  gate_result.json written to {out_dir}")
        return

    # -----------------------------------------------------------------------
    # Init forward (for viz)
    # -----------------------------------------------------------------------
    if args.save_forward_viz:
        x0_init_t = torch.tensor(x0_init_val, dtype=dtype, device=device)
        ls_init_t = torch.tensor(math.log(sigma_init_val), dtype=dtype, device=device)
        Gc_init = _build_gc(x0_init_t, ls_init_t)
        print("\n--- Init forward (viz) ---")
        with torch.no_grad():
            d_init, snaps_init = run_forward(
                solver, loading, Gc_init, n_steps,
                snapshot_steps=snap_steps_viz)
        d_init_np = d_init.cpu().numpy()
        print(f"    max(d)={float(d_init.max()):.4f}")
        _save_damage_png(
            d_init_np, node_x_np, node_y_np, elem_np,
            os.path.join(out_dir, 'init_damage_final.png'),
            title=f'Init  x0={x0_init_val:.1f} mm',
            gc_band_x0=x0_init_val, W=W)
        _make_gif(
            snaps_init, node_x_np, node_y_np, elem_np,
            os.path.join(out_dir, 'init_damage_evolution.gif'), W=W)
        with torch.no_grad():
            x_path_init, _ = differentiable_crack_path_x(
                d_init, node_x, node_y, y_bins, sigma_bin)
        x_init_mean = float(x_path_init[mass_mask].mean()) if mass_mask.any() else float('nan')
        x_true_mean = float(x_path_true[mass_mask].mean()) if mass_mask.any() else float('nan')
        print(f"    init x-centroid = {x_init_mean:.2f} mm  "
              f"truth = {x_true_mean:.2f} mm  "
              f"diff = {x_true_mean - x_init_mean:.2f} mm")

    # -----------------------------------------------------------------------
    # L-BFGS inversion
    # -----------------------------------------------------------------------
    print(f"\n--- Inversion: {args.n_iters} iters ---")
    x0_p = torch.tensor(x0_init_val, dtype=dtype, device=device,
                         requires_grad=True)
    ls_p = torch.tensor(math.log(sigma_init_val), dtype=dtype, device=device,
                        requires_grad=True)

    optimizer = torch.optim.LBFGS([x0_p, ls_p], lr=1.0,
                                   max_iter=20, history_size=10,
                                   line_search_fn='strong_wolfe')

    history = {'iter': [], 'loss': [], 'x0': [], 'sigma': [], 'x0_err_mm': [],
               'wall_s': []}
    t_inv_start = time.time()

    for it in range(args.n_iters):
        def closure():
            optimizer.zero_grad()
            Gc_f = _build_gc(x0_p, ls_p)
            d_out, _ = run_forward(
                solver, loading, Gc_f, n_steps,
                checkpoint_chunks=args.checkpoint_chunks)
            if args.obs_mode == 'path':
                x_pred, _ = differentiable_crack_path_x(
                    d_out, node_x, node_y, y_bins, sigma_bin)
                residual = (x_pred - x_path_true.detach())[mass_mask]
                loss = 0.5 * (residual ** 2).mean()
            else:
                loss = 0.5 * ((d_out - d_true.detach()) ** 2).mean()
            loss.backward()
            return loss

        loss_val = optimizer.step(closure)
        wall = time.time() - t_inv_start
        x0_cur = float(x0_p.detach())
        sig_cur = float(torch.exp(ls_p).detach())
        err = abs(x0_cur - args.x0_truth)

        history['iter'].append(it)
        history['loss'].append(float(loss_val))
        history['x0'].append(x0_cur)
        history['sigma'].append(sig_cur)
        history['x0_err_mm'].append(err)
        history['wall_s'].append(wall)

        print(f"  iter {it:3d}  loss={float(loss_val):.4e}  "
              f"x0={x0_cur:.3f} (err={err:.3f} mm)  "
              f"sigma={sig_cur:.3f}  wall={wall:.1f}s", flush=True)

    x0_final = float(x0_p.detach())
    sig_final = float(torch.exp(ls_p).detach())
    result = {
        'x0_truth': args.x0_truth,
        'sigma_truth': args.sigma_truth,
        'weak_fraction': args.weak_fraction,
        'x0_recovered': x0_final,
        'sigma_recovered': sig_final,
        'x0_err_mm': abs(x0_final - args.x0_truth),
        'wall_s': time.time() - t_inv_start,
        'history': history,
    }
    out_json = os.path.join(out_dir, 'demo_inverse_gc_3pb.json')
    with open(out_json, 'w') as f:
        json.dump(result, f, indent=2)
    print(f"\n  Final: x0={x0_final:.4f} mm  err={abs(x0_final-args.x0_truth):.4f} mm")
    print(f"  Results written to {out_json}")


if __name__ == '__main__':
    main()
