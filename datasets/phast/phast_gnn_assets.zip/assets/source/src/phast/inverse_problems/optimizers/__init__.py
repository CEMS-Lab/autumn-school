"""Inverse-problem optimizers for paper 2.

Currently exposes:

* :class:`ESOptimizer` -- gradient-free Evolutionary Strategies baseline
  (Salimans et al. 2017; Suh et al. 2022 §5).
"""
from .es_optimizer import ESOptimizer

__all__ = ["ESOptimizer"]
