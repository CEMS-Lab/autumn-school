"""Identifiability diagnostics for inverse problems (issue #476).

The external review (papers/paper3/notes/external_review_responses_2026-05-09.md,
Q1) flagged that two Gc fields can produce indistinguishable damage
"attractors" once the dissipation rate equilibrates. The Fisher
Information Matrix (FIM) evaluated at the truth parameter set is the
canonical local-identifiability test: a rank-deficient FIM means at
least one parameter direction is unobservable from the chosen
observable.

This sub-module ships the building blocks but does NOT bake the
diagnostic into any demo (follow-up PR).
"""
from .identifiability import (
    fim_finite_difference,
    fim_autograd,
    identifiability_report,
)
from .observability_gate import (
    jacobian_reverse,
    jacobian_finite_difference,
    jacobian_summary,
    loss_and_gradient,
    descent_alignment,
    line_probe,
    observability_gate_report,
    observability_gate_report_fd,
)
from .crack_path_initializer import (
    damage_weighted_path,
    infer_crack_axis,
    estimate_particle_initializers,
)
from .cnn_particle_initializer import (
    ParticleCNNConfig,
    TinyParticleInitializerCNN,
    normalise_damage_image,
    rasterize_nodal_field,
    normalized_to_physical,
    physical_to_normalized,
    predict_particle_initializers,
)

__all__ = [
    'fim_finite_difference',
    'fim_autograd',
    'identifiability_report',
    'jacobian_reverse',
    'jacobian_finite_difference',
    'jacobian_summary',
    'loss_and_gradient',
    'descent_alignment',
    'line_probe',
    'observability_gate_report',
    'observability_gate_report_fd',
    'damage_weighted_path',
    'infer_crack_axis',
    'estimate_particle_initializers',
    'ParticleCNNConfig',
    'TinyParticleInitializerCNN',
    'normalise_damage_image',
    'rasterize_nodal_field',
    'normalized_to_physical',
    'physical_to_normalized',
    'predict_particle_initializers',
]
