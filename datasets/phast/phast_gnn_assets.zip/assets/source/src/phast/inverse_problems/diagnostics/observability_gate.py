"""Pre-optimisation observability gate for inverse demos.

The FIM-at-truth diagnostic answers whether an observable can identify
parameters locally at the answer. Before burning GPU time, we also need
the operational question at the initial guess:

* does the chosen observable have non-trivial sensitivity to each free
  parameter?
* is the local descent direction aligned with the synthetic truth?
* does the loss decrease along the simple init-to-truth line?

This module keeps those checks solver-agnostic. Callers provide a
differentiable ``observable_fn(theta)``; the gate assembles the Jacobian
and a compact JSON-serialisable report.
"""
from __future__ import annotations

from collections.abc import Callable, Sequence
import math

import torch


TensorFn = Callable[[torch.Tensor], torch.Tensor]


def _as_float(value: torch.Tensor | float) -> float:
    if isinstance(value, torch.Tensor):
        return float(value.detach().cpu())
    return float(value)


def _flatten_obs(obs: torch.Tensor) -> torch.Tensor:
    return obs.reshape(-1)


def jacobian_reverse(observable_fn: TensorFn,
                     theta: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Return ``(J, obs)`` for a differentiable observable.

    ``J`` has shape ``(n_observations, n_parameters)`` and is assembled by
    reverse-mode AD, one VJP per observable component. This is intended
    for low-dimensional inverse gates, not dense field-scale production.
    """
    theta_leaf = theta.detach().clone().requires_grad_(True)
    obs = _flatten_obs(observable_fn(theta_leaf))
    if obs.numel() == 0:
        raise ValueError("observable_fn returned an empty tensor")
    rows = []
    for i in range(obs.numel()):
        grad = torch.autograd.grad(
            obs[i], theta_leaf, retain_graph=i < obs.numel() - 1,
            allow_unused=False,
        )[0]
        rows.append(grad.detach())
    return torch.stack(rows, dim=0), obs.detach()


def jacobian_finite_difference(
    observable_fn: TensorFn,
    theta: torch.Tensor,
    rel_step: float = 1e-3,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return ``(J, obs)`` by central finite differences.

    This is the practical path for phase-field inverse gates with few
    unknowns and many compressed observations: it costs ``2*k`` forward
    solves rather than one backward per observation component.
    """
    theta0 = theta.detach().clone()
    with torch.no_grad():
        obs0 = _flatten_obs(observable_fn(theta0)).detach()
    rows = obs0.numel()
    cols = theta0.numel()
    J = torch.zeros((rows, cols), dtype=torch.float64)
    for j in range(cols):
        h = rel_step * max(abs(float(theta0[j].detach().cpu())), 1.0)
        theta_p = theta0.clone()
        theta_m = theta0.clone()
        theta_p[j] = theta_p[j] + h
        theta_m[j] = theta_m[j] - h
        with torch.no_grad():
            obs_p = _flatten_obs(observable_fn(theta_p)).detach()
            obs_m = _flatten_obs(observable_fn(theta_m)).detach()
        J[:, j] = (obs_p.to(dtype=torch.float64)
                   - obs_m.to(dtype=torch.float64)) / (2.0 * h)
    return J, obs0


def jacobian_summary(J: torch.Tensor,
                     rel_rank_tol: float = 1e-8) -> dict:
    """Summarise observation sensitivity from a Jacobian matrix."""
    J64 = J.detach().to(dtype=torch.float64)
    column_norms = torch.linalg.vector_norm(J64, dim=0)
    svals = torch.linalg.svdvals(J64)
    svals, _ = torch.sort(svals, descending=True)
    smax = _as_float(svals[0]) if svals.numel() else 0.0
    smin = _as_float(svals[-1]) if svals.numel() else 0.0
    if smin > 0.0:
        cond = smax / smin
    elif smax > 0.0:
        cond = math.inf
    else:
        cond = math.inf
    rank = int((svals > rel_rank_tol * smax).sum().item()) if smax > 0 else 0
    return {
        "n_observations": int(J64.shape[0]),
        "n_parameters": int(J64.shape[1]),
        "column_norms": column_norms.cpu().tolist(),
        "column_norm_min": _as_float(column_norms.min()) if column_norms.numel() else 0.0,
        "column_norm_max": _as_float(column_norms.max()) if column_norms.numel() else 0.0,
        "singular_values": svals.cpu().tolist(),
        "condition_number": cond,
        "effective_rank": rank,
        "rel_rank_tol": float(rel_rank_tol),
    }


def loss_and_gradient(loss_fn: TensorFn,
                      theta: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Evaluate a scalar loss and gradient at ``theta``."""
    theta_leaf = theta.detach().clone().requires_grad_(True)
    loss = loss_fn(theta_leaf)
    if loss.numel() != 1:
        raise ValueError("loss_fn must return a scalar tensor")
    grad = torch.autograd.grad(loss, theta_leaf, allow_unused=False)[0]
    return loss.detach(), grad.detach()


def descent_alignment(grad: torch.Tensor,
                      theta_init: torch.Tensor,
                      theta_truth: torch.Tensor) -> dict:
    """Compare ``-grad`` at init with the vector from init to truth."""
    direction = theta_truth.detach() - theta_init.detach()
    grad64 = grad.detach().to(dtype=torch.float64)
    direction64 = direction.to(dtype=torch.float64)
    grad_norm = torch.linalg.vector_norm(grad64)
    direction_norm = torch.linalg.vector_norm(direction64)
    denom = (grad_norm * direction_norm).clamp_min(
        torch.finfo(torch.float64).eps)
    descent_dot = torch.dot(-grad64, direction64)
    grad_dot = torch.dot(grad64, direction64)
    return {
        "grad_norm": _as_float(grad_norm),
        "direction_to_truth_norm": _as_float(direction_norm),
        "grad_dot_to_truth": _as_float(grad_dot),
        "descent_dot_to_truth": _as_float(descent_dot),
        "cos_descent_truth": _as_float(descent_dot / denom),
        "grad": grad64.cpu().tolist(),
        "direction_to_truth": direction64.cpu().tolist(),
    }


def line_probe(loss_fn: TensorFn,
               theta_init: torch.Tensor,
               theta_truth: torch.Tensor,
               alphas: Sequence[float] = (0.0, 0.25, 0.5, 0.75, 1.0),
               require_grad: bool = False) -> list[dict]:
    """Evaluate loss on ``theta(alpha)=init+alpha*(truth-init)``."""
    rows = []
    theta0 = theta_init.detach()
    direction = theta_truth.detach() - theta0
    context = torch.enable_grad() if require_grad else torch.no_grad()
    with context:
        for alpha in alphas:
            theta = (theta0 + float(alpha) * direction).detach()
            if require_grad:
                theta = theta.requires_grad_(True)
            loss = loss_fn(theta)
            rows.append({
                "alpha": float(alpha),
                "loss": _as_float(loss),
            })
    return rows


def observability_gate_report(
    observable_fn: TensorFn,
    loss_fn: TensorFn,
    theta_init: torch.Tensor,
    theta_truth: torch.Tensor,
    alphas: Sequence[float] = (0.0, 0.25, 0.5, 0.75, 1.0),
    rel_rank_tol: float = 1e-8,
    min_column_norm: float = 1e-10,
    min_loss_at_init: float = 1e-12,
    max_condition_number: float = 1e8,
    min_descent_cosine: float = 0.0,
) -> dict:
    """Run the full pre-job observability gate.

    The pass/fail thresholds are deliberately conservative. A failed
    gate should not be interpreted as a proof of impossibility; it says
    that this observable/setup is a poor candidate for a long local
    gradient optimisation from this initialisation.
    """
    J, obs = jacobian_reverse(observable_fn, theta_init)
    jac = jacobian_summary(J, rel_rank_tol=rel_rank_tol)
    loss0, grad = loss_and_gradient(loss_fn, theta_init)
    align = descent_alignment(grad, theta_init, theta_truth)
    line = line_probe(loss_fn, theta_init, theta_truth, alphas=alphas)
    finite = (
        torch.isfinite(J).all()
        and torch.isfinite(grad).all()
        and torch.isfinite(loss0)
    )
    columns_ok = jac["column_norm_min"] >= min_column_norm
    loss_ok = _as_float(loss0) >= min_loss_at_init
    rank_ok = jac["effective_rank"] == jac["n_parameters"]
    cond_ok = math.isfinite(jac["condition_number"]) and (
        jac["condition_number"] <= max_condition_number)
    descent_ok = align["cos_descent_truth"] > min_descent_cosine
    line_losses = [row["loss"] for row in line]
    line_improves = min(line_losses) < line_losses[0] if line_losses else False
    pass_gate = bool(finite and columns_ok and loss_ok and rank_ok and cond_ok
                     and descent_ok and line_improves)
    reasons = []
    if not bool(finite):
        reasons.append("non-finite loss/J/gradient")
    if not columns_ok:
        reasons.append("one or more parameter columns have negligible sensitivity")
    if not loss_ok:
        reasons.append("loss at initial guess is too small to identify parameters")
    if not rank_ok:
        reasons.append("Jacobian is rank deficient")
    if not cond_ok:
        reasons.append("Jacobian is ill conditioned")
    if not descent_ok:
        reasons.append("local descent direction does not point toward truth")
    if not line_improves:
        reasons.append("init-to-truth line does not reduce the loss")
    return {
        "pass": pass_gate,
        "reasons": reasons,
        "loss_at_init": _as_float(loss0),
        "observable_norm_at_init": _as_float(torch.linalg.vector_norm(obs)),
        "jacobian": jac,
        "descent_alignment": align,
        "line_probe": line,
        "thresholds": {
            "min_column_norm": float(min_column_norm),
            "min_loss_at_init": float(min_loss_at_init),
            "max_condition_number": float(max_condition_number),
            "min_descent_cosine": float(min_descent_cosine),
            "rel_rank_tol": float(rel_rank_tol),
        },
    }


def observability_gate_report_fd(
    observable_fn: TensorFn,
    loss_fn: TensorFn,
    theta_init: torch.Tensor,
    theta_truth: torch.Tensor,
    alphas: Sequence[float] = (0.0, 0.25, 0.5, 0.75, 1.0),
    rel_step: float = 1e-3,
    rel_rank_tol: float = 1e-8,
    min_column_norm: float = 1e-10,
    min_loss_at_init: float = 1e-12,
    max_condition_number: float = 1e8,
    min_descent_cosine: float = 0.0,
) -> dict:
    """Finite-difference-Jacobian variant of
    :func:`observability_gate_report`.

    Use this for solver-level gates when ``n_parameters`` is small and
    ``n_observations`` is moderate or large. It still uses autograd for
    the scalar loss direction, so it checks whether the actual gradient
    path used by the optimiser points toward the synthetic truth.
    """
    J, obs = jacobian_finite_difference(
        observable_fn, theta_init, rel_step=rel_step)
    jac = jacobian_summary(J, rel_rank_tol=rel_rank_tol)
    loss0, grad = loss_and_gradient(loss_fn, theta_init)
    align = descent_alignment(grad, theta_init, theta_truth)
    line = line_probe(loss_fn, theta_init, theta_truth, alphas=alphas)
    finite = (
        torch.isfinite(J).all()
        and torch.isfinite(grad).all()
        and torch.isfinite(loss0)
    )
    columns_ok = jac["column_norm_min"] >= min_column_norm
    loss_ok = _as_float(loss0) >= min_loss_at_init
    rank_ok = jac["effective_rank"] == jac["n_parameters"]
    cond_ok = math.isfinite(jac["condition_number"]) and (
        jac["condition_number"] <= max_condition_number)
    descent_ok = align["cos_descent_truth"] > min_descent_cosine
    line_losses = [row["loss"] for row in line]
    line_improves = min(line_losses) < line_losses[0] if line_losses else False
    pass_gate = bool(finite and columns_ok and loss_ok and rank_ok and cond_ok
                     and descent_ok and line_improves)
    reasons = []
    if not bool(finite):
        reasons.append("non-finite loss/J/gradient")
    if not columns_ok:
        reasons.append("one or more parameter columns have negligible sensitivity")
    if not loss_ok:
        reasons.append("loss at initial guess is too small to identify parameters")
    if not rank_ok:
        reasons.append("Jacobian is rank deficient")
    if not cond_ok:
        reasons.append("Jacobian is ill conditioned")
    if not descent_ok:
        reasons.append("local descent direction does not point toward truth")
    if not line_improves:
        reasons.append("init-to-truth line does not reduce the loss")
    return {
        "pass": pass_gate,
        "reasons": reasons,
        "loss_at_init": _as_float(loss0),
        "observable_norm_at_init": _as_float(torch.linalg.vector_norm(obs)),
        "jacobian": jac,
        "descent_alignment": align,
        "line_probe": line,
        "thresholds": {
            "min_column_norm": float(min_column_norm),
            "min_loss_at_init": float(min_loss_at_init),
            "max_condition_number": float(max_condition_number),
            "min_descent_cosine": float(min_descent_cosine),
            "rel_rank_tol": float(rel_rank_tol),
            "rel_step": float(rel_step),
            "jacobian_mode": "finite_difference",
        },
    }


__all__ = [
    "jacobian_reverse",
    "jacobian_finite_difference",
    "jacobian_summary",
    "loss_and_gradient",
    "descent_alignment",
    "line_probe",
    "observability_gate_report",
    "observability_gate_report_fd",
]
