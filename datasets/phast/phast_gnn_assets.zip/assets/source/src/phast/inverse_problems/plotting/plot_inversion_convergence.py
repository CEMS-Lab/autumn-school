#!/usr/bin/env python
"""Plot L-BFGS inversion convergence + recovered-vs-truth field.

Auto-detects demo type from the JSON's keys:
  - inclusion (1- or 3-particle): expects 'truth_particles', 'history'
    with per-iter 'pos_err_per_particle_mm' and 'particles'.
  - gc_horizontal low_rank: expects 'x0_truth', 'x0_recovered', 'history'
    with per-iter 'x0', 'sigma', 'x0_err_mm', 'loss'.
  - gc_horizontal full_field: 'k_unknowns', 'history' with 'err_L2_rel'.

Usage:
    python plot_inversion_convergence.py <results_dir> [--out figure.png]
"""
from __future__ import annotations
import argparse
import glob
import json
import os
import sys

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.tri import Triangulation


def load_json(input_dir):
    cands = ['demo_inverse_stiff_inclusion.json',
             'demo_inverse_gc_horizontal.json']
    for c in cands:
        p = os.path.join(input_dir, c)
        if os.path.exists(p):
            with open(p) as fh:
                return c, json.load(fh)
    sys.exit(f"No inversion JSON in {input_dir}; found: "
             f"{os.listdir(input_dir)}")


def plot_inclusion(json_data, input_dir, out_png):
    history = json_data['history']
    iters = [h['iter']        for h in history]
    losses = [h['loss']        for h in history]
    pos_err_max = [h['pos_err_max_mm'] for h in history]
    pos_err_per = np.array([h['pos_err_per_particle_mm']
                              for h in history])  # (n_iters, n_particles)
    truth_pts = np.array(json_data['truth_particles'])
    init_pts  = np.array(json_data['init_particles'])
    rec_pts   = np.array(json_data['recovered_particles'])
    particles_traj = np.array([h['particles']
                                  for h in history])  # (n_iters, n_p, 2)
    n_p = truth_pts.shape[0]

    fig, axes = plt.subplots(2, 2, figsize=(13, 9))

    # (a) loss vs iter (semilog)
    ax = axes[0, 0]
    ax.semilogy(iters, losses, 'b-o', ms=5, lw=1.4)
    ax.set_xlabel('iteration')
    ax.set_ylabel('damage-field MSE loss')
    ax.set_title('(a) L-BFGS loss')
    ax.grid(True, which='both', alpha=0.3)

    # (b) position error per particle (semilog) + max
    ax = axes[0, 1]
    for i in range(n_p):
        ax.semilogy(iters, pos_err_per[:, i],
                      '-o', ms=4, lw=1.0, label=f'particle {i+1}')
    ax.semilogy(iters, pos_err_max, 'k-', lw=2, alpha=0.6, label='max')
    ax.set_xlabel('iteration')
    ax.set_ylabel(r'$\|(x_h, y_h) - (x_h^*, y_h^*)\|$  [mm]')
    ax.set_title('(b) Position error')
    ax.grid(True, which='both', alpha=0.3)
    ax.legend(loc='best', fontsize=8)

    # (c) particle trajectory in (x, y) — truth, init, recovered, path
    ax = axes[1, 0]
    cmap = plt.cm.viridis(np.linspace(0, 1, n_p))
    for i in range(n_p):
        ax.plot(particles_traj[:, i, 0], particles_traj[:, i, 1],
                  '-o', color=cmap[i], ms=4, lw=1.2,
                  label=f'particle {i+1} traj')
        ax.plot(truth_pts[i, 0], truth_pts[i, 1],
                  '*', color=cmap[i], ms=18, mec='k', mew=0.6,
                  label=f'truth {i+1}' if i == 0 else None)
        ax.plot(init_pts[i, 0], init_pts[i, 1],
                  's', color=cmap[i], ms=8, mec='k', mew=0.6,
                  label=f'init {i+1}'  if i == 0 else None)
        ax.plot(rec_pts[i, 0], rec_pts[i, 1],
                  'D', color=cmap[i], ms=8, mec='k', mew=0.6,
                  label=f'rec {i+1}'   if i == 0 else None)
    ax.axhline(8, color='k', ls=':', lw=0.8, alpha=0.5,
                label='unperturbed crack y=8')
    ax.set_xlabel('x_h [mm]')
    ax.set_ylabel('y_h [mm]')
    ax.set_title('(c) L-BFGS trajectory in parameter space')
    ax.grid(alpha=0.3)
    ax.legend(loc='best', fontsize=7, ncol=2)
    ax.set_aspect('equal', adjustable='datalim')

    # (d) truth damage with recovered/truth particle markers
    ax = axes[1, 1]
    # Try both file names; the inversion run wrote damage_truth.npz +
    # damage_recovered.npz under the same input_dir.
    truth_npz = os.path.join(input_dir, 'damage_truth.npz')
    rec_npz   = os.path.join(input_dir, 'damage_recovered.npz')
    if os.path.exists(truth_npz) and os.path.exists(rec_npz):
        zt = np.load(truth_npz, allow_pickle=True)
        zr = np.load(rec_npz,   allow_pickle=True)
        nodes = zt['nodes']
        elements = zt['elements']
        d_truth = zt['d_target']
        d_rec   = zr['d_recovered']
        diff = d_rec - d_truth
        tri = Triangulation(nodes[:, 0], nodes[:, 1], elements)
        im = ax.tripcolor(tri, diff, cmap='RdBu_r',
                            shading='gouraud', vmin=-0.5, vmax=0.5)
        plt.colorbar(im, ax=ax, label='d_rec - d_truth', shrink=0.8)
        for i in range(n_p):
            ax.plot(truth_pts[i, 0], truth_pts[i, 1], 'k*', ms=12,
                      label='truth' if i == 0 else None)
            ax.plot(rec_pts[i, 0], rec_pts[i, 1], 'kD', ms=8,
                      label='rec'   if i == 0 else None)
        ax.set_aspect('equal')
        ax.legend(loc='upper right', fontsize=8)
        ax.set_title('(d) Damage residual at recovered θ')
        ax.set_xlabel('x [mm]')
        ax.set_ylabel('y [mm]')
    else:
        ax.text(0.5, 0.5, 'damage_truth.npz / damage_recovered.npz\nnot found',
                  ha='center', va='center', transform=ax.transAxes)
        ax.set_title('(d) Damage residual — N/A')

    fig.suptitle(f'Inclusion inversion: {os.path.basename(input_dir)}  '
                  f'({n_p} particles, max err = '
                  f'{pos_err_max[-1]:.3f} mm, {len(iters)} iters, '
                  f'{json_data.get("forward_sims", "?")} fwd sims)',
                  fontsize=11)
    fig.tight_layout()
    fig.savefig(out_png, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f"Saved: {out_png}")


def plot_gc(json_data, input_dir, out_png):
    history = json_data['history']
    iters = history['iter']
    losses = history['loss']
    mode = json_data['param_mode']

    fig, axes = plt.subplots(2, 2, figsize=(13, 9))

    # (a) loss vs iter
    ax = axes[0, 0]
    ax.semilogy(iters, losses, 'b-o', ms=5, lw=1.4)
    ax.set_xlabel('iteration')
    ax.set_ylabel('damage MSE loss')
    ax.set_title('(a) L-BFGS loss')
    ax.grid(True, which='both', alpha=0.3)

    # (b) error vs iter
    ax = axes[0, 1]
    if mode == 'low_rank' and 'x0_err_mm' in history:
        ax.semilogy(iters, history['x0_err_mm'], 'r-o', ms=4, lw=1.2,
                      label=r'$|x_0 - x_0^*|$')
        ax.set_ylabel('x0 error [mm]')
    elif mode == 'full_field' and 'err_L2_rel' in history:
        ax.semilogy(iters, history['err_L2_rel'], 'r-o', ms=4, lw=1.2,
                      label=r'$\|G_c - G_c^*\|_2 / \|G_c^*\|_2$')
        ax.set_ylabel('relative L2 error')
    ax.set_xlabel('iteration')
    ax.set_title(f'(b) Recovery error ({mode})')
    ax.grid(True, which='both', alpha=0.3)
    ax.legend(loc='best', fontsize=9)

    # (c) low-rank: x0/sigma trajectory; full_field: Gc field comparison
    ax = axes[1, 0]
    if mode == 'low_rank':
        x0_t = json_data['x0_truth']
        s_t  = json_data['sigma_truth']
        ax.plot(history['x0'], history['sigma'], 'g-o', ms=4, lw=1.2,
                  label='LBFGS trajectory')
        ax.plot([x0_t], [s_t], 'r*', ms=18, mec='k', mew=0.6, label='truth')
        if 'x0_recovered' in json_data:
            ax.plot([json_data['x0_recovered']],
                      [json_data['sigma_recovered']],
                      'kD', ms=10, mec='k', mew=0.6, label='recovered')
        ax.set_xlabel(r'$x_0$ [mm]')
        ax.set_ylabel(r'$\sigma$ [mm]')
        ax.set_title('(c) (x0, sigma) trajectory')
        ax.grid(alpha=0.3)
        ax.legend(loc='best', fontsize=8)
    else:
        truth_npz = os.path.join(input_dir, 'truth.npz')
        rec_npy   = os.path.join(input_dir, 'Gc_recovered.npy')
        if os.path.exists(truth_npz) and os.path.exists(rec_npy):
            zt = np.load(truth_npz, allow_pickle=True)
            Gc_true = zt['Gc_true']
            Gc_rec  = np.load(rec_npy)
            cents   = zt['centroids']
            diff = (Gc_rec - Gc_true) / np.maximum(np.abs(Gc_true), 1e-12)
            sc = ax.scatter(cents[:, 0], cents[:, 1], c=diff, s=2,
                              cmap='RdBu_r', vmin=-0.4, vmax=0.4)
            plt.colorbar(sc, ax=ax, label='(Gc_rec - Gc_true) / Gc_true',
                            shrink=0.8)
            ax.set_aspect('equal')
            ax.set_xlabel('x [mm]')
            ax.set_ylabel('y [mm]')
            ax.set_title('(c) Gc relative residual')

    # (d) damage residual
    ax = axes[1, 1]
    truth_npz = os.path.join(input_dir, 'truth.npz')
    if os.path.exists(truth_npz):
        zt = np.load(truth_npz, allow_pickle=True)
        nodes = zt['nodes']
        elements = zt['elements']
        d_truth = zt['d_target']
        # Recovered damage: rerun forward at recovered params (cheap to
        # do in postprocess but expensive here; the demo doesn't save
        # d_recovered for the gc demo). Plot truth alone instead.
        tri = Triangulation(nodes[:, 0], nodes[:, 1], elements)
        im = ax.tripcolor(tri, d_truth, cmap='inferno',
                            shading='gouraud', vmin=0, vmax=1)
        plt.colorbar(im, ax=ax, label='d truth', shrink=0.8)
        if mode == 'low_rank':
            x0_t = json_data['x0_truth']
            ax.axvline(x0_t, color='cyan', ls='--', lw=1,
                        label=f'truth x0={x0_t}')
            if 'x0_recovered' in json_data:
                ax.axvline(json_data['x0_recovered'], color='lime',
                            ls='-', lw=1, label='recovered')
            ax.legend(loc='upper right', fontsize=8)
        ax.set_aspect('equal')
        ax.set_xlabel('x [mm]')
        ax.set_ylabel('y [mm]')
        ax.set_title('(d) Truth damage')

    fig.suptitle(f'Gc-horizontal inversion ({mode}): '
                  f'{os.path.basename(input_dir)}', fontsize=11)
    fig.tight_layout()
    fig.savefig(out_png, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f"Saved: {out_png}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument('input_dir')
    p.add_argument('--out', default=None)
    args = p.parse_args()

    json_name, data = load_json(args.input_dir)
    out = args.out or os.path.join(args.input_dir, 'inversion_convergence.png')

    if 'truth_particles' in data:
        plot_inclusion(data, args.input_dir, out)
    elif 'param_mode' in data:
        plot_gc(data, args.input_dir, out)
    else:
        sys.exit(f"Cannot detect demo type from {json_name}; "
                  f"keys: {list(data.keys())}")


if __name__ == '__main__':
    main()
