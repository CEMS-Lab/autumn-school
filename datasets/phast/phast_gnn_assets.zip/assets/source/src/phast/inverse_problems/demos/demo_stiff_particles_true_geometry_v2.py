#!/usr/bin/env python
"""Forward gate for true circular stiff-particle SENT demos.

This is the v2 physics/visualisation counterpart to
``demo_inverse_stiff_inclusion.py``. The legacy D1/D2 demos use Gaussian
stiffness bumps on a fixed mesh so particle centres remain differentiable.
Here the particle is a real Gmsh disk surface sharing interface curves with
the matrix. That gives a conforming mesh and a sharp material interface, but
the particle position is fixed by geometry; inverse recovery needs either a
remeshing/shape-derivative route or a fixed-mesh smooth-indicator surrogate.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.boundary_conditions import BoundaryConditions
from phast.config import LoadingConfig
from phast.device import DeviceContext
from phast.material import create_material
from phast.mesh import FEMMesh
from phast.mesh_generator import rectangular_sent_circular_inclusions
from phast.staggered_solver import SolverConfig, StaggeredSolver

from inverse_problems.demos.demo_inverse_stiff_inclusion import (
    E_BULK,
    GC,
    L0,
    NU,
    RHO,
    run_forward,
)


def _parse_particles(csv: str | None, default: list[tuple[float, float]]):
    if csv is None:
        return default
    vals = [float(v) for v in csv.split(',') if v.strip()]
    if len(vals) % 2:
        raise ValueError("--truth_particles must contain x,y pairs")
    return [(vals[i], vals[i + 1]) for i in range(0, len(vals), 2)]


def build_solver(
    *,
    particles: list[tuple[float, float]],
    radius: float,
    W: float,
    H: float,
    a: float,
    h_crack: float,
    h_coarse: float,
    delta_U: float,
    tau_ramp: float,
    damping_zeta: float,
    energy_split: str,
    pf_model: str,
    plane_stress: bool,
    device: str,
    dtype: torch.dtype,
    output_dir: Path,
):
    msh = output_dir / "sent_true_particles_v2.msh"
    rectangular_sent_circular_inclusions(
        str(msh),
        W=W,
        H=H,
        a=a,
        inclusions=[(x, y, radius) for x, y in particles],
        l0=L0,
        h_crack=h_crack,
        h_coarse=h_coarse,
        h_inclusion=h_crack,
        verbose=True,
    )
    mesh = FEMMesh(str(msh), device=device, dtype=dtype)
    mesh.identify_boundaries()

    mat = create_material(
        E=E_BULK,
        nu=NU,
        rho=RHO,
        Gc=GC,
        l0=L0,
        energy_split=energy_split,
        pf_model=pf_model,
        plane_stress=plane_stress,
        gamma_correction=True,
    )
    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)
    bcs.add(mesh.node_sets['top'], component=1, value=+delta_U)
    bcs.add(mesh.node_sets['bottom'], component=1, value=-delta_U)
    bcs.fix(mesh.node_sets['left'], component=0)

    cfg = SolverConfig(
        solver_type='explicit',
        differentiable=False,
        damage_every=1,
        preconditioner='jacobi',
        damping_ratio_max=damping_zeta,
        enable_damage=True,
        H_update_method='custom_subgrad',
    )
    solver = StaggeredSolver(
        mesh, mat, bcs, config=cfg, ctx=DeviceContext(device, dtype)
    )
    centroids = mesh.nodes[mesh.elements].mean(dim=1)
    loading = LoadingConfig(ramp_type='smooth', t_ramp=tau_ramp)
    return solver, centroids, loading, msh


def particle_element_mask(centroids, particles, radius):
    mask = torch.zeros(
        centroids.shape[0], dtype=torch.bool, device=centroids.device
    )
    r2 = radius * radius
    for x, y in particles:
        dx = centroids[:, 0] - x
        dy = centroids[:, 1] - y
        mask = mask | ((dx * dx + dy * dy) <= r2 * (1.0 + 1e-8))
    return mask


def save_particle_viz(
    *,
    nodes,
    elements,
    damage,
    snapshots,
    snap_steps,
    particles,
    radius,
    out_dir: Path,
    n_steps: int,
    title: str,
):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.tri as mtri
    from matplotlib.patches import Circle

    nodes_np = nodes.detach().cpu().numpy()
    elem_np = elements.detach().cpu().numpy()
    tri = mtri.Triangulation(nodes_np[:, 0], nodes_np[:, 1], elem_np)

    def draw(arr, frame_title, path):
        arr = np.nan_to_num(arr, nan=0.0, posinf=1.0, neginf=0.0)
        fig, ax = plt.subplots(1, 1, figsize=(7.0, 4.2))
        tcf = ax.tricontourf(tri, arr, levels=64, cmap='inferno',
                             vmin=0.0, vmax=1.0)
        plt.colorbar(tcf, ax=ax, shrink=0.82, label='damage d')
        for i, (x, y) in enumerate(particles, start=1):
            ax.add_patch(Circle((x, y), radius, facecolor='#f3c78d',
                                edgecolor='#8b5a20', lw=1.4, alpha=0.45))
            ax.plot(x, y, marker='o', ms=4, color='#8b5a20')
            ax.text(x, y + radius + 0.2, f'P{i}', ha='center',
                    va='bottom', fontsize=8, color='#5a3912')
        ax.set_aspect('equal')
        ax.set_xlabel('x (mm)')
        ax.set_ylabel('y (mm)')
        ax.set_title(frame_title, fontsize=10)
        fig.tight_layout()
        fig.savefig(path, dpi=170)
        plt.close(fig)

    out_dir.mkdir(parents=True, exist_ok=True)
    png = out_dir / "truth_damage_final_particles.png"
    d_np = damage.detach().cpu().numpy()
    draw(d_np, f"{title}: final damage", png)

    gif = None
    if snapshots:
        try:
            from PIL import Image
        except ImportError:
            return {"png": str(png), "gif": None}
        frames = []
        for snap, step in zip(snapshots, snap_steps):
            tmp = out_dir / f"_frame_{step:06d}.png"
            draw(
                snap.detach().cpu().numpy(),
                f"{title}: step {step}/{n_steps}",
                tmp,
            )
            frames.append(Image.open(tmp).convert("RGB"))
            tmp.unlink(missing_ok=True)
        gif = out_dir / "truth_damage_evolution_particles.gif"
        frames[0].save(
            gif,
            save_all=True,
            append_images=frames[1:],
            duration=170,
            loop=0,
        )
    return {"png": str(png), "gif": str(gif) if gif else None}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device', default='cpu')
    p.add_argument('--dtype', choices=['float32', 'float64'], default='float64')
    p.add_argument('--n_particles', type=int, choices=[1, 3], default=1)
    p.add_argument('--truth_particles', default=None)
    p.add_argument('--radius', type=float, default=1.6)
    p.add_argument('--E_particle_factor', type=float, default=5.0)
    p.add_argument('--Gc_particle_factor', type=float, default=2.0)
    p.add_argument('--smoke', action='store_true')
    p.add_argument('--mid', action='store_true')
    p.add_argument('--n_steps', type=int, default=None)
    p.add_argument('--delta_U', type=float, default=5e-2)
    p.add_argument('--tau_ramp_us', type=float, default=30.0)
    p.add_argument('--damping_zeta', type=float, default=0.05)
    p.add_argument('--energy_split', choices=['amor', 'spectral', 'star_convex'],
                   default='spectral')
    p.add_argument('--pf_model', choices=['AT1', 'AT2'], default='AT1')
    p.add_argument('--plane_strain', action='store_true')
    p.add_argument('--n_viz_frames', type=int, default=20)
    p.add_argument('--output_dir', default='results_true_particles_v2')
    args = p.parse_args()

    dtype = torch.float32 if args.dtype == 'float32' else torch.float64
    out_dir = Path(args.output_dir)
    if not out_dir.is_absolute():
        out_dir = Path(THIS_DIR) / out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    W, H, a = 32.0, 16.0, 4.0
    if args.n_particles == 1:
        default_particles = [(16.0, 9.5)]
    else:
        default_particles = [(13.0, 9.5), (19.0, 6.5), (25.0, 9.5)]
    particles = _parse_particles(args.truth_particles, default_particles)
    if len(particles) != args.n_particles:
        raise ValueError("--n_particles and --truth_particles disagree")

    if args.smoke:
        h_crack, h_coarse = 0.4, 2.0
        n_steps = args.n_steps if args.n_steps is not None else 1500
    elif args.mid:
        h_crack, h_coarse = 0.1, 0.8
        n_steps = args.n_steps if args.n_steps is not None else 4500
    else:
        h_crack, h_coarse = 0.05, 0.5
        n_steps = args.n_steps if args.n_steps is not None else 9000

    print("=" * 72)
    print("  True-geometry stiff-particle SENT v2 forward gate")
    print("=" * 72)
    print(f"  Issue: #569")
    print(f"  Particles: {particles}, radius={args.radius} mm")
    print(f"  E: matrix={E_BULK:.1f} MPa, particle="
          f"{args.E_particle_factor * E_BULK:.1f} MPa")
    print(f"  Gc: matrix={GC:.3f} N/mm, particle="
          f"{args.Gc_particle_factor * GC:.3f} N/mm")
    print(f"  Mesh target: h_crack={h_crack}, h_coarse={h_coarse}")
    print(f"  Steps={n_steps}, split={args.energy_split}, model={args.pf_model}")

    solver, centroids, loading, msh = build_solver(
        particles=particles,
        radius=args.radius,
        W=W,
        H=H,
        a=a,
        h_crack=h_crack,
        h_coarse=h_coarse,
        delta_U=args.delta_U,
        tau_ramp=args.tau_ramp_us * 1e-6,
        damping_zeta=args.damping_zeta,
        energy_split=args.energy_split,
        pf_model=args.pf_model,
        plane_stress=not args.plane_strain,
        device=args.device,
        dtype=dtype,
        output_dir=out_dir,
    )

    mask = particle_element_mask(centroids, particles, args.radius)
    E_field = torch.where(
        mask,
        torch.as_tensor(args.E_particle_factor * E_BULK,
                        dtype=dtype, device=args.device),
        torch.as_tensor(E_BULK, dtype=dtype, device=args.device),
    )
    Gc_field = torch.where(
        mask,
        torch.as_tensor(args.Gc_particle_factor * GC,
                        dtype=dtype, device=args.device),
        torch.as_tensor(GC, dtype=dtype, device=args.device),
    )
    solver.diff_Gc_field = Gc_field

    first = max(int(0.05 * n_steps), 1)
    snap_steps = list(np.linspace(first, n_steps, args.n_viz_frames,
                                  dtype=int).tolist())
    t0 = time.time()
    with torch.no_grad():
        d_final, snaps, _ = run_forward(
            solver,
            loading,
            E_field,
            n_steps,
            snapshot_steps=snap_steps,
        )
        d_final = d_final.detach().clone()
        snaps = [s.detach().clone() for s in snaps]
    elapsed = time.time() - t0

    print(f"  Forward done in {elapsed:.1f} s")
    print(f"  Mesh: {solver.mesh.n_nodes} nodes, {solver.mesh.n_elems} elems, "
          f"particle elems={int(mask.sum().item())}")
    print(f"  Damage: max={float(d_final.max()):.3f}, "
          f"#d>0.5={int((d_final > 0.5).sum().item())}")

    np.savez_compressed(
        out_dir / "truth_fields.npz",
        nodes=solver.mesh.nodes.detach().cpu().numpy(),
        elements=solver.mesh.elements.detach().cpu().numpy(),
        d_final=d_final.detach().cpu().numpy(),
        snapshots=np.stack([s.detach().cpu().numpy() for s in snaps]),
        snap_steps=np.asarray(snap_steps, dtype=np.int64),
        E_field=E_field.detach().cpu().numpy(),
        Gc_field=Gc_field.detach().cpu().numpy(),
        particle_mask=mask.detach().cpu().numpy(),
    )
    metadata = {
        "issue": 569,
        "mesh": str(msh),
        "particles": particles,
        "radius_mm": args.radius,
        "E_matrix_MPa": E_BULK,
        "E_particle_MPa": args.E_particle_factor * E_BULK,
        "Gc_matrix_N_per_mm": GC,
        "Gc_particle_N_per_mm": args.Gc_particle_factor * GC,
        "n_steps": n_steps,
        "delta_U_mm": args.delta_U,
        "tau_ramp_us": args.tau_ramp_us,
        "h_crack": h_crack,
        "h_coarse": h_coarse,
        "energy_split": args.energy_split,
        "pf_model": args.pf_model,
        "plane_stress": not args.plane_strain,
        "elapsed_s": elapsed,
        "max_damage": float(d_final.max()),
        "n_d_gt_0p5": int((d_final > 0.5).sum().item()),
    }
    with open(out_dir / "metadata.json", "w") as fh:
        json.dump(metadata, fh, indent=2)

    demo_id = 1 if args.n_particles == 1 else 2
    title = f"D{demo_id} true circular particle v2"
    paths = save_particle_viz(
        nodes=solver.mesh.nodes,
        elements=solver.mesh.elements,
        damage=d_final,
        snapshots=snaps,
        snap_steps=snap_steps,
        particles=particles,
        radius=args.radius,
        out_dir=out_dir,
        n_steps=n_steps,
        title=title,
    )
    print(f"  PNG: {paths['png']}")
    if paths["gif"]:
        print(f"  GIF: {paths['gif']}")
    print("  Note: this is a conforming-geometry forward gate, not a "
          "moving-centre autograd inverse demo.")


if __name__ == '__main__':
    main()
