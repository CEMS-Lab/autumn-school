#!/usr/bin/env python
"""Demo: microstructure (soft-inclusion) identification from a crack path.

Geometric inverse problem: given the observed final damage field of a
SENT specimen containing one circular soft inclusion (a 'hole-like'
weak spot), recover the inclusion's centre coordinates (x_h, y_h).

Inclusion is modelled as a smooth Gaussian dip in the per-element Gc
field (so the parameters (x_h, y_h) flow through the autograd graph
naturally; no remeshing needed):

    Gc(x) = Gc_bulk * (1 - alpha * exp(-||x - x_h||^2 / (2 sigma^2)))

with alpha = 0.95 and sigma = 0.5 mm fixed (could be added as
unknowns; kept fixed here for a clean 2-DOF demo).

Material: PMMA (Bleyer 2017 parameters). Reference for the bulk Gc
value is Bleyer & Molinari 2017, Int. J. Fract. 204:79-100; for the
microstructure-from-crack-path framing see Gao & Yoshinaga (2023)
"Inverse identification of spatially inhomogeneous fracture toughness
fields", who recovered fracture-toughness fields (rather than
geometric inclusion locations) from observed crack paths via a
phase-field forward solver.

Usage:
  python demo_inverse_microstructure.py --device cuda --n_steps 200 \\
                                        --n_iters 12 --optimizer lbfgs
"""
import argparse
import os
import sys
import time
import json
import tempfile
import subprocess

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS_DIR)
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.material import Material
from phast.mesh import FEMMesh
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.device import DeviceContext
from phast.config import LoadingConfig
from phast.inverse_problems._tbptt import (
    run_forward_tbptt_generic,
    make_install_Gc_field,
)


# Geometry: 32 x 16 mm plate with 4 mm edge notch on left at y=H/2
# (Bleyer 2017). The crack starts at (4, 8) and propagates rightward.
W_PLATE, H_PLATE, A_NOTCH = 32.0, 16.0, 4.0
GC_BULK   = 0.3        # PMMA Gc, N/mm  (= 300 J/m^2, Bleyer 2017)
ALPHA     = 0.95       # inclusion depth (Gc reduction = 95 %% at centre)
SIGMA_INC = 1.5        # inclusion radius scale (mm); reach ~3*sigma = 4.5 mm
# Place the soft inclusion ~2 mm BELOW the crack centerline (y=8) at x=15
# so that the propagating crack curves toward it. Far enough off-line to
# leave a clear yh signature in the final damage field, close enough that
# the Gaussian's tail still couples (separation 2 mm < ~3*sigma = 4.5 mm).
TRUE_XH, TRUE_YH = 15.0, 6.0
# Offset initial guess by 3 mm in x and 1.5 mm in y -- still inside the
# Gaussian's effective basin so the L-BFGS gradient is non-vanishing.
INIT_XH, INIT_YH = 12.0, 7.5


def build_mesh(h_crack, h_coarse, device, dtype):
    geo = f"""
    lc_crack = {h_crack};
    lc_coarse = {h_coarse};
    Point(1) = {{0,    0, 0, lc_coarse}};
    Point(2) = {{{W_PLATE}, 0, 0, lc_coarse}};
    Point(3) = {{{W_PLATE}, {H_PLATE}, 0, lc_coarse}};
    Point(4) = {{0,    {H_PLATE}, 0, lc_coarse}};
    Point(5) = {{0,    {H_PLATE/2 - 0.05}, 0, lc_crack}};
    Point(6) = {{{A_NOTCH}, {H_PLATE/2 - 0.05}, 0, lc_crack}};
    Point(7) = {{{A_NOTCH}, {H_PLATE/2 + 0.05}, 0, lc_crack}};
    Point(8) = {{0,    {H_PLATE/2 + 0.05}, 0, lc_crack}};
    Line(1) = {{1, 2}}; Line(2) = {{2, 3}}; Line(3) = {{3, 4}};
    Line(4) = {{4, 8}}; Line(5) = {{8, 7}}; Line(6) = {{7, 6}};
    Line(7) = {{6, 5}}; Line(8) = {{5, 1}};
    Curve Loop(1) = {{1,2,3,4,5,6,7,8}};
    Plane Surface(1) = {{1}};
    Physical Surface("dom") = {{1}};
    Physical Curve("bottom") = {{1}};
    Physical Curve("right")  = {{2}};
    Physical Curve("top")    = {{3}};
    Physical Curve("left")   = {{4, 8}};
    """
    geo_p = os.path.join(tempfile.gettempdir(), "microstructure_demo.geo")
    msh_p = os.path.join(tempfile.gettempdir(), "microstructure_demo.msh")
    with open(geo_p, "w") as f:
        f.write(geo)
    subprocess.run(["gmsh", "-2", geo_p, "-o", msh_p, "-format", "msh2"],
                   capture_output=True, check=True)
    m = FEMMesh(msh_p, device=device, dtype=dtype)
    m.identify_boundaries()
    return m


def build_solver(mesh, device, dtype):
    mat = Material(E=3090.0, nu=0.35, Gc=GC_BULK, l0=0.1, rho=1.18e-9,
                   energy_split='amor', pf_model='AT1',
                   plane_stress=True, gamma_correction=True)
    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)
    bcs.add(mesh.node_sets['top'],    component=1, value=+0.04)
    bcs.add(mesh.node_sets['bottom'], component=1, value=-0.04)
    bcs.fix(mesh.node_sets['left'],   component=0)
    cfg = SolverConfig(solver_type='explicit', differentiable=True,
                        damage_every=1)
    return StaggeredSolver(mesh, mat, bcs, config=cfg,
                            ctx=DeviceContext(device, dtype))


def gc_field(centroids, xh, yh):
    """Per-element Gc(x) with a soft Gaussian inclusion at (xh, yh).
    Differentiable in (xh, yh)."""
    x = centroids[:, 0]; y = centroids[:, 1]
    r2 = (x - xh) ** 2 + (y - yh) ** 2
    return GC_BULK * (1.0 - ALPHA * torch.exp(-r2 / (2 * SIGMA_INC ** 2)))


def reset_state(solver):
    n = solver.mesh.n_nodes
    e = solver.damage_solver._cg_elements.shape[0]
    dev, dt = solver.u.device, solver.u.dtype
    solver.u = torch.zeros(n, 2, dtype=dt, device=dev)
    solver.v = torch.zeros(n, 2, dtype=dt, device=dev)
    solver.a = torch.zeros(n, 2, dtype=dt, device=dev)
    solver.d = torch.zeros(n, dtype=dt, device=dev)
    solver.H_elem = torch.zeros(e, dtype=dt, device=dev)
    solver.H_nodal = torch.zeros(n, dtype=dt, device=dev)
    solver._step_count = 0


def run(solver, Gc_field_, n_steps):
    reset_state(solver)
    solver.diff_Gc_field = Gc_field_
    for _ in range(n_steps):
        solver.step_full()
    if hasattr(solver, 'diff_Gc_field'):
        del solver.diff_Gc_field
    return solver.d


def main():
    global SIGMA_INC
    p = argparse.ArgumentParser()
    p.add_argument('--device',  type=str,   default='cpu')
    p.add_argument('--h_crack', type=float, default=0.5)
    p.add_argument('--h_coarse', type=float, default=2.0)
    p.add_argument('--n_steps', type=int,   default=200)
    p.add_argument('--n_iters', type=int,   default=12)
    p.add_argument('--optimizer', type=str, default='lbfgs',
                   choices=['adam', 'lbfgs'])
    p.add_argument('--lr',      type=float, default=0.5)
    p.add_argument('--sigma_inc', type=float, default=SIGMA_INC,
                   help='inclusion radius scale (mm); default 1.5')
    p.add_argument('--output_dir', type=str,
                   default='results_inverse_microstructure')
    p.add_argument('--tbptt_chunk_size', type=int, default=0,
                   help='Truncated-BPTT chunk length (issue #288 / #301). '
                        '0 disables (default; full autograd graph). '
                        'When > 0, the n_steps explicit-dynamics loop is '
                        'split into chunks of this length; per-chunk damage '
                        'MSE-against-truth is the loss, biased gradient.')
    args = p.parse_args()
    SIGMA_INC = args.sigma_inc

    out_dir = (args.output_dir if os.path.isabs(args.output_dir)
               else os.path.join(THIS_DIR, args.output_dir))
    os.makedirs(out_dir, exist_ok=True)

    device, dtype = args.device, torch.float64
    print("=" * 70)
    print("  Inverse demo: microstructure (soft-inclusion) localisation")
    print("=" * 70)
    mesh = build_mesh(args.h_crack, args.h_coarse, device, dtype)
    solver = build_solver(mesh, device, dtype)
    solver.damage_solver.tol = 1e-9
    elements = solver.damage_solver._cg_elements
    centroids = mesh.nodes[elements].mean(dim=1)
    print(f"  Mesh: {mesh.n_nodes} nodes, {len(elements)} elements")
    print(f"  Inclusion sigma = {SIGMA_INC} mm, alpha = {ALPHA}, "
          f"true (xh, yh) = ({TRUE_XH}, {TRUE_YH}) mm")

    # ---- TBPTT setup (issue #301) ----
    # When --tbptt_chunk_size > 0 we route the forward through the shared
    # run_forward_tbptt_generic helper. Demo's run() loops without setting
    # load_factor; constant LoadingConfig is the no-op equivalent.
    tbptt_chunk_steps = None
    d_target_tbptt_chunks = None
    loading = LoadingConfig(ramp_type='constant')
    if args.tbptt_chunk_size > 0:
        cs = int(args.tbptt_chunk_size)
        tbptt_chunk_steps = list(range(cs, args.n_steps, cs))
        if not tbptt_chunk_steps or tbptt_chunk_steps[-1] != args.n_steps:
            tbptt_chunk_steps.append(args.n_steps)
        print(f"\n[TBPTT #301] enabled: chunk_size={cs}, "
              f"{len(tbptt_chunk_steps)} chunks")

    # Truth: forward run with the true inclusion centre.
    print(f"\n[1/3] Forward run with truth inclusion ...")
    Gc_true_field = gc_field(centroids, torch.tensor(TRUE_XH, dtype=dtype,
                                                      device=device),
                             torch.tensor(TRUE_YH, dtype=dtype, device=device))
    with torch.no_grad():
        if args.tbptt_chunk_size > 0:
            _, truth_chunk_snaps, truth_chunk_steps_chk, _ = (
                run_forward_tbptt_generic(
                    solver, loading,
                    install_fn=make_install_Gc_field(Gc_true_field),
                    n_steps=args.n_steps,
                    tbptt_chunk_size=args.tbptt_chunk_size))
            d_target_tbptt_chunks = [s.detach().clone()
                                      for s in truth_chunk_snaps]
            d_target = d_target_tbptt_chunks[-1]
            assert truth_chunk_steps_chk == tbptt_chunk_steps
            if hasattr(solver, 'diff_Gc_field'):
                del solver.diff_Gc_field
        else:
            d_target = run(solver, Gc_true_field, args.n_steps).detach()
    print(f"  Target: max(d) = {d_target.max().item():.3f}, "
          f"damaged nodes = {(d_target > 0.5).sum().item()}")

    # Inversion
    xh = torch.tensor(INIT_XH, dtype=dtype, device=device, requires_grad=True)
    yh = torch.tensor(INIT_YH, dtype=dtype, device=device, requires_grad=True)
    counter = {'n': 0}

    def closure_loss():
        Gc_f = gc_field(centroids, xh, yh)
        if args.tbptt_chunk_size > 0:
            _, chunk_snaps_pred, chunk_steps_pred, _ = (
                run_forward_tbptt_generic(
                    solver, loading,
                    install_fn=make_install_Gc_field(Gc_f),
                    n_steps=args.n_steps,
                    tbptt_chunk_size=args.tbptt_chunk_size))
            assert chunk_steps_pred == tbptt_chunk_steps
            chunk_losses = [
                ((dp - dt) ** 2).mean()
                for dp, dt in zip(chunk_snaps_pred,
                                   d_target_tbptt_chunks)]
            loss = torch.stack(chunk_losses).mean()
            if hasattr(solver, 'diff_Gc_field'):
                del solver.diff_Gc_field
        else:
            d_pred = run(solver, Gc_f, args.n_steps)
            loss = ((d_pred - d_target) ** 2).mean()
        counter['n'] += 1
        return loss

    history = []
    t0 = time.time()
    print(f"\n[2/3] Inversion via {args.optimizer.upper()} from "
          f"(xh, yh) = ({INIT_XH}, {INIT_YH}) ...")

    if args.optimizer == 'adam':
        opt = torch.optim.Adam([xh, yh], lr=args.lr)
        for it in range(args.n_iters):
            opt.zero_grad()
            loss = closure_loss()
            loss.backward()
            opt.step()
            err = float(((xh - TRUE_XH) ** 2 + (yh - TRUE_YH) ** 2).sqrt())
            history.append((it, float(xh), float(yh), float(loss),
                            err, counter['n']))
            print(f"  iter {it:3d}: (xh, yh) = ({float(xh):.3f}, "
                  f"{float(yh):.3f}), |err| = {err:.3f} mm, "
                  f"loss = {float(loss):.3e}, fwd = {counter['n']}")
    else:
        opt = torch.optim.LBFGS([xh, yh], lr=1.0, max_iter=1,
                                tolerance_grad=1e-12, tolerance_change=1e-14,
                                history_size=10, line_search_fn='strong_wolfe')
        for it in range(args.n_iters):
            def closure():
                opt.zero_grad()
                loss = closure_loss()
                loss.backward()
                return loss
            loss = float(opt.step(closure))
            err = float(((xh - TRUE_XH) ** 2 + (yh - TRUE_YH) ** 2).sqrt())
            history.append((it, float(xh), float(yh), float(loss),
                            err, counter['n']))
            print(f"  iter {it:2d}: (xh, yh) = ({float(xh):.3f}, "
                  f"{float(yh):.3f}), |err| = {err:.3f} mm, "
                  f"loss = {loss:.3e}, fwd = {counter['n']}")
            if err < 0.05:
                print(f"  Converged: |err| < 0.05 mm at iter {it}")
                break

    err_final = float(((xh - TRUE_XH) ** 2 + (yh - TRUE_YH) ** 2).sqrt())
    print(f"\n[3/3] Result: (xh, yh) = ({float(xh):.3f}, {float(yh):.3f}) mm "
          f"(true ({TRUE_XH}, {TRUE_YH})), |err| = {err_final:.3f} mm, "
          f"{counter['n']} forward sims, {time.time()-t0:.1f} s")

    # Final forward at recovered params, for plotting.
    with torch.no_grad():
        Gc_final = gc_field(centroids, xh.detach(), yh.detach())
        d_final  = run(solver, Gc_final, args.n_steps).detach()
    npz_path = os.path.join(out_dir, 'demo_inverse_microstructure.npz')
    np.savez(npz_path,
             nodes=mesh.nodes.cpu().numpy(),
             elements=elements.cpu().numpy(),
             d_target=d_target.cpu().numpy(),
             d_final=d_final.cpu().numpy(),
             history=np.array(history, dtype=object),
             true_xh=float(TRUE_XH), true_yh=float(TRUE_YH),
             init_xh=float(INIT_XH), init_yh=float(INIT_YH),
             final_xh=float(xh), final_yh=float(yh),
             sigma_inc=float(SIGMA_INC), alpha=float(ALPHA),
             W_plate=float(W_PLATE), H_plate=float(H_PLATE),
             a_notch=float(A_NOTCH))
    print(f"  Saved NPZ: {npz_path}")

    with open(os.path.join(out_dir, 'demo_inverse_microstructure.json'),
              'w') as fh:
        json.dump({
            'material':   'PMMA (Bleyer 2017), bulk Gc = 300 J/m^2',
            'inclusion':  dict(true=[TRUE_XH, TRUE_YH], init=[INIT_XH, INIT_YH],
                               final=[float(xh), float(yh)],
                               sigma_mm=SIGMA_INC, alpha=ALPHA),
            'err_mm':     err_final,
            'forward_sims': counter['n'],
            'wall_time_s': time.time() - t0,
            'history':    [dict(iter=h[0], xh=h[1], yh=h[2], loss=h[3],
                                err_mm=h[4], forward_evals=h[5])
                            for h in history],
        }, fh, indent=2)

    # Paper-quality figure: damage-field overlay + convergence.
    try:
        from plot_microstructure_inversion import plot_from_npz
        png_path = os.path.join(out_dir, 'demo_inverse_microstructure.png')
        plot_from_npz(npz_path, png_path)
        print(f"  Saved figure: {png_path}")
    except Exception as e:
        print(f"  plot skipped: {e}")
        import traceback; traceback.print_exc()


if __name__ == '__main__':
    main()
