"""Maier-2006-inspired WST sequential inverse benchmark.

The paper's wedge-splitting-test example uses a sequential stochastic estimator
with sensitivities of the forward response. This module provides a compact torch
version: synthetic imposed-relative-displacement/load observations, autograd
sensitivities, and an EKF-style scalar update for ``Gc``.

The reduced quasistatic forward map is deliberately isolated in
:func:`wst_force`; a full quasistatic phase-field solver can replace that
function while keeping the sequential estimator and tests.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import torch


@dataclass(frozen=True)
class WSTConfig:
    """Configuration for the reduced WST inverse problem."""

    true_gc: float = 2.7
    init_gc: float = 3.8
    prior_std_log_gc: float = 0.45
    measurement_std: float = 0.025
    reference_gc: float = 2.7
    stiffness: float = 72.0
    peak_ird: float = 0.36
    softening_width: float = 0.075
    min_variance: float = 1.0e-8


def default_ird(dtype: torch.dtype = torch.float64) -> torch.Tensor:
    """Return imposed-relative-displacement points for WST."""

    return torch.linspace(0.025, 0.78, 24, dtype=dtype)


def _damage_progress(ird: torch.Tensor, gc: torch.Tensor, cfg: WSTConfig) -> torch.Tensor:
    threshold = cfg.peak_ird * torch.sqrt(gc / cfg.reference_gc)
    return torch.sigmoid((ird - threshold) / cfg.softening_width)


def wst_force(log_gc: torch.Tensor, ird: torch.Tensor, cfg: WSTConfig | None = None) -> torch.Tensor:
    """Reduced differentiable WST force-CMOD response."""

    cfg = cfg or WSTConfig()
    ird = ird.to(device=log_gc.device, dtype=log_gc.dtype)
    gc = torch.exp(log_gc)
    damage = _damage_progress(ird, gc, cfg)
    elastic = cfg.stiffness * ird
    post_peak = 1.0 - 0.78 * damage
    cohesive_tail = 0.10 * gc * torch.sqrt(ird + 1.0e-9)
    return elastic * post_peak + cohesive_tail


def make_synthetic_history(cfg: WSTConfig | None = None) -> tuple[torch.Tensor, torch.Tensor]:
    """Generate noise-free synthetic WST IRD/force observations."""

    cfg = cfg or WSTConfig()
    ird = default_ird()
    force = wst_force(torch.tensor(cfg.true_gc, dtype=torch.float64).log(), ird, cfg)
    return ird, force.detach()


def sequential_ekf_recover(cfg: WSTConfig | None = None) -> dict[str, object]:
    """Recover ``Gc`` with an EKF-style scalar log-parameter update.

    State is ``theta = log(Gc)``. The observation operator at each load step is
    the differentiable scalar force response. Autograd supplies the sensitivity
    ``dF/dtheta`` used in the Kalman gain.
    """

    cfg = cfg or WSTConfig()
    ird, observed_force = make_synthetic_history(cfg)
    theta_mean = torch.tensor(float(torch.tensor(cfg.init_gc).log()), dtype=torch.float64)
    variance = torch.tensor(cfg.prior_std_log_gc**2, dtype=torch.float64)
    noise_var = torch.tensor(cfg.measurement_std**2, dtype=torch.float64)
    history: list[dict[str, float]] = []

    for step, (ird_i, force_i) in enumerate(zip(ird, observed_force), start=1):
        theta = theta_mean.detach().clone().requires_grad_(True)
        pred = wst_force(theta, ird_i.reshape(1), cfg).squeeze()
        sensitivity = torch.autograd.grad(pred, theta, retain_graph=False)[0]
        innovation = force_i - pred.detach()
        innovation_var = sensitivity.detach().pow(2) * variance + noise_var
        gain = variance * sensitivity.detach() / innovation_var
        theta_mean = theta_mean + gain * innovation
        variance = (1.0 - gain * sensitivity.detach()) * variance
        variance = variance.clamp_min(cfg.min_variance)
        history.append(
            {
                "step": float(step),
                "ird": float(ird_i),
                "observed_force": float(force_i),
                "predicted_force": float(pred.detach()),
                "sensitivity_dF_dlogGc": float(sensitivity.detach()),
                "gain": float(gain),
                "Gc_mean": float(torch.exp(theta_mean)),
                "std_log_Gc": float(torch.sqrt(variance)),
            }
        )

    recovered = float(torch.exp(theta_mean))
    return {
        "problem": "maier2006_wst_reduced_quasistatic_sequential",
        "true_Gc": cfg.true_gc,
        "init_Gc": cfg.init_gc,
        "recovered_Gc": recovered,
        "relative_error": abs(recovered - cfg.true_gc) / cfg.true_gc,
        "final_std_log_Gc": float(torch.sqrt(variance)),
        "history": history,
        "ird": ird,
        "observed_force": observed_force,
        "claim_boundary": "Reduced differentiable quasistatic surrogate; replace wst_force with PF reaction observable for full validation.",
    }


def force_sensitivity_autograd(
    cfg: WSTConfig | None = None,
    *,
    log_gc: torch.Tensor | None = None,
    ird: torch.Tensor | None = None,
) -> torch.Tensor:
    """Return ``dF/dlog(Gc)`` along a WST history using torch autograd."""

    cfg = cfg or WSTConfig()
    ird = default_ird() if ird is None else ird
    theta = (
        torch.tensor(cfg.init_gc, dtype=torch.float64).log().requires_grad_(True)
        if log_gc is None
        else log_gc.detach().clone().to(dtype=torch.float64).requires_grad_(True)
    )
    force = wst_force(theta, ird.to(dtype=torch.float64), cfg)
    rows = []
    for force_i in force:
        grad = torch.autograd.grad(force_i, theta, retain_graph=True)[0]
        rows.append(grad.detach())
    return torch.stack(rows)


def force_sensitivity_finite_difference(
    cfg: WSTConfig | None = None,
    *,
    log_gc: torch.Tensor | None = None,
    ird: torch.Tensor | None = None,
    eps: float = 1.0e-5,
) -> torch.Tensor:
    """Central finite-difference check for ``dF/dlog(Gc)``."""

    cfg = cfg or WSTConfig()
    ird = default_ird() if ird is None else ird.to(dtype=torch.float64)
    theta = (
        torch.tensor(cfg.init_gc, dtype=torch.float64).log()
        if log_gc is None
        else log_gc.detach().clone().to(dtype=torch.float64)
    )
    force_p = wst_force(theta + eps, ird, cfg)
    force_m = wst_force(theta - eps, ird, cfg)
    return ((force_p - force_m) / (2.0 * eps)).detach()


def run_benchmark(cfg: WSTConfig | None = None) -> dict[str, object]:
    """Compatibility wrapper for running the reduced WST inverse benchmark."""

    return sequential_ekf_recover(cfg)


def _tensor_to_list(value: object) -> object:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    return value


def save_artifacts(result: dict[str, object], out_dir: Path, cfg: WSTConfig | None = None) -> dict[str, str]:
    """Write a JSON summary and PNG figure for a WST EKF result."""

    cfg = cfg or WSTConfig(
        true_gc=float(result["true_Gc"]),
        init_gc=float(result["init_Gc"]),
    )
    out_dir.mkdir(parents=True, exist_ok=True)

    summary = {
        key: _tensor_to_list(value)
        for key, value in result.items()
        if key not in {"ird", "observed_force"}
    }
    summary["observations"] = {
        "imposed_relative_displacement": _tensor_to_list(result["ird"]),
        "splitting_force": _tensor_to_list(result["observed_force"]),
    }
    summary_path = out_dir / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    ird = result["ird"]
    observed_force = result["observed_force"]
    if not isinstance(ird, torch.Tensor) or not isinstance(observed_force, torch.Tensor):
        raise TypeError("result must contain tensor 'ird' and 'observed_force' entries")

    init_force = wst_force(torch.tensor(cfg.init_gc, dtype=torch.float64).log(), ird, cfg).detach()
    recovered_force = wst_force(torch.tensor(float(result["recovered_Gc"]), dtype=torch.float64).log(), ird, cfg).detach()
    history = result["history"]
    estimates = [row["Gc_mean"] for row in history]
    sensitivities = [row["sensitivity_dF_dlogGc"] for row in history]
    stds = [row["std_log_Gc"] for row in history]

    fig, axes = plt.subplots(2, 2, figsize=(10.5, 7.0), constrained_layout=True)
    axes[0, 0].plot(ird, observed_force, "o", label="synthetic observation")
    axes[0, 0].plot(ird, init_force, "--", label="initial")
    axes[0, 0].plot(ird, recovered_force, "-.", label="recovered")
    axes[0, 0].set_xlabel("imposed relative displacement")
    axes[0, 0].set_ylabel("splitting force")
    axes[0, 0].set_title("WST load history")
    axes[0, 0].grid(alpha=0.3)
    axes[0, 0].legend()

    axes[0, 1].plot(ird, sensitivities, "o-", color="#b23a48")
    axes[0, 1].set_xlabel("imposed relative displacement")
    axes[0, 1].set_ylabel("dF/dlog(Gc)")
    axes[0, 1].set_title("autograd sensitivity")
    axes[0, 1].grid(alpha=0.3)

    axes[1, 0].plot(ird, estimates, "o-", color="#26547c")
    axes[1, 0].axhline(cfg.true_gc, color="black", linestyle="--", linewidth=1.0)
    axes[1, 0].set_xlabel("imposed relative displacement")
    axes[1, 0].set_ylabel("Gc estimate")
    axes[1, 0].set_title("sequential EKF estimate")
    axes[1, 0].grid(alpha=0.3)

    axes[1, 1].semilogy(ird, stds, "o-", color="#2a9d8f")
    axes[1, 1].set_xlabel("imposed relative displacement")
    axes[1, 1].set_ylabel("std log(Gc)")
    axes[1, 1].set_title("uncertainty contraction")
    axes[1, 1].grid(alpha=0.3)

    fig.suptitle("Maier-2006-inspired WST sequential inverse benchmark")
    figure_path = out_dir / "wst_sequential_inverse.png"
    fig.savefig(figure_path, dpi=180)
    plt.close(fig)
    return {"summary": str(summary_path), "figure": str(figure_path)}
