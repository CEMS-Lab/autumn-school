"""Optimal sensor placement via Fisher information from FD Jacobian.

Given a Jacobian J (n_obs × n_params) produced by the gate infrastructure,
this module:
  - Computes per-observation sensitivity ||J[i, :]||
  - Ranks spatial sensor subsets by D-optimality (det(F)) or conditioning
  - Produces spatial sensitivity maps for Paper 2 figures

Typical use
-----------
The J matrix is obtained from ``jacobian_finite_difference`` in
``phast.inverse_problems.diagnostics.observability_gate``.
A stored JSON from an observability gate run can also be loaded directly
via ``load_jacobian_from_gate_json``.

For D3 Gc(x) horizontal (obs_mode=full, n_params=2):
    J shape (n_nodes, 2)  — col 0 = dx0, col 1 = d(log_sigma)
    F = J^T @ J             — shape (2, 2), Fisher information matrix

The per-node sensitivity is ||J[i, :]|| = sqrt(sum of squared partial derivs)
and directly shows which spatial measurement locations contribute most to
parameter identifiability.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from torch import Tensor


# ---------------------------------------------------------------------------
# Core Fisher information utilities
# ---------------------------------------------------------------------------

def fisher_matrix(J: Tensor) -> Tensor:
    """F = J^T @ J, shape (n_params, n_params)."""
    J64 = J.to(dtype=torch.float64)
    return J64.T @ J64


def d_optimality(J: Tensor) -> float:
    """D-optimality: log det(F) = sum(log singular_values(J)^2).

    Larger is better. Returns -inf for rank-deficient J.
    """
    svals = torch.linalg.svdvals(J.to(dtype=torch.float64))
    if svals.min() <= 0:
        return float("-inf")
    return float(2.0 * svals.log().sum())


def a_optimality(J: Tensor) -> float:
    """A-optimality: trace(F^{-1}) = sum(1 / sv^2).

    Smaller is better (minimise average posterior variance).
    Returns inf for rank-deficient J.
    """
    svals = torch.linalg.svdvals(J.to(dtype=torch.float64))
    if svals.min() <= 0:
        return float("inf")
    return float((1.0 / svals ** 2).sum())


def condition_number(J: Tensor) -> float:
    svals = torch.linalg.svdvals(J.to(dtype=torch.float64))
    smin = float(svals.min())
    smax = float(svals.max())
    if smin == 0:
        return float("inf")
    return smax / smin


def per_node_sensitivity(J: Tensor) -> np.ndarray:
    """||J[i, :]||_2 for each row (observation node).

    Returns shape (n_obs,).
    """
    J64 = J.to(dtype=torch.float64).detach().cpu()
    return torch.linalg.vector_norm(J64, dim=1).numpy()


def per_param_sensitivity(J: Tensor) -> np.ndarray:
    """||J[:, j]||_2 for each column (parameter).

    Returns shape (n_params,).
    """
    J64 = J.to(dtype=torch.float64).detach().cpu()
    return torch.linalg.vector_norm(J64, dim=0).numpy()


# ---------------------------------------------------------------------------
# Sensor subset ranking
# ---------------------------------------------------------------------------

def rank_spatial_regions(
    J: Tensor,
    node_coords: np.ndarray,
    n_regions: int = 4,
    criterion: str = "d_opt",
) -> List[Dict]:
    """Split the specimen x-range into n_regions bins; rank by criterion.

    Parameters
    ----------
    J             : (n_nodes, n_params)
    node_coords   : (n_nodes, 2) — [x, y] in mm
    n_regions     : number of x-axis bins
    criterion     : 'd_opt' | 'a_opt' | 'condition'

    Returns
    -------
    list of dicts sorted by score, best first
    """
    x = node_coords[:, 0]
    x_min, x_max = float(x.min()), float(x.max())
    bins = np.linspace(x_min, x_max, n_regions + 1)
    results = []
    for k in range(n_regions):
        mask = (x >= bins[k]) & (x < bins[k + 1])
        if k == n_regions - 1:
            mask = (x >= bins[k]) & (x <= bins[k + 1])
        idx = np.where(mask)[0]
        if idx.size < 2:
            continue
        J_sub = J[idx]
        if criterion == "d_opt":
            score = d_optimality(J_sub)
            better = "higher"
        elif criterion == "a_opt":
            score = a_optimality(J_sub)
            better = "lower"
        else:
            score = -condition_number(J_sub)  # negate so higher=better
            better = "lower_cond"
        results.append({
            "region_k": k,
            "x_range": (float(bins[k]), float(bins[k + 1])),
            "n_nodes": int(idx.size),
            "score": score,
            "criterion": criterion,
            "better": better,
        })
    reverse = (criterion != "a_opt")
    return sorted(results, key=lambda r: r["score"], reverse=reverse)


def top_k_sensors(
    J: Tensor,
    node_coords: np.ndarray,
    k: int = 20,
) -> Dict:
    """Return the k nodes with the highest per-node sensitivity.

    Parameters
    ----------
    J            : (n_nodes, n_params)
    node_coords  : (n_nodes, 2)
    k            : number of sensors to select

    Returns
    -------
    dict with 'indices', 'coords', 'sensitivities', 'J_subset' (k × n_params)
    """
    sens = per_node_sensitivity(J)
    top_idx = np.argsort(sens)[::-1][:k].copy()
    J_sub = J[top_idx]
    return {
        "indices": top_idx.tolist(),
        "coords": node_coords[top_idx].tolist(),
        "sensitivities": sens[top_idx].tolist(),
        "J_subset": J_sub.detach().cpu().numpy().tolist(),
        "d_optimality_all": d_optimality(J),
        "d_optimality_top_k": d_optimality(J_sub),
        "condition_all": condition_number(J),
        "condition_top_k": condition_number(J_sub),
    }


# ---------------------------------------------------------------------------
# Load Jacobian from gate JSON
# ---------------------------------------------------------------------------

def load_jacobian_from_gate_json(path: Path) -> Tuple[Tensor, List[str]]:
    """Load the J matrix stored by ``observability_gate_report_fd``.

    The gate JSON stores ``jacobian.col_norms`` and the full Jacobian columns
    via the FD call.  If the raw J was not stored (it isn't by default),
    raises ValueError.
    """
    d = json.loads(Path(path).read_text())
    jac = d.get("jacobian", {})
    raw = jac.get("J_raw")
    if raw is None:
        raise ValueError(
            "Gate JSON does not contain 'J_raw'.  Re-run the gate with "
            "save_J=True or use jacobian_finite_difference() directly.")
    J = torch.tensor(raw, dtype=torch.float64)
    param_names = jac.get("param_names", [f"p{i}" for i in range(J.shape[1])])
    return J, param_names


# ---------------------------------------------------------------------------
# Figure: sensitivity heatmap on specimen geometry
# ---------------------------------------------------------------------------

def plot_sensitivity_heatmap(
    J: Tensor,
    node_coords: np.ndarray,
    param_names: Optional[List[str]] = None,
    truth_x0: Optional[float] = None,
    out_dir: Optional[Path] = None,
    figsize: Tuple[float, float] = (7.0, 2.8),
) -> None:
    """Plot per-parameter and combined sensitivity maps.

    One subplot per parameter (|dR/dp_j| at each node) + one combined
    subplot (||J[i, :]||).  Scatter-plot on specimen x-y coordinates.

    Parameters
    ----------
    J            : (n_nodes, n_params)
    node_coords  : (n_nodes, 2) x, y in mm
    param_names  : list of parameter names
    truth_x0     : optional truth x0 for vertical reference line
    out_dir      : where to save; None = show only
    figsize      : matplotlib figure size
    """
    try:
        import matplotlib.pyplot as plt
        import matplotlib.colors as mcolors
    except ImportError:
        print("  matplotlib not available — skipping sensitivity plot")
        return

    RCPARAMS = {
        "font.family": "serif",
        "font.serif": ["STIXGeneral", "Times New Roman", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 9,
        "axes.labelsize": 9,
        "legend.fontsize": 8,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
    }
    plt.rcParams.update(RCPARAMS)

    J_np = J.detach().cpu().to(torch.float64).numpy()  # (n_nodes, n_params)
    n_params = J_np.shape[1]
    if param_names is None:
        param_names = [f"$p_{{{j}}}$" for j in range(n_params)]

    combined = np.linalg.norm(J_np, axis=1)
    n_cols = n_params + 1
    fig, axes = plt.subplots(1, n_cols, figsize=figsize,
                              constrained_layout=True)
    x = node_coords[:, 0]
    y = node_coords[:, 1]
    s = 2.0  # marker size

    for j in range(n_params):
        col = np.abs(J_np[:, j])
        vmax = np.percentile(col, 99) + 1e-30
        sc = axes[j].scatter(x, y, c=col, s=s, cmap="plasma",
                              vmin=0.0, vmax=vmax, rasterized=True)
        plt.colorbar(sc, ax=axes[j], shrink=0.8, pad=0.02,
                     label=r"$|\partial r/\partial$" + f" {param_names[j]}|")
        axes[j].set_xlabel("$x$ (mm)")
        axes[j].set_ylabel("$y$ (mm)")
        axes[j].set_title(f"Sensitivity: {param_names[j]}")
        axes[j].set_aspect("equal")
        if truth_x0 is not None:
            axes[j].axvline(truth_x0, color="w", lw=0.8, ls="--", alpha=0.7)

    # Combined sensitivity
    sc_c = axes[-1].scatter(x, y, c=combined, s=s, cmap="inferno",
                             vmin=0.0,
                             vmax=np.percentile(combined, 99) + 1e-30,
                             rasterized=True)
    plt.colorbar(sc_c, ax=axes[-1], shrink=0.8, pad=0.02,
                 label=r"$\|J[i, :]\|_2$")
    axes[-1].set_xlabel("$x$ (mm)")
    axes[-1].set_ylabel("$y$ (mm)")
    axes[-1].set_title("Combined sensitivity")
    axes[-1].set_aspect("equal")
    if truth_x0 is not None:
        axes[-1].axvline(truth_x0, color="w", lw=0.8, ls="--", alpha=0.7)

    if out_dir is not None:
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        for ext in ("pdf", "png"):
            kw = {"dpi": 200} if ext == "png" else {}
            fp = out_dir / f"d3_sensitivity_heatmap.{ext}"
            fig.savefig(fp, **kw)
            print(f"  saved: {fp}")
    else:
        plt.show()
    plt.close(fig)


# ---------------------------------------------------------------------------
# Summary report
# ---------------------------------------------------------------------------

def sensor_design_report(
    J: Tensor,
    node_coords: np.ndarray,
    param_names: Optional[List[str]] = None,
    n_top_sensors: int = 20,
    n_regions: int = 4,
) -> Dict:
    """Full sensor design report: top-k, regional ranking, Fisher summary.

    Returns a JSON-serialisable dict.
    """
    F = fisher_matrix(J)
    svals = torch.linalg.svdvals(J.to(dtype=torch.float64)).tolist()

    report = {
        "n_obs": int(J.shape[0]),
        "n_params": int(J.shape[1]),
        "param_names": param_names or [f"p{j}" for j in range(J.shape[1])],
        "fisher": {
            "d_optimality": d_optimality(J),
            "a_optimality": a_optimality(J),
            "condition": condition_number(J),
            "singular_values": svals,
            "F": F.tolist(),
        },
        "per_param_norms": per_param_sensitivity(J).tolist(),
        "top_k_sensors": top_k_sensors(J, node_coords, k=n_top_sensors),
        "regional_ranking": rank_spatial_regions(
            J, node_coords, n_regions=n_regions, criterion="d_opt"),
    }
    return report
