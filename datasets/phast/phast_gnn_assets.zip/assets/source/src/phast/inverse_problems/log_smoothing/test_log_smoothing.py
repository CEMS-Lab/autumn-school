"""Smoke + unit tests for the log-domain smoothing of the
phase-field history-field ``max()``.

Run from the repository root:

    pytest inverse_problems/log_smoothing/test_log_smoothing.py -v

The tests verify three properties Paper 3 P3-C3 hangs on:

1. **Forward equivalence.**  At ``beta = 1e6`` in float64, the
   log-smoothed surrogate reproduces ``torch.maximum`` to within
   ``1e-6`` in the L-infinity norm on random positive inputs that
   stay away from the crossing seam.

2. **Gradient at the active set.**  When ``psi^+`` exactly equals
   ``H_prev`` (a measure-zero set where ``torch.maximum`` has an
   ill-defined sub-gradient that PyTorch silently resolves to one
   of {0, 1}), the log-smoothed surrogate returns a finite gradient
   ``dH/dpsi = sigmoid(0) = 0.5``, smoothly bridging the two sides.

3. **Smoothness.**  ``log_smooth(H, psi + eps) - log_smooth(H, psi)``
   is ``O(eps)`` across the crossing — no jump.
"""
from __future__ import annotations

import math
import os
import sys

import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
# Make ``inverse_problems`` importable both when run as a script
# from the package root and as ``pytest path/to/test_log_smoothing.py``.
sys.path.insert(0, os.path.join(THIS_DIR, "..", ".."))
sys.path.insert(0, os.path.join(THIS_DIR, "..", "..", ".."))

try:
    from phast.inverse_problems.log_smoothing import (  # noqa: E402
        LogSmoothedHistory,
        log_smoothed_history_update,
    )
except ModuleNotFoundError:
    from inverse_problems.log_smoothing import (  # noqa: E402
        LogSmoothedHistory,
        log_smoothed_history_update,
    )


DTYPE = torch.float64
BETA_TIGHT = 1.0e6


def _away_from_crossing(n: int, seed: int = 0) -> tuple[torch.Tensor, torch.Tensor]:
    """Random positive (H_prev, psi_plus) with |log H_prev - log psi_plus| >= 1.

    Keeps inputs out of the smoothing window so we can cleanly compare
    to ``torch.maximum`` at tight tolerance.
    """
    g = torch.Generator().manual_seed(seed)
    log_H = torch.empty(n, dtype=DTYPE).uniform_(-3.0, 3.0, generator=g)
    log_psi = torch.empty(n, dtype=DTYPE).uniform_(-3.0, 3.0, generator=g)
    # Push apart by at least 1 in log-space.
    sep = (log_psi - log_H).sign()
    sep = torch.where(sep == 0, torch.ones_like(sep), sep)
    log_psi = log_H + sep * (1.0 + (log_psi - log_H).abs())
    return log_H.exp(), log_psi.exp()


def test_forward_equivalence_away_from_crossing() -> None:
    H_prev, psi = _away_from_crossing(2048, seed=0)
    H_max = torch.maximum(H_prev, psi)
    H_smooth = log_smoothed_history_update(H_prev, psi, beta=BETA_TIGHT)
    err = (H_smooth - H_max).abs().max().item()
    # Multiplicative bias is ~2^(1/beta) ~ 1 + log(2)/beta;
    # at H ~ 20 this is ~ 1.4e-5, but only at the crossing.
    # Off-crossing inputs (separation >= 1 in log) have bias ~ 0.
    assert err < 1.0e-6, f"forward equivalence failed: max-abs-diff = {err:.3e}"


def test_branch_psi_zero() -> None:
    H_prev = torch.tensor([1.0, 2.0, 0.5], dtype=DTYPE)
    psi = torch.zeros_like(H_prev)
    out = log_smoothed_history_update(H_prev, psi, beta=BETA_TIGHT)
    assert torch.allclose(out, H_prev), "psi=0 branch must return H_prev"


def test_branch_H_zero() -> None:
    H_prev = torch.zeros(3, dtype=DTYPE)
    psi = torch.tensor([1.0, 2.0, 0.5], dtype=DTYPE)
    out = log_smoothed_history_update(H_prev, psi, beta=BETA_TIGHT)
    assert torch.allclose(out, psi), "H=0 branch must return psi"


def test_gradient_at_active_set_is_finite_and_nontrivial() -> None:
    """At psi == H_prev exactly, max() returns the {0,1} sub-gradient
    arbitrarily; the log-smoothed surrogate returns sigmoid(0) = 0.5."""
    H_prev = torch.tensor([1.0, 2.0, 5.0], dtype=DTYPE)
    psi = H_prev.clone().detach().requires_grad_(True)

    H_smooth = log_smoothed_history_update(H_prev, psi, beta=BETA_TIGHT)
    H_smooth.sum().backward()
    g_smooth = psi.grad.clone()

    # At the crossing q = log psi - log H_prev = 0, so
    # dH/dpsi = exp(q_new) * sigmoid(0) / psi = H_prev * 0.5 / psi.
    # Since psi == H_prev here, the analytic value is 0.5 exactly.
    expected = torch.full_like(g_smooth, 0.5)
    assert torch.allclose(g_smooth, expected, atol=1.0e-6), (
        f"log-smoothed gradient at active set is {g_smooth.tolist()}, "
        f"expected ~0.5"
    )

    # Compare to autograd-through-torch.maximum on a slightly *off-tie*
    # input: at the seam itself PyTorch returns the average 0.5 by
    # convention (modern releases), but a hair to either side it snaps
    # to 0 or 1 — that snapping is the discontinuity the log-smoothed
    # surrogate eliminates.
    eps_tie = 1.0e-12  # well below float64 round-off in this range
    psi_lo = (H_prev - eps_tie).detach().clone().requires_grad_(True)
    psi_hi = (H_prev + eps_tie).detach().clone().requires_grad_(True)
    torch.maximum(H_prev, psi_lo).sum().backward()
    torch.maximum(H_prev, psi_hi).sum().backward()
    g_lo = psi_lo.grad.clone()
    g_hi = psi_hi.grad.clone()
    assert torch.allclose(g_lo, torch.zeros_like(g_lo)), (
        f"max gradient just below seam should be 0, got {g_lo.tolist()}"
    )
    assert torch.allclose(g_hi, torch.ones_like(g_hi)), (
        f"max gradient just above seam should be 1, got {g_hi.tolist()}"
    )

    # Log-smoothed across the same micro-window: smooth, near 0.5 on
    # both sides (it bridges 0 and 1 with width 1/beta in log-space).
    psi_lo2 = (H_prev - eps_tie).detach().clone().requires_grad_(True)
    psi_hi2 = (H_prev + eps_tie).detach().clone().requires_grad_(True)
    log_smoothed_history_update(H_prev, psi_lo2, beta=BETA_TIGHT).sum().backward()
    log_smoothed_history_update(H_prev, psi_hi2, beta=BETA_TIGHT).sum().backward()
    g_smooth_lo = psi_lo2.grad.clone()
    g_smooth_hi = psi_hi2.grad.clone()
    # Smoothed gradients are continuous across the seam: both sides
    # near 0.5 (the smoothing window is ~1/beta in log-space, far
    # wider than eps_tie).
    assert torch.allclose(g_smooth_lo, expected, atol=1.0e-6), (
        f"log-smoothed grad below seam {g_smooth_lo.tolist()} != ~0.5"
    )
    assert torch.allclose(g_smooth_hi, expected, atol=1.0e-6), (
        f"log-smoothed grad above seam {g_smooth_hi.tolist()} != ~0.5"
    )


def test_smoothness_across_crossing() -> None:
    """log_smooth(H, psi + eps) - log_smooth(H, psi) should be O(eps),
    not a jump, when sweeping psi through the crossing."""
    H_prev = torch.tensor([1.0], dtype=DTYPE)
    eps = 1.0e-3
    psi_lo = torch.tensor([1.0 - 5 * eps], dtype=DTYPE)
    psi_hi = torch.tensor([1.0 + 5 * eps], dtype=DTYPE)
    H_lo = log_smoothed_history_update(H_prev, psi_lo, beta=BETA_TIGHT)
    H_hi = log_smoothed_history_update(H_prev, psi_hi, beta=BETA_TIGHT)
    jump = (H_hi - H_lo).abs().item()
    # 10*eps span across the crossing, slope at most 1 -> jump < 11*eps.
    assert jump < 11.0 * eps, f"jump = {jump:.3e} too large for eps={eps}"
    assert jump > 4.0 * eps, (
        f"jump = {jump:.3e} suspiciously small — surrogate is over-smoothing"
    )


def test_module_wrapper_matches_function() -> None:
    H_prev, psi = _away_from_crossing(64, seed=1)
    ls = LogSmoothedHistory(beta=BETA_TIGHT)
    out_mod = ls(H_prev, psi)
    out_fn = log_smoothed_history_update(H_prev, psi, beta=BETA_TIGHT)
    assert torch.equal(out_mod, out_fn)


def test_monotone_in_time() -> None:
    """H_new >= H_prev pointwise, exactly (no negative drift)."""
    H_prev, psi = _away_from_crossing(256, seed=2)
    H_new = log_smoothed_history_update(H_prev, psi, beta=BETA_TIGHT)
    assert (H_new + 1.0e-12 >= H_prev).all(), "monotonicity violated"


def test_limit_recovers_max() -> None:
    """As beta -> infty (here 1e8), max-abs-diff -> 0 in float64."""
    H_prev, psi = _away_from_crossing(1024, seed=3)
    H_smooth = log_smoothed_history_update(H_prev, psi, beta=1.0e8)
    H_max = torch.maximum(H_prev, psi)
    err = (H_smooth - H_max).abs().max().item()
    assert err < 1.0e-8, f"large-beta limit error {err:.3e}"


if __name__ == "__main__":
    # Allow running as a script for quick smoke without pytest.
    import traceback

    tests = [
        test_forward_equivalence_away_from_crossing,
        test_branch_psi_zero,
        test_branch_H_zero,
        test_gradient_at_active_set_is_finite_and_nontrivial,
        test_smoothness_across_crossing,
        test_module_wrapper_matches_function,
        test_monotone_in_time,
        test_limit_recovers_max,
    ]
    n_pass = 0
    for fn in tests:
        try:
            fn()
            print(f"  PASS  {fn.__name__}")
            n_pass += 1
        except Exception:
            print(f"  FAIL  {fn.__name__}")
            traceback.print_exc()
    print(f"\n{n_pass}/{len(tests)} passed")
    sys.exit(0 if n_pass == len(tests) else 1)
