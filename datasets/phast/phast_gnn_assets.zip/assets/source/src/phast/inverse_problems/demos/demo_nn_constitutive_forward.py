#!/usr/bin/env python
"""Demo 10 forward gate: differentiable neural constitutive-law proxy.

This is intentionally a forward-review prototype, not a solver-coupled
inverse claim. Issue #87 tracks the full learned-constitutive integration
inside ``FEMOperators``. The purpose here is to generate a reproducible
Paper 2/3 candidate bundle showing the low-dimensional constitutive forward
observable that a later inverse problem would recover from: stress-strain,
degradation, traction-separation, and load-displacement curves.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))


class SmallConstitutiveNet(torch.nn.Module):
    """Tiny positive-dissipation scalar law for the forward gate."""

    def __init__(self, hidden=32):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Linear(2, hidden),
            torch.nn.SiLU(),
            torch.nn.Linear(hidden, hidden),
            torch.nn.SiLU(),
            torch.nn.Linear(hidden, 1),
        )

    def forward(self, strain, damage):
        x = torch.stack([strain, damage], dim=-1)
        raw = self.net(x).squeeze(-1)
        # Positive tangent modulus surrogate. The residual avoids a zero
        # stiffness law, which would be unphysical in the downstream solver.
        return 1.0e-3 + torch.nn.functional.softplus(raw)


def analytic_target(strain, damage, E0, beta):
    g = (1.0 - damage).clamp_min(0.0) ** 2 + 1.0e-6
    hardening = 1.0 + beta * strain.square()
    sigma = E0 * g * strain / hardening
    traction = sigma * torch.exp(-3.0 * damage)
    load = torch.trapz(traction, strain)
    return sigma, traction, load


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device', type=str, default='cpu',
                   choices=['cpu', 'cuda'])
    p.add_argument('--n_points', type=int, default=256)
    p.add_argument('--E0', type=float, default=3090.0)
    p.add_argument('--beta', type=float, default=80.0)
    p.add_argument('--seed', type=int, default=10)
    p.add_argument('--output_dir', type=str,
                   default='results_nn_constitutive_forward')
    args = p.parse_args()

    out_dir = (args.output_dir if os.path.isabs(args.output_dir)
               else os.path.join(THIS_DIR, args.output_dir))
    os.makedirs(out_dir, exist_ok=True)

    device = args.device
    if device == 'cuda' and not torch.cuda.is_available():
        device = 'cpu'
    dtype = torch.float64
    torch.manual_seed(args.seed)

    strain = torch.linspace(0.0, 0.03, args.n_points,
                            dtype=dtype, device=device)
    damage = torch.linspace(0.0, 0.95, args.n_points,
                            dtype=dtype, device=device)
    E0 = torch.tensor(args.E0, dtype=dtype, device=device,
                      requires_grad=True)
    beta = torch.tensor(args.beta, dtype=dtype, device=device,
                        requires_grad=True)
    sigma_target, traction_target, load_target = analytic_target(
        strain, damage, E0, beta)

    net = SmallConstitutiveNet().to(device=device, dtype=dtype)
    modulus_scale = net(strain / strain.max().clamp_min(1e-12), damage)
    sigma_nn = E0 * modulus_scale / modulus_scale.detach().mean() * (
        (1.0 - damage).clamp_min(0.0) ** 2 + 1.0e-6) * strain
    traction_nn = sigma_nn * torch.exp(-3.0 * damage)
    load_nn = torch.trapz(traction_nn, strain)
    loss = ((sigma_nn - sigma_target) ** 2).mean() / (
        sigma_target.square().mean() + 1e-24)
    loss = loss + (load_nn - load_target).square() / (
        load_target.square() + 1e-24)
    loss.backward()

    arrays = {
        'strain': strain.detach().cpu().numpy(),
        'damage': damage.detach().cpu().numpy(),
        'sigma_target': sigma_target.detach().cpu().numpy(),
        'traction_target': traction_target.detach().cpu().numpy(),
        'sigma_nn_untrained': sigma_nn.detach().cpu().numpy(),
        'traction_nn_untrained': traction_nn.detach().cpu().numpy(),
    }
    np.savez_compressed(os.path.join(out_dir, 'truth_forward_bundle.npz'),
                        **arrays)
    meta = {
        'status': 'forward_proxy',
        'note': ('D10 is a constitutive-law forward proxy only; issue #87 '
                 'tracks solver-coupled learned constitutive integration.'),
        'loss': float(loss.detach().cpu()),
        'grad_E0': float(E0.grad.detach().cpu()),
        'grad_beta': float(beta.grad.detach().cpu()),
        'device': device,
        'n_points': int(args.n_points),
        'bundle': 'truth_forward_bundle.npz',
    }
    with open(os.path.join(out_dir, 'forward_bundle.json'), 'w') as fh:
        json.dump(meta, fh, indent=2)

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 3, figsize=(12.0, 3.5),
                             constrained_layout=True)
    axes[0].plot(arrays['strain'], arrays['sigma_target'], label='target')
    axes[0].plot(arrays['strain'], arrays['sigma_nn_untrained'],
                 label='NN forward', linestyle='--')
    axes[0].set_xlabel('strain')
    axes[0].set_ylabel('stress (MPa)')
    axes[0].legend()
    axes[1].plot(arrays['damage'], arrays['traction_target'], label='target')
    axes[1].plot(arrays['damage'], arrays['traction_nn_untrained'],
                 label='NN forward', linestyle='--')
    axes[1].set_xlabel('damage d')
    axes[1].set_ylabel('traction proxy')
    axes[2].plot(arrays['damage'], (1.0 - arrays['damage']) ** 2)
    axes[2].set_xlabel('damage d')
    axes[2].set_ylabel('degradation g(d)')
    fig.suptitle('Demo 10 forward proxy: differentiable constitutive law')
    fig.savefig(os.path.join(out_dir, 'demo10_nn_constitutive_forward.png'),
                dpi=180)
    plt.close(fig)

    print("=" * 72)
    print("  Demo 10 NN constitutive forward proxy")
    print("=" * 72)
    print(f"  Output: {out_dir}")
    print(f"  loss={meta['loss']:.6e}, grad_E0={meta['grad_E0']:.6e}, "
          f"grad_beta={meta['grad_beta']:.6e}")


if __name__ == '__main__':
    main()
