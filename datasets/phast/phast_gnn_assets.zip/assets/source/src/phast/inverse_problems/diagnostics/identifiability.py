"""Fisher-Information-Matrix-at-truth diagnostic (issue #476).

For a forward model y = forward_fn(theta) and an observable o = obs_fn(y),
the Gauss-Newton approximation to the FIM (assuming unit observation
noise) is

    F = J^T J,    J_{i, k} = partial o_i / partial theta_k.

We compute J two ways:

* :func:`fim_finite_difference` -- 2-sided FD on theta, requires only a
  forward call. Good as a sanity check and for forward models that are
  not autograd-friendly.

* :func:`fim_autograd` -- vector-Jacobian product via ``torch.autograd``,
  exact up to FP noise. Preferred when ``forward_fn`` and ``obs_fn``
  are both differentiable in ``theta``.

:func:`identifiability_report` summarises the SVD: condition number,
effective rank (count of singular values above ``1e-6 * sigma_max``),
and the singular values themselves. This is the local-identifiability
verdict used in the dynamic-attractor write-up.
"""
from __future__ import annotations

from typing import Callable

import torch


def _flatten_obs(o: torch.Tensor) -> torch.Tensor:
    """Reshape an arbitrary-shaped observable to a 1-D vector for the
    Jacobian assembly. Keeps dtype/device."""
    return o.reshape(-1)


def fim_finite_difference(
    forward_fn: Callable[[torch.Tensor], torch.Tensor],
    theta_truth: torch.Tensor,
    obs_fn: Callable[[torch.Tensor], torch.Tensor] | None = None,
    eps: float = 1e-3,
) -> torch.Tensor:
    """Gauss-Newton FIM at ``theta_truth`` via 2-sided finite differences.

    Parameters
    ----------
    forward_fn : Callable[[theta], y]
        Maps a 1-D parameter vector to a forward solution. ``theta`` is
        passed as a detached tensor.
    theta_truth : torch.Tensor, shape (k,)
        The point at which the FIM is evaluated.
    obs_fn : optional, Callable[[y], o]
        Observable extractor. Defaults to identity.
    eps : float
        Relative perturbation: theta_k +/- eps * max(|theta_k|, 1).

    Returns
    -------
    F : torch.Tensor, shape (k, k)
        Symmetric PSD matrix ``J^T J``. The matrix is symmetrised
        explicitly via ``0.5 * (F + F.T)`` to suppress FD round-off
        asymmetries.
    """
    if obs_fn is None:
        obs_fn = lambda y: y  # noqa: E731
    theta = theta_truth.detach().to(dtype=torch.float64).clone()
    k = theta.numel()
    # Reference forward (only needed to size J; we use central diff so
    # we don't depend on the central value itself).
    y0 = forward_fn(theta)
    o0 = _flatten_obs(obs_fn(y0)).detach().to(dtype=torch.float64)
    m = o0.numel()
    J = torch.zeros((m, k), dtype=torch.float64)
    for j in range(k):
        h = eps * max(abs(float(theta[j])), 1.0)
        tp = theta.clone(); tp[j] = tp[j] + h
        tm = theta.clone(); tm[j] = tm[j] - h
        op = _flatten_obs(obs_fn(forward_fn(tp))).detach().to(
            dtype=torch.float64)
        om = _flatten_obs(obs_fn(forward_fn(tm))).detach().to(
            dtype=torch.float64)
        J[:, j] = (op - om) / (2.0 * h)
    F = J.T @ J
    return 0.5 * (F + F.T)


def fim_autograd(
    forward_fn: Callable[[torch.Tensor], torch.Tensor],
    theta_truth: torch.Tensor,
    obs_fn: Callable[[torch.Tensor], torch.Tensor] | None = None,
) -> torch.Tensor:
    """Gauss-Newton FIM at ``theta_truth`` via ``torch.autograd``.

    Builds the Jacobian J by reverse-mode AD: one backward per
    observable component. For ``m`` outputs and ``k`` parameters the
    cost is ``m`` backward passes.

    Notes
    -----
    * Requires ``forward_fn`` + ``obs_fn`` to be differentiable in the
      parameter vector ``theta``.
    * Output is symmetrised the same way as :func:`fim_finite_difference`
      to keep both code paths comparable.
    """
    if obs_fn is None:
        obs_fn = lambda y: y  # noqa: E731
    theta = theta_truth.detach().to(dtype=torch.float64).clone()
    theta.requires_grad_(True)
    o = _flatten_obs(obs_fn(forward_fn(theta)))
    m = o.numel()
    k = theta.numel()
    J = torch.zeros((m, k), dtype=torch.float64)
    for i in range(m):
        if theta.grad is not None:
            theta.grad = None
        # Retain graph except on the last component.
        retain = (i < m - 1)
        gi = torch.autograd.grad(o[i], theta, retain_graph=retain)[0]
        J[i, :] = gi.detach().to(dtype=torch.float64)
    F = J.T @ J
    return 0.5 * (F + F.T)


def identifiability_report(
    fim: torch.Tensor,
    rel_rank_tol: float = 1e-6,
) -> dict:
    """SVD-based summary of an FIM.

    Parameters
    ----------
    fim : torch.Tensor, shape (k, k)
        A symmetric PSD matrix (output of one of the ``fim_*`` builders
        above). Symmetry / PSD-ness is not re-checked here.
    rel_rank_tol : float
        Singular values below ``rel_rank_tol * sigma_max`` are treated
        as zero for the effective-rank count.

    Returns
    -------
    dict with keys:
      * ``singular_values`` : 1-D torch.Tensor, sorted descending
      * ``condition_number`` : float, ``sigma_max / sigma_min``
        (``inf`` if ``sigma_min == 0``)
      * ``effective_rank`` : int, ``sum(sigma > rel_rank_tol * sigma_max)``
      * ``rel_rank_tol`` : float, the tolerance used (echoed for
        downstream logging)
    """
    s = torch.linalg.svdvals(fim).to(dtype=torch.float64)
    s_sorted, _ = torch.sort(s, descending=True)
    s_max = float(s_sorted[0]) if s_sorted.numel() else 0.0
    s_min = float(s_sorted[-1]) if s_sorted.numel() else 0.0
    if s_min > 0.0:
        cond = s_max / s_min
    else:
        cond = float('inf')
    eff_rank = int((s_sorted > rel_rank_tol * s_max).sum().item()) \
        if s_max > 0.0 else 0
    return {
        'singular_values': s_sorted,
        'condition_number': cond,
        'effective_rank': eff_rank,
        'rel_rank_tol': rel_rank_tol,
    }


__all__ = [
    'fim_finite_difference',
    'fim_autograd',
    'identifiability_report',
]
