"""Pytest collection boundary for the optimizer tests.

The repo root has its own ``__init__.py`` (the legacy ``phast``
package layout); when pytest walks parent directories looking for
``conftest.py`` it ends up importing that root ``__init__.py``, which
contains relative imports that only work when the file is loaded as
part of a parent package. The tests in this directory are deliberately
*self-contained* (they test ``ESOptimizer`` against analytic loss
functions, no PF solver involvement) so we don't need any of that
machinery.

This conftest acts as a collection root: pytest will stop walking up
past this file. We also push the repo root onto ``sys.path`` so that
relative imports of ``inverse_problems`` from inside the test work
when invoked from outside this directory.
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_HERE, "..", ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

collect_ignore_glob = ["__init__.py"]
