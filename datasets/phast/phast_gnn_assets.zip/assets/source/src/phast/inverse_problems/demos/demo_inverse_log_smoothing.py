#!/usr/bin/env python
"""Demo: log-domain smoothing of the irreversibility ``max()`` vs the
hard ``max`` and the primal ``softmax_H_beta``, for material parameter
recovery.

Reproduces the scalar (Gc, l0) inversion of
``demo_autograd_inversion.py`` but routes the history-field update
through one of three surrogates, selected by ``--history``:

  ``max``         hard ``torch.maximum`` (default in solver)
  ``softmax``     primal smooth-max ``softmax_H_beta`` (config knob)
  ``log_smooth``  log-domain smoothing at large beta (this PR)

The log-smooth route is wired by *monkey-patching* the bound method
``StaggeredSolver._H_update`` on the solver instance — the solver
source itself is untouched (see ``LogSmoothedHistory`` docstring).

Note: this is *not* a proximal Galerkin method.  Keith & Surowiec
(2024, FoCM) describe a structure-preserving FEM with latent-variable
Bregman regularisation and a true KKT active-set; that is *not* what
this demo or its underlying module implements.  The closed-form
update used here is simply softplus-smoothed-relu in log-space.

Usage
-----
    python demo_inverse_log_smoothing.py --history all
    python demo_inverse_log_smoothing.py --history log_smooth --n_iters 30

Note on the ``softmax`` baseline: the additive bias of the primal
smooth-max ``H_prev + softplus(beta*(psi-H_prev))/beta`` is
``log(2)/beta``, which scales with the magnitude of ``H``.  At the
crack-tip cells ``psi^+`` is order ``Gc/l0 ~ 5`` and at ``beta=10``
the bias is ``~7e-2``, comparable to the signal; in this small-step,
small-iter LBFGS configuration the optimiser over-corrects into a
bad basin (``Gc -> 0.45``).  This is *expected* — and is precisely
the failure mode the log-domain surrogate avoids by making the bias
multiplicative (and tiny at beta=1e6) instead of additive.

``--history all`` runs all three back-to-back and writes:

    results_log_smoothing/history_max.json
    results_log_smoothing/history_softmax_b10.json
    results_log_smoothing/history_log_smooth.json
    results_log_smoothing/comparison.png

Then ``papers/paper3/figures/proximal_vs_softmax.py`` renders panel (c).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
import time
import types

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.abspath(os.path.join(THIS_DIR, "..", ".."))
PKG_PARENT = os.path.dirname(PKG_ROOT)

# Register the package directory as ``phast`` regardless of
# where the package physically lives (e.g. inside a git worktree whose
# directory name is not ``phast``).  This mirrors what the
# main-repo demos rely on implicitly via the symlinked package path.
if "phast" not in sys.modules:
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location(
        "phast",
        os.path.join(PKG_ROOT, "__init__.py"),
        submodule_search_locations=[PKG_ROOT],
    )
    _mod = _ilu.module_from_spec(_spec)
    sys.modules["phast"] = _mod
    _spec.loader.exec_module(_mod)
sys.path.insert(0, PKG_PARENT)
sys.path.insert(0, PKG_ROOT)

from phast.material import Material  # noqa: E402
from phast.mesh import FEMMesh  # noqa: E402
from phast.boundary_conditions import BoundaryConditions  # noqa: E402
from phast.staggered_solver import (  # noqa: E402
    StaggeredSolver, SolverConfig,
)
from phast.mesh_generator import rectangular_sent  # noqa: E402
from phast.device import DeviceContext  # noqa: E402
from phast.config import LoadingConfig  # noqa: E402
from phast.inverse_problems.log_smoothing import (  # noqa: E402
    log_smoothed_history_update,
)
from phast.inverse_problems._tbptt import (  # noqa: E402
    run_forward_tbptt_generic,
    make_install_diff_Gc,
)


# ---------------------------------------------------------------------------
# Mesh / solver builders (mirror demo_autograd_inversion.py)
# ---------------------------------------------------------------------------

def build_mesh(device: str, dtype: torch.dtype, h_crack: float = 1.0,
               h_coarse: float = 2.5) -> FEMMesh:
    mesh_path = os.path.join(tempfile.gettempdir(),
                             "demo_log_smoothing_mesh.msh")
    rectangular_sent(mesh_path, W=20.0, H=20.0, a=10.0, l0=0.5,
                     h_crack=h_crack, h_coarse=h_coarse)
    mesh = FEMMesh(mesh_path, device=device, dtype=dtype)
    mesh.identify_boundaries()
    return mesh


def build_solver(mesh: FEMMesh, history_mode: str,
                 sigma: float = 500.0, device: str = "cpu",
                 softmax_beta: float = 10.0,
                 log_smooth_beta: float = 1.0e6) -> StaggeredSolver:
    """Build a StaggeredSolver wired with the requested history surrogate.

    history_mode: ``'max'`` | ``'softmax'`` | ``'log_smooth'``.
    """
    mat = Material(E=210000.0, nu=0.30, Gc=2.7, l0=0.5, rho=7.8e-9,
                   energy_split="spectral", pf_model="AT2",
                   eta_residual=1e-7)
    ctx = DeviceContext(device=device, profile=False, compile_solvers=False)
    bcs = BoundaryConditions(mesh.n_nodes, device=ctx.device, dtype=ctx.dtype)
    bcs.add_neumann(mesh.node_sets["top"], [0.0, 1.0])
    bcs.add_neumann(mesh.node_sets["bottom"], [0.0, -1.0])
    bcs.fix(mesh.node_sets["left"], 0)

    if history_mode == "max":
        cfg = SolverConfig(solver_type="explicit", dt_safety=0.5,
                           differentiable=True)
    elif history_mode == "softmax":
        cfg = SolverConfig(solver_type="explicit", dt_safety=0.5,
                           differentiable=True,
                           softmax_H_beta=softmax_beta)
    elif history_mode == "log_smooth":
        cfg = SolverConfig(solver_type="explicit", dt_safety=0.5,
                           differentiable=True)
    else:
        raise ValueError(f"unknown history_mode={history_mode}")

    solver = StaggeredSolver(mesh, mat, bcs, config=cfg, ctx=ctx)
    solver.f_ext = sigma * bcs.get_neumann_forces(mesh)

    if history_mode == "log_smooth":
        # Monkey-patch the bound method to route through the log-domain
        # smoothed surrogate without touching staggered_solver.py source.
        beta = log_smooth_beta

        def _log_smooth_H_update(self, H_old, psi):
            return log_smoothed_history_update(H_old, psi, beta=beta)

        solver._H_update = types.MethodType(_log_smooth_H_update, solver)

    return solver


def run_forward(solver: StaggeredSolver, Gc_t: torch.Tensor,
                l0_t: torch.Tensor, n_steps: int) -> torch.Tensor:
    solver.diff_Gc = Gc_t
    solver.diff_l0 = l0_t
    n_nodes = solver.mesh.n_nodes
    dtype = solver.u.dtype
    device = solver.u.device
    solver.u = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.v = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.a = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.d = torch.zeros(n_nodes, dtype=dtype, device=device)
    n_elems = len(solver.mesh.elements)
    solver.H_elem = torch.zeros(n_elems, dtype=dtype, device=device)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dtype, device=device)
    if hasattr(solver, "_explicit_step_count"):
        solver._explicit_step_count = 0
    solver._step_count = 0
    for _ in range(n_steps):
        solver.step_full()
    return solver.d


# ---------------------------------------------------------------------------
# Inversion driver
# ---------------------------------------------------------------------------

def run_inversion(history_mode: str, args, mesh: FEMMesh,
                  d_target: torch.Tensor, dtype: torch.dtype,
                  device: str,
                  d_target_tbptt_chunks=None) -> dict:
    """Run one inversion with the requested history surrogate. Returns
    the loss/parameter history dict (matching demo_autograd_inversion).

    When ``args.tbptt_chunk_size > 0`` the per-iteration forward is
    routed through ``run_forward_tbptt_generic`` (issue #301); the loss
    is the mean of per-chunk damage MSEs. ``d_target_tbptt_chunks`` is
    the cached list of per-chunk truth snapshots (must be supplied when
    TBPTT is enabled). Constant ``LoadingConfig`` is the no-op for this
    demo's plain ``solver.step_full()`` loop (Dirichlet BCs are zero-fixed
    and ``f_ext`` is set externally).
    """
    print(f"\n=== history='{history_mode}' ===")
    solver = build_solver(mesh, history_mode=history_mode,
                          sigma=500.0, device=device,
                          softmax_beta=args.softmax_beta,
                          log_smooth_beta=args.log_smooth_beta)
    tbptt_on = int(getattr(args, "tbptt_chunk_size", 0)) > 0
    loading = LoadingConfig(ramp_type='constant') if tbptt_on else None

    Gc_init = 4.0
    l0_init = 0.75
    log_Gc = torch.tensor(float(np.log(Gc_init)), dtype=dtype,
                          device=device, requires_grad=True)
    log_l0 = torch.tensor(float(np.log(l0_init)), dtype=dtype,
                          device=device, requires_grad=True)

    optimizer = torch.optim.LBFGS(
        [log_Gc, log_l0], lr=1.0, max_iter=4,
        history_size=10, line_search_fn="strong_wolfe",
    )

    history = {"iter": [], "loss": [], "Gc": [], "l0": [],
               "rel_err_Gc": [], "rel_err_l0": [], "wall_time": []}
    iter_state = {"n_forwards": 0}

    def closure():
        optimizer.zero_grad()
        Gc_t = torch.exp(log_Gc)
        l0_t = torch.exp(log_l0)
        if tbptt_on:
            assert d_target_tbptt_chunks is not None, (
                "TBPTT path requires per-chunk truth snapshots")
            _, chunk_snaps_pred, _, _ = run_forward_tbptt_generic(
                solver, loading,
                install_fn=make_install_diff_Gc(Gc_t, l0_t),
                n_steps=args.n_steps,
                tbptt_chunk_size=int(args.tbptt_chunk_size))
            chunk_losses = [
                ((dp - dt) ** 2).mean()
                for dp, dt in zip(chunk_snaps_pred,
                                   d_target_tbptt_chunks)]
            loss = torch.stack(chunk_losses).mean()
        else:
            d_pred = run_forward(solver, Gc_t, l0_t, args.n_steps)
            loss = ((d_pred - d_target) ** 2).mean()
        loss.backward()
        iter_state["n_forwards"] += 1
        return loss

    Gc_true = 2.7
    l0_true = 0.5
    t_loop = time.time()
    for it in range(args.n_iters):
        t_iter = time.time()
        try:
            loss = optimizer.step(closure)
        except RuntimeError as exc:
            print(f"  it {it:3d} | LBFGS error: {exc}")
            break
        Gc_val = float(torch.exp(log_Gc).item())
        l0_val = float(torch.exp(log_l0).item())
        history["iter"].append(it)
        history["loss"].append(float(loss.item()))
        history["Gc"].append(Gc_val)
        history["l0"].append(l0_val)
        history["rel_err_Gc"].append(abs(Gc_val - Gc_true) / Gc_true)
        history["rel_err_l0"].append(abs(l0_val - l0_true) / l0_true)
        history["wall_time"].append(time.time() - t_iter)
        if it % max(1, args.n_iters // 10) == 0 or it == args.n_iters - 1:
            print(f"  it {it:3d} | loss={loss.item():.3e} "
                  f"| Gc={Gc_val:.4f} | l0={l0_val:.4f} "
                  f"| {history['wall_time'][-1]:.1f}s",
                  flush=True)
    print(f"  total wall-time: {time.time() - t_loop:.1f}s "
          f"({iter_state['n_forwards']} forwards)")

    return {
        "history_mode": history_mode,
        "history": history,
        "n_forwards": iter_state["n_forwards"],
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--n_steps", type=int, default=30)
    p.add_argument("--n_iters", type=int, default=20)
    p.add_argument("--history", type=str, default="all",
                   choices=["max", "softmax", "log_smooth", "all"])
    p.add_argument("--softmax_beta", type=float, default=10.0)
    p.add_argument("--log_smooth_beta", type=float, default=1.0e6)
    p.add_argument("--device", type=str, default="cpu")
    p.add_argument("--h_crack", type=float, default=1.0)
    p.add_argument("--output_dir", type=str, default="results_log_smoothing")
    p.add_argument("--tbptt_chunk_size", type=int, default=0,
                   help="Truncated-BPTT chunk length (issue #288 / #301). "
                        "0 disables (default; full autograd graph). When "
                        ">0, the n_steps explicit-dynamics loop is split "
                        "into chunks of this length and per-chunk damage "
                        "MSE is the (biased) loss. Constant LoadingConfig "
                        "is the no-op equivalent for this demo's plain "
                        "solver.step_full() loop.")
    args = p.parse_args()

    out_dir = os.path.join(THIS_DIR, args.output_dir)
    os.makedirs(out_dir, exist_ok=True)

    dtype = torch.float64
    print("=" * 70)
    print("  DEMO: log-domain smoothing of irreversibility max()")
    print("        (P3-C3 — issue #290)")
    print("=" * 70)

    mesh = build_mesh(args.device, dtype, h_crack=args.h_crack)
    print(f"  Mesh: {int(mesh.n_nodes)} nodes, "
          f"{int(len(mesh.elements))} elements")

    Gc_true, l0_true = 2.7, 0.5
    print(f"\n[1/2] Generating target damage at (Gc*, l0*) = "
          f"({Gc_true}, {l0_true}) using hard-max solver ...")
    truth_solver = build_solver(mesh, history_mode="max",
                                device=args.device)
    d_target_tbptt_chunks = None
    if args.tbptt_chunk_size > 0:
        cs = int(args.tbptt_chunk_size)
        n_chunks = (args.n_steps + cs - 1) // cs
        print(f"\n[TBPTT #301] enabled: chunk_size={cs}, "
              f"{n_chunks} chunks")
        loading_truth = LoadingConfig(ramp_type='constant')
        with torch.no_grad():
            Gc_star = torch.tensor(Gc_true, dtype=dtype,
                                    device=args.device)
            l0_star = torch.tensor(l0_true, dtype=dtype,
                                    device=args.device)
            d_target, truth_chunk_snaps, _, _ = run_forward_tbptt_generic(
                truth_solver, loading_truth,
                install_fn=make_install_diff_Gc(Gc_star, l0_star),
                n_steps=args.n_steps, tbptt_chunk_size=cs)
            d_target_tbptt_chunks = [s.detach().clone()
                                      for s in truth_chunk_snaps]
            d_target = d_target_tbptt_chunks[-1]
    else:
        with torch.no_grad():
            d_target = run_forward(
                truth_solver,
                torch.tensor(Gc_true, dtype=dtype, device=args.device),
                torch.tensor(l0_true, dtype=dtype, device=args.device),
                args.n_steps,
            ).detach().clone()
    print(f"  target: max(d)={d_target.max().item():.4f}  "
          f"damaged>0.1 = {(d_target > 0.1).sum().item()}")

    print("\n[2/2] Inversion runs ...")
    modes = (["max", "softmax", "log_smooth"]
             if args.history == "all" else [args.history])
    results = {}
    for mode in modes:
        res = run_inversion(mode, args, mesh, d_target, dtype,
                             args.device,
                             d_target_tbptt_chunks=d_target_tbptt_chunks)
        suffix = "max" if mode == "max" else (
            f"softmax_b{int(args.softmax_beta)}" if mode == "softmax"
            else "log_smooth"
        )
        path = os.path.join(out_dir, f"history_{suffix}.json")
        with open(path, "w") as fp:
            json.dump(res, fp, indent=2)
        print(f"  -> {path}")
        results[mode] = res

    # Side-by-side convergence plot.
    if len(results) > 1:
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(figsize=(5.5, 3.6))
            for mode, style in [("max", "k-o"), ("softmax", "C1--s"),
                                ("log_smooth", "C0:^")]:
                if mode not in results:
                    continue
                h = results[mode]["history"]
                ax.semilogy(h["iter"], h["loss"], style, ms=3, lw=1.4,
                            label=mode)
            ax.set_xlabel("iteration")
            ax.set_ylabel("MSE loss")
            ax.set_title("Inversion convergence — irreversibility surrogates")
            ax.legend()
            ax.grid(True, alpha=0.3, which="both")
            fig.tight_layout()
            fig.savefig(os.path.join(out_dir, "comparison.png"),
                        dpi=150, bbox_inches="tight")
            plt.close(fig)
            print(f"  -> {os.path.join(out_dir, 'comparison.png')}")
        except Exception as exc:
            print(f"  comparison plot skipped: {exc}")

    # Honest summary line.
    print()
    for mode, res in results.items():
        h = res["history"]
        if not h["loss"]:
            print(f"  {mode}: no iterations completed")
            continue
        print(f"  {mode:11s}: final loss={h['loss'][-1]:.3e}  "
              f"Gc={h['Gc'][-1]:.4f}  l0={h['l0'][-1]:.4f}")


if __name__ == "__main__":
    main()
