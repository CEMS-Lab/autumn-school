#!/usr/bin/env python
"""
Head-to-head inverse-identification demo against Stanić et al. (2026, IJNME).

Stanić et al. identify 6 material parameters of an embedded-discontinuity FEM
model on Kalthoff's dynamic test using a 3-phase Bayesian MCMC scheme with
gPCE surrogate. Their reported cost is ~15,000 high-fidelity Kalthoff forward
simulations to build the surrogates, plus MCMC sampling on top.

Here we identify the analogous material parameters of the phase-field model
on the SAME geometry with the SAME measurement type (nodal displacements at
Stanić Table 2 sampling points), using gradient-based optimisation through
the phast. Gradients are computed by central finite differences on
the parameter vector inside a single PyTorch tensor; the algorithmic
structure is identical to a true autograd loop and would drop in unchanged
once the Material class accepts tensor-valued parameters end-to-end.

Parameters identified (phase-field analogue of Stanić's K, G, σ_un/us, G_fn/fs):
    E    Young's modulus              [MPa]
    nu   Poisson's ratio              [-]
    Gc   fracture toughness           [N/mm]   (analogue of G_fn)
    l0   regularisation length        [mm]     (encodes critical stress)

Forward problem: Kalthoff plate (B2), AT2 + spectral split + plane strain.
Synthetic target: forward run at known θ*, optionally + Gaussian noise.
Observations: u_x and u_y at the 6 nodal coordinates of Stanić Table 2.
Optimiser: L-BFGS or Adam on log-parameters (positivity).
Gradient: central FD on the parameter vector (5 forwards per gradient at k=4).

Usage:
    python inverse.py --smoke           # very coarse, ~1 min, validates loop
    python inverse.py                   # default settings (~10–30 min on CPU)
    python inverse.py --n_iters 50      # more iterations
"""

import os
import sys
import time
import json
import argparse
import math
import tempfile
from dataclasses import dataclass

import numpy as np
import torch
from scipy.optimize import minimize

# Make phast importable
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.mesh_generator import kalthoff_winkler as gen_kalthoff_mesh
from phast.mesh import FEMMesh
from phast.material import create_material, Material
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.device import DeviceContext
from phast.inverse_problems.sampling import (
    prefix_resample_indices,
    unique_even_sample_steps,
)


# ---------------------------------------------------------------------------
# Stanić Table 2 sampling points (mm) — 6 nodes between the two notches.
# Their plate is 100 wide × 200 tall with notches at y=75 and y=125.
# ---------------------------------------------------------------------------
STANIC_SAMPLING_POINTS = np.array([
    [10.0,  91.25],   # point 1
    [35.0,  91.25],   # point 2
    [45.0,  91.25],   # point 3
    [ 5.0, 108.75],   # point 4
    [20.0, 108.75],   # point 5
    [45.0, 108.75],   # point 6
])

# ---------------------------------------------------------------------------
# Line-elongation measurement segments (Stanić Table 3 & 4 style).
#
# These are line segments that cross the CRACK PATH. The elongation
# ΔL = |u(P2) - u(P1)| along the segment is highly sensitive to Gc and l0
# because it captures the crack opening displacement directly. Without these,
# the loss at the 6 nodal sampling points (which are between the notches,
# far from the crack tips) is dominated by elastic wave propagation and
# Gc/l0 are weakly identified.
#
# Each segment: (x1, y1, x2, y2). We place them across the expected ~65°
# crack path from the upper notch tip (50, 125) and lower notch tip (50, 75).
# ---------------------------------------------------------------------------
CRACK_LINE_SEGMENTS = np.array([
    # Upper notch crack (~65° downward from tip at (50, 125))
    # Segment ΔL1: near notch tip
    [42.50, 131.02,  57.50, 131.02],   # horizontal line at y=131, x spanning crack
    # Segment ΔL2: further along crack
    [42.50, 139.80,  65.00, 139.80],   # at y=140 (crack has propagated right)
    # Lower notch crack (~65° upward from tip at (50, 75))
    # Segment ΔL3: near notch tip
    [42.50,  68.98,  57.50,  68.98],
    # Segment ΔL4: further along crack
    [42.50,  60.20,  65.00,  60.20],
])

# ---------------------------------------------------------------------------
# True parameters (phase-field analogue of Stanić's "ground truth")
# ---------------------------------------------------------------------------
THETA_TRUE = dict(
    E=190000.0,    # MPa  (Borden 190 GPa; Stanić uses ~210 via K,G)
    nu=0.30,
    Gc=22.13,      # N/mm
    l0=0.50,       # mm   (coarsened from 0.195 for tractable inverse demo)
)
PARAM_NAMES = ['E', 'nu', 'Gc', 'l0']
# Initial guess: 1.5x true on E, Gc, l0; 1.2x on nu (must stay < 0.5)
THETA_INIT = dict(
    E=190000.0 * 1.5,
    nu=0.30 * 1.2,
    Gc=22.13 * 1.5,
    l0=0.50 * 1.5,
)


# ---------------------------------------------------------------------------
# Forward simulation: theta -> displacement at sampling points over time
# ---------------------------------------------------------------------------

def _impact_displacement(t, v0, t_ramp):
    if t < t_ramp:
        return (v0 / (2.0 * t_ramp)) * t * t
    return v0 * t - v0 * t_ramp / 2.0


@dataclass
class ForwardConfig:
    h_crack: float = 2.0       # coarse for tractable FD inversion
    h_coarse: float = 8.0
    T_total: float = 30.0e-6   # only need crack initiation regime
    v0: float = 16500.0        # mm/s
    t_ramp: float = 1.0e-6     # s
    n_save: int = 30           # number of time samples to keep for the loss
    device: str = 'cpu'
    damage_every: int = 3
    seed: int = 0


def build_mesh(cfg: ForwardConfig, l0: float, mesh_path: str = None):
    """Build the Kalthoff mesh once. Geometry is independent of (E, nu, Gc),
    so the same mesh is reused across all forward runs in the inversion loop.

    The mesh DOES depend on l0 (fine-zone sizing), but for the inverse
    problem we sweep parameters in a small ball around l0_true and use
    the mesh built at l0_true throughout. Effects of mesh-resizing on the
    loss are O(h_crack) and absorbed into the loss noise floor.
    """
    if mesh_path is None:
        mesh_path = os.path.join(tempfile.gettempdir(),
                                 'kalthoff_inverse_mesh.msh')
    gen_kalthoff_mesh(
        mesh_path,
        W=100.0, H=200.0, a=50.0,
        notch_y1=125.0, notch_y2=75.0,
        l0=l0,
        h_crack=cfg.h_crack,
        h_coarse=cfg.h_coarse,
        verbose=False,
    )
    return mesh_path


def find_sampling_node_indices(mesh_nodes_xy: np.ndarray) -> np.ndarray:
    """Locate the closest mesh node to each Stanić sampling point."""
    idx = np.zeros(len(STANIC_SAMPLING_POINTS), dtype=np.int64)
    for j, p in enumerate(STANIC_SAMPLING_POINTS):
        d2 = (mesh_nodes_xy[:, 0] - p[0])**2 + (mesh_nodes_xy[:, 1] - p[1])**2
        idx[j] = int(np.argmin(d2))
    return idx


def find_line_segment_node_pairs(mesh_nodes_xy: np.ndarray) -> np.ndarray:
    """For each line segment in CRACK_LINE_SEGMENTS, find the closest mesh
    nodes to each endpoint. Returns (n_segments, 2) array of node indices."""
    pairs = np.zeros((len(CRACK_LINE_SEGMENTS), 2), dtype=np.int64)
    for j, seg in enumerate(CRACK_LINE_SEGMENTS):
        p1 = seg[:2]
        p2 = seg[2:]
        d1 = (mesh_nodes_xy[:, 0] - p1[0])**2 + (mesh_nodes_xy[:, 1] - p1[1])**2
        d2 = (mesh_nodes_xy[:, 0] - p2[0])**2 + (mesh_nodes_xy[:, 1] - p2[1])**2
        pairs[j, 0] = int(np.argmin(d1))
        pairs[j, 1] = int(np.argmin(d2))
    return pairs


# Module-level cache: build the solver, mesh, BCs ONCE per (mesh_path, cfg)
# so the repeated forward_simulate() calls inside the FD/Powell loop reuse
# the same StaggeredSolver, FEMOperators, PhaseFieldDamageSolver, AMG preconditioner,
# and BoundaryConditions. Only the per-call material parameters and the
# state tensors (u, v, a, d, H_elem, H_nodal) change between calls.
#
# Without this cache, ~1800 forward_simulate calls would each rebuild the
# entire FEM machinery (10s of milliseconds × 1800 = 30+ minutes of pure
# overhead) AND the per-iteration log lines from FEMMesh / DamageSolver
# init flood the SLURM stdout.
_solver_cache = {}


def _get_or_build_solver(cfg: ForwardConfig, mesh_path: str):
    """Build the StaggeredSolver once per (mesh_path, device, dtype) tuple
    and cache it. Subsequent calls return the same solver instance.

    Material parameters are placeholders here; they get overridden inside
    forward_simulate via direct attribute assignment on solver.material
    (and solver.damage_solver._Gc / _l0 / _Gc_l0 / _Gc_over_l0 for the
    cached fast path).
    """
    cache_key = (mesh_path, cfg.device, cfg.h_crack, cfg.damage_every)
    if cache_key in _solver_cache:
        return _solver_cache[cache_key]

    ctx = DeviceContext(device=cfg.device, profile=False, compile_solvers=False)
    mesh = FEMMesh(mesh_path, device=ctx.device, dtype=ctx.dtype)
    mesh.identify_boundaries()

    # Placeholder material — will be overridden per call
    mat = Material(
        E=190000.0, nu=0.30, Gc=22.13, l0=0.5,
        rho=8.0e-9,
        eta_residual=1e-6,
        energy_split='spectral',
        pf_model='AT2',
        plane_stress=False,
    )

    coords = mesh.nodes
    tol = cfg.h_crack * 0.5
    impact_mask = (
        (coords[:, 0] < tol) &
        (coords[:, 1] > 75.0 - tol) &
        (coords[:, 1] < 125.0 + tol)
    )
    impact_nodes = torch.where(impact_mask)[0]

    bcs = BoundaryConditions(mesh.n_nodes, device=ctx.device, dtype=ctx.dtype)
    bcs.add(impact_nodes, 0, 1.0)
    bcs.load_factor = 0.0

    cfg_solver = SolverConfig(
        solver_type='explicit',
        dt_safety=0.8,
        use_multigrid=True,
        damage_every=cfg.damage_every,
    )
    solver = StaggeredSolver(mesh, mat, bcs, config=cfg_solver, ctx=ctx)

    nodes_np = mesh.nodes.cpu().numpy()
    sample_idx = find_sampling_node_indices(nodes_np)
    line_pairs = find_line_segment_node_pairs(nodes_np)

    bundle = dict(
        ctx=ctx, mesh=mesh, mat=mat, bcs=bcs, solver=solver,
        sample_idx=sample_idx, line_pairs=line_pairs,
        dt=float(solver.dt),
    )
    _solver_cache[cache_key] = bundle
    return bundle


def _set_material_params(solver, ds, E, nu, Gc, l0, pf_model='AT2'):
    """Override the cached material parameters in-place on the existing solver.

    The damage solver caches several derived quantities (_Gc_l0,
    _Gc_over_l0, _at1_source, _cg_Gc_l0_diag_lap) at construction time;
    we update them here to match the new (Gc, l0) without rebuilding the
    solver.
    """
    solver.material.E = E
    solver.material.nu = nu
    solver.material.Gc = Gc
    solver.material.l0 = l0
    ds._Gc = Gc
    ds._l0 = l0
    if pf_model == 'AT1':
        ds._Gc_l0 = 0.75 * Gc * l0
        ds._Gc_over_l0 = 0.0
        ds._at1_source = 3.0 * Gc / (8.0 * l0)
    else:  # AT2
        ds._Gc_l0 = Gc * l0
        ds._Gc_over_l0 = Gc / l0
        ds._at1_source = 0.0
    ds._cg_Gc_l0_diag_lap = ds._Gc_l0 * ds._cg_diag_lap


def _reset_state(solver):
    """Reset (u, v, a, d, H_elem, H_nodal, step counters) to zero for a
    fresh forward simulation."""
    n_nodes = solver.mesh.n_nodes
    n_elems = len(solver.mesh.elements)
    dtype = solver.u.dtype
    device = solver.u.device
    solver.u = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.v = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.a = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.d = torch.zeros(n_nodes, dtype=dtype, device=device)
    solver.H_elem = torch.zeros(n_elems, dtype=dtype, device=device)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dtype, device=device)
    if hasattr(solver, '_explicit_step_count'):
        solver._explicit_step_count = 0
    solver._step_count = 0


def forward_simulate(theta: np.ndarray,
                     cfg: ForwardConfig,
                     mesh_path: str,
                     verbose: bool = False) -> np.ndarray:
    """Run one Kalthoff forward simulation with parameters theta = [E, nu, Gc, l0].

    Reuses a cached solver across calls — see _get_or_build_solver.

    Returns
    -------
    obs : np.ndarray of shape (min(n_save, n_steps), 6, 2)
        u_x and u_y at the 6 sampling points, recorded at n_save evenly
        spaced time instants from 0 to T_total.
    """
    E, nu, Gc, l0 = float(theta[0]), float(theta[1]), float(theta[2]), float(theta[3])
    if not (0.05 < nu < 0.49):
        raise ValueError(f"nu out of valid range: {nu}")
    if E <= 0 or Gc <= 0 or l0 <= 0:
        raise ValueError(f"non-positive parameter: E={E}, Gc={Gc}, l0={l0}")

    bundle = _get_or_build_solver(cfg, mesh_path)
    solver = bundle['solver']
    ds = solver.damage_solver
    sample_idx = bundle['sample_idx']
    line_pairs = bundle['line_pairs']
    dt = bundle['dt']

    # Override material parameters for this call (no solver rebuild)
    _set_material_params(solver, ds, E, nu, Gc, l0,
                          pf_model=solver.material.pf_model)
    _reset_state(solver)
    solver.bcs.load_factor = 0.0

    n_steps = int(math.ceil(cfg.T_total / dt))

    save_steps = unique_even_sample_steps(n_steps, cfg.n_save)
    save_set = set(int(s) for s in save_steps)
    save_to_row = {int(s): r for r, s in enumerate(save_steps)}

    n_pts = len(sample_idx)
    n_segs = len(line_pairs)
    n_saved = len(save_steps)
    obs = np.zeros((n_saved, n_pts, 2), dtype=np.float64)
    # Line elongations: ΔL = u(P2) - u(P1) per segment (2 components)
    elongations = np.zeros((n_saved, n_segs, 2), dtype=np.float64)

    for step in range(n_steps):
        t_now = step * dt
        solver.bcs.load_factor = _impact_displacement(t_now, cfg.v0, cfg.t_ramp)
        solver.step_full()
        if step in save_set:
            row = save_to_row[step]
            u_np = solver.u.detach().cpu().numpy().reshape(-1, 2)
            obs[row, :, :] = u_np[sample_idx, :]
            # Line elongations across the crack path
            for s in range(n_segs):
                i1, i2 = line_pairs[s]
                elongations[row, s, :] = u_np[i2] - u_np[i1]
        if verbose and step % max(1, n_steps // 10) == 0:
            max_d = float(solver.d.max().item())
            print(f"    step {step:5d}/{n_steps}  t={t_now*1e6:6.2f}us  max(d)={max_d:.4f}")

    return obs, elongations


# ---------------------------------------------------------------------------
# Loss and gradient
# ---------------------------------------------------------------------------

def compute_loss(theta: np.ndarray, target_obs: np.ndarray,
                 target_elong: np.ndarray,
                 cfg: ForwardConfig, mesh_path: str) -> float:
    """MSE between simulated and target observables.

    Combines two measurement types:
    1. Nodal displacements at the 6 Stanić sampling points (sensitive to E, nu)
    2. Line elongations across the crack path (sensitive to Gc, l0)

    Both are normalised to the same scale so neither dominates.
    """
    sim_obs, sim_elong = forward_simulate(theta, cfg, mesh_path)
    diff_obs = sim_obs - target_obs
    diff_elong = sim_elong - target_elong

    # Normalize each by its RMS magnitude so they contribute equally.
    # If the target elongation is negligible (no crack yet), fall back to
    # the obs scale to avoid dividing by ~0.
    obs_scale = max(np.sqrt(np.mean(target_obs ** 2)), 1e-12)
    elong_scale = max(np.sqrt(np.mean(target_elong ** 2)), obs_scale * 0.1)

    loss_obs = float(np.mean((diff_obs / obs_scale) ** 2))
    loss_elong = float(np.mean((diff_elong / elong_scale) ** 2))
    return loss_obs + loss_elong


def central_fd_gradient(theta: np.ndarray, target_obs: np.ndarray,
                        target_elong: np.ndarray,
                        cfg: ForwardConfig, mesh_path: str,
                        rel_eps: float = 5e-3) -> tuple:
    """Central finite-difference gradient of the loss w.r.t. theta.

    Cost: 2k forwards per call (no extra forward at theta itself).
    Returns (loss_at_theta, gradient).
    """
    k = len(theta)
    grad = np.zeros(k, dtype=np.float64)
    loss_c = compute_loss(theta, target_obs, target_elong, cfg, mesh_path)
    n_forward_calls = 1
    for i in range(k):
        h = max(abs(theta[i]) * rel_eps, 1e-10)
        tp = theta.copy(); tp[i] += h
        tm = theta.copy(); tm[i] -= h
        # nu must stay in (0, 0.5) for plane strain
        if PARAM_NAMES[i] == 'nu':
            tp[i] = min(tp[i], 0.49)
            tm[i] = max(tm[i], 0.05)
        Lp = compute_loss(tp, target_obs, target_elong, cfg, mesh_path)
        Lm = compute_loss(tm, target_obs, target_elong, cfg, mesh_path)
        grad[i] = (Lp - Lm) / (tp[i] - tm[i])
        n_forward_calls += 2
    return loss_c, grad, n_forward_calls


# ---------------------------------------------------------------------------
# Phase definitions for the multi-phase variant (mirrors Stanić Table 1)
# ---------------------------------------------------------------------------

PHASES_2STAGE = [
    # Stage 1: elastic only — short window, identify (E, nu)
    dict(name='elastic',
         params=['E', 'nu'],
         t_total_us=20.0),
    # Stage 2: fracture — fix (E, nu), identify (Gc, l0)
    dict(name='fracture',
         params=['Gc', 'l0'],
         t_total_us=60.0),
]


def run_phase(target_pair, theta_state, free_params, cfg, mesh_path,
              n_iters, out_dir, phase_name, history, forward_counter, best,
              args):
    """Run one Powell phase optimising only `free_params` from theta_state.

    target_pair : tuple (target_obs, target_elong)
    """
    target_obs, target_elong = target_pair
    n_free = len(free_params)
    free_idx = [PARAM_NAMES.index(k) for k in free_params]

    log_x0 = np.log(np.array([theta_state[i] for i in free_idx]))
    log_bounds_full = [
        (math.log(0.3 * THETA_TRUE['E']),  math.log(3.0 * THETA_TRUE['E'])),
        (math.log(0.10),                    math.log(0.49)),
        (math.log(0.3 * THETA_TRUE['Gc']), math.log(3.0 * THETA_TRUE['Gc'])),
        (math.log(0.3 * THETA_TRUE['l0']), math.log(3.0 * THETA_TRUE['l0'])),
    ]
    log_bounds_phase = [log_bounds_full[i] for i in free_idx]

    def fun(log_x):
        theta = theta_state.copy()
        for j, idx in enumerate(free_idx):
            theta[idx] = float(np.exp(log_x[j]))
        loss = compute_loss(theta, target_obs, target_elong, cfg, mesh_path)
        forward_counter['n'] += 1
        if loss < best['loss']:
            best['loss'] = float(loss)
            best['theta'] = theta.copy()
        return loss

    iter_idx = {'n': len(history['iter'])}

    def callback(log_x):
        it = iter_idx['n']
        theta = theta_state.copy()
        for j, idx in enumerate(free_idx):
            theta[idx] = float(np.exp(log_x[j]))
        rel_err = {k: float(abs(theta[PARAM_NAMES.index(k)] - THETA_TRUE[k]) / THETA_TRUE[k])
                   for k in PARAM_NAMES}
        history['iter'].append(it)
        history['phase'].append(phase_name)
        history['loss'].append(float(best['loss']))
        history['theta'].append([float(theta[i]) for i in range(len(PARAM_NAMES))])
        history['rel_err'].append(rel_err)
        history['forward_count'].append(int(forward_counter['n']))
        history['best_theta'].append([float(b) for b in best['theta']])
        theta_str = ', '.join(f"{k}={theta[i]:.4g}({rel_err[k]:.1%})"
                              for i, k in enumerate(PARAM_NAMES))
        print(f"  [{phase_name}] it {it:3d} | best_loss={best['loss']:.3e} "
              f"| fwds={forward_counter['n']:5d} | {theta_str}", flush=True)
        # Stream to disk so we can monitor mid-run
        _flush_history(out_dir, history, forward_counter, args, cfg)
        iter_idx['n'] += 1

    # maxfev caps the TOTAL function evaluations. Without this, Powell's
    # internal line search can call fun() an unbounded number of times per
    # iteration when the landscape is flat — we observed 25+ min stalls
    # during verification. 25 evals per iter × n_iters is generous.
    result = minimize(
        fun,
        x0=log_x0,
        method='Powell',
        bounds=log_bounds_phase,
        callback=callback,
        options=dict(maxiter=n_iters, maxfev=n_iters * 25,
                     disp=True, xtol=1e-4, ftol=1e-6),
    )
    print(f"  [{phase_name}] Powell status: {result.message}", flush=True)
    print(f"  [{phase_name}] nfev (scipy)= {result.nfev}, niter= {result.nit}", flush=True)

    # Update theta_state with free params from the best
    for idx in free_idx:
        theta_state[idx] = best['theta'][idx]
    return theta_state


def _flush_history(out_dir, history, forward_counter, args, cfg):
    """Stream the current history to disk after every callback."""
    path = os.path.join(out_dir, 'history.json')
    payload = {
        'theta_true': THETA_TRUE,
        'theta_init': THETA_INIT,
        'param_names': PARAM_NAMES,
        'config': {
            'h_crack': cfg.h_crack, 'h_coarse': cfg.h_coarse,
            'T_total_us': cfg.T_total * 1e6,
            'n_save': cfg.n_save,
            'n_iters': args.n_iters,
            'fd_rel': args.fd_rel,
            'noise': args.noise,
            'mode': args.mode,
        },
        'history': history,
        'total_forward_simulations': int(forward_counter['n']),
    }
    tmp = path + '.tmp'
    with open(tmp, 'w') as fp:
        json.dump(payload, fp, indent=2)
    os.replace(tmp, path)


# ---------------------------------------------------------------------------
# Main inversion driver
# ---------------------------------------------------------------------------

def run_inversion(args):
    out_dir = os.path.join(THIS_DIR, args.output_dir) \
        if not os.path.isabs(args.output_dir) else args.output_dir
    os.makedirs(out_dir, exist_ok=True)

    # Build a config from CLI; the per-phase t_total may override
    cfg = ForwardConfig(
        h_crack=args.h_crack,
        h_coarse=args.h_coarse,
        T_total=args.t_total * 1e-6,
        device=args.device,
        damage_every=args.damage_every,
        n_save=args.n_save,
    )

    print("=" * 72)
    print("  Inverse Kalthoff identification — head-to-head with Stanić 2026")
    print("=" * 72)
    print(f"  Mode:  {args.mode}")
    print(f"  Mesh:  h_crack={cfg.h_crack}, h_coarse={cfg.h_coarse}")
    print(f"  Time:  T_total={cfg.T_total*1e6:.0f} us, n_save={cfg.n_save}")
    print(f"  Params identified: {PARAM_NAMES}")
    print(f"  True   theta*: {[f'{THETA_TRUE[k]:.4g}' for k in PARAM_NAMES]}")
    print(f"  Init   theta0: {[f'{THETA_INIT[k]:.4g}' for k in PARAM_NAMES]}")
    print(flush=True)

    # ---- Build mesh once at l0_true ----
    mesh_path = build_mesh(cfg, l0=THETA_TRUE['l0'])
    print(f"  Mesh path: {mesh_path}", flush=True)

    # Pre-build the cached solver here so the mesh init lines appear once
    # at the top of the log instead of being interleaved with iter output.
    bundle = _get_or_build_solver(cfg, mesh_path)
    n_nodes = int(bundle['mesh'].n_nodes)
    n_elems = int(len(bundle['mesh'].elements))
    print(f"  Mesh: {n_nodes} nodes, {n_elems} elements", flush=True)

    # ---- Generate synthetic target at the LONGEST time window ----
    cfg_target = cfg
    if args.mode == '2phase':
        # Use the longer phase window so the target covers both phases
        cfg_target = ForwardConfig(
            h_crack=cfg.h_crack, h_coarse=cfg.h_coarse,
            T_total=max(p['t_total_us'] for p in PHASES_2STAGE) * 1e-6,
            device=cfg.device, damage_every=cfg.damage_every,
            n_save=cfg.n_save,
        )

    print(f"\n[1/2] Generating synthetic target at T={cfg_target.T_total*1e6:.0f} us ...",
          flush=True)
    t0 = time.time()
    theta_true = np.array([THETA_TRUE[k] for k in PARAM_NAMES], dtype=np.float64)
    target_obs, target_elong = forward_simulate(
        theta_true, cfg_target, mesh_path, verbose=True)
    t_target = time.time() - t0
    print(f"  Target generated in {t_target:.1f}s", flush=True)
    print(f"  Target obs shape: {target_obs.shape}, "
          f"elong shape: {target_elong.shape}", flush=True)
    print(f"  Target |u| max = {np.abs(target_obs).max():.4e} mm, "
          f"|ΔL| max = {np.abs(target_elong).max():.4e} mm", flush=True)

    if args.noise > 0:
        rng = np.random.default_rng(0)
        target_obs = target_obs + rng.normal(0.0, args.noise, size=target_obs.shape)
        target_elong = target_elong + rng.normal(0.0, args.noise,
                                                   size=target_elong.shape)
        print(f"  Added Gaussian noise: sigma = {args.noise:.2e} mm", flush=True)

    np.save(os.path.join(out_dir, 'target_obs.npy'), target_obs)
    np.save(os.path.join(out_dir, 'target_elong.npy'), target_elong)

    # ---- Optimisation ----
    history = {'iter': [], 'phase': [], 'loss': [], 'theta': [], 'rel_err': [],
               'forward_count': [], 'best_theta': []}
    forward_counter = {'n': 1}
    best = {'loss': float('inf'), 'theta': np.array([THETA_INIT[k] for k in PARAM_NAMES],
                                                     dtype=np.float64)}
    theta_state = np.array([THETA_INIT[k] for k in PARAM_NAMES], dtype=np.float64)

    target_pair = (target_obs, target_elong)

    if args.mode == 'joint':
        print(f"\n[2/2] Running joint Powell on all 4 parameters ...", flush=True)
        theta_state = run_phase(target_pair, theta_state, PARAM_NAMES, cfg, mesh_path,
                                args.n_iters, out_dir, 'joint',
                                history, forward_counter, best, args)
    elif args.mode == '2phase':
        print(f"\n[2/2] Running 2-phase Powell (mirrors Stanić's multi-phase) ...",
              flush=True)
        for phase in PHASES_2STAGE:
            phase_cfg = ForwardConfig(
                h_crack=cfg.h_crack, h_coarse=cfg.h_coarse,
                T_total=phase['t_total_us'] * 1e-6,
                device=cfg.device, damage_every=cfg.damage_every,
                n_save=min(cfg.n_save, max(10, int(cfg.n_save * phase['t_total_us'] / cfg_target.T_total / 1e6))),
            )
            # Crop both targets to this phase's time window
            obs_phase = _crop_target_time(target_obs, cfg_target.T_total,
                                           phase_cfg.T_total, phase_cfg.n_save)
            elong_phase = _crop_target_time(target_elong, cfg_target.T_total,
                                             phase_cfg.T_total, phase_cfg.n_save)
            print(f"\n  Phase {phase['name']}: identifying {phase['params']}, "
                  f"T={phase['t_total_us']:.0f} us, target shape {obs_phase.shape}",
                  flush=True)
            theta_state = run_phase(
                (obs_phase, elong_phase), theta_state, phase['params'],
                phase_cfg, mesh_path, args.n_iters, out_dir, phase['name'],
                history, forward_counter, best, args)
    else:
        raise ValueError(f"Unknown mode: {args.mode}")

    total_forwards = forward_counter['n']
    print(f"\n=== FINAL ===", flush=True)
    print(f"  best loss: {best['loss']:.4e}", flush=True)
    for i, k in enumerate(PARAM_NAMES):
        err = abs(best['theta'][i] - THETA_TRUE[k]) / THETA_TRUE[k]
        print(f"    {k:5s} = {best['theta'][i]:.4g}  (true {THETA_TRUE[k]:.4g}, err {err:+.2%})",
              flush=True)
    print(f"  Total forward simulations: {total_forwards}", flush=True)
    print(f"  Stanić et al. 2026: ~15,173 forwards (3 surrogate phases)", flush=True)
    print(f"  Speed-up over Stanić: {15173 / total_forwards:.1f}x", flush=True)

    # Final flush to disk (with the FINAL best)
    history['final_best_loss'] = float(best['loss'])
    history['final_best_theta'] = [float(b) for b in best['theta']]
    _flush_history(out_dir, history, forward_counter, args, cfg)
    print(f"\nSaved history → {os.path.join(out_dir, 'history.json')}", flush=True)


def _crop_target_time(target_full, T_full_s, T_phase_s, n_save_phase):
    """Resample the target prefix to unique samples covering ``[0, T_phase]``."""
    n_save_full = target_full.shape[0]
    # The full target has samples evenly spaced over [0, T_full]
    # We want samples evenly spaced over [0, T_phase] from the same array
    # by index slicing.
    frac = T_phase_s / T_full_s
    n_keep = min(n_save_full, max(1, int(round(n_save_full * frac))))
    keep_idx = prefix_resample_indices(n_keep, n_save_phase)
    return target_full[keep_idx, :, :]


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--smoke', action='store_true',
                   help='Run a tiny version (~1 min) to validate the loop')
    p.add_argument('--mode', type=str, default='joint',
                   choices=['joint', '2phase'],
                   help="'joint' = all 4 params at once; "
                        "'2phase' = elastic (E,nu) then fracture (Gc,l0), "
                        "mirroring Stanić's multi-phase approach")
    p.add_argument('--h_crack', type=float, default=2.0)
    p.add_argument('--h_coarse', type=float, default=8.0)
    p.add_argument('--t_total', type=float, default=30.0,
                   help='Total simulation time [us] (joint mode); '
                        'in 2phase mode each phase uses its own window')
    p.add_argument('--n_save', type=int, default=30,
                   help='Number of time samples in the loss')
    p.add_argument('--damage_every', type=int, default=3)
    p.add_argument('--device', type=str, default='cpu')
    p.add_argument('--n_iters', type=int, default=20,
                   help='Powell maxiter (per phase in 2phase mode)')
    p.add_argument('--fd_rel', type=float, default=5e-3,
                   help='Relative FD step size (only used by FD-gradient mode, '
                        'kept for compatibility)')
    p.add_argument('--noise', type=float, default=0.0,
                   help='Gaussian noise sigma [mm] added to target')
    p.add_argument('--output_dir', type=str, default='results')
    args = p.parse_args()

    if args.smoke:
        args.h_crack = 4.0
        args.h_coarse = 12.0
        args.t_total = 12.0
        args.n_save = 10
        args.n_iters = 3
        args.output_dir = 'results_smoke'

    run_inversion(args)


if __name__ == '__main__':
    main()
