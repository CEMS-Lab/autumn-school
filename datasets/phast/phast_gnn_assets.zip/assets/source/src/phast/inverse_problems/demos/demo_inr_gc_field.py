"""Smoke demo: recover a piecewise Gc(x) field via INR parametrisation.

This is a *forward+backward+optimise* sanity check, not a paper-quality
inverse problem. It demonstrates that the new
``inverse_problems.parametrisations`` module can:

    1. Build an ``FieldINR`` over a tiny 2-D grid that mimics FE node coords.
    2. Define a target piecewise Gc(x) (low-toughness inclusion in a
       higher-toughness matrix).
    3. Optimise the INR parameters by Adam to fit the target.
    4. Print the initial and final L2 losses.

Full-loop integration (couple INR Gc into the staggered solver, run an
adjoint inverse problem) is tracked as the Paper-2 follow-up to #205.

Run::

    python -m phast.inverse_problems.demos.demo_inr_gc_field
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from phast.inverse_problems.parametrisations import (
    FieldINR,
    evaluate_at_nodes,
)


def make_pseudo_node_coords(n_per_side: int = 24) -> torch.Tensor:
    """A tiny ``(n_nodes, 2)`` tensor on [-1, 1]^2 standing in for FE nodes."""
    g = torch.linspace(-1.0, 1.0, n_per_side)
    yy, xx = torch.meshgrid(g, g, indexing="ij")
    return torch.stack([xx.reshape(-1), yy.reshape(-1)], dim=-1)


def piecewise_gc_target(coords: torch.Tensor) -> torch.Tensor:
    """Low-Gc disk inclusion (radius 0.35) in a high-Gc matrix."""
    r2 = (coords ** 2).sum(dim=-1)
    inside = r2 < 0.35 ** 2
    gc = torch.where(
        inside,
        torch.full_like(r2, 30.0),   # low Gc inclusion
        torch.full_like(r2, 100.0),  # matrix
    )
    return gc


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--n_per_side", type=int, default=48)
    p.add_argument("--n_steps", type=int, default=600)
    p.add_argument("--lr", type=float, default=2e-3)
    p.add_argument("--output_dir", type=str,
                   default="papers/paper2/figures/forward_gate/accepted/D8_inr_gc_smoke")
    args = p.parse_args()

    root = Path(__file__).resolve().parents[2]
    out_dir = Path(args.output_dir)
    if not out_dir.is_absolute():
        out_dir = root / out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    torch.manual_seed(0)
    coords = make_pseudo_node_coords(n_per_side=args.n_per_side)
    target = piecewise_gc_target(coords)

    inr = FieldINR(
        n_input_dims=2,
        n_fourier_features=64,
        fourier_sigma=4.0,
        hidden_width=64,
        n_hidden_layers=3,
        seed=0,
    )
    n_params = inr.n_trainable_parameters()
    n_nodes = coords.shape[0]
    print(
        f"[demo_inr_gc_field] nodes = {n_nodes}, "
        f"INR trainable params = {n_params} "
        f"(compression ratio = {n_nodes / n_params:.2f}x)"
    )

    opt = torch.optim.Adam(inr.parameters(), lr=args.lr)
    losses: list[float] = []
    for step in range(args.n_steps):
        opt.zero_grad()
        pred = evaluate_at_nodes(inr, coords)
        loss = ((pred - target) ** 2).mean()
        loss.backward()
        opt.step()
        losses.append(loss.item())
        if step % 100 == 0:
            print(f"  step {step:4d}  loss = {loss.item():.4e}")

    with torch.no_grad():
        pred = evaluate_at_nodes(inr, coords)
        rel_l2 = ((pred - target).norm() / target.norm()).item()
        pred_np = pred.cpu().numpy().reshape(args.n_per_side, args.n_per_side)
        target_np = target.cpu().numpy().reshape(args.n_per_side, args.n_per_side)
        coords_np = coords.cpu().numpy()

    np.savez_compressed(
        out_dir / "inr_gc_smoke_bundle.npz",
        coords=coords_np,
        target=target_np,
        pred=pred_np,
        losses=np.asarray(losses),
    )
    meta = {
        "status": "INR smoke only; not coupled through the fracture solver",
        "n_per_side": int(args.n_per_side),
        "n_nodes": int(n_nodes),
        "n_params": int(n_params),
        "n_steps": int(args.n_steps),
        "lr": float(args.lr),
        "init_loss": float(losses[0]),
        "final_loss": float(losses[-1]),
        "rel_l2": float(rel_l2),
    }
    with open(out_dir / "forward_bundle.json", "w") as fh:
        json.dump(meta, fh, indent=2)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["STIXGeneral", "Times New Roman", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "pdf.fonttype": 42,
    })
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.1),
                             constrained_layout=True)
    im0 = axes[0].imshow(target_np, origin="lower", extent=(-1, 1, -1, 1),
                         vmin=30.0, vmax=100.0, cmap="viridis")
    axes[0].set_title("target $G_c$")
    im1 = axes[1].imshow(pred_np, origin="lower", extent=(-1, 1, -1, 1),
                         vmin=30.0, vmax=100.0, cmap="viridis")
    axes[1].set_title("INR fit")
    axes[2].semilogy(losses, color="tab:red")
    axes[2].set_title("fit loss")
    axes[2].set_xlabel("Adam step")
    axes[2].set_ylabel("MSE")
    for ax in axes[:2]:
        ax.set_xlabel("$x$")
        ax.set_ylabel("$y$")
    fig.colorbar(im1, ax=axes[:2], shrink=0.82, label="$G_c$")
    fig.suptitle(
        f"Demo 8 INR $G_c$ smoke: rel. L2 = {rel_l2:.3f}, "
        f"{n_params} parameters"
    )
    fig.savefig(out_dir / "demo8_inr_gc_smoke.png", dpi=220)
    fig.savefig(out_dir / "demo8_inr_gc_smoke.pdf")
    plt.close(fig)

    print(
        f"[demo_inr_gc_field] init loss = {losses[0]:.4e}   "
        f"final loss = {losses[-1]:.4e}   rel L2 = {rel_l2:.4f}"
    )
    print(f"[demo_inr_gc_field] wrote {out_dir}")
    assert losses[-1] < losses[0], "INR did not reduce the loss"


if __name__ == "__main__":
    main()
