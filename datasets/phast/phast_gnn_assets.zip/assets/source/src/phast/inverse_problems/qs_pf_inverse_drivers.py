"""Quasistatic PF inverse drivers for TPBT and WST-style scalar Gc recovery.

These drivers are the PF replacements for the reduced Maier-inspired
surrogates. They keep the inverse target intentionally narrow: scalar
``G_c`` recovery from synthetic quasistatic phase-field response observations.
"""

from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch

from phast.boundary_conditions import BoundaryConditions
from phast.device import DeviceContext
from phast.inverse_problems.diagnostics.observability_gate import (
    descent_alignment,
    jacobian_summary,
    line_probe,
)
from phast.material import Material, create_material
from phast.mesh import FEMMesh
from phast.mesh_generator import miehe_tension, three_point_bending
from phast.staggered_solver import SolverConfig, StaggeredSolver


@dataclass(frozen=True)
class PFTPBTConfig:
    """Three-point-bending PF scalar Gc inverse configuration."""

    W: float = 8.0
    H: float = 2.0
    a: float = 0.4
    l0: float = 0.12
    h_crack: float = 0.25
    h_coarse: float = 0.65
    E: float = 20800.0
    nu: float = 0.3
    true_Gc: float = 0.50
    init_Gc: float = 0.80
    displacements: tuple[float, ...] = (0.015, 0.030, 0.045, 0.060)
    energy_split: str = "isotropic"
    pf_model: str = "AT2"
    backend: str = "scipy"
    stagger_tol: float = 1.0e-6
    max_stagger: int = 160
    dic_stride: int = 16
    reaction_weight: float = 1.0
    dic_weight: float = 0.05
    damage_weight: float = 0.0


@dataclass(frozen=True)
class PFWSTConfig:
    """WST-style notched-block force-CMOD PF scalar Gc inverse configuration.

    This is not an exact Maier wedge-splitting specimen. It is a real
    quasistatic phase-field notched block with force-CMOD observations and a
    wedge-splitting-style scalar recovery contract.
    """

    L: float = 1.0
    a: float = 0.5
    l0: float = 0.08
    h_crack: float = 0.10
    h_coarse: float = 0.22
    true_Gc: float = 2.70
    init_Gc: float = 3.80
    displacements: tuple[float, ...] = (0.002, 0.004, 0.006, 0.008)
    energy_split: str = "isotropic"
    pf_model: str = "AT2"
    backend: str = "scipy"
    stagger_tol: float = 1.0e-6
    max_stagger: int = 120
    dic_stride: int = 20
    reaction_weight: float = 1.0
    cmod_weight: float = 0.40
    dic_weight: float = 0.05
    damage_weight: float = 0.0


@dataclass
class PFRollout:
    displacements: torch.Tensor
    reaction: torch.Tensor
    dic: torch.Tensor
    d_final: torch.Tensor
    u_final: torch.Tensor
    max_damage: torch.Tensor
    cmod: torch.Tensor | None = None


def _interior_dic_indices(mesh: FEMMesh, stride: int) -> torch.Tensor:
    stride = max(1, int(stride))
    nodes = mesh.nodes
    x = nodes[:, 0]
    y = nodes[:, 1]
    x_margin = 0.05 * float((x.max() - x.min()).clamp_min(1.0))
    y_margin = 0.05 * float((y.max() - y.min()).clamp_min(1.0))
    interior = torch.where(
        (x > x.min() + x_margin)
        & (x < x.max() - x_margin)
        & (y > y.min() + y_margin)
        & (y < y.max() - y_margin)
    )[0]
    if interior.numel() == 0:
        interior = torch.arange(mesh.n_nodes, dtype=torch.long)
    return interior[::stride].long()


def build_pf_tpbt_mesh(out_dir: Path, cfg: PFTPBTConfig, *, verbose: bool = False) -> FEMMesh:
    out_dir.mkdir(parents=True, exist_ok=True)
    mesh_path = out_dir / "pf_tpbt.msh"
    three_point_bending(
        str(mesh_path),
        W=cfg.W,
        H=cfg.H,
        a=cfg.a,
        l0=cfg.l0,
        h_crack=cfg.h_crack,
        h_coarse=cfg.h_coarse,
        verbose=verbose,
    )
    mesh = FEMMesh(str(mesh_path), device="cpu", dtype=torch.float64)
    mesh.identify_boundaries()
    return mesh


def build_pf_wst_mesh(out_dir: Path, cfg: PFWSTConfig, *, verbose: bool = False) -> FEMMesh:
    out_dir.mkdir(parents=True, exist_ok=True)
    mesh_path = out_dir / "pf_wst_style.msh"
    miehe_tension(
        str(mesh_path),
        L=cfg.L,
        a=cfg.a,
        l0=cfg.l0,
        h_crack=cfg.h_crack,
        h_coarse=cfg.h_coarse,
        verbose=verbose,
    )
    mesh = FEMMesh(str(mesh_path), device="cpu", dtype=torch.float64)
    mesh.identify_boundaries()
    return mesh


def _make_tpbt_solver(mesh: FEMMesh, cfg: PFTPBTConfig) -> StaggeredSolver:
    material = Material(
        E=cfg.E,
        nu=cfg.nu,
        Gc=cfg.true_Gc,
        l0=cfg.l0,
        rho=7.8e-9,
        energy_split=cfg.energy_split,
        pf_model=cfg.pf_model,
    )
    bcs = BoundaryConditions(mesh.n_nodes, mesh.device, mesh.dtype)
    bcs.fix(mesh.node_sets["support_left"], 0)
    bcs.fix(mesh.node_sets["support_left"], 1)
    bcs.fix(mesh.node_sets["support_right"], 1)
    bcs.add(mesh.node_sets["load_point"], 1, -1.0)
    solver_cfg = SolverConfig(
        solver_type="quasi_static",
        differentiable=True,
        stagger_tol=cfg.stagger_tol,
        max_stagger=cfg.max_stagger,
        preconditioner="jacobi",
        use_multigrid=False,
        backend=cfg.backend,
    )
    return StaggeredSolver(
        mesh,
        material,
        bcs,
        config=solver_cfg,
        ctx=DeviceContext("cpu", torch.float64),
    )


def _make_wst_solver(mesh: FEMMesh, cfg: PFWSTConfig) -> StaggeredSolver:
    material = create_material(
        "miehe_tension",
        l0=cfg.l0,
        pf_model=cfg.pf_model,
        energy_split=cfg.energy_split,
        gamma_correction=True,
    )
    bcs = BoundaryConditions(mesh.n_nodes, mesh.device, mesh.dtype)
    bcs.fix(mesh.node_sets["bottom"], 0)
    bcs.fix(mesh.node_sets["bottom"], 1)
    bcs.add(mesh.node_sets["top"], 1, 1.0)
    solver_cfg = SolverConfig(
        solver_type="quasi_static",
        differentiable=True,
        stagger_tol=cfg.stagger_tol,
        max_stagger=cfg.max_stagger,
        preconditioner="jacobi",
        use_multigrid=False,
        backend=cfg.backend,
    )
    return StaggeredSolver(
        mesh,
        material,
        bcs,
        config=solver_cfg,
        ctx=DeviceContext("cpu", torch.float64),
    )


def rollout_pf_tpbt(mesh: FEMMesh, cfg: PFTPBTConfig, Gc: torch.Tensor) -> PFRollout:
    solver = _make_tpbt_solver(mesh, cfg)
    solver.diff_Gc = Gc
    load_nodes = mesh.node_sets["load_point"]
    dic_idx = _interior_dic_indices(mesh, cfg.dic_stride)
    reactions = []
    dic_samples = []
    for disp in cfg.displacements:
        solver.bcs.load_factor = float(disp)
        solver.step_full()
        fint = solver.fem.internal_force(solver.u, solver.d)
        reactions.append(fint[load_nodes, 1].sum())
        dic_samples.append(solver.u[dic_idx].reshape(-1))
    return PFRollout(
        displacements=torch.tensor(cfg.displacements, dtype=torch.float64),
        reaction=torch.stack(reactions),
        dic=torch.cat(dic_samples),
        d_final=solver.d,
        u_final=solver.u,
        max_damage=solver.d.max(),
    )


def rollout_pf_wst(mesh: FEMMesh, cfg: PFWSTConfig, Gc: torch.Tensor) -> PFRollout:
    solver = _make_wst_solver(mesh, cfg)
    solver.diff_Gc = Gc
    top = mesh.node_sets["top"]
    upper = mesh.node_sets["notch_upper"]
    lower = mesh.node_sets["notch_lower"]
    dic_idx = _interior_dic_indices(mesh, cfg.dic_stride)
    reactions = []
    dic_samples = []
    cmods = []
    for disp in cfg.displacements:
        solver.bcs.load_factor = float(disp)
        solver.step_full()
        fint = solver.fem.internal_force(solver.u, solver.d)
        reactions.append(fint[top, 1].sum())
        dic_samples.append(solver.u[dic_idx].reshape(-1))
        cmods.append(solver.u[upper, 1].mean() - solver.u[lower, 1].mean())
    return PFRollout(
        displacements=torch.tensor(cfg.displacements, dtype=torch.float64),
        reaction=torch.stack(reactions),
        dic=torch.cat(dic_samples),
        d_final=solver.d,
        u_final=solver.u,
        max_damage=solver.d.max(),
        cmod=torch.stack(cmods),
    )


def pf_tpbt_loss_components(
    pred: PFRollout,
    target: PFRollout,
    cfg: PFTPBTConfig,
) -> dict[str, torch.Tensor]:
    r_scale = target.reaction.detach().abs().max().clamp_min(1.0)
    dic_scale = target.dic.detach().abs().max().clamp_min(1.0e-12)
    reaction = ((pred.reaction - target.reaction.detach()) / r_scale).pow(2).mean()
    dic = ((pred.dic - target.dic.detach()) / dic_scale).pow(2).mean()
    damage = (pred.d_final - target.d_final.detach()).pow(2).mean()
    total = cfg.reaction_weight * reaction + cfg.dic_weight * dic + cfg.damage_weight * damage
    return {
        "reaction": reaction,
        "dic": dic,
        "damage_field": damage,
        "weighted_total": total,
    }


def pf_tpbt_loss(pred: PFRollout, target: PFRollout, cfg: PFTPBTConfig) -> torch.Tensor:
    return pf_tpbt_loss_components(pred, target, cfg)["weighted_total"]


def _weighted_residual_channel(
    pred: torch.Tensor,
    target: torch.Tensor,
    *,
    weight: float,
    scale_floor: float,
) -> torch.Tensor:
    if weight <= 0.0:
        return pred.new_zeros(0)
    scale = target.detach().abs().max().clamp_min(scale_floor)
    residual = pred.reshape(-1) - target.detach().reshape(-1)
    return math.sqrt(float(weight)) * residual / scale


def pf_tpbt_residual_vector(
    pred: PFRollout,
    target: PFRollout,
    cfg: PFTPBTConfig,
) -> torch.Tensor:
    """Weighted response residual vector used for observability diagnostics."""

    channels = [
        _weighted_residual_channel(
            pred.reaction,
            target.reaction,
            weight=cfg.reaction_weight,
            scale_floor=1.0,
        ),
        _weighted_residual_channel(
            pred.dic,
            target.dic,
            weight=cfg.dic_weight,
            scale_floor=1.0e-12,
        ),
        _weighted_residual_channel(
            pred.d_final,
            target.d_final,
            weight=cfg.damage_weight,
            scale_floor=1.0,
        ),
    ]
    return torch.cat([channel for channel in channels if channel.numel() > 0])


def pf_wst_loss_components(
    pred: PFRollout,
    target: PFRollout,
    cfg: PFWSTConfig,
) -> dict[str, torch.Tensor]:
    r_scale = target.reaction.detach().abs().max().clamp_min(1.0)
    cmod_scale = target.cmod.detach().abs().max().clamp_min(1.0e-12)
    dic_scale = target.dic.detach().abs().max().clamp_min(1.0e-12)
    reaction = ((pred.reaction - target.reaction.detach()) / r_scale).pow(2).mean()
    cmod = ((pred.cmod - target.cmod.detach()) / cmod_scale).pow(2).mean()
    dic = ((pred.dic - target.dic.detach()) / dic_scale).pow(2).mean()
    damage = (pred.d_final - target.d_final.detach()).pow(2).mean()
    total = (
        cfg.reaction_weight * reaction
        + cfg.cmod_weight * cmod
        + cfg.dic_weight * dic
        + cfg.damage_weight * damage
    )
    return {
        "reaction": reaction,
        "cmod": cmod,
        "dic": dic,
        "damage_field": damage,
        "weighted_total": total,
    }


def pf_wst_loss(pred: PFRollout, target: PFRollout, cfg: PFWSTConfig) -> torch.Tensor:
    return pf_wst_loss_components(pred, target, cfg)["weighted_total"]


def pf_wst_residual_vector(
    pred: PFRollout,
    target: PFRollout,
    cfg: PFWSTConfig,
) -> torch.Tensor:
    """Weighted response residual vector used for observability diagnostics."""

    if pred.cmod is None or target.cmod is None:
        raise ValueError("WST residual vector requires CMOD observations")
    channels = [
        _weighted_residual_channel(
            pred.reaction,
            target.reaction,
            weight=cfg.reaction_weight,
            scale_floor=1.0,
        ),
        _weighted_residual_channel(
            pred.cmod,
            target.cmod,
            weight=cfg.cmod_weight,
            scale_floor=1.0e-12,
        ),
        _weighted_residual_channel(
            pred.dic,
            target.dic,
            weight=cfg.dic_weight,
            scale_floor=1.0e-12,
        ),
        _weighted_residual_channel(
            pred.d_final,
            target.d_final,
            weight=cfg.damage_weight,
            scale_floor=1.0,
        ),
    ]
    return torch.cat([channel for channel in channels if channel.numel() > 0])


def _float_components(components: dict[str, torch.Tensor]) -> dict[str, float]:
    return {key: float(value.detach()) for key, value in components.items()}


def _tpbt_loss_weights(cfg: PFTPBTConfig) -> dict[str, float]:
    return {
        "reaction": cfg.reaction_weight,
        "dic": cfg.dic_weight,
        "damage": cfg.damage_weight,
    }


def _wst_loss_weights(cfg: PFWSTConfig) -> dict[str, float]:
    return {
        "reaction": cfg.reaction_weight,
        "cmod": cfg.cmod_weight,
        "dic": cfg.dic_weight,
        "damage": cfg.damage_weight,
    }


def _optimized_channels(weights: dict[str, float]) -> list[str]:
    return [name for name, weight in weights.items() if weight > 0.0]


def _central_fd_grad(
    forward,
    loss_fn,
    mesh: FEMMesh,
    cfg,
    target: PFRollout,
    gc_value: float,
    eps: float = 1.0e-4,
) -> float:
    vals = []
    for sign in (1.0, -1.0):
        trial = torch.tensor(
            math.exp(math.log(gc_value) + sign * eps),
            dtype=torch.float64,
            requires_grad=True,
        )
        vals.append(loss_fn(forward(mesh, cfg, trial), target, cfg))
    return float(((vals[0] - vals[1]) / (2.0 * eps)).detach())


def _autograd_grad(forward, loss_fn, mesh: FEMMesh, cfg, target: PFRollout, gc_value: float) -> tuple[float, float]:
    log_gc = torch.tensor(math.log(gc_value), dtype=torch.float64, requires_grad=True)
    loss = loss_fn(forward(mesh, cfg, torch.exp(log_gc)), target, cfg)
    loss.backward()
    return float(loss.detach()), float(log_gc.grad.detach())


def _scalar_gc_observability_report(
    *,
    forward,
    loss_fn,
    residual_fn,
    mesh: FEMMesh,
    cfg,
    target: PFRollout,
    init_gc: float,
    true_gc: float,
    grad_at_init: float,
    rel_step: float = 1.0e-3,
    alphas: tuple[float, ...] = (0.0, 0.5, 1.0),
) -> dict[str, object]:
    """Small scalar-Gc gate for QS PF response inverses.

    This is a diagnostic, not a proof of a production benchmark. It answers
    the pre-optimisation questions in issue #621 for the current synthetic
    target: does the response residual change with ``G_c``, does the local
    descent direction point toward the truth, and is the simple line from
    initial value to truth downhill?
    """

    theta_init = torch.tensor([math.log(init_gc)], dtype=torch.float64)
    theta_truth = torch.tensor([math.log(true_gc)], dtype=torch.float64)

    def _roll(theta: torch.Tensor) -> PFRollout:
        return forward(mesh, cfg, torch.exp(theta[0]))

    def observable_fn(theta: torch.Tensor) -> torch.Tensor:
        return residual_fn(_roll(theta), target, cfg)

    def loss_fn_theta(theta: torch.Tensor) -> torch.Tensor:
        return loss_fn(_roll(theta), target, cfg)

    obs0 = observable_fn(theta_init.clone().requires_grad_(True)).detach()
    h = rel_step * max(abs(float(theta_init[0])), 1.0)
    theta_p = (
        theta_init + torch.tensor([h], dtype=torch.float64)
    ).requires_grad_(True)
    theta_m = (
        theta_init - torch.tensor([h], dtype=torch.float64)
    ).requires_grad_(True)
    obs_p = observable_fn(theta_p).detach()
    obs_m = observable_fn(theta_m).detach()
    J = ((obs_p - obs_m) / (2.0 * h)).reshape(-1, 1).to(dtype=torch.float64)
    obs = obs0.reshape(-1)
    jac = jacobian_summary(J)
    grad = torch.tensor([grad_at_init], dtype=torch.float64)
    align = descent_alignment(grad, theta_init, theta_truth)
    line = line_probe(
        loss_fn_theta,
        theta_init,
        theta_truth,
        alphas=alphas,
        require_grad=True,
    )
    line_losses = [row["loss"] for row in line]
    finite = (
        torch.isfinite(J).all()
        and torch.isfinite(grad).all()
        and all(math.isfinite(value) for value in line_losses)
    )
    loss_at_init = line_losses[0] if line_losses else math.inf
    line_improves = min(line_losses) < loss_at_init if line_losses else False
    columns_ok = jac["column_norm_min"] > 1.0e-10
    descent_ok = align["cos_descent_truth"] > 0.0
    rank_ok = jac["effective_rank"] == jac["n_parameters"]
    passed = bool(finite and columns_ok and descent_ok and rank_ok and line_improves)
    reasons: list[str] = []
    if not bool(finite):
        reasons.append("non-finite residual Jacobian, gradient, or line-probe loss")
    if not columns_ok:
        reasons.append("scalar Gc response residual has negligible sensitivity")
    if not descent_ok:
        reasons.append("local descent direction does not point toward true Gc")
    if not rank_ok:
        reasons.append("response residual Jacobian is rank deficient")
    if not line_improves:
        reasons.append("init-to-truth line does not reduce loss")
    return {
        "pass": passed,
        "reasons": reasons,
        "parameterization": "theta = log(Gc)",
        "theta_init": float(theta_init[0]),
        "theta_truth": float(theta_truth[0]),
        "loss_at_init": float(loss_at_init),
        "observable_norm_at_init": float(torch.linalg.vector_norm(obs).detach()),
        "jacobian": jac,
        "descent_alignment": align,
        "line_probe": line,
        "thresholds": {
            "min_column_norm": 1.0e-10,
            "min_descent_cosine": 0.0,
            "rel_step": float(rel_step),
            "jacobian_mode": "finite_difference",
        },
    }


def recover_pf_scalar_gc(
    *,
    mesh: FEMMesh,
    cfg,
    forward,
    loss_fn,
    residual_fn,
    true_gc: float,
    init_gc: float,
    max_iter: int = 6,
) -> dict[str, object]:
    target = forward(mesh, cfg, torch.tensor(true_gc, dtype=torch.float64, requires_grad=True))
    initial = forward(mesh, cfg, torch.tensor(init_gc, dtype=torch.float64, requires_grad=True))
    log_gc = torch.tensor(math.log(init_gc), dtype=torch.float64, requires_grad=True)
    opt = torch.optim.LBFGS([log_gc], lr=0.7, max_iter=max_iter, line_search_fn="strong_wolfe")
    history: list[dict[str, float]] = []

    def closure() -> torch.Tensor:
        opt.zero_grad()
        pred = forward(mesh, cfg, torch.exp(log_gc))
        loss = loss_fn(pred, target, cfg)
        loss.backward()
        history.append(
            {
                "Gc": float(torch.exp(log_gc).detach()),
                "loss": float(loss.detach()),
                "grad_log_Gc": float(log_gc.grad.detach()),
            }
        )
        return loss

    opt.step(closure)
    recovered_gc = float(torch.exp(log_gc.detach()))
    recovered = forward(mesh, cfg, torch.tensor(recovered_gc, dtype=torch.float64, requires_grad=True))
    grad_loss, grad_ad = _autograd_grad(forward, loss_fn, mesh, cfg, target, init_gc)
    grad_fd = _central_fd_grad(forward, loss_fn, mesh, cfg, target, init_gc)
    grad_rel = abs(grad_ad - grad_fd) / max(abs(grad_fd), 1.0e-30)
    observability = _scalar_gc_observability_report(
        forward=forward,
        loss_fn=loss_fn,
        residual_fn=residual_fn,
        mesh=mesh,
        cfg=cfg,
        target=target,
        init_gc=init_gc,
        true_gc=true_gc,
        grad_at_init=grad_ad,
    )
    return {
        "target": target,
        "initial": initial,
        "recovered": recovered,
        "history": history,
        "true_Gc": true_gc,
        "init_Gc": init_gc,
        "recovered_Gc": recovered_gc,
        "relative_error": abs(recovered_gc - true_gc) / true_gc,
        "gradcheck_loss": grad_loss,
        "grad_autograd": grad_ad,
        "grad_fd": grad_fd,
        "grad_rel_error": grad_rel,
        "observability_gate": observability,
    }


def recover_pf_tpbt_gc(mesh: FEMMesh, cfg: PFTPBTConfig, *, max_iter: int = 6) -> dict[str, object]:
    result = recover_pf_scalar_gc(
        mesh=mesh,
        cfg=cfg,
        forward=rollout_pf_tpbt,
        loss_fn=pf_tpbt_loss,
        residual_fn=pf_tpbt_residual_vector,
        true_gc=cfg.true_Gc,
        init_gc=cfg.init_Gc,
        max_iter=max_iter,
    )
    result["problem"] = "pf_tpbt_scalar_gc"
    result["claim_boundary"] = (
        "Real quasistatic PF TPBT scalar Gc inverse from synthetic "
        "response observations; final damage is diagnostic unless "
        "damage_weight is set above zero."
    )
    result["loss_components_initial"] = _float_components(
        pf_tpbt_loss_components(result["initial"], result["target"], cfg)
    )
    result["loss_components_recovered"] = _float_components(
        pf_tpbt_loss_components(result["recovered"], result["target"], cfg)
    )
    result["loss_weights"] = _tpbt_loss_weights(cfg)
    result["optimized_channels"] = _optimized_channels(result["loss_weights"])
    return result


def recover_pf_wst_gc(mesh: FEMMesh, cfg: PFWSTConfig, *, max_iter: int = 6) -> dict[str, object]:
    result = recover_pf_scalar_gc(
        mesh=mesh,
        cfg=cfg,
        forward=rollout_pf_wst,
        loss_fn=pf_wst_loss,
        residual_fn=pf_wst_residual_vector,
        true_gc=cfg.true_Gc,
        init_gc=cfg.init_Gc,
        max_iter=max_iter,
    )
    result["problem"] = "pf_wst_style_scalar_gc"
    result["claim_boundary"] = (
        "Real quasistatic PF force-CMOD scalar Gc inverse from synthetic "
        "response observations on a WST-style notched block; not an exact "
        "Maier specimen geometry, and final damage is diagnostic unless "
        "damage_weight is set above zero."
    )
    result["loss_components_initial"] = _float_components(
        pf_wst_loss_components(result["initial"], result["target"], cfg)
    )
    result["loss_components_recovered"] = _float_components(
        pf_wst_loss_components(result["recovered"], result["target"], cfg)
    )
    result["loss_weights"] = _wst_loss_weights(cfg)
    result["optimized_channels"] = _optimized_channels(result["loss_weights"])
    return result


def save_pf_inverse_artifacts(result: dict[str, object], out_dir: Path, *, title: str) -> dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    summary_path = out_dir / "summary.json"
    history_path = out_dir / "convergence.csv"
    figure_path = out_dir / "pf_inverse.png"
    observability_path = out_dir / "observability_gate.json"
    target: PFRollout = result["target"]
    initial: PFRollout = result["initial"]
    recovered: PFRollout = result["recovered"]
    loss_weights = result.get("loss_weights") or {}
    damage_weight = float(loss_weights.get("damage", 0.0))
    summary = {
        "problem": result["problem"],
        "claim_boundary": result["claim_boundary"],
        "observation_contract": {
            "optimized_channels": result.get("optimized_channels"),
            "damage_field_role": "optimized_observation" if damage_weight > 0.0 else "diagnostic_only",
        },
        "true_Gc": result["true_Gc"],
        "init_Gc": result["init_Gc"],
        "recovered_Gc": result["recovered_Gc"],
        "relative_error": result["relative_error"],
        "loss_weights": loss_weights,
        "loss_components": {
            "initial": result.get("loss_components_initial"),
            "recovered": result.get("loss_components_recovered"),
        },
        "gradcheck": {
            "loss_at_init": result["gradcheck_loss"],
            "autograd_dloss_dlogGc": result["grad_autograd"],
            "fd_dloss_dlogGc": result["grad_fd"],
            "relative_error": result["grad_rel_error"],
        },
        "observability_gate": result.get("observability_gate"),
        "n_load_steps": int(target.reaction.numel()),
        "max_damage": {
            "target": float(target.max_damage.detach()),
            "initial": float(initial.max_damage.detach()),
            "recovered": float(recovered.max_damage.detach()),
        },
    }
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    observability = result.get("observability_gate")
    if observability is not None:
        observability_path.write_text(json.dumps(observability, indent=2) + "\n")
    with history_path.open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["iteration", "Gc", "loss", "grad_log_Gc"])
        writer.writeheader()
        for iteration, row in enumerate(result["history"]):
            writer.writerow({"iteration": iteration, **row})

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    disps = target.displacements.detach().cpu().numpy()
    fig, axes = plt.subplots(1, 3, figsize=(12.2, 3.6), constrained_layout=True)
    axes[0].plot(disps, target.reaction.detach().cpu().numpy(), "o-", label="target")
    axes[0].plot(disps, initial.reaction.detach().cpu().numpy(), "s--", label="initial")
    axes[0].plot(disps, recovered.reaction.detach().cpu().numpy(), "^-.", label="recovered")
    axes[0].set_xlabel("imposed displacement")
    axes[0].set_ylabel("reaction")
    axes[0].grid(alpha=0.3)
    axes[0].legend()

    if target.cmod is not None:
        axes[1].plot(disps, target.cmod.detach().cpu().numpy(), "o-", label="target")
        axes[1].plot(disps, initial.cmod.detach().cpu().numpy(), "s--", label="initial")
        axes[1].plot(disps, recovered.cmod.detach().cpu().numpy(), "^-.", label="recovered")
        axes[1].set_ylabel("CMOD")
    else:
        axes[1].plot(
            ["target", "initial", "recovered"],
            [
                float(target.max_damage.detach()),
                float(initial.max_damage.detach()),
                float(recovered.max_damage.detach()),
            ],
            "o-",
        )
        axes[1].set_ylabel("max damage")
    axes[1].set_xlabel("load step" if target.cmod is not None else "state")
    axes[1].grid(alpha=0.3)

    axes[2].semilogy([row["loss"] for row in result["history"]], "o-", color="#b23a48")
    axes[2].set_xlabel("closure evaluation")
    axes[2].set_ylabel("loss")
    axes[2].grid(alpha=0.3)
    fig.suptitle(title)
    fig.savefig(figure_path, dpi=180)
    plt.close(fig)
    artifacts = {
        "summary": str(summary_path),
        "history": str(history_path),
        "figure": str(figure_path),
    }
    if observability is not None:
        artifacts["observability_gate"] = str(observability_path)
    return artifacts
