#!/usr/bin/env python
"""Paper figure generator for spatial Gc(x) recovery.

Produces three-panel figure for paper §4:
  (a) truth Gc(x) field
  (b) recovered Gc(x) field
  (c) loss + L2 error vs iteration

Plus scaling study plot:
  (d) wall-clock per gradient: autograd (flat) vs FD (linear in k)

Usage:
    python plot_spatial_gc_results.py --recovery_dir results_spatial_gc \
        --scaling_csv results_scaling/scaling_study.csv
"""
import os
import sys
import json
import argparse
import csv

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.tri as tri

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

# Match surrounding paper body text (cas-sc / STIX serif).
try:
    from phast.paper_figure_style import apply_style
    apply_style()
except ImportError:
    pass

from phast.mesh import FEMMesh  # for triangulation
import torch


def _regenerate_mesh(recovery_dir, h_crack, h_coarse):
    """Fallback: rebuild the mesh from the same geo template used by
    demo_spatial_gc_recovery.build_sent_mesh for a given h_crack/h_coarse.
    Needed for legacy recovery dirs that didn't persist the mesh."""
    from .demo_spatial_gc_recovery import build_sent_mesh
    mesh = build_sent_mesh(h_crack, h_coarse, device='cpu', dtype=torch.float64)
    return mesh.nodes.cpu().numpy(), mesh.elements.cpu().numpy()


def load_recovery(recovery_dir, mesh_msh=None, fallback_h=None):
    """Load recovery results + build triangulation for plotting.

    Prefers the mesh_nodes/mesh_elements .npy files saved inside
    recovery_dir (robust against multiple demos overwriting /tmp).
    Falls back to the mesh .msh in recovery_dir, then the explicit
    mesh_msh argument.
    """
    Gc_true = np.load(os.path.join(recovery_dir, 'Gc_true.npy'))
    Gc_rec = np.load(os.path.join(recovery_dir, 'Gc_recovered.npy'))
    target = np.load(os.path.join(recovery_dir, 'target_damage.npy'))
    with open(os.path.join(recovery_dir, 'history.json')) as f:
        hist = json.load(f)

    nodes_npy = os.path.join(recovery_dir, 'mesh_nodes.npy')
    elems_npy = os.path.join(recovery_dir, 'mesh_elements.npy')
    if os.path.exists(nodes_npy) and os.path.exists(elems_npy):
        nodes = np.load(nodes_npy)
        elements = np.load(elems_npy)
    elif fallback_h is not None:
        # Legacy path: regenerate mesh from a known h_crack
        nodes, elements = _regenerate_mesh(recovery_dir,
                                            fallback_h, 5 * fallback_h)
    else:
        # Legacy path: fall back to a .msh file
        if mesh_msh is None:
            local_msh = os.path.join(recovery_dir, 'mesh.msh')
            if os.path.exists(local_msh):
                mesh_msh = local_msh
            else:
                import tempfile
                mesh_msh = os.path.join(tempfile.gettempdir(),
                                          "spatial_gc_demo.msh")
        mesh = FEMMesh(mesh_msh, device='cpu', dtype=torch.float64)
        nodes = mesh.nodes.cpu().numpy()
        elements = (mesh.elements.cpu().numpy()
                    if hasattr(mesh, 'elements')
                    else np.array([c.data for c in mesh._cells
                                   if c.type == 'triangle'][0]))

    # Sanity-check that the mesh matches the field size
    if elements.shape[0] != Gc_true.shape[0]:
        raise ValueError(
            f"Mesh/field mismatch: mesh has {elements.shape[0]} "
            f"triangles but Gc_true has {Gc_true.shape[0]} elements. "
            f"Check that the mesh persisted alongside the recovery "
            f"data in {recovery_dir}.")
    return Gc_true, Gc_rec, target, hist, nodes, elements


def plot_field_on_elements(ax, nodes, elements, field, cmap, title, vmin, vmax):
    """Plot an element-wise field via tripcolor (flat shading)."""
    triangulation = tri.Triangulation(nodes[:, 0], nodes[:, 1], elements)
    pc = ax.tripcolor(triangulation, facecolors=field, cmap=cmap,
                       vmin=vmin, vmax=vmax, edgecolors='none')
    ax.set_aspect('equal')
    ax.set_title(title, fontsize=10)
    ax.set_xticks([]); ax.set_yticks([])
    return pc


def plot_recovery_figure(recovery_dir, output_path, mesh_msh=None,
                         fallback_h=None):
    Gc_true, Gc_rec, target, hist, nodes, elements = \
        load_recovery(recovery_dir, mesh_msh, fallback_h=fallback_h)
    n_elem = len(Gc_true)

    # 2×2 grid: (a) truth, (b) recovered in top row;
    # (c) error field, (d) convergence in bottom row.
    # Aspect keeps mesh panels readable at paper column width (~3" each).
    fig = plt.figure(figsize=(10, 5.5))
    from matplotlib.gridspec import GridSpec
    gs = GridSpec(2, 2, figure=fig, hspace=0.42, wspace=0.35)
    ax_truth = fig.add_subplot(gs[0, 0])
    ax_rec   = fig.add_subplot(gs[0, 1])
    ax_err   = fig.add_subplot(gs[1, 0])
    ax_conv  = fig.add_subplot(gs[1, 1])

    # Shared scale for truth/recovered; RdBu_r: blue=weak, red=strong.
    vmin = min(Gc_true.min(), Gc_rec.min())
    vmax = max(Gc_true.max(), Gc_rec.max())

    pc = plot_field_on_elements(ax_truth, nodes, elements, Gc_true,
                                'RdBu_r', f'(a) Truth $G_c(\mathbf{{x}})$',
                                vmin, vmax)
    plt.colorbar(pc, ax=ax_truth, shrink=0.8, label='$G_c$ [N/mm]')

    pc = plot_field_on_elements(ax_rec, nodes, elements, Gc_rec,
                                'RdBu_r', '(b) Recovered $G_c(\mathbf{x})$',
                                vmin, vmax)
    plt.colorbar(pc, ax=ax_rec, shrink=0.8, label='$G_c$ [N/mm]')

    # (c) absolute error field
    err = np.abs(Gc_rec - Gc_true)
    pc = plot_field_on_elements(ax_err, nodes, elements, err,
                                'Reds', r'(c) $|G_{c,\mathrm{rec}} - G_{c,\mathrm{true}}|$',
                                0, err.max())
    plt.colorbar(pc, ax=ax_err, shrink=0.8, label=r'$|\Delta G_c|$')

    # (d) convergence history — dual-axis: MSE loss (blue) + rel. L2 (red)
    it = np.asarray(hist['iter'])
    loss = np.asarray(hist['loss'])
    err_L2 = np.asarray(hist['err_L2_rel'])
    ax2 = ax_conv.twinx()
    ax_conv.semilogy(it, loss, color='#457B9D', lw=2, label='MSE loss')
    ax2.semilogy(it, err_L2, color='#E63946', lw=2, ls='--',
                 label=r'$\|G_{c,\mathrm{rec}} - G_{c,\mathrm{true}}\| / \|G_{c,\mathrm{true}}\|$')
    ax_conv.set_xlabel('L-BFGS iteration')
    ax_conv.set_ylabel('MSE loss', color='#457B9D')
    ax2.set_ylabel('Rel. $L^2$ error', color='#E63946')
    ax_conv.tick_params(axis='y', labelcolor='#457B9D')
    ax2.tick_params(axis='y', labelcolor='#E63946')
    ax_conv.set_title('(d) Convergence')
    ax_conv.grid(True, alpha=0.3)

    fig.suptitle(
        f'Spatial $G_c(\\mathbf{{x}})$ recovery via autograd  '
        f'($k = {n_elem}$ unknowns)',
        fontsize=10, y=1.01)
    fig.savefig(output_path, dpi=200, bbox_inches='tight')
    plt.close(fig)
    print(f"Saved: {output_path}")


def plot_scaling_figure(scaling_csv, output_path):
    rows = list(csv.DictReader(open(scaling_csv)))
    k = np.array([int(r['n_elem']) for r in rows])
    t_ad = np.array([float(r['autograd_s']) for r in rows])
    t_fd_full = np.array([float(r['fd_full_s']) for r in rows])

    fig, ax = plt.subplots(1, 1, figsize=(6, 4))
    ax.loglog(k, t_ad, 'b-o', lw=2, ms=8, label='Autograd (this work)')
    ax.loglog(k, t_fd_full, 'r--s', lw=2, ms=8, label='Finite differences')

    # Reference lines
    k_ref = np.array([k.min(), k.max()])
    ax.loglog(k_ref, [t_ad.mean(), t_ad.mean()], 'b:', alpha=0.5,
               label='O(1) reference')
    # FD: scale linearly from first measured point
    fd_slope = t_fd_full[0] / k[0]
    ax.loglog(k_ref, fd_slope * k_ref, 'r:', alpha=0.5, label='O(k) reference')

    ax.set_xlabel('Number of unknowns k = n_elem')
    ax.set_ylabel('Wall time per gradient [s]')
    ax.set_title('Cost per gradient scaling')
    ax.legend(loc='upper left')
    ax.grid(True, which='both', alpha=0.3)

    # Annotate the k at which FD crosses 1 hour
    one_hour = 3600
    if t_fd_full.max() < one_hour:
        k_1hr = one_hour / fd_slope
        ax.axhline(one_hour, color='gray', ls=':', alpha=0.5)
        ax.annotate(f'FD = 1 hr at k ≈ {k_1hr:.0e}',
                     xy=(k_ref[-1], one_hour), ha='right', va='bottom',
                     fontsize=9, color='gray')

    fig.tight_layout()
    fig.savefig(output_path, dpi=200, bbox_inches='tight')
    plt.close(fig)
    print(f"Saved: {output_path}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--recovery_dir', type=str, default=None,
                   help='Dir with Gc_true/Gc_recovered/target/history outputs')
    p.add_argument('--scaling_csv', type=str, default=None,
                   help='Path to scaling_study.csv')
    p.add_argument('--mesh_msh', type=str, default=None,
                   help='Path to mesh .msh file (defaults to /tmp/spatial_gc_demo.msh)')
    p.add_argument('--fallback_h', type=float, default=None,
                   help='h_crack used during recovery — enables mesh '
                        'regeneration when mesh_nodes/.msh is absent.')
    p.add_argument('--out', type=str, default='.')
    args = p.parse_args()

    os.makedirs(args.out, exist_ok=True)

    if args.recovery_dir:
        plot_recovery_figure(
            args.recovery_dir,
            os.path.join(args.out, 'spatial_gc_recovery.png'),
            mesh_msh=args.mesh_msh,
            fallback_h=args.fallback_h)

    if args.scaling_csv:
        plot_scaling_figure(
            args.scaling_csv,
            os.path.join(args.out, 'spatial_gc_scaling.png'))


if __name__ == '__main__':
    main()
