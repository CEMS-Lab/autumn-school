"""Sampling helpers for inverse-problem observation histories."""

from __future__ import annotations

import numpy as np


def unique_even_sample_steps(n_steps: int, n_samples: int) -> np.ndarray:
    """Return unique zero-based step indices for an inverse observation history.

    ``numpy.linspace(..., dtype=int)`` silently repeats indices when
    ``n_samples > n_steps``. Repeated indices are unsafe for inverse runs that
    map ``step -> observation row`` because later duplicates overwrite earlier
    rows and leave some target rows at their zero initial value.

    The returned length is ``min(n_steps, n_samples)``.
    """
    n_steps = int(n_steps)
    n_samples = int(n_samples)
    if n_steps <= 0:
        raise ValueError(f"n_steps must be positive, got {n_steps}")
    if n_samples <= 0:
        raise ValueError(f"n_samples must be positive, got {n_samples}")
    n_keep = min(n_steps, n_samples)
    steps = np.rint(np.linspace(0, n_steps - 1, n_keep)).astype(np.int64)
    return np.unique(steps)


def prefix_resample_indices(n_available: int, n_samples: int) -> np.ndarray:
    """Return unique row indices for resampling a prefix of an observation array."""
    return unique_even_sample_steps(n_available, n_samples)
