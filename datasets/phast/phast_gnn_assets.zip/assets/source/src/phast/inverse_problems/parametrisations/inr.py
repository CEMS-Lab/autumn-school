"""Implicit Neural Representation (INR) for scalar parameter fields.

A ``FieldINR`` is a small MLP ``f_theta : R^d -> R`` that *is* the parameter
field. Inverse problems optimise ``theta`` (a few hundred to a few thousand
weights) instead of one degree of freedom per FE node, yielding a strong
smoothness prior with very few parameters.

Combined with random Fourier features (Tancik 2020) the network can fit
high-frequency targets without the spectral-bias pathology of a plain MLP.

Inspiration: Zobeiry 2026 (INR + Fourier features for PDE-constrained
inverse problems). Issue #205 in the phast tracker.
"""

from __future__ import annotations

import torch
from torch import nn

from .fourier_features import FourierFeatures


class FieldINR(nn.Module):
    """A small MLP that maps spatial coordinates to a scalar parameter value.

    Parameters
    ----------
    n_input_dims : int, default 2
        Spatial dimension of the input coordinates.
    n_fourier_features : int, default 64
        Number of random Fourier projections. Set to 0 to disable the
        lift and feed raw coordinates directly to the MLP (the network
        then degenerates to a vanilla coordinate MLP).
    fourier_sigma : float, default 3.0
        Standard deviation for the Fourier-feature projection matrix.
    hidden_width : int, default 64
        Width of each hidden MLP layer.
    n_hidden_layers : int, default 3
        Number of hidden layers (each a Linear + GELU).
    activation : nn.Module factory, default nn.GELU
        Activation used between hidden layers.
    output_activation : nn.Module or None, default None
        Optional activation on the scalar output (e.g. ``nn.Softplus()``
        when the target field must be positive).
    seed : int or None, default None
        Seed for the Fourier projection. Network weights use the global
        ``torch.manual_seed`` (caller's responsibility).
    """

    def __init__(
        self,
        n_input_dims: int = 2,
        n_fourier_features: int = 64,
        fourier_sigma: float = 3.0,
        hidden_width: int = 64,
        n_hidden_layers: int = 3,
        activation: type[nn.Module] = nn.GELU,
        output_activation: nn.Module | None = None,
        seed: int | None = None,
    ) -> None:
        super().__init__()
        if n_hidden_layers < 1:
            raise ValueError("n_hidden_layers must be >= 1")
        if hidden_width < 1:
            raise ValueError("hidden_width must be >= 1")

        self.n_input_dims = int(n_input_dims)
        self.fourier = FourierFeatures(
            n_features=n_fourier_features,
            sigma=fourier_sigma,
            n_input_dims=n_input_dims,
            seed=seed,
        )

        in_dim = self.fourier.out_features
        layers: list[nn.Module] = []
        prev = in_dim
        for _ in range(n_hidden_layers):
            layers.append(nn.Linear(prev, hidden_width))
            layers.append(activation())
            prev = hidden_width
        layers.append(nn.Linear(prev, 1))
        if output_activation is not None:
            layers.append(output_activation)
        self.mlp = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Evaluate the field.

        Parameters
        ----------
        x : Tensor, shape (..., n_input_dims)

        Returns
        -------
        Tensor, shape (...,) -- scalar field, last dim squeezed.
        """
        feats = self.fourier(x)
        out = self.mlp(feats)  # (..., 1)
        return out.squeeze(-1)

    def n_trainable_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def evaluate_at_nodes(
    inr: FieldINR, node_coords: torch.Tensor
) -> torch.Tensor:
    """Evaluate an ``FieldINR`` at a set of FE node coordinates.

    Thin convenience wrapper: returns a 1-D tensor of length ``n_nodes``
    matching the row order of ``node_coords``.

    Parameters
    ----------
    inr : FieldINR
    node_coords : Tensor, shape (n_nodes, n_input_dims)

    Returns
    -------
    Tensor, shape (n_nodes,) -- field values, one per node, in the same
    order as ``node_coords``.
    """
    if node_coords.dim() != 2:
        raise ValueError(
            "node_coords must be a 2-D tensor (n_nodes, n_dims); got "
            f"shape {tuple(node_coords.shape)}"
        )
    if node_coords.shape[1] != inr.n_input_dims:
        raise ValueError(
            f"node_coords last dim ({node_coords.shape[1]}) must match "
            f"inr.n_input_dims ({inr.n_input_dims})"
        )
    return inr(node_coords)
