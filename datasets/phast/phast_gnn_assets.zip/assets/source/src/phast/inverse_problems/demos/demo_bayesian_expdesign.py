"""Bayesian experimental design loop for crack-parameter identification.

Two-round closed-loop Bayesian experiment on synthetic D3 geometry:

  Round 1:
    - HMC posterior p(θ | data_1) from a sparse sensor layout
    - Posterior Fisher information recommends optimal new sensor location S*

  Round 2:
    - Re-run HMC on the expanded dataset (data_1 + data at S*)
    - Posterior credible interval narrows → quantified information gain

Parameters recovered:
  θ = (x0, log_A)
    x0   : crack-tip x-coordinate [mm], prior N(16, 4²)
    log_A: log displacement amplitude, prior N(0, 1²)

Synthetic forward model (no mesh required):
  u_i(θ) = A · exp(-((s_x_i - x0)² + s_y_i²) / L²)
  where s_i is the i-th sensor location, L = 4 mm.

Usage
-----
::

    python -m phast.inverse_problems.demos.demo_bayesian_expdesign

Typical output::

    Round 1 posterior std:   x0=1.42 mm, log_A=0.31
    Optimal new sensor: x=18.4mm, y=0.0mm  (D-opt gain +0.83 nats)
    Round 2 posterior std:   x0=0.87 mm, log_A=0.19
    Credible interval narrowed by 38.7%  ✓

References
----------
issue #592 — Bayesian experimental design loop: HMC posterior + optimal sensor placement
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch
from torch import Tensor

# ---------------------------------------------------------------------------
# Synthetic forward model for D3-like crack scenario
# ---------------------------------------------------------------------------

L_CRACK = 4.0    # crack displacement length scale [mm]
SIGMA_NOISE = 0.005  # observation noise std [mm]
X_CRACK_TRUTH = 16.0
LOG_A_TRUTH = 0.0    # A = 1.0 mm at crack tip
N_DOMAIN = 25        # candidate sensor pool along x ∈ [5, 25] mm, y = 0


def _forward(theta: Tensor, sensors_x: Tensor, sensors_y: Tensor) -> Tensor:
    """Synthetic crack-tip displacement at sensor positions.

    u_i = A * exp(-((s_x_i - x0)^2 + s_y_i^2) / L^2)

    Parameters
    ----------
    theta     : (2,) — [x0 [mm], log_A]
    sensors_x : (n,) — sensor x-coords [mm]
    sensors_y : (n,) — sensor y-coords [mm]

    Returns
    -------
    u : (n,) predicted displacement [mm]
    """
    x0 = theta[0]
    log_A = theta[1]
    A = torch.exp(log_A)
    r2 = (sensors_x - x0) ** 2 + sensors_y ** 2
    return A * torch.exp(-r2 / (L_CRACK ** 2))


def _make_synthetic_obs(
    theta_truth: Tensor,
    sensors_x: Tensor,
    sensors_y: Tensor,
    noise_std: float = SIGMA_NOISE,
    seed: int = 0,
) -> Tensor:
    """Ground-truth forward + additive noise."""
    torch.manual_seed(seed)
    u_clean = _forward(theta_truth, sensors_x, sensors_y)
    noise = torch.randn_like(u_clean) * noise_std
    return u_clean + noise


# ---------------------------------------------------------------------------
# Potential function U(θ) = -log p(θ|data)
# ---------------------------------------------------------------------------

def _make_potential(
    obs: Tensor,
    sensors_x: Tensor,
    sensors_y: Tensor,
    sigma_noise: float = SIGMA_NOISE,
    prior_x0_mean: float = 16.0,
    prior_x0_std: float = 4.0,
    prior_logA_std: float = 1.0,
) -> callable:
    """Build U(θ) = -log p(θ|data) with Gaussian likelihood + prior."""
    def U(theta: Tensor) -> Tensor:
        u_pred = _forward(theta, sensors_x, sensors_y)
        residual = u_pred - obs
        nll = 0.5 * (residual / sigma_noise).pow(2).sum()
        # Gaussian prior: x0 ~ N(x0_mean, x0_std²), log_A ~ N(0, logA_std²)
        prior_x0 = 0.5 * ((theta[0] - prior_x0_mean) / prior_x0_std) ** 2
        prior_logA = 0.5 * (theta[1] / prior_logA_std) ** 2
        return nll + prior_x0 + prior_logA
    return U


# ---------------------------------------------------------------------------
# Fisher-based optimal sensor recommendation
# ---------------------------------------------------------------------------

def _jacobian_at(
    theta_mean: Tensor,
    sensors_x: Tensor,
    sensors_y: Tensor,
) -> np.ndarray:
    """Numerical Jacobian J = ∂u/∂θ at theta_mean, shape (n_sensors, 2)."""
    eps = 1e-4
    theta_mean = theta_mean.clone()
    n = sensors_x.shape[0]
    J = np.zeros((n, 2))
    for j in range(2):
        th_p = theta_mean.clone()
        th_m = theta_mean.clone()
        th_p[j] += eps
        th_m[j] -= eps
        u_p = _forward(th_p, sensors_x, sensors_y).detach().numpy()
        u_m = _forward(th_m, sensors_x, sensors_y).detach().numpy()
        J[:, j] = (u_p - u_m) / (2 * eps)
    return J


def _fisher_d_optimality(J_full: np.ndarray, sigma_noise: float) -> float:
    """log det(F) where F = J^T J / sigma²."""
    F = J_full.T @ J_full / sigma_noise ** 2
    sign, logdet = np.linalg.slogdet(F)
    if sign <= 0:
        return float("-inf")
    return float(logdet)


def recommend_next_sensor(
    posterior_samples: np.ndarray,
    candidate_x: np.ndarray,
    candidate_y: np.ndarray,
    active_mask: np.ndarray,
    sigma_noise: float = SIGMA_NOISE,
) -> Tuple[int, float]:
    """Greedy D-optimal sensor selection.

    Parameters
    ----------
    posterior_samples : (n_samples, 2) — HMC posterior samples
    candidate_x, candidate_y : (n_cand,) — candidate positions
    active_mask      : (n_cand,) bool — currently active sensors
    sigma_noise      : observation noise std

    Returns
    -------
    best_idx : index into candidate arrays of recommended new sensor
    d_opt_gain : improvement in log det(F) from adding that sensor
    """
    theta_mean = torch.tensor(posterior_samples.mean(0), dtype=torch.float64)
    sensors_x_all = torch.tensor(candidate_x, dtype=torch.float64)
    sensors_y_all = torch.tensor(candidate_y, dtype=torch.float64)

    # Jacobian at posterior mean, over ALL candidate locations
    J_all = _jacobian_at(theta_mean, sensors_x_all, sensors_y_all)

    # Current Fisher info (active sensors only)
    J_active = J_all[active_mask]
    d_opt_current = _fisher_d_optimality(J_active, sigma_noise) if J_active.shape[0] > 0 else float("-inf")

    best_idx = -1
    best_gain = float("-inf")
    for i, is_active in enumerate(active_mask):
        if is_active:
            continue  # skip already-active sensors
        # Tentatively add sensor i
        candidate_rows = np.concatenate([J_active, J_all[i : i + 1]], axis=0)
        d_opt_new = _fisher_d_optimality(candidate_rows, sigma_noise)
        gain = d_opt_new - d_opt_current
        if gain > best_gain:
            best_gain = gain
            best_idx = i

    return best_idx, best_gain


# ---------------------------------------------------------------------------
# Main design loop
# ---------------------------------------------------------------------------

def run_design_loop(
    n_warmup: int = 30,
    n_samples: int = 50,
    step_size: float = 0.05,
    n_leapfrog: int = 5,
    verbose: bool = True,
    seed: int = 0,
) -> Dict:
    """Two-round Bayesian experimental design loop.

    Returns dict with round1/round2 posterior statistics and sensor info.
    """
    from phast.inverse_problems.hmc import hmc_sample

    dtype = torch.float64
    torch.manual_seed(seed)
    np.random.seed(seed)

    # --- Candidate sensor pool ---
    cand_x = np.linspace(5.0, 25.0, N_DOMAIN)
    cand_y = np.zeros(N_DOMAIN)

    # --- Ground truth ---
    theta_truth = torch.tensor([X_CRACK_TRUTH, LOG_A_TRUTH], dtype=dtype)

    # --- Round 1: sparse 5-sensor layout ---
    # Evenly spaced: indices 0, 6, 12, 18, 24
    r1_idx = np.array([0, 6, 12, 18, 24])
    active_mask = np.zeros(N_DOMAIN, dtype=bool)
    active_mask[r1_idx] = True

    s_x_r1 = torch.tensor(cand_x[r1_idx], dtype=dtype)
    s_y_r1 = torch.tensor(cand_y[r1_idx], dtype=dtype)
    obs_r1 = _make_synthetic_obs(theta_truth, s_x_r1, s_y_r1, seed=seed)

    if verbose:
        print("=" * 60)
        print("Bayesian experimental design loop (synthetic D3)")
        print("=" * 60)
        print(f"\nTruth: x0={X_CRACK_TRUTH:.1f} mm, log_A={LOG_A_TRUTH:.1f}")
        print(f"Round 1: {len(r1_idx)} sensors at x={cand_x[r1_idx].round(1)}")

    U_r1 = _make_potential(obs_r1, s_x_r1, s_y_r1)
    theta_init_r1 = torch.tensor([15.0, 0.2], dtype=dtype)

    t0 = time.time()
    result_r1 = hmc_sample(
        U_r1,
        theta_init=theta_init_r1,
        n_warmup=n_warmup,
        n_samples=n_samples,
        step_size=step_size,
        n_leapfrog=n_leapfrog,
        verbose=False,
    )
    t_r1 = time.time() - t0

    samples_r1 = np.array(result_r1["samples"])   # (n_samples, 2)
    std_x0_r1 = float(samples_r1[:, 0].std())
    std_logA_r1 = float(samples_r1[:, 1].std())
    mean_x0_r1 = float(samples_r1[:, 0].mean())
    accept_r1 = float(result_r1["accept_rate"])

    if verbose:
        print(f"\nRound 1 HMC ({n_samples} samples, {t_r1:.1f}s):")
        print(f"  accept_rate = {accept_r1:.2f}")
        print(f"  posterior mean x0 = {mean_x0_r1:.2f} mm  (truth={X_CRACK_TRUTH:.1f})")
        print(f"  posterior std  x0 = {std_x0_r1:.3f} mm")
        print(f"  posterior std log_A = {std_logA_r1:.3f}")

    # --- Sensor recommendation ---
    best_sensor_idx, d_opt_gain = recommend_next_sensor(
        samples_r1, cand_x, cand_y, active_mask,
    )
    if verbose:
        print(f"\nOptimal new sensor: x={cand_x[best_sensor_idx]:.1f} mm, "
              f"y={cand_y[best_sensor_idx]:.1f} mm")
        print(f"  D-optimality gain: {d_opt_gain:.4f} nats")

    # --- Round 2: add optimal sensor ---
    r2_idx = np.append(r1_idx, best_sensor_idx)
    active_mask_r2 = np.zeros(N_DOMAIN, dtype=bool)
    active_mask_r2[r2_idx] = True

    s_x_r2 = torch.tensor(cand_x[r2_idx], dtype=dtype)
    s_y_r2 = torch.tensor(cand_y[r2_idx], dtype=dtype)
    obs_r2 = _make_synthetic_obs(theta_truth, s_x_r2, s_y_r2, seed=seed + 1)

    if verbose:
        print(f"\nRound 2: {len(r2_idx)} sensors "
              f"(+x={cand_x[best_sensor_idx]:.1f} mm)")

    U_r2 = _make_potential(obs_r2, s_x_r2, s_y_r2)
    theta_init_r2 = torch.tensor([mean_x0_r1, float(samples_r1[:, 1].mean())],
                                 dtype=dtype)

    t0 = time.time()
    result_r2 = hmc_sample(
        U_r2,
        theta_init=theta_init_r2,
        n_warmup=n_warmup,
        n_samples=n_samples,
        step_size=step_size,
        n_leapfrog=n_leapfrog,
        verbose=False,
    )
    t_r2 = time.time() - t0

    samples_r2 = np.array(result_r2["samples"])
    std_x0_r2 = float(samples_r2[:, 0].std())
    std_logA_r2 = float(samples_r2[:, 1].std())
    mean_x0_r2 = float(samples_r2[:, 0].mean())
    accept_r2 = float(result_r2["accept_rate"])

    # 95% credible interval width (2×1.96σ)
    ci_r1 = 2 * 1.96 * std_x0_r1
    ci_r2 = 2 * 1.96 * std_x0_r2
    ci_reduction_pct = 100.0 * (ci_r1 - ci_r2) / (ci_r1 + 1e-30)

    if verbose:
        print(f"\nRound 2 HMC ({n_samples} samples, {t_r2:.1f}s):")
        print(f"  accept_rate = {accept_r2:.2f}")
        print(f"  posterior mean x0 = {mean_x0_r2:.2f} mm  (truth={X_CRACK_TRUTH:.1f})")
        print(f"  posterior std  x0 = {std_x0_r2:.3f} mm")
        print(f"  posterior std log_A = {std_logA_r2:.3f}")
        print(f"\n95% CI (x0): Round 1={ci_r1:.3f} mm → Round 2={ci_r2:.3f} mm")
        print(f"Credible interval narrowed by {ci_reduction_pct:.1f}%")
        if ci_r2 < ci_r1:
            print("PASS — posterior uncertainty reduced after optimal sensor addition")
        else:
            print("WARNING — posterior uncertainty did not decrease; check HMC convergence")
        print("=" * 60)

    return {
        "round1": {
            "n_sensors": int(len(r1_idx)),
            "sensor_x": cand_x[r1_idx].tolist(),
            "posterior_mean_x0": mean_x0_r1,
            "posterior_std_x0": std_x0_r1,
            "posterior_std_logA": std_logA_r1,
            "accept_rate": accept_r1,
            "ci_95_x0_mm": ci_r1,
        },
        "sensor_design": {
            "best_sensor_idx": int(best_sensor_idx),
            "best_sensor_x": float(cand_x[best_sensor_idx]),
            "d_opt_gain_nats": d_opt_gain,
        },
        "round2": {
            "n_sensors": int(len(r2_idx)),
            "sensor_x": cand_x[r2_idx].tolist(),
            "posterior_mean_x0": mean_x0_r2,
            "posterior_std_x0": std_x0_r2,
            "posterior_std_logA": std_logA_r2,
            "accept_rate": accept_r2,
            "ci_95_x0_mm": ci_r2,
        },
        "ci_reduction_pct": ci_reduction_pct,
        "truth": {"x0": X_CRACK_TRUTH, "log_A": LOG_A_TRUTH},
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--n_warmup", type=int, default=30,
                   help="HMC warmup steps per round (default 30)")
    p.add_argument("--n_samples", type=int, default=50,
                   help="HMC posterior samples per round (default 50)")
    p.add_argument("--step_size", type=float, default=0.05)
    p.add_argument("--n_leapfrog", type=int, default=5)
    p.add_argument("--output_dir", type=str, default=None)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--quiet", action="store_true")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()

    result = run_design_loop(
        n_warmup=args.n_warmup,
        n_samples=args.n_samples,
        step_size=args.step_size,
        n_leapfrog=args.n_leapfrog,
        verbose=not args.quiet,
        seed=args.seed,
    )

    if args.output_dir:
        out = Path(args.output_dir)
        out.mkdir(parents=True, exist_ok=True)
        out_path = out / "bayesian_expdesign_result.json"
        with open(out_path, "w") as f:
            json.dump(result, f, indent=2)
        print(f"Results saved to {out_path}")

    # Exit with non-zero if CI did not narrow (for CI gate)
    ci_r1 = result["round1"]["ci_95_x0_mm"]
    ci_r2 = result["round2"]["ci_95_x0_mm"]
    if ci_r2 >= ci_r1:
        print(f"FAIL: CI did not narrow ({ci_r1:.3f} → {ci_r2:.3f} mm)")
        sys.exit(1)
    sys.exit(0)
