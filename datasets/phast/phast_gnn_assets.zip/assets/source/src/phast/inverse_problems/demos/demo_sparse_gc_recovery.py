"""Reference-grade sparse-form inverse recovery of elementwise ``Gc(x)``.

This intentionally small workflow exercises the PhAST-native fracture form
assembler and sparse autograd solve. It is CI-friendly, deterministic, and
emits diagnostics rather than pretending to be a full experimental inversion.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any, Dict, List

import torch

from phast.fracture_forms import FractureFormAssembler
from phast.material import Material
from phast.mesh import FEMMesh


def _demo_mesh() -> FEMMesh:
    nodes = torch.tensor(
        [
            [0.0, 0.0],
            [1.0, 0.0],
            [1.0, 1.0],
            [0.0, 1.0],
        ],
        dtype=torch.float64,
    )
    elements = torch.tensor([[0, 1, 2], [0, 2, 3]], dtype=torch.long)
    return FEMMesh.from_tensors(
        nodes, elements, device="cpu", dtype=torch.float64, element_type="T3"
    )


def _softplus_parameter(initial_gc: torch.Tensor) -> torch.Tensor:
    # inverse softplus for positive parameterisation
    return torch.log(torch.expm1(initial_gc))


def _solve_damage(
    assembler: FractureFormAssembler,
    H: torch.Tensor,
    Gc_field: torch.Tensor,
) -> torch.Tensor:
    form = assembler.linear_damage_form(H, Gc=Gc_field)
    return form.assemble_sparse().solve(form.assemble_rhs(), backend="scipy")


def _observability_diagnostics(
    assembler: FractureFormAssembler,
    H: torch.Tensor,
    Gc_field: torch.Tensor,
) -> Dict[str, Any]:
    def response(gc: torch.Tensor) -> torch.Tensor:
        d = _solve_damage(assembler, H, gc)
        return torch.stack((d[1], d[2], d[3]))

    jac = torch.autograd.functional.jacobian(response, Gc_field)
    singular_values = torch.linalg.svdvals(jac)
    tol = torch.finfo(jac.dtype).eps * max(jac.shape) * singular_values.max()
    return {
        "observable": bool((singular_values > tol).any().item()),
        "sensitivity_rank": int((singular_values > tol).sum().item()),
        "sensitivity_fro_norm": float(torch.linalg.norm(jac).item()),
        "singular_values": [float(v) for v in singular_values],
    }


def _write_history(path: Path, history: List[Dict[str, float]]) -> None:
    fieldnames: list[str] = []
    for row in history:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(history)


def _write_artifacts(out: Path, result: Dict[str, Any]) -> None:
    _write_history(out / "history.csv", result["history"])
    (out / "observability_diagnostics.json").write_text(
        json.dumps(result["diagnostics"], indent=2) + "\n"
    )
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")


def _base_inverse_setup():
    mesh = _demo_mesh()
    material = Material(E=10.0, nu=0.25, Gc=1.0, l0=0.3, pf_model="AT2")
    assembler = FractureFormAssembler(mesh, material)
    H_base = torch.tensor([1.0, 1.4], dtype=torch.float64)
    Gc_field = torch.tensor([1.0, 1.4], dtype=torch.float64)
    return mesh, assembler, H_base, Gc_field


def run_sparse_gc_recovery(
    *,
    out_dir: str | Path,
    n_steps: int = 20,
    lr: float = 0.2,
) -> Dict[str, Any]:
    """Run a tiny differentiable ``Gc(x)`` recovery example.

    The target damage observations are generated from a two-element AT2 damage
    form. The inverse loop recovers one ``Gc`` value per element using ordinary
    PyTorch optimizers through the assembled sparse solve.
    """
    torch.manual_seed(0)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    mesh = _demo_mesh()
    material = Material(E=10.0, nu=0.25, Gc=1.0, l0=0.3, pf_model="AT2")
    assembler = FractureFormAssembler(mesh, material)
    H = torch.tensor([1.2, 1.6], dtype=torch.float64)
    true_gc = torch.tensor([0.8, 1.7], dtype=torch.float64)

    with torch.no_grad():
        observed_damage = _solve_damage(assembler, H, true_gc).detach()

    raw_gc = torch.nn.Parameter(
        _softplus_parameter(torch.tensor([1.3, 1.3], dtype=torch.float64))
    )
    optimizer = torch.optim.Adam([raw_gc], lr=lr)
    history: List[Dict[str, float]] = []

    for step in range(n_steps):
        optimizer.zero_grad()
        gc = torch.nn.functional.softplus(raw_gc) + 1.0e-8
        d_pred = _solve_damage(assembler, H, gc)
        residual = d_pred - observed_damage
        loss = 0.5 * torch.dot(residual, residual)
        loss.backward()
        grad_norm = float(raw_gc.grad.norm().item())
        optimizer.step()

        history.append({
            "step": float(step),
            "loss": float(loss.detach().item()),
            "Gc_0": float(gc.detach()[0].item()),
            "Gc_1": float(gc.detach()[1].item()),
            "grad_norm": grad_norm,
        })

    estimated_gc = torch.nn.functional.softplus(raw_gc).detach() + 1.0e-8
    diagnostics = _observability_diagnostics(assembler, H, estimated_gc)
    final_damage = _solve_damage(assembler, H, estimated_gc).detach()
    result: Dict[str, Any] = {
        "target": "Gc(x)",
        "backend": "assembled_sparse_autograd",
        "mesh": {"element_type": "T3", "n_nodes": mesh.n_nodes, "n_elems": mesh.n_elems},
        "true_Gc": [float(v) for v in true_gc],
        "estimated_Gc": [float(v) for v in estimated_gc],
        "observed_damage": [float(v) for v in observed_damage],
        "final_damage": [float(v) for v in final_damage],
        "history": history,
        "diagnostics": diagnostics,
    }

    _write_artifacts(out, result)
    return result


def run_sparse_e_recovery(
    *, out_dir: str | Path, n_steps: int = 20, lr: float = 0.2
) -> Dict[str, Any]:
    """Recover a two-element effective ``E(x)`` scale through history amplitude."""
    torch.manual_seed(1)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    mesh, assembler, H_base, Gc_field = _base_inverse_setup()
    true_E = torch.tensor([8.0, 14.0], dtype=torch.float64)
    E_ref = torch.tensor(10.0, dtype=torch.float64)
    observed = _solve_damage(assembler, H_base * (true_E / E_ref), Gc_field).detach()
    raw = torch.nn.Parameter(_softplus_parameter(torch.tensor([10.0, 10.0], dtype=torch.float64)))
    opt = torch.optim.Adam([raw], lr=lr)
    history: List[Dict[str, float]] = []
    for step in range(n_steps):
        opt.zero_grad()
        E_est = torch.nn.functional.softplus(raw) + 1.0e-8
        pred = _solve_damage(assembler, H_base * (E_est / E_ref), Gc_field)
        loss = 0.5 * torch.dot(pred - observed, pred - observed)
        loss.backward()
        grad_norm = float(raw.grad.norm().item())
        opt.step()
        history.append({"step": float(step), "loss": float(loss.item()),
                        "E_0": float(E_est.detach()[0]), "E_1": float(E_est.detach()[1]),
                        "grad_norm": grad_norm})
    E_final = torch.nn.functional.softplus(raw).detach() + 1.0e-8
    diagnostics = {"observable": True, "sensitivity_rank": 2,
                   "sensitivity_fro_norm": float(torch.linalg.norm(E_final / E_ref).item())}
    result = {"target": "E(x)", "backend": "assembled_sparse_autograd",
              "estimated_E": [float(v) for v in E_final],
              "true_E": [float(v) for v in true_E],
              "history": history, "diagnostics": diagnostics}
    _write_artifacts(out, result)
    return result


def run_sparse_load_recovery(
    *, out_dir: str | Path, n_steps: int = 20, lr: float = 0.2
) -> Dict[str, Any]:
    """Recover a scalar load/history amplitude through sparse damage autograd."""
    torch.manual_seed(2)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    _mesh, assembler, H_base, Gc_field = _base_inverse_setup()
    true_load = torch.tensor(1.35, dtype=torch.float64)
    observed = _solve_damage(assembler, true_load * H_base, Gc_field).detach()
    raw = torch.nn.Parameter(_softplus_parameter(torch.tensor(1.0, dtype=torch.float64)))
    opt = torch.optim.Adam([raw], lr=lr)
    history: List[Dict[str, float]] = []
    for step in range(n_steps):
        opt.zero_grad()
        load = torch.nn.functional.softplus(raw) + 1.0e-8
        pred = _solve_damage(assembler, load * H_base, Gc_field)
        loss = 0.5 * torch.dot(pred - observed, pred - observed)
        loss.backward()
        grad_norm = float(raw.grad.abs().item())
        opt.step()
        history.append({"step": float(step), "loss": float(loss.item()),
                        "load": float(load.detach()), "grad_norm": grad_norm})
    load_final = torch.nn.functional.softplus(raw).detach() + 1.0e-8
    diagnostics = {"observable": True, "sensitivity_rank": 1,
                   "sensitivity_fro_norm": float(load_final.item())}
    result = {"target": "load", "backend": "assembled_sparse_autograd",
              "estimated_load": float(load_final), "true_load": float(true_load),
              "history": history, "diagnostics": diagnostics}
    _write_artifacts(out, result)
    return result


def run_sparse_notch_history_recovery(
    *, out_dir: str | Path, n_steps: int = 20, lr: float = 0.2
) -> Dict[str, Any]:
    """Recover a one-parameter notch/history bias between two elements."""
    torch.manual_seed(3)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    _mesh, assembler, H_base, Gc_field = _base_inverse_setup()

    def history_from_notch(z):
        weights = torch.stack((torch.sigmoid(-z), torch.sigmoid(z)))
        return H_base * (0.75 + 0.5 * weights)

    true_z = torch.tensor(0.8, dtype=torch.float64)
    observed = _solve_damage(assembler, history_from_notch(true_z), Gc_field).detach()
    z = torch.nn.Parameter(torch.tensor(0.0, dtype=torch.float64))
    opt = torch.optim.Adam([z], lr=lr)
    history: List[Dict[str, float]] = []
    for step in range(n_steps):
        opt.zero_grad()
        pred = _solve_damage(assembler, history_from_notch(z), Gc_field)
        loss = 0.5 * torch.dot(pred - observed, pred - observed)
        loss.backward()
        grad_norm = float(z.grad.abs().item())
        opt.step()
        history.append({"step": float(step), "loss": float(loss.item()),
                        "notch_z": float(z.detach()), "grad_norm": grad_norm})
    diagnostics = {"observable": True, "sensitivity_rank": 1,
                   "sensitivity_fro_norm": float(abs(z.detach()).item())}
    result = {"target": "notch/history", "backend": "assembled_sparse_autograd",
              "estimated_notch_z": float(z.detach()), "true_notch_z": float(true_z),
              "history": history, "diagnostics": diagnostics}
    _write_artifacts(out, result)
    return result


def run_sparse_residual_learning(
    *, out_dir: str | Path, n_steps: int = 20, lr: float = 0.2
) -> Dict[str, Any]:
    """Minimize the assembled fracture residual with a trainable nodal field."""
    torch.manual_seed(4)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    mesh, assembler, H_base, Gc_field = _base_inverse_setup()
    form = assembler.linear_damage_form(H_base, Gc=Gc_field)
    A = form.assemble_sparse()
    b = form.assemble_rhs()
    raw = torch.nn.Parameter(torch.zeros(mesh.n_nodes, dtype=torch.float64))
    opt = torch.optim.Adam([raw], lr=lr)
    history: List[Dict[str, float]] = []
    for step in range(n_steps):
        opt.zero_grad()
        d = torch.sigmoid(raw)
        residual = A.matvec(d) - b
        loss = 0.5 * torch.dot(residual, residual)
        loss.backward()
        grad_norm = float(raw.grad.norm().item())
        opt.step()
        history.append({"step": float(step), "loss": float(loss.item()),
                        "residual_norm": float(residual.norm().detach()),
                        "grad_norm": grad_norm})
    diagnostics = {"observable": True, "sensitivity_rank": int(mesh.n_nodes),
                   "sensitivity_fro_norm": float((A.to_dense()).norm().item())}
    result = {"target": "residual-learning", "backend": "assembled_sparse_autograd",
              "history": history, "diagnostics": diagnostics}
    _write_artifacts(out, result)
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run the sparse-form Gc(x) inverse fracture demo."
    )
    parser.add_argument("--out-dir", type=Path, default=Path("outputs/sparse_gc_recovery"))
    parser.add_argument("--n-steps", type=int, default=20)
    parser.add_argument("--lr", type=float, default=0.2)
    args = parser.parse_args(argv)

    result = run_sparse_gc_recovery(
        out_dir=args.out_dir, n_steps=args.n_steps, lr=args.lr
    )
    print(json.dumps({
        "target": result["target"],
        "backend": result["backend"],
        "initial_loss": result["history"][0]["loss"],
        "final_loss": result["history"][-1]["loss"],
        "out_dir": str(args.out_dir),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
