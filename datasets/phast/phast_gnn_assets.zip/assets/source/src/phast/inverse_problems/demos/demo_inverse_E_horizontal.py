#!/usr/bin/env python
"""Spatial E(x) recovery with a HORIZONTAL stiffness gradation, on the
same Bleyer-PMMA 32 x 16 mm SENT geometry as the stiff-inclusion and
gc_horizontal demos.

The plate, notch, material model, loading, and damping match the
companion demos so all Paper-2 forward simulations share one geometry
and physics setup. The truth heterogeneity here is a vertical stiffer
band in Young's modulus:

    E(x) = E_bulk * (1 + alpha * exp(-(x - x0)^2 / (2 sigma^2)))

A crack propagating from the notch on the left will deflect / slow as
it approaches the stiff band (E maximum at x = x0). This is the
field-level analogue of the discrete particle inclusion in
demo_inverse_stiff_inclusion (which parameterises a single Gaussian
bump rather than a continuous band).

Boundary effects
----------------
The plate is 32 x 16 mm; the truth band sits at x0 = 16 mm with
sigma = 2 mm, so the crack feels the gradient between roughly x = 12
and x = 20. Wave round-trip time on this plate is ~33 us
(c_p ~ 1.7 mm/us, 2*W = 64 mm). With Kelvin-Voigt damping zeta = 0.1
each reflection is attenuated by a factor of 2-3, so by the end of the
default n_steps = 9000 (~660 us simulated) the cumulative reflected
energy is small relative to the crack-driven damage signal --
matching the validated B1-B4 setups in the paper. The truth and
recovered damage fields are compared with the same boundary noise,
so the inversion is self-consistent.

Invertibility
-------------
Two parameter modes are supported:

  --param low_rank   : 3-parameter truth (x0, sigma, alpha).
                       Recover (x0, log sigma) by L-BFGS; alpha held
                       at truth. Loss surface is smooth in the
                       band-centre coordinate.
  --param full_field : per-element E, k = n_elem unknowns. Strict
                       autograd headline; FD is infeasible.

Either mode supports --forward_only and --save_snapshots N for the
validation-style snapshot+tip telemetry stored in truth.npz.
"""
from __future__ import annotations
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.mesh_generator import rectangular_sent as gen_mesh
from phast.mesh import FEMMesh
from phast.material import create_material
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.config import LoadingConfig, compute_load_factor
from phast.device import DeviceContext


# Bleyer PMMA constants (shared with inclusion demos).
NU = 0.35
RHO = 1.18e-9          # tonne/mm^3
GC = 0.3               # N/mm
L0 = 0.1               # mm
E_BULK = 3090.0        # MPa = 3.09 GPa

# Plate geometry (shared).
W, H, A = 32.0, 16.0, 4.0
CRACK_Y = H / 2.0      # = 8 mm

# Horizontal-band defaults.
DEFAULT_X0 = 16.0
DEFAULT_SIGMA = 2.0
DEFAULT_ALPHA = 0.5      # 50% stiffer at the band centre


def horizontal_E_band_field(centroids, x0, sigma, alpha,
                            E_nominal=E_BULK):
    """Per-element E with a vertical stiff band centred at x = x0.

    E_e = E_nominal * (1 + alpha * exp(-(x_c - x0)^2 / (2 sigma^2)))

    alpha > 0 produces a stiffer band (crack approaches and deflects
    or slows). Note the SIGN flip relative to the gc_horizontal
    weak-band parametrisation.
    """
    x_c = centroids[:, 0]
    bump = torch.exp(-((x_c - x0) ** 2) / (2.0 * sigma ** 2))
    return E_nominal * (1.0 + alpha * bump)


def build_sent_mesh(h_crack, h_coarse, device, dtype):
    """Bleyer-scale 32 x 16 mm SENT mesh shared with the inclusion demo."""
    # Per-process scratch path so concurrent jobs sharing /tmp on the
    # same node do not race on the same .msh file.
    _tag = os.environ.get('SLURM_JOB_ID', f'pid{os.getpid()}')
    msh = f"/tmp/E_horizontal_bleyer_{_tag}.msh"
    gen_mesh(msh, W=W, H=H, a=A, l0=L0,
             h_crack=h_crack, h_coarse=h_coarse, branching=True)
    mesh = FEMMesh(msh, device=device, dtype=dtype)
    mesh.identify_boundaries()
    return mesh, msh


def build_solver(mesh, dU, tau_ramp, damping_zeta, device, dtype,
                 softmax_H_beta=None, H_update_method='hard_max',
                 H_update_scale=None):
    mat = create_material(
        E=E_BULK, nu=NU, rho=RHO, Gc=GC, l0=L0,
        energy_split='amor', pf_model='AT1', plane_stress=True,
        gamma_correction=True,
    )
    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)
    bcs.add(mesh.node_sets['top'],    component=1, value=+dU)
    bcs.add(mesh.node_sets['bottom'], component=1, value=-dU)
    bcs.fix(mesh.node_sets['left'], component=0)
    cfg = SolverConfig(
        solver_type='explicit', differentiable=True,
        damage_every=1, preconditioner='jacobi',
        damping_ratio_max=damping_zeta,
        softmax_H_beta=softmax_H_beta,
        H_update_method=H_update_method,
        H_update_scale=H_update_scale,
    )
    return StaggeredSolver(mesh, mat, bcs, config=cfg,
                            ctx=DeviceContext(device, dtype))


def reaction_force_y(solver, u, d, top_idx):
    """Differentiable summed top-boundary reaction force."""
    f_int = solver.fem.internal_force(u, d)
    return f_int[top_idx, 1].sum()


def run_forward(solver, loading, E_field, n_steps, snapshot_steps=None,
                checkpoint_chunks=0, detach_snapshots=True,
                load_steps=None, top_idx=None):
    """Forward run with optional damage snapshots for validation telemetry.

    Snaps in this demo are detached (numpy) and only used outside the
    closure for telemetry — so checkpointing doesn't need to thread them
    back into the graph. When ``checkpoint_chunks > 0`` and a backward
    is required, time loop is split into N segments via
    ``torch.utils.checkpoint``.
    """
    n_nodes = solver.mesh.n_nodes
    n_elem = solver.mesh.n_elems
    dt = solver.dtype
    dev = solver.device
    solver.u = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.v = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.a = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.d = torch.zeros(n_nodes, dtype=dt, device=dev)
    solver.H_elem = torch.zeros(n_elem, dtype=dt, device=dev)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dt, device=dev)
    solver._step_count = 0
    solver.install_diff_E_field(E_field)
    snap_set = set(snapshot_steps) if snapshot_steps else set()
    load_set = set(load_steps) if load_steps else set()
    snaps = [] if snapshot_steps else None
    loads = [] if load_steps else None
    solver_dt = solver.dt

    use_checkpoint = (
        checkpoint_chunks > 0 and torch.is_grad_enabled()
        and E_field.requires_grad
    )
    if use_checkpoint and load_steps:
        raise RuntimeError(
            "--obs_mode load_disp currently requires full-BPTT without "
            "checkpoint_chunks so reaction samples stay on tape.")
    _progress_every = max(1, min(n_steps // 20, 1000))
    _t_loop_start = time.time()
    if not use_checkpoint:
        for step in range(n_steps):
            solver.bcs.load_factor = compute_load_factor(
                step, solver_dt, loading)
            solver.step_full()
            if step + 1 in snap_set:
                if detach_snapshots:
                    snap = solver.d.detach().cpu().numpy().copy()
                else:
                    snap = solver.d
                snaps.append((step + 1, snap))
            if step + 1 in load_set:
                loads.append(reaction_force_y(
                    solver, solver.u, solver.d, top_idx))
            if (step + 1) % _progress_every == 0:
                print(f"    forward step {step+1}/{n_steps} "
                      f"max(d)={float(solver.d.max()):.3f} "
                      f"({time.time() - _t_loop_start:.1f}s elapsed)",
                      flush=True)
        return solver.d, snaps, loads

    def _chunk(u_in, v_in, a_in, d_in, He_in, Hn_in,
               base_step, k_steps):
        solver.u = u_in
        solver.v = v_in
        solver.a = a_in
        solver.d = d_in
        solver.H_elem = He_in
        solver.H_nodal = Hn_in
        solver._step_count = base_step
        for j in range(k_steps):
            step = base_step + j
            solver.bcs.load_factor = compute_load_factor(
                step, solver_dt, loading)
            solver.step_full()
        return (solver.u, solver.v, solver.a, solver.d,
                solver.H_elem, solver.H_nodal)

    chunk_size = (n_steps + checkpoint_chunks - 1) // checkpoint_chunks
    u, v, a, d = solver.u, solver.v, solver.a, solver.d
    He, Hn = solver.H_elem, solver.H_nodal
    n_total_chunks = (n_steps + chunk_size - 1) // chunk_size
    chunk_progress_every = max(1, n_total_chunks // 20)
    _chunk_idx = 0
    base = 0
    while base < n_steps:
        k = min(chunk_size, n_steps - base)
        u, v, a, d, He, Hn = torch.utils.checkpoint.checkpoint(
            _chunk, u, v, a, d, He, Hn, base, k,
            use_reentrant=False,
        )
        _chunk_idx += 1
        if (_chunk_idx % chunk_progress_every == 0
                or _chunk_idx == n_total_chunks):
            print(f"    forward chunk {_chunk_idx}/{n_total_chunks} "
                  f"(step {base + k}/{n_steps}, "
                  f"max(d)={float(d.detach().max()):.3f}, "
                  f"{time.time() - _t_loop_start:.1f}s elapsed)",
                  flush=True)
        # Detached telemetry snaps inside the chunk window are dropped
        # under checkpointing; snap collection in this mode requires a
        # post-hoc forward pass (see truth pass which runs in no_grad).
        base += k

    solver.u = u
    solver.v = v
    solver.a = a
    solver.d = d
    solver.H_elem = He
    solver.H_nodal = Hn
    return solver.d, snaps, loads


def differentiable_crack_path(d_node, node_x, node_y, x_bins,
                                 sigma_bin, p=4):
    """Soft-binned damage-weighted centerline y(x), differentiable.

    Mirrors the function of the same name in
    demos/demo_inverse_stiff_inclusion.py. Kept local rather than
    factored out to keep this demo self-contained.

    For each bin centre x_b:
        y_b = sum_n w_n * y_n / sum_n w_n
    with w_n(x_b) = d_n^p * exp(-(x_n - x_b)^2 / (2 sigma_bin^2)).

    Returns ``(y_pred, mass)``: the centerline at each bin and the
    total weight per bin (used to mask empty bins).
    """
    diff = node_x.unsqueeze(0) - x_bins.unsqueeze(1)
    spatial_w = torch.exp(-(diff ** 2) / (2.0 * sigma_bin ** 2))
    damage_w = torch.clamp(d_node, min=0.0).pow(p)
    w = spatial_w * damage_w.unsqueeze(0)
    mass = w.sum(dim=1)
    y_w = (w * node_y.unsqueeze(0)).sum(dim=1)
    y_pred = y_w / (mass + 1e-12)
    return y_pred, mass


def soft_tip_x_np(d_node, node_x_np, p=8):
    w = np.maximum(d_node, 0.0) ** p
    s = w.sum()
    return float((w * node_x_np).sum() / (s + 1e-12)) if s > 0 else 0.0


def crack_extent_features(d_node, node_x, node_y, crack_y,
                          width, sigma_y=2.0, p=4):
    """Compressed crack-speed observable for horizontal material bands."""
    d_pos = torch.clamp(d_node, min=0.0, max=1.0)
    y_w = torch.exp(-((node_y - crack_y) ** 2) / (2.0 * sigma_y ** 2))
    w = y_w * d_pos.pow(p)
    w_sum = w.sum()
    soft_tip = (w * node_x).sum() / (w_sum + 1e-12)
    damage_mass = (y_w * d_pos).sum() / (y_w.sum() + 1e-12)
    return torch.stack((soft_tip / width, damage_mass))


def crack_extent_series(snaps, node_x, node_y, crack_y, width, sigma_y):
    return torch.stack([
        crack_extent_features(s, node_x, node_y, crack_y, width, sigma_y)
        for s in snaps
    ])


def crack_arrival_observable(snaps, step_ids, node_x, node_y, x_bins,
                             sigma_x, crack_y, sigma_y,
                             threshold=0.2, beta=40.0):
    """Soft first-arrival and activation history along the crack corridor."""
    diff_x = node_x.unsqueeze(0) - x_bins.unsqueeze(1)
    wx = torch.exp(-(diff_x ** 2) / (2.0 * sigma_x ** 2))
    wy = torch.exp(-((node_y - crack_y) ** 2) / (2.0 * sigma_y ** 2))
    denom = (wx * wy.unsqueeze(0)).sum(dim=1).clamp_min(1e-12)

    activity = []
    for d in snaps:
        d_pos = torch.clamp(d, min=0.0, max=1.0)
        activity.append((wx * (wy * d_pos).unsqueeze(0)).sum(dim=1) / denom)
    activity = torch.stack(activity, dim=0)

    crossed = torch.sigmoid(beta * (activity - threshold))
    survival = torch.cumprod(
        torch.cat([
            torch.ones_like(crossed[:1]),
            1.0 - crossed[:-1] + 1e-6,
        ], dim=0),
        dim=0,
    )
    first_w = crossed * survival
    steps = torch.as_tensor(step_ids, dtype=node_x.dtype, device=node_x.device)
    steps = steps / steps[-1].clamp_min(1.0)
    arrival = (first_w * steps[:, None]).sum(dim=0) / (
        first_w.sum(dim=0) + 1e-8)
    arrival = torch.where(first_w.sum(dim=0) < 1e-5,
                          torch.ones_like(arrival), arrival)
    return arrival, activity


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device', type=str, default='cpu')
    p.add_argument('--dtype', type=str, default='float64',
                   choices=['float32', 'float64'],
                   help='Halve activation memory on CUDA with float32. '
                        'CPU/MPS still need float64. For inversion '
                        'gradient quality, prefer float64 + '
                        '--checkpoint_chunks.')
    p.add_argument('--checkpoint_chunks', type=int, default=0,
                   help='Split time loop into N gradient-checkpoint segments. '
                        '0 disables. Memory drops ~N, backward ~2x slower.')
    p.add_argument('--tbptt_chunk_size', type=int, default=0,
                   help='Truncated-BPTT chunk length (issue #288 / #301). '
                        '0 disables (default; full autograd graph). '
                        'When > 0, the n_steps explicit-dynamics loop is '
                        'split into chunks of this length; per-chunk damage '
                        'MSE-against-truth is the loss, biased gradient.')
    p.add_argument('--time_weight_lambda', type=float, default=0.0,
                   help='Exponential snapshot down-weighting (issue '
                        '#475). Per-snapshot residual is multiplied by '
                        'exp(-lambda * t/T) where T=max(snapshot_steps). '
                        'Default 0.0 = uniform = byte-identical legacy.')
    p.add_argument('--smoke', action='store_true')
    p.add_argument('--mid', action='store_true',
                   help='h_crack=0.1, n_steps=4500 (~5-10 min on Mac CPU)')
    p.add_argument('--h_crack', type=float, default=None)
    p.add_argument('--h_coarse', type=float, default=None)
    p.add_argument('--n_steps', type=int, default=None)
    p.add_argument('--n_iters', type=int, default=10)
    p.add_argument('--optimizer', type=str, default='lbfgs',
                   choices=['lbfgs', 'adam'],
                   help='Optimizer for inverse parameters. Adam is useful '
                        'for smoke-scale full-field objectives whose raw '
                        'adjoint gradients are too large for L-BFGS.')
    p.add_argument('--optimizer_lr', type=float, default=None,
                   help='Override optimizer learning rate. Defaults: '
                        '0.3 for L-BFGS, 0.02 for Adam.')
    p.add_argument('--grad_clip_norm', type=float, default=None,
                   help='If set, clip inverse-parameter gradient norm after '
                        'backward and before the optimizer step.')
    p.add_argument('--delta_U', type=float, default=5e-2)
    p.add_argument('--tau_ramp_us', type=float, default=30.0)
    p.add_argument('--damping_zeta', type=float, default=0.1)
    p.add_argument('--softmax_H_beta', type=float, default=None,
                   help='Use differentiable softplus/softmax smoothing '
                        'for the irreversible history update H=max(H,psi+). '
                        'Default None keeps the hard max update.')
    p.add_argument('--H_update_method', type=str, default='hard_max',
                   choices=['hard_max', 'softmax', 'smooth_max',
                            'log_smooth', 'custom_subgrad'],
                   help='History update operator. Use custom_subgrad first '
                        'for inverse reruns; hard_max is a control.')
    p.add_argument('--H_update_scale', type=float, default=None,
                   help='Backward sigmoid scale for custom_subgrad. Default '
                        'uses the solver production scale.')
    p.add_argument('--x0_truth', type=float, default=DEFAULT_X0)
    p.add_argument('--sigma_truth', type=float, default=DEFAULT_SIGMA)
    p.add_argument('--alpha_truth', type=float, default=DEFAULT_ALPHA)
    p.add_argument('--param', type=str, default='low_rank',
                   choices=['low_rank', 'full_field'])
    p.add_argument('--recover', type=str, default='x0_sigma',
                   choices=['x0_sigma', 'x0'],
                   help='Low-rank recovery subset. x0_sigma recovers '
                        '(x0, log sigma); x0 keeps sigma fixed at '
                        '--sigma_init and recovers only the band centre.')
    p.add_argument('--obs_mode', type=str, default='full',
                   choices=['full', 'path', 'extent', 'arrival',
                            'arrival_dic', 'load_disp',
                            'load_displacement'],
                   help='full = MSE on final damage field; '
                        'path = damage-weighted crack centerline y(x), '
                        'truth-mass-weighted on a fixed x-grid '
                        '(differentiable, n_path_bins samples); '
                        'extent = multi-time soft crack-front x and '
                        'near-crack damage mass; '
                        'arrival/arrival_dic = multi-time soft crack-front '
                        'arrival plus local activation history; '
                        'load_disp/load_displacement = normalised MSE on '
                        'sampled top-boundary reaction force.')
    p.add_argument('--n_path_bins', type=int, default=40,
                   help='Number of x-bins for --obs_mode path.')
    p.add_argument('--path_sigma_factor', type=float, default=0.6,
                   help='Bin width as a fraction of inter-bin spacing.')
    p.add_argument('--extent_sigma_y', type=float, default=2.0,
                   help='Gaussian y-window width in mm for --obs_mode extent.')
    p.add_argument('--arrival_threshold', type=float, default=0.2,
                   help='Damage threshold for the soft first-arrival '
                        'observable.')
    p.add_argument('--arrival_beta', type=float, default=40.0,
                   help='Sigmoid sharpness for the soft first-arrival '
                        'observable.')
    p.add_argument('--arrival_activity_weight', type=float, default=0.25,
                   help='Relative weight on the full activation-history term '
                        'for --obs_mode arrival/arrival_dic.')
    p.add_argument('--n_load_samples', type=int, default=24,
                   help='Number of reaction-force samples for '
                        '--obs_mode load_disp/load_displacement.')
    p.add_argument('--x0_init', type=float, default=None)
    p.add_argument('--sigma_init', type=float, default=None)
    p.add_argument('--observability_gate', action='store_true',
                   help='Run the finite-difference observability gate at '
                        'the initial low-rank parameters and exit before '
                        'optimisation. Reports dO/dtheta column norms, '
                        'conditioning, descent direction, and line probe.')
    p.add_argument('--gate_alphas', type=str,
                   default='0.0,0.25,0.5,0.75,1.0',
                   help='Comma-separated init-to-truth alphas for '
                        '--observability_gate.')
    p.add_argument('--gate_fd_rel_step', type=float, default=1e-3,
                   help='Relative central-difference step for the '
                        '--observability_gate Jacobian.')
    p.add_argument('--save_snapshots', type=int, default=0)
    p.add_argument('--forward_only', action='store_true')
    p.add_argument('--resume', action='store_true',
                   help='If --output_dir contains inv_checkpoint.pt and '
                        'truth.npz from a previous run, skip the truth pass '
                        'and continue L-BFGS from the saved iterate.')
    p.add_argument('--output_dir', type=str, default='results_E_horizontal')
    p.add_argument('--save_forward_viz', dest='save_forward_viz',
                   action='store_true', default=True,
                   help='Before L-BFGS, save truth/init '
                        'damage_final.png + damage_evolution.gif so '
                        'the user can sanity-check the forward setup '
                        'before committing to a long inversion '
                        '(default: enabled).')
    p.add_argument('--no_save_forward_viz', dest='save_forward_viz',
                   action='store_false',
                   help='Disable pre-inversion forward-viz '
                        '(saves one extra forward pass at init).')
    p.add_argument('--n_viz_frames', type=int, default=20,
                   help='Frames in <label>_damage_evolution.gif '
                        '(default 20).')
    args = p.parse_args()
    if args.obs_mode == 'load_displacement':
        args.obs_mode = 'load_disp'
    if args.obs_mode == 'load_disp' and args.tbptt_chunk_size > 0:
        raise RuntimeError(
            "--obs_mode load_disp currently requires full-BPTT; "
            "set --tbptt_chunk_size 0.")

    if args.smoke:
        h_crack  = args.h_crack  if args.h_crack  is not None else 0.4
        h_coarse = args.h_coarse if args.h_coarse is not None else 2.0
        n_steps  = args.n_steps  if args.n_steps  is not None else 2500
    elif args.mid:
        h_crack  = args.h_crack  if args.h_crack  is not None else 0.1
        h_coarse = args.h_coarse if args.h_coarse is not None else 0.8
        n_steps  = args.n_steps  if args.n_steps  is not None else 4500
    else:
        h_crack  = args.h_crack  if args.h_crack  is not None else 0.05
        h_coarse = args.h_coarse if args.h_coarse is not None else 0.5
        n_steps  = args.n_steps  if args.n_steps  is not None else 9000

    out_dir = (args.output_dir if os.path.isabs(args.output_dir)
               else os.path.join(THIS_DIR, args.output_dir))
    os.makedirs(out_dir, exist_ok=True)

    device = args.device
    dtype = torch.float32 if args.dtype == 'float32' else torch.float64
    tau_ramp = args.tau_ramp_us * 1e-6

    print("=" * 72)
    print("  Horizontal E(x) recovery on Bleyer-PMMA 32 x 16 mm SENT")
    print("=" * 72)
    print(f"  Plate: {W} x {H} mm, notch a = {A} mm, crack axis y = {CRACK_Y}")
    print(f"  Truth band: x0 = {args.x0_truth} mm, sigma = {args.sigma_truth} mm,"
          f" alpha_truth = {args.alpha_truth}")
    print(f"  param mode: {args.param}; obs mode: {args.obs_mode}")
    print(f"  Loading: smooth-cosine ramp tau_ramp = {args.tau_ramp_us} us, "
          f"delta_U = {args.delta_U} mm")
    print(f"  Damping: zeta_max = {args.damping_zeta}")
    print(f"  Mesh:  h_crack = {h_crack}, h_coarse = {h_coarse}; "
          f"n_steps = {n_steps}, device = {device}")

    mesh, msh_path = build_sent_mesh(h_crack, h_coarse, device, dtype)
    solver = build_solver(mesh, args.delta_U, tau_ramp,
                            args.damping_zeta, device, dtype,
                            softmax_H_beta=args.softmax_H_beta,
                            H_update_method=args.H_update_method,
                            H_update_scale=args.H_update_scale)
    centroids = mesh.nodes[mesh.elements].mean(dim=1)
    n_elem = mesh.n_elems
    n_nodes = mesh.n_nodes
    loading = LoadingConfig(ramp_type='smooth', t_ramp=tau_ramp)
    print(f"  Mesh: {n_nodes} nodes, {n_elem} elements")
    print(f"  dt = {solver.dt:.3e} s; total simulated = "
          f"{solver.dt * n_steps * 1e6:.1f} us")
    snap_count = max(
        args.save_snapshots,
        12 if args.obs_mode in ('extent', 'arrival', 'arrival_dic') else 0,
        args.n_viz_frames if args.save_forward_viz else 0,
    )
    if snap_count > 0:
        snap_steps = list(np.linspace(max(int(0.05 * n_steps), 1),
                                        n_steps,
                                        snap_count,
                                        dtype=int).tolist())
        print(f"  Snapshots: {len(snap_steps)} times "
              f"({snap_steps[0]} ... {snap_steps[-1]})")
    else:
        snap_steps = None

    node_x_np = mesh.nodes[:, 0].cpu().numpy()
    node_x = mesh.nodes[:, 0]
    node_y = mesh.nodes[:, 1]

    if args.obs_mode == 'load_disp':
        first = max(int(0.10 * n_steps), 1)
        load_steps = list(np.linspace(first, n_steps, args.n_load_samples,
                                      dtype=int).tolist())
        top_idx = mesh.node_sets['top']
        print(f"  Load samples: {len(load_steps)} reaction-force samples "
              f"({load_steps[0]} ... {load_steps[-1]})")
    else:
        load_steps = None
        top_idx = None

    # Path-mode bin grid (constant for both truth and all closure forwards).
    if args.obs_mode in ('path', 'arrival', 'arrival_dic'):
        x_bins = torch.linspace(A, W, args.n_path_bins,
                                  dtype=dtype, device=device)
        bin_dx = float(x_bins[1] - x_bins[0])
        path_sigma = args.path_sigma_factor * bin_dx
        print(f"  Path/arrival bins: {args.n_path_bins} from x={A} to x={W}, "
              f"sigma_bin = {path_sigma:.3f} mm")
    else:
        x_bins = None
        path_sigma = None

    # --- Truth (or resume from cached truth) ---
    truth_npz_path = os.path.join(out_dir, 'truth.npz')
    ckpt_path = os.path.join(out_dir, 'inv_checkpoint.pt')
    truth_cached = args.resume and os.path.exists(truth_npz_path)
    inv_resume = args.resume and os.path.exists(ckpt_path)
    resume_active = truth_cached  # legacy alias for truth-cache reuse

    if truth_cached:
        print(f"\n[1/3] Resuming from existing truth cache ...")
        z = np.load(truth_npz_path, allow_pickle=True)
        target = torch.tensor(z['d_target'], dtype=dtype, device=device)
        truth_key = 'E_true' if 'E_true' in z.files else 'Gc_true'
        E_true = torch.tensor(z[truth_key], dtype=dtype, device=device)
        if args.obs_mode == 'load_disp' and 'load_steps' in z.files:
            load_steps = [int(v) for v in z['load_steps'].tolist()]
        # Reload cached snapshots (saved by the non-resume branch) so
        # forward-viz can rebuild the truth gif without re-running the
        # truth forward.
        if 'snapshots' in z.files and 'snapshot_steps' in z.files:
            snap_d_arr = z['snapshots']
            snap_steps_arr = z['snapshot_steps']
            snaps_truth = [(int(s), snap_d_arr[i])
                           for i, s in enumerate(snap_steps_arr)]
        else:
            snaps_truth = []
        print(f"  reloaded truth: max(d)={target.max():.3f}, "
              f"#d>0.5={(target>0.5).sum().item()}", flush=True)
    else:
        if args.resume:
            print(f"  --resume requested but {truth_npz_path} missing; "
                  "running fresh truth pass.",
                  flush=True)
        print(f"\n[1/{'2' if args.forward_only else '3'}] Forward at truth ...")
        t0 = time.time()
        with torch.no_grad():
            E_true = horizontal_E_band_field(
                centroids,
                torch.tensor(args.x0_truth,        dtype=dtype, device=device),
                torch.tensor(args.sigma_truth,     dtype=dtype, device=device),
                torch.tensor(args.alpha_truth,   dtype=dtype, device=device),
            )
            target, snaps_truth, loads_truth = run_forward(
                solver, loading, E_true, n_steps,
                snapshot_steps=snap_steps,
                load_steps=load_steps if args.obs_mode == 'load_disp' else None,
                top_idx=top_idx if args.obs_mode == 'load_disp' else None)
            target = target.detach().clone()
        print(f"  Truth: max(d) = {target.max():.3f}, "
              f"#d>0.5 = {(target>0.5).sum().item()}, "
              f"E range [{E_true.min():.4e}, {E_true.max():.4e}], "
              f"{time.time()-t0:.1f} s")

    # Path-mode: pre-compute the truth path and per-bin mass once so
    # the closure doesn't redo it every forward.
    if args.obs_mode == 'path':
        with torch.no_grad():
            y_target_path, mass_target_path = differentiable_crack_path(
                target, node_x, node_y, x_bins, path_sigma, p=4)
        keep = mass_target_path > mass_target_path.max() * 0.05
        if keep.any():
            print(f"  Truth path y(x) range over significant-mass bins: "
                  f"y_min={y_target_path[keep].min():.3f}, "
                  f"y_max={y_target_path[keep].max():.3f} mm "
                  f"({int(keep.sum())} of {args.n_path_bins} bins)")
        else:
            print("  WARNING: truth path has no significant-mass bins; "
                  "the crack may not have propagated.")
    else:
        y_target_path = None
        mass_target_path = None

    if args.obs_mode == 'extent':
        if not snaps_truth:
            raise RuntimeError("--obs_mode extent requires truth snapshots.")
        with torch.no_grad():
            extent_target = crack_extent_series(
                [torch.tensor(s[1], dtype=dtype, device=device)
                 if not torch.is_tensor(s[1]) else s[1]
                 for s in snaps_truth],
                node_x, node_y, CRACK_Y, W, args.extent_sigma_y).detach()
        print("  Truth extent features (tip/W, mass): "
              + ", ".join(
                  f"({float(v[0]):.3f},{float(v[1]):.3e})"
                  for v in extent_target))
    else:
        extent_target = None

    if args.obs_mode in ('arrival', 'arrival_dic'):
        if not snaps_truth:
            raise RuntimeError("--obs_mode arrival requires truth snapshots.")
        with torch.no_grad():
            arrival_target, activity_target = crack_arrival_observable(
                [torch.tensor(s[1], dtype=dtype, device=device)
                 if not torch.is_tensor(s[1]) else s[1]
                 for s in snaps_truth],
                [int(s[0]) for s in snaps_truth],
                node_x, node_y, x_bins, path_sigma, CRACK_Y,
                args.extent_sigma_y,
                threshold=args.arrival_threshold,
                beta=args.arrival_beta)
            arrival_target = arrival_target.detach()
            activity_target = activity_target.detach()
        print("  Truth arrival range: "
              f"{float(arrival_target.min()):.3f} ... "
              f"{float(arrival_target.max()):.3f}; "
              f"activity max={float(activity_target.max()):.3f}")
    else:
        arrival_target = None
        activity_target = None

    if args.obs_mode == 'load_disp':
        if truth_cached and 'load_reaction_y' in z.files:
            load_target = torch.tensor(z['load_reaction_y'],
                                       dtype=dtype, device=device)
        elif truth_cached:
            raise RuntimeError(
                "--resume with --obs_mode load_disp requires cached "
                "load_reaction_y in truth.npz.")
        else:
            load_target = torch.stack(loads_truth).detach()
        scale = load_target.abs().max() + 1e-12
        print("  Truth load reaction samples: "
              f"min={float(load_target.min()):.4e}, "
              f"max={float(load_target.max()):.4e}, "
              f"scale={float(scale):.4e}")
    else:
        load_target = None

    truth_save = {
        'nodes':         mesh.nodes.cpu().numpy(),
        'elements':      mesh.elements.cpu().numpy(),
        'centroids':     centroids.cpu().numpy(),
        'd_target':      target.cpu().numpy(),
        'E_true':        E_true.cpu().numpy(),
        'x0_truth':      args.x0_truth,
        'sigma_truth':   args.sigma_truth,
        'alpha_truth': args.alpha_truth,
        'W':             W,
        'H':             H,
        'a':             A,
        'n_steps':       n_steps,
        'dt':            solver.dt,
        'delta_U':       args.delta_U,
        'tau_ramp_us':   args.tau_ramp_us,
        'damping_zeta':  args.damping_zeta,
        'param_mode':    args.param,
    }
    if snaps_truth is not None and len(snaps_truth) > 0:
        snap_steps_arr = np.array([s[0] for s in snaps_truth])
        snap_d = np.stack([s[1] for s in snaps_truth])
        truth_save['snapshot_steps'] = snap_steps_arr
        truth_save['snapshots']      = snap_d
        truth_save['snapshot_t_us']  = snap_steps_arr * solver.dt * 1e6
        tip_traj = np.array([soft_tip_x_np(s, node_x_np) for s in snap_d])
        truth_save['tip_x_truth'] = tip_traj
    if args.obs_mode == 'load_disp' and load_target is not None:
        truth_save['load_steps'] = np.array(load_steps, dtype=np.int64)
        truth_save['load_t_us'] = (
            np.array(load_steps, dtype=np.float64) * solver.dt * 1e6)
        truth_save['load_reaction_y'] = load_target.detach().cpu().numpy()
    if not resume_active:
        np.savez(os.path.join(out_dir, 'truth.npz'), **truth_save)
        if os.path.exists(msh_path):
            import shutil as _sh
            _sh.copyfile(msh_path, os.path.join(out_dir, 'mesh.msh'))
        print(f"  Truth saved -> {out_dir}/truth.npz")

    # --- Pre-inversion forward visualisation (truth) ---
    if args.save_forward_viz:
        try:
            from inverse_problems._viz import save_forward_viz
            snap_arrays = ([s[1] for s in snaps_truth]
                           if snaps_truth else None)
            snap_step_idx = ([s[0] for s in snaps_truth]
                             if snaps_truth else None)
            paths = save_forward_viz(
                mesh.nodes, mesh.elements, target, out_dir,
                label='truth', snapshots=snap_arrays,
                snap_steps=snap_step_idx, n_steps_total=n_steps,
            )
            print(f"  [forward-viz] truth png -> {paths['png']}")
            if paths['gif']:
                print(f"  [forward-viz] truth gif -> {paths['gif']}")
        except Exception as exc:
            print(f"  [forward-viz] truth viz failed: {exc}")

    # --- Pre-inversion forward visualisation (init guess) ---
    if args.save_forward_viz and not args.forward_only:
        x0_init_v = (args.x0_init if args.x0_init is not None
                     else args.x0_truth + 1.5)
        sigma_init_v = (args.sigma_init if args.sigma_init is not None
                        else 1.0)
        print(f"\n[1b] Forward at init guess "
              f"(x0={x0_init_v}, sigma={sigma_init_v}, "
              f"{n_steps} steps, no_grad) for forward-viz ...")
        t0_init = time.time()
        try:
            with torch.no_grad():
                E_init_field = horizontal_E_band_field(
                    centroids,
                    torch.tensor(x0_init_v, dtype=dtype, device=device),
                    torch.tensor(sigma_init_v, dtype=dtype, device=device),
                    torch.tensor(args.alpha_truth, dtype=dtype, device=device),
                )
                d_init_full, snaps_init, _ = run_forward(
                    solver, loading, E_init_field, n_steps,
                    snapshot_steps=snap_steps)
                d_init_full = d_init_full.detach().clone()
            print(f"  Init forward done in {time.time()-t0_init:.1f}s, "
                  f"max(d)={d_init_full.max().item():.3f}, "
                  f"#d>0.5={(d_init_full>0.5).sum().item()}")
            from inverse_problems._viz import save_forward_viz
            init_arrays = ([s[1] for s in snaps_init]
                           if snaps_init else None)
            init_step_idx = ([s[0] for s in snaps_init]
                             if snaps_init else None)
            paths_i = save_forward_viz(
                mesh.nodes, mesh.elements, d_init_full, out_dir,
                label='init', snapshots=init_arrays,
                snap_steps=init_step_idx, n_steps_total=n_steps,
            )
            print(f"  [forward-viz] init png -> {paths_i['png']}")
            if paths_i['gif']:
                print(f"  [forward-viz] init gif -> {paths_i['gif']}")
        except Exception as exc:
            print(f"  [forward-viz] init forward/viz failed: {exc}")

    if args.forward_only:
        print("\n--forward_only set; skipping inversion.")
        return

    # --- TBPTT setup (issue #301) ---
    tbptt_chunk_steps = None
    d_target_tbptt_chunks = None
    if args.tbptt_chunk_size > 0:
        if args.obs_mode != 'full':
            raise SystemExit(
                "--tbptt_chunk_size > 0 requires --obs_mode full. "
                "path/extent-mode TBPTT is not implemented in this demo.")
        if args.checkpoint_chunks > 0:
            raise SystemExit(
                "--tbptt_chunk_size and --checkpoint_chunks are "
                "mutually exclusive paths.")
        cs = int(args.tbptt_chunk_size)
        tbptt_chunk_steps = list(range(cs, n_steps, cs))
        if not tbptt_chunk_steps or tbptt_chunk_steps[-1] != n_steps:
            tbptt_chunk_steps.append(n_steps)
        print(f"\n[TBPTT #301] enabled: chunk_size={cs}, "
              f"{len(tbptt_chunk_steps)} chunks")
        from phast.inverse_problems._tbptt import (
            run_forward_tbptt_generic, make_install_E_field)
        with torch.no_grad():
            _, truth_chunk_snaps, truth_chunk_steps_chk, _ = (
                run_forward_tbptt_generic(
                    solver, loading,
                    install_fn=make_install_E_field(E_true),
                    n_steps=n_steps,
                    tbptt_chunk_size=cs))
            d_target_tbptt_chunks = [s.detach().clone()
                                      for s in truth_chunk_snaps]
        assert truth_chunk_steps_chk == tbptt_chunk_steps

    # --- Inversion ---
    history = {'iter': [], 'loss': [], 'wall_s': []}

    def _compute_loss(d_pred, snaps_pred=None, loads_pred=None):
        """Loss selector for damage, path, arrival, and load observables."""
        if args.obs_mode == 'path':
            y_pred_path, _ = differentiable_crack_path(
                d_pred, node_x, node_y, x_bins, path_sigma, p=4)
            sq = (y_pred_path - y_target_path) ** 2
            return (mass_target_path * sq).sum() / (
                mass_target_path.sum() + 1e-12)
        if args.obs_mode == 'extent':
            if snaps_pred is None:
                raise RuntimeError("extent loss requires differentiable snapshots.")
            extent_pred = crack_extent_series(
                [s[1] for s in snaps_pred],
                node_x, node_y, CRACK_Y, W, args.extent_sigma_y)
            scale = torch.tensor([1.0, 0.05], dtype=dtype, device=device)
            return (((extent_pred - extent_target) / scale) ** 2).mean()
        if args.obs_mode in ('arrival', 'arrival_dic'):
            if snaps_pred is None:
                raise RuntimeError(
                    "arrival loss requires differentiable snapshots.")
            arrival_pred, activity_pred = crack_arrival_observable(
                [s[1] for s in snaps_pred],
                [int(s[0]) for s in snaps_pred],
                node_x, node_y, x_bins, path_sigma, CRACK_Y,
                args.extent_sigma_y,
                threshold=args.arrival_threshold,
                beta=args.arrival_beta)
            arrival_loss = ((arrival_pred - arrival_target) ** 2).mean()
            activity_loss = ((activity_pred - activity_target) ** 2).mean()
            return arrival_loss + args.arrival_activity_weight * activity_loss
        if args.obs_mode == 'load_disp':
            if loads_pred is None:
                raise RuntimeError("load_disp loss requires reaction samples.")
            loads_pred_t = torch.stack(loads_pred)
            scale = load_target.abs().max() + 1e-12
            return (((loads_pred_t - load_target) / scale) ** 2).mean()
        return ((d_pred - target) ** 2).mean()

    def _observation_residual(d_pred, snaps_pred=None, loads_pred=None):
        """Vector residual used by the observability gate."""
        if args.obs_mode == 'path':
            y_pred_path, _ = differentiable_crack_path(
                d_pred, node_x, node_y, x_bins, path_sigma, p=4)
            w = (mass_target_path / (mass_target_path.sum() + 1e-12)).sqrt()
            return w * (y_pred_path - y_target_path)
        if args.obs_mode == 'extent':
            if snaps_pred is None:
                raise RuntimeError("extent residual requires snapshots.")
            extent_pred = crack_extent_series(
                [s[1] for s in snaps_pred],
                node_x, node_y, CRACK_Y, W, args.extent_sigma_y)
            scale = torch.tensor([1.0, 0.05], dtype=dtype, device=device)
            return ((extent_pred - extent_target) / scale).reshape(-1)
        if args.obs_mode in ('arrival', 'arrival_dic'):
            if snaps_pred is None:
                raise RuntimeError("arrival residual requires snapshots.")
            arrival_pred, activity_pred = crack_arrival_observable(
                [s[1] for s in snaps_pred],
                [int(s[0]) for s in snaps_pred],
                node_x, node_y, x_bins, path_sigma, CRACK_Y,
                args.extent_sigma_y,
                threshold=args.arrival_threshold,
                beta=args.arrival_beta)
            return torch.cat([
                arrival_pred - arrival_target,
                math.sqrt(args.arrival_activity_weight)
                * (activity_pred - activity_target).reshape(-1),
            ])
        if args.obs_mode == 'load_disp':
            if loads_pred is None:
                raise RuntimeError("load_disp residual requires loads.")
            loads_pred_t = torch.stack(loads_pred)
            scale = load_target.abs().max() + 1e-12
            return (loads_pred_t - load_target) / scale
        return (d_pred - target).reshape(-1)

    if args.param == 'low_rank':
        x0_init = (args.x0_init if args.x0_init is not None
                   else args.x0_truth + 1.5)
        sigma_init = (args.sigma_init if args.sigma_init is not None
                      else 1.0)
        x0 = torch.tensor(x0_init, dtype=dtype, device=device,
                           requires_grad=True)
        log_sigma = torch.tensor(
            float(np.log(sigma_init)),
            dtype=dtype,
            device=device,
            requires_grad=(args.recover == 'x0_sigma'))
        wf = torch.tensor(args.alpha_truth, dtype=dtype, device=device)
        params = [x0] if args.recover == 'x0' else [x0, log_sigma]
        if args.optimizer == 'adam':
            opt = torch.optim.Adam(
                params,
                lr=(args.optimizer_lr
                    if args.optimizer_lr is not None else 0.02))
        else:
            opt = torch.optim.LBFGS(
                params,
                lr=(args.optimizer_lr
                    if args.optimizer_lr is not None else 0.3),
                max_iter=1, history_size=10, line_search_fn='strong_wolfe',
                tolerance_grad=1e-12, tolerance_change=1e-12)
        history['x0'] = []
        history['sigma'] = []
        history['x0_err_mm'] = []
        _lr_counter = {'fwd': 0, 'iter': 0}
        start_iter = 0
        if inv_resume:
            ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
            with torch.no_grad():
                x0.copy_(torch.tensor(float(ckpt['x0']), dtype=dtype, device=device))
                log_sigma.copy_(torch.tensor(float(ckpt['log_sigma']),
                                              dtype=dtype, device=device))
            opt.load_state_dict(ckpt['optimizer_state'])
            start_iter = int(ckpt['next_iter'])
            _lr_counter['fwd'] = int(ckpt['counter_fwd'])
            for k in ('x0', 'sigma', 'x0_err_mm', 'iter', 'loss', 'wall_s'):
                if k in ckpt['history']:
                    history[k] = list(ckpt['history'][k])
            print(f"  Resumed: starting at iter {start_iter}, "
                  f"after {_lr_counter['fwd']} forward evals; "
                  f"x0={float(x0):.3f}, "
                  f"sigma={float(torch.exp(log_sigma)):.3f}.",
                  flush=True)

        def closure():
            cc = _lr_counter['fwd'] + 1
            it_now = _lr_counter['iter']
            x0_print = float(x0.detach())
            sigma_print = float(torch.exp(log_sigma.detach()))
            print(f"  [iter {it_now} closure call {cc}] starting forward "
                  f"(x0={x0_print:.3f}, sigma={sigma_print:.3f}) ...",
                  flush=True)
            t_fwd = time.time()
            opt.zero_grad()
            sigma = torch.exp(log_sigma)
            E_field = horizontal_E_band_field(centroids, x0, sigma, wf)
            if args.tbptt_chunk_size > 0:
                from phast.inverse_problems._tbptt import (
                    run_forward_tbptt_generic, make_install_E_field)
                _, chunk_snaps_pred, chunk_steps_pred, _ = (
                    run_forward_tbptt_generic(
                        solver, loading,
                        install_fn=make_install_E_field(E_field),
                        n_steps=n_steps,
                        tbptt_chunk_size=args.tbptt_chunk_size))
                assert chunk_steps_pred == tbptt_chunk_steps
                chunk_losses = [
                    ((dp - dt) ** 2).mean()
                    for dp, dt in zip(chunk_snaps_pred,
                                       d_target_tbptt_chunks)]
                if args.time_weight_lambda != 0.0:
                    from phast.inverse_problems._loss_weights import (
                        time_weights, weighted_mean)
                    _w = time_weights(tbptt_chunk_steps,
                                       args.time_weight_lambda,
                                       dtype=chunk_losses[0].dtype,
                                       device=chunk_losses[0].device)
                    loss = weighted_mean(chunk_losses, _w)
                else:
                    loss = torch.stack(chunk_losses).mean()
            else:
                if (args.obs_mode in ('extent', 'arrival', 'arrival_dic')
                        and args.checkpoint_chunks > 0):
                    raise RuntimeError(
                        "--obs_mode extent/arrival currently requires full-BPTT "
                        "without checkpoint_chunks so snapshots stay on tape.")
                closure_snaps = (
                    snap_steps if args.obs_mode in (
                        'extent', 'arrival', 'arrival_dic') else None)
                closure_load_steps = (
                    load_steps if args.obs_mode == 'load_disp' else None)
                d, snaps_pred, loads_pred = run_forward(
                    solver, loading, E_field, n_steps,
                    snapshot_steps=closure_snaps,
                    checkpoint_chunks=args.checkpoint_chunks,
                    detach_snapshots=(args.obs_mode not in (
                        'extent', 'arrival', 'arrival_dic')),
                    load_steps=closure_load_steps,
                    top_idx=top_idx if args.obs_mode == 'load_disp' else None)
                loss = _compute_loss(d, snaps_pred, loads_pred)
            fwd_s = time.time() - t_fwd
            t_bwd = time.time()
            loss.backward()
            if args.grad_clip_norm is not None:
                torch.nn.utils.clip_grad_norm_(params,
                                               args.grad_clip_norm)
            bwd_s = time.time() - t_bwd
            gx = float(x0.grad) if x0.grad is not None else float('nan')
            gs = float(log_sigma.grad) if log_sigma.grad is not None else float('nan')
            tag = "[TBPTT]" if args.tbptt_chunk_size > 0 else ""
            print(f"  [iter {it_now} closure call {cc}] "
                  f"loss={float(loss):.4e}  d/dx0={gx:.3e}  "
                  f"d/dlog_sigma={gs:.3e}  "
                  f"fwd={fwd_s:.1f}s  bwd={bwd_s:.1f}s {tag}",
                  flush=True)
            _lr_counter['fwd'] += 1
            return loss

        if args.observability_gate:
            from phast.inverse_problems.diagnostics import (
                observability_gate_report_fd,
            )

            alphas = [float(s) for s in args.gate_alphas.split(',')
                      if s.strip()]
            if args.recover == 'x0':
                theta_init = torch.tensor([x0_init], dtype=dtype,
                                          device=device)
                theta_truth = torch.tensor([args.x0_truth], dtype=dtype,
                                           device=device)
            else:
                theta_init = torch.tensor(
                    [x0_init, float(np.log(sigma_init))],
                    dtype=dtype, device=device)
                theta_truth = torch.tensor(
                    [args.x0_truth, float(np.log(args.sigma_truth))],
                    dtype=dtype, device=device)

            def _theta_to_x0_sigma(theta_vec):
                if args.recover == 'x0':
                    sigma_fixed = torch.exp(log_sigma.detach()).to(
                        dtype=theta_vec.dtype, device=theta_vec.device)
                    return theta_vec[0], sigma_fixed
                return theta_vec[0], torch.exp(theta_vec[1])

            def _run_residual(theta_vec):
                x0_gate, sigma_gate = _theta_to_x0_sigma(theta_vec)
                E_gate = horizontal_E_band_field(
                    centroids, x0_gate, sigma_gate, wf)
                gate_snaps = (
                    snap_steps if args.obs_mode in (
                        'extent', 'arrival', 'arrival_dic') else None)
                gate_load_steps = (
                    load_steps if args.obs_mode == 'load_disp' else None)
                d_gate, snaps_gate, loads_gate = run_forward(
                    solver, loading, E_gate, n_steps,
                    snapshot_steps=gate_snaps,
                    checkpoint_chunks=0,
                    detach_snapshots=(args.obs_mode not in (
                        'extent', 'arrival', 'arrival_dic')),
                    load_steps=gate_load_steps,
                    top_idx=top_idx if args.obs_mode == 'load_disp' else None)
                return _observation_residual(d_gate, snaps_gate, loads_gate)

            def _gate_loss(theta_vec):
                r = _run_residual(theta_vec)
                return (r * r).mean()

            report = observability_gate_report_fd(
                _run_residual, _gate_loss, theta_init, theta_truth,
                alphas=alphas, rel_step=args.gate_fd_rel_step)
            out_path = os.path.join(out_dir, 'observability_gate.json')
            with open(out_path, 'w') as fh:
                json.dump(report, fh, indent=2)
            print(f"\n[observability-gate] pass={report['pass']} "
                  f"reasons={report['reasons']}")
            print(f"[observability-gate] wrote {out_path}; "
                  "skipping optimisation.")
            return

        opt_target = "x0 only" if args.recover == 'x0' else "(x0, log sigma)"
        print(f"\n[2/3] {args.optimizer.upper()} on {opt_target}; "
              f"init x0={x0_init}, "
              f"sigma={sigma_init} (starting at iter {start_iter})",
              flush=True)
        t_inv = time.time()
        for it in range(start_iter, args.n_iters):
            _lr_counter['iter'] = it
            print(f"\n=== outer iter {it}/{args.n_iters - 1} "
                  f"({_lr_counter['fwd']} closure calls so far) ===",
                  flush=True)
            t_it = time.time()
            if args.optimizer == 'adam':
                loss_tensor = closure()
                opt.step()
                loss = float(loss_tensor.detach())
            else:
                loss = float(opt.step(closure))
            cur_x0 = float(x0.detach())
            cur_sig = float(torch.exp(log_sigma).detach())
            err = abs(cur_x0 - args.x0_truth)
            history['iter'].append(it)
            history['loss'].append(loss)
            history['x0'].append(cur_x0)
            history['sigma'].append(cur_sig)
            history['x0_err_mm'].append(err)
            history['wall_s'].append(time.time() - t_it)
            print(f"  it {it:2d} | loss={loss:.3e} | x0={cur_x0:.3f} mm "
                  f"(err {err:.3f}) | sigma={cur_sig:.3f} mm | "
                  f"{time.time()-t_it:.1f}s")

            # Atomic per-iter checkpoint write.
            ckpt_tmp = ckpt_path + '.tmp'
            torch.save({
                'next_iter':       it + 1,
                'x0':              cur_x0,
                'log_sigma':       float(log_sigma.detach()),
                'optimizer_state': opt.state_dict(),
                'counter_fwd':     _lr_counter['fwd'],
                'history':         dict(history),
                'param_mode':      'low_rank',
                'recover':         args.recover,
                'obs_mode':        args.obs_mode,
                'n_steps':         n_steps,
            }, ckpt_tmp)
            os.replace(ckpt_tmp, ckpt_path)
            print(f"  ckpt -> {ckpt_path} (iter {it+1} ready to resume)",
                  flush=True)
        wall = time.time() - t_inv

        with torch.no_grad():
            E_rec = horizontal_E_band_field(centroids, x0,
                                             torch.exp(log_sigma), wf)
        np.save(os.path.join(out_dir, 'E_recovered.npy'),
                E_rec.cpu().numpy())
        json_out = {
            'param_mode':      'low_rank',
            'recover':         args.recover,
            'obs_mode':        args.obs_mode,
            'n_path_bins':     args.n_path_bins if args.obs_mode == 'path' else None,
            'extent_sigma_y':   args.extent_sigma_y if args.obs_mode == 'extent' else None,
            'n_load_samples':   args.n_load_samples if args.obs_mode == 'load_disp' else None,
            'checkpoint_chunks': args.checkpoint_chunks,
            'x0_truth':        args.x0_truth,
            'sigma_truth':     args.sigma_truth,
            'alpha_truth':   args.alpha_truth,
            'x0_recovered':    float(x0.detach()),
            'sigma_recovered': float(torch.exp(log_sigma).detach()),
            'x0_err_mm':       abs(float(x0.detach()) - args.x0_truth),
            'wall_s':          wall,
            'history':         history,
        }
    else:
        E_init = torch.full((n_elem,), E_BULK, dtype=dtype, device=device)
        log_E = torch.log(E_init).clone().requires_grad_(True)
        if args.optimizer == 'adam':
            opt = torch.optim.Adam(
                [log_E],
                lr=(args.optimizer_lr
                    if args.optimizer_lr is not None else 0.02))
        else:
            opt = torch.optim.LBFGS(
                [log_E],
                lr=(args.optimizer_lr
                    if args.optimizer_lr is not None else 0.5),
                max_iter=3, history_size=10,
                line_search_fn='strong_wolfe')
        history['err_L2_rel'] = []

        def closure():
            opt.zero_grad()
            E_field = torch.exp(log_E)
            if args.tbptt_chunk_size > 0:
                from phast.inverse_problems._tbptt import (
                    run_forward_tbptt_generic, make_install_E_field)
                _, chunk_snaps_pred, _, _ = run_forward_tbptt_generic(
                    solver, loading,
                    install_fn=make_install_E_field(E_field),
                    n_steps=n_steps,
                    tbptt_chunk_size=args.tbptt_chunk_size)
                chunk_losses = [
                    ((dp - dt) ** 2).mean()
                    for dp, dt in zip(chunk_snaps_pred,
                                       d_target_tbptt_chunks)]
                if args.time_weight_lambda != 0.0:
                    from phast.inverse_problems._loss_weights import (
                        time_weights, weighted_mean)
                    _w = time_weights(tbptt_chunk_steps,
                                       args.time_weight_lambda,
                                       dtype=chunk_losses[0].dtype,
                                       device=chunk_losses[0].device)
                    loss = weighted_mean(chunk_losses, _w)
                else:
                    loss = torch.stack(chunk_losses).mean()
            else:
                d, _, loads_pred = run_forward(
                    solver, loading, E_field, n_steps,
                    checkpoint_chunks=args.checkpoint_chunks,
                    load_steps=(load_steps if args.obs_mode == 'load_disp'
                                else None),
                    top_idx=top_idx if args.obs_mode == 'load_disp' else None)
                loss = _compute_loss(d, loads_pred=loads_pred)
            loss.backward()
            if args.grad_clip_norm is not None:
                torch.nn.utils.clip_grad_norm_([log_E],
                                               args.grad_clip_norm)
            return loss

        print(f"\n[2/3] {args.optimizer.upper()} on log(E_e), "
              f"k = {n_elem} unknowns")
        t_inv = time.time()
        for it in range(args.n_iters):
            t_it = time.time()
            if args.optimizer == 'adam':
                loss_tensor = closure()
                opt.step()
                loss = float(loss_tensor.detach())
            else:
                loss = float(opt.step(closure))
            with torch.no_grad():
                E_cur = torch.exp(log_E).detach()
                err = (E_cur - E_true).norm().item() / E_true.norm().item()
            history['iter'].append(it)
            history['loss'].append(loss)
            history['err_L2_rel'].append(err)
            history['wall_s'].append(time.time() - t_it)
            print(f"  it {it:2d} | loss={loss:.3e} | "
                  f"||E-E*||/||E*|| = {err:.4e} | "
                  f"{time.time()-t_it:.1f}s")
        wall = time.time() - t_inv

        with torch.no_grad():
            E_rec = torch.exp(log_E).detach()
        np.save(os.path.join(out_dir, 'E_recovered.npy'),
                E_rec.cpu().numpy())
        json_out = {
            'param_mode':       'full_field',
            'obs_mode':         args.obs_mode,
            'n_path_bins':      args.n_path_bins if args.obs_mode == 'path' else None,
            'n_load_samples':   args.n_load_samples if args.obs_mode == 'load_disp' else None,
            'checkpoint_chunks': args.checkpoint_chunks,
            'k_unknowns':       n_elem,
            'x0_truth':         args.x0_truth,
            'sigma_truth':      args.sigma_truth,
            'alpha_truth':    args.alpha_truth,
            'final_loss':       history['loss'][-1] if history['loss'] else None,
            'final_err_L2_rel': (history['err_L2_rel'][-1]
                                  if history['err_L2_rel'] else None),
            'wall_s':           wall,
            'history':          history,
        }

    with open(os.path.join(out_dir, 'demo_inverse_E_horizontal.json'),
              'w') as fh:
        json.dump(json_out, fh, indent=2)
    print(f"\n[3/3] Saved: {out_dir}/")


if __name__ == '__main__':
    main()
