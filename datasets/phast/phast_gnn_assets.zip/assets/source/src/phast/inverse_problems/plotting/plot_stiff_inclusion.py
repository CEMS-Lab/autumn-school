#!/usr/bin/env python
"""Build the §4.2 stiff-inclusion inversion figure from smoke / HPC outputs.

Reads ``damage_truth.npz``, ``damage_recovered.npz``, and
``demo_inverse_stiff_inclusion.json`` from the demo's output directory
(default: ``results_inverse_stiff_inclusion/``) and produces a four-panel
figure:
    (a) target damage with truth-inclusion overlay and L-BFGS trajectory
        in physical (x, y) space starting from the initial guess;
    (b) recovered damage at converged (x_h, y_h);
    (c) MSE loss vs L-BFGS outer iteration (semilog);
    (d) position error |(x_h, y_h) - (x_h*, y_h*)| vs iteration (semilog).

Uses STIX serif per the paper-font feedback. Saves at 200 dpi.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle


# Paper rcParams (STIX serif everywhere) per feedback_paper_font.
plt.rcParams.update({
    "font.family":       "serif",
    "font.serif":        ["STIXGeneral"],
    "mathtext.fontset":  "stix",
    "axes.titlesize":    11,
    "axes.labelsize":    10,
    "xtick.labelsize":   9,
    "ytick.labelsize":   9,
    "legend.fontsize":   9,
})


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input_dir", type=str,
                   default=os.path.join(
                       os.path.dirname(os.path.abspath(__file__)),
                       "results_inverse_stiff_inclusion"))
    p.add_argument("--output", type=str,
                   default=os.path.join(
                       os.path.dirname(os.path.abspath(__file__)),
                       "..", "papers/paper", "figures",
                       "demo_inverse_stiff_inclusion.png"))
    p.add_argument("--dpi", type=int, default=200)
    args = p.parse_args()

    truth = np.load(os.path.join(args.input_dir, "damage_truth.npz"))
    rec = np.load(os.path.join(args.input_dir, "damage_recovered.npz"))
    with open(os.path.join(args.input_dir,
                             "demo_inverse_stiff_inclusion.json")) as fh:
        meta = json.load(fh)

    nodes = truth["nodes"]
    elements = truth["elements"]
    d_target = truth["d_target"]
    d_rec = rec["d_recovered"]
    W = float(truth["W"])
    H = float(truth["H"])
    a = float(truth["a"])
    sigma = float(truth["sigma"])
    x_t, y_t = float(truth["x_truth"]), float(truth["y_truth"])
    x_r, y_r = float(rec["x_recovered"]), float(rec["y_recovered"])
    x_i, y_i = meta["init"]["x_h"], meta["init"]["y_h"]
    history = meta["history"]
    its = np.array([h["iter"] for h in history])
    xhs = np.array([h["x_h"] for h in history])
    yhs = np.array([h["y_h"] for h in history])
    losses = np.array([h["loss"] for h in history])
    errs = np.array([h["pos_err_mm"] for h in history])

    fig = plt.figure(figsize=(7.4, 5.0))
    gs = fig.add_gridspec(
        2, 3, width_ratios=[1.0, 1.0, 0.04],
        height_ratios=[1.0, 1.05],
        hspace=0.50, wspace=0.30,
        left=0.08, right=0.93, top=0.93, bottom=0.10,
    )
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    cax = fig.add_subplot(gs[0, 2])
    ax_c = fig.add_subplot(gs[1, 0])
    ax_d = fig.add_subplot(gs[1, 1])

    # ----- (a) target damage with truth + trajectory -----------------------
    tpc = ax_a.tripcolor(nodes[:, 0], nodes[:, 1], elements, d_target,
                          shading="gouraud", cmap="inferno",
                          vmin=0.0, vmax=1.0, rasterized=True)
    ax_a.add_patch(Rectangle((0, 0), W, H, fill=False, ec="black", lw=0.9))
    ax_a.plot([0, a, a, 0],
              [H/2 - 0.03*H, H/2 - 0.03*H, H/2 + 0.03*H, H/2 + 0.03*H],
              "k-", lw=0.7)
    # Truth inclusion 2-sigma disc + star
    ax_a.add_patch(plt.Circle((x_t, y_t), 2 * sigma, fill=False,
                                ec="#d62728", lw=1.4, ls="--", zorder=5))
    ax_a.plot(x_t, y_t, marker="*", ms=14, mec="black", mfc="#d62728",
               zorder=6)
    # Initial guess + trajectory (init -> recovered)
    traj_x = np.concatenate([[x_i], xhs])
    traj_y = np.concatenate([[y_i], yhs])
    ax_a.plot(traj_x, traj_y, "-", color="#1f77b4", lw=1.4, zorder=4)
    ax_a.plot(traj_x, traj_y, "o", color="#1f77b4", ms=4, zorder=5)
    ax_a.plot(x_i, y_i, marker="s", ms=8, mec="black", mfc="#1f77b4",
               zorder=6, label="init")
    ax_a.set_aspect("equal")
    ax_a.set_xlim(0, W); ax_a.set_ylim(0, H)
    ax_a.set_title(r"(a) Target $d^{\,*}$ with truth $(x_h^{*}, y_h^{*})$")
    ax_a.set_xlabel(r"$x$ (mm)"); ax_a.set_ylabel(r"$y$ (mm)")

    # ----- (b) recovered damage with converged centre ----------------------
    ax_b.tripcolor(nodes[:, 0], nodes[:, 1], elements, d_rec,
                    shading="gouraud", cmap="inferno",
                    vmin=0.0, vmax=1.0, rasterized=True)
    ax_b.add_patch(Rectangle((0, 0), W, H, fill=False, ec="black", lw=0.9))
    ax_b.plot([0, a, a, 0],
              [H/2 - 0.03*H, H/2 - 0.03*H, H/2 + 0.03*H, H/2 + 0.03*H],
              "k-", lw=0.7)
    ax_b.add_patch(plt.Circle((x_r, y_r), 2 * sigma, fill=False,
                                ec="#2ca02c", lw=1.4, ls="--", zorder=5))
    ax_b.plot(x_r, y_r, marker="*", ms=14, mec="black", mfc="#2ca02c",
               zorder=6)
    ax_b.set_aspect("equal")
    ax_b.set_xlim(0, W); ax_b.set_ylim(0, H)
    ax_b.set_title(r"(b) Recovered $d$ at $(\hat{x}_h, \hat{y}_h)$")
    ax_b.set_xlabel(r"$x$ (mm)"); ax_b.set_ylabel(r"$y$ (mm)")

    cb = plt.colorbar(tpc, cax=cax)
    cb.set_label(r"damage $d$")

    # ----- (c) MSE loss --------------------------------------------------
    ax_c.semilogy(its, losses, "o-", color="#d62728", lw=1.4, ms=5)
    ax_c.set_xlabel("L-BFGS outer iteration")
    ax_c.set_ylabel("MSE loss")
    ax_c.set_title("(c) Loss convergence")
    ax_c.grid(True, which="both", ls=":", alpha=0.4)

    # ----- (d) position error --------------------------------------------
    ax_d.semilogy(its, errs, "o-", color="#1f77b4", lw=1.4, ms=5)
    ax_d.axhline(float(meta["h_crack_mm"]), ls="--", color="grey", lw=0.8,
                  label=fr"mesh $h = {meta['h_crack_mm']}$ mm")
    ax_d.set_xlabel("L-BFGS outer iteration")
    ax_d.set_ylabel(r"$\|(x_h, y_h) - (x_h^{*}, y_h^{*})\|$ (mm)")
    ax_d.set_title("(d) Position error")
    ax_d.grid(True, which="both", ls=":", alpha=0.4)
    ax_d.legend(loc="upper right")

    leg = [
        Line2D([0], [0], marker="*", color="none", mec="black",
                mfc="#d62728", ms=12, label="truth"),
        Line2D([0], [0], marker="s", color="none", mec="black",
                mfc="#1f77b4", ms=8, label="init"),
        Line2D([0], [0], marker="*", color="none", mec="black",
                mfc="#2ca02c", ms=12, label="recovered"),
    ]
    ax_a.legend(handles=leg, loc="lower left", fontsize=8,
                  framealpha=0.85)

    fig.savefig(args.output, dpi=args.dpi, bbox_inches="tight")
    size_kb = os.path.getsize(args.output) / 1024.0
    print(f"  Wrote {args.output}  ({size_kb:.1f} kB at {args.dpi} dpi)")


if __name__ == "__main__":
    sys.exit(main() or 0)
