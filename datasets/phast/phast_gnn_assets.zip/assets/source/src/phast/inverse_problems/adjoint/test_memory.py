"""Peak-memory measurement: autograd O(N) vs Griewank sqrt(N) vs full recompute.

CPU sampling is unreliable for fast operations because the autograd tape
is built and consumed in milliseconds; a Python sampling thread misses
the peak. We instead measure the **saved-tensor footprint** (the bytes
that autograd retains for backward) directly via
``torch.autograd.graph.saved_tensors_hooks``, which fires once per
saved tensor at pack time. This is the dominant component of peak
memory for these recurrences and produces a deterministic, noise-free
table.

CPU only. Float64.

Run as a script for the table; pytest collects the assertion that
Griewank's saved-tensor footprint scales as O(sqrt(N)) and is
strictly less than autograd's O(N) at N=1000.
"""
from __future__ import annotations

import math
import threading
from typing import List

import torch

from inverse_problems.adjoint import DiscreteAdjoint


class SavedBytesAccumulator:
    """Counter using saved_tensors_hooks. Sums unique storage bytes
    saved on the autograd tape during the wrapped block."""

    def __init__(self):
        self.seen = set()
        self.total = 0
        self._lock = threading.Lock()

    def pack(self, t):
        try:
            sp = t.untyped_storage().data_ptr()
            sz = t.untyped_storage().nbytes()
        except Exception:
            sp = t.data_ptr()
            sz = t.element_size() * t.nelement()
        with self._lock:
            if sp != 0 and sp not in self.seen:
                self.seen.add(sp)
                self.total += sz
        return t  # store as-is

    def unpack(self, t):
        return t


def _measure_saved_bytes(fn) -> int:
    acc = SavedBytesAccumulator()
    with torch.autograd.graph.saved_tensors_hooks(acc.pack, acc.unpack):
        fn()
    return acc.total


def _stepper_factory(n_dim: int, n_param: int, dtype, device):
    torch.manual_seed(0)
    A = torch.randn(n_dim, n_dim, dtype=dtype, device=device) / math.sqrt(n_dim)
    B = torch.randn(n_param, n_dim, dtype=dtype, device=device) / math.sqrt(n_param)

    def stepper(state, params):
        (x,) = state
        (theta,) = params
        return (torch.tanh(x @ A + theta @ B) * 0.97,)

    return stepper


def _run_autograd(stepper, n_steps, n_dim, n_param, dtype, device):
    x = torch.randn(n_dim, dtype=dtype, device=device, requires_grad=True)
    th = torch.randn(n_param, dtype=dtype, device=device, requires_grad=True)
    state = (x,)
    params = (th,)
    for _ in range(n_steps):
        state = stepper(state, params)
    loss = (state[0] ** 2).sum()
    loss.backward()


def _run_griewank(stepper, n_steps, n_dim, n_param, dtype, device,
                  n_checkpoints=None):
    x = torch.randn(n_dim, dtype=dtype, device=device, requires_grad=True)
    th = torch.randn(n_param, dtype=dtype, device=device, requires_grad=True)
    if n_checkpoints is None:
        n_checkpoints = max(1, int(math.ceil(math.sqrt(n_steps))))
    adj = DiscreteAdjoint(stepper, n_steps=n_steps, n_checkpoints=n_checkpoints)
    out = adj((x,), (th,))
    loss = (out[0] ** 2).sum()
    loss.backward()


def measure_table(N_list=(50, 200, 500, 1000), n_dim=400, n_param=8,
                  dtype=torch.float64, device=None):
    """Saved-tensor bytes vs N for the three schemes.

    The autograd path saves ~2 floating-point intermediates per step
    (matmul output, tanh activation), each of size ``n_dim`` ->
    O(N * n_dim) total. The Griewank path saves only the sqrt(N)
    checkpoint snapshots PLUS the per-chunk tape (which itself is
    O(sqrt(N))), giving O(sqrt(N) * n_dim). The single-checkpoint
    "full recompute" extreme stores only the initial state.
    """
    if device is None:
        device = torch.device("cpu")
    stepper = _stepper_factory(n_dim, n_param, dtype, device)
    rows = []
    for N in N_list:
        n_ck = max(1, int(math.ceil(math.sqrt(N))))
        b_auto = _measure_saved_bytes(
            lambda N=N: _run_autograd(stepper, N, n_dim, n_param, dtype, device)
        )
        b_grie = _measure_saved_bytes(
            lambda N=N: _run_griewank(stepper, N, n_dim, n_param, dtype, device)
        )
        # "Full-recompute O(1)" is the textbook scheme that replays from
        # the initial state for every backward step: O(N^2) time, O(1)
        # memory (only x_0 + a single-step tape). We model it by
        # measuring saved bytes of a 1-step run -- that constant is what
        # peak memory would be if no intermediate checkpoint were ever
        # retained.
        b_full = _measure_saved_bytes(
            lambda: _run_autograd(stepper, 1, n_dim, n_param, dtype, device)
        )
        rows.append((N, n_ck,
                     b_auto / (1024 * 1024),
                     b_grie / (1024 * 1024),
                     b_full / (1024 * 1024)))
    return rows


def test_griewank_uses_less_memory_at_n1000():
    rows = measure_table(N_list=(1000,))
    N, n_ck, m_auto, m_grie, m_full = rows[0]
    print(
        f"N={N} ckpts={n_ck} | autograd={m_auto:.2f} MB "
        f"| griewank={m_grie:.2f} MB | full-recompute={m_full:.2f} MB"
    )
    assert m_grie < m_auto, (
        f"griewank ({m_grie:.2f} MB) not less than autograd ({m_auto:.2f} MB)"
    )


def test_griewank_scales_as_sqrt_n():
    """At fixed n_dim, Griewank saved-bytes / autograd saved-bytes
    should shrink roughly as sqrt(N) / N = 1/sqrt(N) as N grows."""
    rows = measure_table(N_list=(50, 200, 500, 1000))
    ratios = [(N, mg / ma) for (N, _, ma, mg, _) in rows if ma > 0]
    print("ratios (griewank/autograd):", ratios)
    # 1000 should be smaller ratio than 50 -- not strict equality, but
    # monotone-ish on the synthetic problem.
    assert ratios[-1][1] < ratios[0][1], (
        f"griewank/autograd ratio did not shrink: {ratios}"
    )


def main():
    rows = measure_table()
    print(f"{'N':>6} {'sqrt(N)':>8} {'autograd[MB]':>14} "
          f"{'griewank[MB]':>14} {'full-recomp[MB]':>16}")
    for N, n_ck, ma, mg, mf in rows:
        print(f"{N:>6d} {n_ck:>8d} {ma:>14.3f} {mg:>14.3f} {mf:>16.3f}")
    return rows


if __name__ == "__main__":
    main()
