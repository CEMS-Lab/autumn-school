#!/usr/bin/env python
"""
Demo: Native autograd material parameter recovery through dynamic phase-field.

This is the headline demo that backs the autograd claim in the paper.
Unlike the existing papers/paper/demos/demo_inversion.py (which uses central
finite differences), this demo uses *real* end-to-end autograd through
the explicit dynamic loop:

    1. Wrap (Gc, l0) as torch.Tensor with requires_grad=True
    2. Run a full forward simulation (mechanics + damage, N time steps)
    3. Compute MSE loss against a target damage field
    4. Call loss.backward() — gradient flows through:
         velocity-Verlet → spectral stress (E, nu) → ψ+ → H
         → damage CG solve (implicit diff via _AdjointDamageSolveScalar)
       and back to (Gc.grad, l0.grad)
    5. Adam step
    6. Repeat

Cost per iteration: 1 forward + 1 backward ≈ 3× forward (the backward
runs two extra CG solves: one for d_unc recovery and one for the adjoint
λ). For comparison, central FD on (Gc, l0) costs 4 extra forwards per
iteration. The advantage grows as the parameter dimension grows; this
scalar demo (k=2) is the smallest meaningful test case.

Usage:
    python demo_autograd_inversion.py
    python demo_autograd_inversion.py --n_steps 30 --n_iters 50
    python demo_autograd_inversion.py --device cuda
"""
import os
import sys
import time
import argparse
import json
import tempfile

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.material import Material
from phast.mesh import FEMMesh
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.mesh_generator import rectangular_sent
from phast.device import DeviceContext
from phast.config import LoadingConfig
from phast.inverse_problems._tbptt import (
    run_forward_tbptt_generic,
    make_install_diff_Gc,
)


def build_mesh(device, dtype, h_crack=1.0, h_coarse=2.5):
    mesh_path = os.path.join(tempfile.gettempdir(), 'demo_autograd_mesh.msh')
    rectangular_sent(mesh_path, W=20.0, H=20.0, a=10.0, l0=0.5,
                     h_crack=h_crack, h_coarse=h_coarse)
    mesh = FEMMesh(mesh_path, device=device, dtype=dtype)
    mesh.identify_boundaries()
    return mesh


def build_solver(mesh, sigma=500.0, device='cpu'):
    """Build the StaggeredSolver ONCE — reused across all iterations."""
    mat = Material(E=210000.0, nu=0.30, Gc=2.7, l0=0.5, rho=7.8e-9,
                   energy_split='spectral', pf_model='AT2',
                   eta_residual=1e-7)
    ctx = DeviceContext(device=device, profile=False, compile_solvers=False)
    bcs = BoundaryConditions(mesh.n_nodes, device=ctx.device, dtype=ctx.dtype)
    bcs.add_neumann(mesh.node_sets['top'],    [0.0, 1.0])
    bcs.add_neumann(mesh.node_sets['bottom'], [0.0, -1.0])
    bcs.fix(mesh.node_sets['left'], 0)
    cfg = SolverConfig(solver_type='explicit', dt_safety=0.5,
                        differentiable=True)
    solver = StaggeredSolver(mesh, mat, bcs, config=cfg, ctx=ctx)
    solver.f_ext = sigma * bcs.get_neumann_forces(mesh)
    return solver


def run_forward(solver, Gc_t, l0_t, n_steps, snapshot_steps=None):
    """One forward simulation reusing `solver`. Resets state, returns final
    damage with autograd graph attached.

    When ``snapshot_steps`` is a non-empty iterable of (1-indexed) step
    numbers, also returns a list of damage tensors at those steps for
    forward-viz purposes. Returns ``(d_final, snaps)`` in that case;
    backward-compatible single-tensor return when ``snapshot_steps`` is
    None.
    """
    solver.diff_Gc = Gc_t
    solver.diff_l0 = l0_t
    n_nodes = solver.mesh.n_nodes
    dtype = solver.u.dtype
    device = solver.u.device
    solver.u = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.v = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.a = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.d = torch.zeros(n_nodes, dtype=dtype, device=device)
    n_elems = len(solver.mesh.elements)
    solver.H_elem = torch.zeros(n_elems, dtype=dtype, device=device)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dtype, device=device)
    if hasattr(solver, '_explicit_step_count'):
        solver._explicit_step_count = 0
    solver._step_count = 0

    snap_set = set(int(s) for s in snapshot_steps) if snapshot_steps else set()
    snaps = [] if snap_set else None

    for step in range(n_steps):
        solver.step_full()
        if snaps is not None and (step + 1) in snap_set:
            snaps.append(solver.d.detach().clone())
    if snaps is not None:
        return solver.d, snaps
    return solver.d


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--n_steps', type=int, default=50,
                   help='Time steps per simulation (default: 50)')
    p.add_argument('--n_iters', type=int, default=40,
                   help='Optimisation iterations (default: 40)')
    p.add_argument('--optimizer', type=str, default='lbfgs',
                   choices=['adam', 'lbfgs'],
                   help='Optimiser (default: lbfgs — faster on smooth losses)')
    p.add_argument('--lr', type=float, default=0.5,
                   help='Adam learning rate on log-parameters '
                        '(L-BFGS uses 1.0 internally)')
    p.add_argument('--device', type=str, default='cpu')
    p.add_argument('--h_crack', type=float, default=1.0)
    p.add_argument('--output_dir', type=str, default='results_autograd_demo')
    p.add_argument('--save_forward_viz', dest='save_forward_viz',
                   action='store_true', default=True,
                   help='Before optimisation, save '
                        'truth/init_damage_final.png + _evolution.gif '
                        'so the user can sanity-check the forward '
                        'setup (default: enabled).')
    p.add_argument('--no_save_forward_viz', dest='save_forward_viz',
                   action='store_false')
    p.add_argument('--n_viz_frames', type=int, default=20,
                   help='Frames in <label>_damage_evolution.gif.')
    p.add_argument('--tbptt_chunk_size', type=int, default=0,
                   help='Truncated-BPTT chunk length (issue #288 / #301). '
                        '0 disables (default; full autograd graph). '
                        'When > 0, the n_steps explicit-dynamics loop is '
                        'split into chunks of this length; per-chunk damage '
                        'MSE-against-truth is the loss, biased gradient. '
                        'f_ext is set externally and unaffected by '
                        'load_factor; constant LoadingConfig is the no-op '
                        'equivalent of the demo plain step-loop.')
    args = p.parse_args()

    out_dir = os.path.join(THIS_DIR, args.output_dir)
    os.makedirs(out_dir, exist_ok=True)

    print("=" * 70)
    print("  DEMO: Native autograd material parameter recovery")
    print("       (real autograd through dynamic phase-field, not FD)")
    print("=" * 70)

    Gc_true = 2.7
    l0_true = 0.5
    Gc_init = 4.0   # 1.5x truth
    l0_init = 0.75  # 1.5x truth

    device = args.device
    dtype = torch.float64

    print(f"  Device: {device}, dtype: float64")
    print(f"  Mesh: SENT 20x20mm, h_crack={args.h_crack}")
    print(f"  Time steps per forward: {args.n_steps}")
    print(f"  Truth: Gc*={Gc_true}, l0*={l0_true}")
    print(f"  Init:  Gc0={Gc_init}, l0_0={l0_init}  (1.5x truth)")
    print(f"  Optimiser: {args.optimizer} on log-params (lr={args.lr})")

    mesh = build_mesh(device, dtype, h_crack=args.h_crack)
    print(f"  Mesh: {int(mesh.n_nodes)} nodes, {int(len(mesh.elements))} elements")
    print("  Building solver (one-time init) ...")
    solver = build_solver(mesh, sigma=500.0, device=device)
    print()

    # ---- TBPTT setup (issue #301) ----
    # Constant LoadingConfig is the no-op equivalent for this demo
    # (Dirichlet BCs are zero-fixed; f_ext is set externally and not
    # multiplied by load_factor in step_full).
    tbptt_chunk_steps = None
    d_target_tbptt_chunks = None
    loading = LoadingConfig(ramp_type='constant')
    if args.tbptt_chunk_size > 0:
        cs = int(args.tbptt_chunk_size)
        tbptt_chunk_steps = list(range(cs, args.n_steps, cs))
        if not tbptt_chunk_steps or tbptt_chunk_steps[-1] != args.n_steps:
            tbptt_chunk_steps.append(args.n_steps)
        print(f"\n[TBPTT #301] enabled: chunk_size={cs}, "
              f"{len(tbptt_chunk_steps)} chunks")

    # ---- Generate target ----
    print("[1/2] Generating target damage field at (Gc*, l0*) ...")
    t0 = time.time()
    snap_steps = None
    if args.save_forward_viz and args.n_viz_frames > 0:
        n_frames = min(args.n_viz_frames, args.n_steps)
        first = max(int(0.05 * args.n_steps), 1)
        snap_steps = list(np.linspace(first, args.n_steps, n_frames,
                                       dtype=int).tolist())
    with torch.no_grad():
        Gc_star = torch.tensor(Gc_true, dtype=dtype, device=device)
        l0_star = torch.tensor(l0_true, dtype=dtype, device=device)
        if args.tbptt_chunk_size > 0:
            _, truth_chunk_snaps, truth_chunk_steps_chk, _ = (
                run_forward_tbptt_generic(
                    solver, loading,
                    install_fn=make_install_diff_Gc(Gc_star, l0_star),
                    n_steps=args.n_steps,
                    tbptt_chunk_size=args.tbptt_chunk_size))
            d_target_tbptt_chunks = [s.detach().clone()
                                      for s in truth_chunk_snaps]
            d_target = d_target_tbptt_chunks[-1]
            assert truth_chunk_steps_chk == tbptt_chunk_steps
            snaps_truth = None
        elif snap_steps is not None:
            d_target, snaps_truth = run_forward(
                solver, Gc_star, l0_star, args.n_steps,
                snapshot_steps=snap_steps)
            d_target = d_target.detach().clone()
        else:
            snaps_truth = None
            d_target = run_forward(solver, Gc_star, l0_star,
                                    args.n_steps).detach().clone()
    t_target = time.time() - t0

    # Pre-inversion forward-viz on truth + init parameters.
    if args.save_forward_viz:
        try:
            from inverse_problems._viz import save_forward_viz
            paths = save_forward_viz(
                mesh.nodes, mesh.elements, d_target, out_dir,
                label='truth', snapshots=snaps_truth,
                snap_steps=snap_steps, n_steps_total=args.n_steps,
            )
            print(f"  [forward-viz] truth -> {paths['png']}"
                  + (f", {paths['gif']}" if paths['gif'] else ''))
            print(f"  [forward-viz] running init forward at "
                  f"Gc={Gc_init}, l0={l0_init} ...")
            with torch.no_grad():
                Gc_i = torch.tensor(Gc_init, dtype=dtype, device=device)
                l0_i = torch.tensor(l0_init, dtype=dtype, device=device)
                if snap_steps is not None:
                    d_init, snaps_init = run_forward(
                        solver, Gc_i, l0_i, args.n_steps,
                        snapshot_steps=snap_steps)
                else:
                    d_init = run_forward(solver, Gc_i, l0_i, args.n_steps)
                    snaps_init = None
                d_init = d_init.detach().clone()
            paths_i = save_forward_viz(
                mesh.nodes, mesh.elements, d_init, out_dir,
                label='init', snapshots=snaps_init,
                snap_steps=snap_steps, n_steps_total=args.n_steps,
            )
            print(f"  [forward-viz] init  -> {paths_i['png']}"
                  + (f", {paths_i['gif']}" if paths_i['gif'] else ''))
        except Exception as exc:
            print(f"  [forward-viz] failed: {exc}")

    print(f"  Target: max(d) = {d_target.max().item():.4f}, "
          f"damaged nodes (d>0.1) = {(d_target > 0.1).sum().item()}")
    print(f"  Forward time: {t_target:.2f}s")

    # ---- Optimisation ----
    print("\n[2/2] Optimising (Gc, l0) via autograd through dynamic loop ...")
    log_Gc = torch.tensor(float(np.log(Gc_init)), dtype=dtype,
                           device=device, requires_grad=True)
    log_l0 = torch.tensor(float(np.log(l0_init)), dtype=dtype,
                           device=device, requires_grad=True)

    if args.optimizer == 'lbfgs':
        optimizer = torch.optim.LBFGS(
            [log_Gc, log_l0], lr=1.0, max_iter=4,
            history_size=10, line_search_fn='strong_wolfe')
    else:
        optimizer = torch.optim.Adam([log_Gc, log_l0], lr=args.lr)

    history = {
        'iter': [], 'loss': [], 'Gc': [], 'l0': [],
        'rel_err_Gc': [], 'rel_err_l0': [], 'wall_time': [],
    }
    t_loop = time.time()
    iter_state = {'n_forwards': 0}

    def closure_eval():
        """Run forward + backward, return loss (used by both optimizers)."""
        optimizer.zero_grad()
        Gc_t = torch.exp(log_Gc)
        l0_t = torch.exp(log_l0)
        if args.tbptt_chunk_size > 0:
            _, chunk_snaps_pred, chunk_steps_pred, _ = (
                run_forward_tbptt_generic(
                    solver, loading,
                    install_fn=make_install_diff_Gc(Gc_t, l0_t),
                    n_steps=args.n_steps,
                    tbptt_chunk_size=args.tbptt_chunk_size))
            assert chunk_steps_pred == tbptt_chunk_steps
            chunk_losses = [
                ((dp - dt) ** 2).mean()
                for dp, dt in zip(chunk_snaps_pred,
                                   d_target_tbptt_chunks)]
            loss = torch.stack(chunk_losses).mean()
        else:
            d_pred = run_forward(solver, Gc_t, l0_t, args.n_steps)
            loss = ((d_pred - d_target) ** 2).mean()
        loss.backward()
        iter_state['n_forwards'] += 1
        return loss

    for it in range(args.n_iters):
        t_iter = time.time()
        if args.optimizer == 'lbfgs':
            loss = optimizer.step(closure_eval)
        else:
            loss = closure_eval()
            optimizer.step()

        Gc_val = float(torch.exp(log_Gc).item())
        l0_val = float(torch.exp(log_l0).item())
        rel_Gc = abs(Gc_val - Gc_true) / Gc_true
        rel_l0 = abs(l0_val - l0_true) / l0_true
        history['iter'].append(it)
        history['loss'].append(float(loss.item()))
        history['Gc'].append(Gc_val)
        history['l0'].append(l0_val)
        history['rel_err_Gc'].append(rel_Gc)
        history['rel_err_l0'].append(rel_l0)
        history['wall_time'].append(time.time() - t_iter)

        if it % max(1, args.n_iters // 20) == 0 or it == args.n_iters - 1:
            print(f"  it {it:3d} | loss={loss.item():.3e} "
                  f"| Gc={Gc_val:.4f} ({rel_Gc:.2%}) "
                  f"| l0={l0_val:.4f} ({rel_l0:.2%}) "
                  f"| fwds={iter_state['n_forwards']:3d} "
                  f"| {history['wall_time'][-1]:.1f}s",
                  flush=True)

    total_t = time.time() - t_loop
    print(f"\nTotal optimisation time: {total_t:.1f}s "
          f"({total_t/args.n_iters:.1f}s/iter)")

    # Save history
    with open(os.path.join(out_dir, 'history.json'), 'w') as fp:
        json.dump({
            'truth': {'Gc': Gc_true, 'l0': l0_true},
            'init': {'Gc': Gc_init, 'l0': l0_init},
            'config': {
                'n_steps': args.n_steps,
                'n_iters': args.n_iters,
                'lr': args.lr,
                'h_crack': args.h_crack,
                'device': args.device,
            },
            'history': history,
            'total_wall_time_s': total_t,
            'forwards_used': args.n_iters,  # 1 forward per iter (autograd)
            'forwards_FD_baseline': args.n_iters * 5,  # 1 + 4 FD = 5 per iter for k=2 central
        }, fp, indent=2)
    print(f"History → {os.path.join(out_dir, 'history.json')}")

    # ---- Plot ----
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 3, figsize=(14, 4))

        ax = axes[0]
        ax.semilogy(history['iter'], history['loss'], 'b-o', ms=3)
        ax.set_xlabel('Iteration')
        ax.set_ylabel('MSE loss')
        ax.set_title('(a) Loss convergence')
        ax.grid(True, alpha=0.3)

        ax = axes[1]
        ax.plot(history['iter'], history['Gc'], 'b-o', ms=3, label=r'$G_c$')
        ax.axhline(Gc_true, color='r', ls='--', label=f'true {Gc_true}')
        ax.set_xlabel('Iteration')
        ax.set_ylabel(r'$G_c$ [N/mm]')
        ax.set_title('(b) Recovered $G_c$')
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        ax = axes[2]
        ax.plot(history['iter'], history['l0'], 'g-o', ms=3, label=r'$\ell_0$')
        ax.axhline(l0_true, color='r', ls='--', label=f'true {l0_true}')
        ax.set_xlabel('Iteration')
        ax.set_ylabel(r'$\ell_0$ [mm]')
        ax.set_title(r'(c) Recovered $\ell_0$')
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        fig.suptitle('Native autograd material recovery '
                     '(real backward through dynamic PF, not FD)',
                     fontsize=12)
        fig.tight_layout()
        out_path = os.path.join(out_dir, 'demo_autograd_convergence.png')
        fig.savefig(out_path, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f"Figure → {out_path}")
    except Exception as e:
        print(f"Plot skipped: {e}")

    print()
    final_Gc = history['Gc'][-1]
    final_l0 = history['l0'][-1]
    print(f"FINAL: Gc = {final_Gc:.4f} (true {Gc_true}, err "
          f"{100*abs(final_Gc-Gc_true)/Gc_true:.2f}%)")
    print(f"FINAL: l0 = {final_l0:.4f} (true {l0_true}, err "
          f"{100*abs(final_l0-l0_true)/l0_true:.2f}%)")
    print(f"Forwards used (autograd): {args.n_iters}")
    print(f"Forwards needed (central FD baseline): {args.n_iters * 5}")
    print(f"Speedup over FD: 5x at k=2 params")
    print(f"  (advantage scales linearly with k; at k=10000 it would be ~5000x)")


if __name__ == '__main__':
    main()
