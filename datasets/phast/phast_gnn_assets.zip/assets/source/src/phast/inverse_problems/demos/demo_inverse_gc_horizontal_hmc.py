#!/usr/bin/env python3
"""HMC posterior sampling for the D3 Gc(x) horizontal-band problem.

Runs Hamiltonian Monte Carlo using the differentiable phase-field solver
as the potential energy U(theta) = loss(theta) = MSE(damage_pred, damage_truth).
Samples the 2D posterior p(x0, sigma_g | damage_obs).

Comparison target: Stanić et al. 2026 (stanic2026probabilistic) uses MCMC
with O(10^4) forward evaluations via surrogate.  We use O(300) gradient
evaluations directly through the solver.

Usage (Mac CPU, debug run)::

    python -m phast.inverse_problems.demos.demo_inverse_gc_horizontal_hmc \\
        --device cpu --dtype float64 \\
        --n_steps 500 --checkpoint_chunks 10 \\
        --n_warmup 5 --n_samples 10 --n_leapfrog 3 \\
        --output_dir /tmp/hmc_debug

Usage (HPC GPU, paper run)::

    python -m phast.inverse_problems.demos.demo_inverse_gc_horizontal_hmc \\
        --device cuda --dtype float64 \\
        --n_steps 2000 --checkpoint_chunks 40 \\
        --n_warmup 50 --n_samples 50 --n_leapfrog 3 \\
        --step_size 0.08 \\
        --output_dir $OUT/D3_Gc_hmc_n2000
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.mesh_generator import rectangular_sent as gen_mesh
from phast.mesh import FEMMesh
from phast.material import create_material
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.config import LoadingConfig, compute_load_factor
from phast.device import DeviceContext
from phast.inverse_problems.hmc import (
    hmc_sample, gelman_rubin, effective_sample_size, summarise_chain,
)
from phast.inverse_problems.demos.demo_inverse_gc_horizontal import (
    horizontal_band_field, build_sent_mesh, build_solver, run_forward,
    NU, RHO, GC, L0, E_BULK, W, H, A, CRACK_Y,
    DEFAULT_X0, DEFAULT_SIGMA, DEFAULT_WEAK_FRACTION,
)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse():
    p = argparse.ArgumentParser(
        description="HMC posterior sampling for D3 Gc(x) horizontal-band")
    # Mesh / physics
    p.add_argument("--h_crack",   type=float, default=0.4)
    p.add_argument("--h_coarse",  type=float, default=2.0)
    p.add_argument("--n_steps",   type=int,   default=2000)
    p.add_argument("--weak_fraction", type=float, default=DEFAULT_WEAK_FRACTION)
    p.add_argument("--damping_zeta",  type=float, default=0.05)
    p.add_argument("--delta_U",       type=float, default=0.05)
    p.add_argument("--H_update_method", default="custom_subgrad")
    p.add_argument("--H_update_scale",  type=float, default=1.0)
    p.add_argument("--checkpoint_chunks", type=int, default=40)
    # Truth
    p.add_argument("--x0_truth",    type=float, default=16.0)
    p.add_argument("--sigma_truth", type=float, default=2.0)
    # HMC init
    p.add_argument("--x0_init",    type=float, default=17.5,
                   help="HMC starting x0 (mm)")
    p.add_argument("--sigma_init", type=float, default=3.0,
                   help="HMC starting sigma_g (mm)")
    # HMC hyperparameters
    p.add_argument("--n_warmup",   type=int,   default=50)
    p.add_argument("--n_samples",  type=int,   default=50)
    p.add_argument("--n_leapfrog", type=int,   default=3)
    p.add_argument("--step_size",  type=float, default=0.08,
                   help="Initial leapfrog step size (mm units)")
    p.add_argument("--target_accept", type=float, default=0.65)
    p.add_argument("--mass_x0",    type=float, default=1.0,
                   help="Diagonal mass for x0 (mm^{-2} scale)")
    p.add_argument("--mass_sigma", type=float, default=1.0,
                   help="Diagonal mass for sigma in log-space")
    p.add_argument("--rng_seed",   type=int,   default=42)
    # Two-chain run for R-hat
    p.add_argument("--n_chains",   type=int,   default=2,
                   help="Number of independent chains (each offset from init)")
    p.add_argument("--chain_offset", type=float, default=0.5,
                   help="x0 offset between chains (mm)")
    # Device / output
    p.add_argument("--device",     default="cpu")
    p.add_argument("--dtype",      default="float64")
    p.add_argument("--output_dir", default="/tmp/hmc_d3")
    return p.parse_args()


# ---------------------------------------------------------------------------
# Setup helpers
# ---------------------------------------------------------------------------

def _build_gc(centroids, p0, p1, wf, dtype, device):
    """p0 = x0 (mm), p1 = log(sigma); returns per-element Gc field."""
    return horizontal_band_field(centroids, p0, torch.exp(p1), wf)


def _setup(args):
    dtype = torch.float64 if args.dtype == "float64" else torch.float32
    device = torch.device(args.device)

    # Mesh
    mesh, msh = build_sent_mesh(args.h_crack, args.h_coarse, device, dtype)
    n_nodes = mesh.n_nodes
    centroids = mesh.nodes[mesh.elements].mean(dim=1)

    # Loading
    tau_ramp = 1e-6
    dU = args.delta_U / 2.0
    loading = LoadingConfig(ramp_type="smooth", t_ramp=tau_ramp)
    wf = torch.tensor(args.weak_fraction, dtype=dtype, device=device)

    solver = build_solver(
        mesh, dU, tau_ramp,
        damping_zeta=args.damping_zeta,
        device=device, dtype=dtype,
        H_update_method=args.H_update_method,
        H_update_scale=args.H_update_scale,
    )

    # Truth forward
    print("Running truth forward ...", flush=True)
    t0 = time.time()
    p0_truth = torch.tensor(args.x0_truth, dtype=dtype, device=device)
    p1_truth = torch.tensor(float(np.log(args.sigma_truth)), dtype=dtype, device=device)
    Gc_truth = _build_gc(centroids, p0_truth, p1_truth, wf, dtype, device)
    with torch.no_grad():
        target, _, _ = run_forward(
            solver, loading, Gc_truth, args.n_steps,
            checkpoint_chunks=0)
    target = target.detach()
    print(f"  truth forward done in {time.time()-t0:.1f}s, "
          f"max(d)={float(target.max()):.3f}", flush=True)

    return solver, loading, centroids, wf, target, dtype, device


# ---------------------------------------------------------------------------
# Potential function factory
# ---------------------------------------------------------------------------

def _make_potential(solver, loading, centroids, wf, target, n_steps,
                    checkpoint_chunks):
    """Return U(theta) callable for HMC.

    theta = [x0, log_sigma] — both differentiable.
    """
    def potential_fn(theta: torch.Tensor) -> torch.Tensor:
        p0 = theta[0]
        p1 = theta[1]
        Gc = horizontal_band_field(centroids, p0, torch.exp(p1), wf)
        d_pred, _, _ = run_forward(
            solver, loading, Gc, n_steps,
            checkpoint_chunks=checkpoint_chunks)
        loss = ((d_pred - target) ** 2).mean()
        return loss

    return potential_fn


# ---------------------------------------------------------------------------
# Visualisation
# ---------------------------------------------------------------------------

def _plot_posterior(all_chains: list, args, out_dir: Path):
    try:
        import matplotlib.pyplot as plt
        from matplotlib import rcParams
    except ImportError:
        print("  matplotlib not available — skipping posterior plot", flush=True)
        return

    rcParams.update({
        "font.family": "serif",
        "font.serif": ["STIXGeneral", "Times New Roman", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 9,
        "axes.labelsize": 9,
        "legend.fontsize": 8,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
    })

    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8), constrained_layout=True)

    colors = ["#2166ac", "#d6604d", "#4dac26", "#8073ac"]
    for ci, chain in enumerate(all_chains):
        s = chain["samples"]  # (n_samples, 2)
        x0s = s[:, 0]
        sigmas = np.exp(s[:, 1])
        c = colors[ci % len(colors)]
        axes[0].scatter(x0s, sigmas, s=6, alpha=0.5, color=c,
                        label=f"chain {ci+1}")
        axes[1].plot(x0s, alpha=0.7, lw=0.8, color=c)

    axes[0].axvline(args.x0_truth, color="k", lw=1.2, ls="--",
                    label=r"$x_0^{\star}$")
    axes[0].axhline(args.sigma_truth, color="gray", lw=1.2, ls=":",
                    label=r"$\sigma^{\star}$")
    axes[0].set_xlabel(r"$x_0$ (mm)")
    axes[0].set_ylabel(r"$\sigma_g$ (mm)")
    axes[0].set_title(r"D3 posterior: $(x_0,\,\sigma_g)$")
    axes[0].legend(loc="upper right", framealpha=0.8)

    axes[1].axhline(args.x0_truth, color="k", lw=1.0, ls="--")
    axes[1].set_xlabel("HMC iteration")
    axes[1].set_ylabel(r"$x_0$ (mm)")
    axes[1].set_title(r"$x_0$ trace")

    for ext in ("pdf", "png"):
        kw = {"dpi": 200} if ext == "png" else {}
        fig.savefig(out_dir / f"d3_hmc_posterior.{ext}", **kw)
        print(f"  saved: {out_dir / f'd3_hmc_posterior.{ext}'}", flush=True)
    plt.close(fig)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    args = _parse()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("  D3 Gc(x) -- HMC posterior sampling")
    print("=" * 60)
    print(f"  truth: x0={args.x0_truth}, sigma={args.sigma_truth}")
    print(f"  init:  x0={args.x0_init}, sigma={args.sigma_init}")
    print(f"  HMC:   n_warmup={args.n_warmup}, n_samples={args.n_samples}, "
          f"n_leapfrog={args.n_leapfrog}")
    print(f"  n_chains={args.n_chains}, step_size={args.step_size}")
    print(f"  n_steps={args.n_steps}, checkpoint_chunks={args.checkpoint_chunks}")
    print()

    solver, loading, centroids, wf, target, dtype, device = _setup(args)
    potential_fn = _make_potential(
        solver, loading, centroids, wf, target,
        args.n_steps, args.checkpoint_chunks)

    mass_diag = torch.tensor(
        [args.mass_x0, args.mass_sigma], dtype=dtype, device=device)

    all_chains = []
    for ci in range(args.n_chains):
        x0_i = args.x0_init + ci * args.chain_offset
        log_sigma_i = float(np.log(args.sigma_init))
        theta_init = torch.tensor([x0_i, log_sigma_i], dtype=dtype, device=device)

        print(f"\n--- Chain {ci+1}/{args.n_chains}  init=[{x0_i:.2f}, "
              f"sigma={args.sigma_init:.2f}] ---", flush=True)

        result = hmc_sample(
            potential_fn,
            theta_init,
            n_samples=args.n_samples,
            n_warmup=args.n_warmup,
            step_size=args.step_size,
            n_leapfrog=args.n_leapfrog,
            mass_diag=mass_diag,
            target_accept=args.target_accept,
            adapt_step_size=True,
            rng_seed=args.rng_seed + ci,
            verbose=True,
        )
        all_chains.append(result)

        chain_out = out_dir / f"chain_{ci+1}.json"
        chain_out.write_text(json.dumps({
            "samples": result["samples"].tolist(),
            "warmup": result["warmup"].tolist(),
            "accept_rate": result["accept_rate"],
            "n_grad_evals": result["n_grad_evals"],
            "step_size_final": result["step_size_final"],
            "diagnostics": result["diagnostics"],
        }, indent=2))
        print(f"  chain {ci+1} saved -> {chain_out}", flush=True)

    # Posterior summary
    all_samples = [c["samples"] for c in all_chains]

    # R-hat across chains (if ≥ 2)
    r_hat = gelman_rubin(all_samples) if len(all_chains) >= 2 else np.array([float("nan")] * 2)
    print(f"\n  R-hat: x0={r_hat[0]:.4f}  log_sigma={r_hat[1]:.4f}")

    pooled = np.concatenate(all_samples, axis=0)  # (n_total, 2)
    ess = effective_sample_size(pooled)
    mean_x0 = float(pooled[:, 0].mean())
    std_x0  = float(pooled[:, 0].std())
    mean_sigma = float(np.exp(pooled[:, 1]).mean())
    std_sigma  = float(np.exp(pooled[:, 1]).std())

    total_grads = sum(c["n_grad_evals"] for c in all_chains)

    summary = {
        "truth": {"x0": args.x0_truth, "sigma": args.sigma_truth},
        "posterior": {
            "x0_mean": mean_x0, "x0_std": std_x0,
            "sigma_mean": mean_sigma, "sigma_std": std_sigma,
            "x0_err_mm": abs(mean_x0 - args.x0_truth),
            "sigma_err_mm": abs(mean_sigma - args.sigma_truth),
        },
        "convergence": {
            "r_hat_x0": float(r_hat[0]),
            "r_hat_log_sigma": float(r_hat[1]),
            "ess_x0": float(ess[0]),
            "ess_log_sigma": float(ess[1]),
        },
        "efficiency": {
            "total_grad_evals": total_grads,
            "n_chains": args.n_chains,
            "n_warmup": args.n_warmup,
            "n_samples": args.n_samples,
            "n_leapfrog": args.n_leapfrog,
        },
    }

    print("\n  === SUMMARY ===")
    print(f"  x0:    mean={mean_x0:.4f}  std={std_x0:.4f}  "
          f"err={abs(mean_x0-args.x0_truth):.4f} mm  (truth={args.x0_truth})")
    print(f"  sigma: mean={mean_sigma:.4f}  std={std_sigma:.4f}  "
          f"err={abs(mean_sigma-args.sigma_truth):.4f} mm  (truth={args.sigma_truth})")
    print(f"  R-hat: x0={r_hat[0]:.4f}  log_sigma={r_hat[1]:.4f}")
    print(f"  ESS: x0={ess[0]:.1f}  log_sigma={ess[1]:.1f}")
    print(f"  total grad evals: {total_grads}")

    # Gate check
    gate_pass = (
        r_hat[0] < 1.1 and r_hat[1] < 1.1
        and abs(mean_x0 - args.x0_truth) < 0.5
        and abs(mean_sigma - args.sigma_truth) < 0.5
        and total_grads < 600
    )
    summary["gate_pass"] = bool(gate_pass)
    print(f"\n  GATE: {'PASS' if gate_pass else 'FAIL'}")

    summary_path = out_dir / "hmc_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2))
    print(f"  summary -> {summary_path}", flush=True)

    _plot_posterior(all_chains, args, out_dir)
    print("Done.", flush=True)


if __name__ == "__main__":
    main()
