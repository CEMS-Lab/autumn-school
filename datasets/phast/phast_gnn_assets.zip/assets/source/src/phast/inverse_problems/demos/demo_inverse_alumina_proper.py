#!/usr/bin/env python
"""Proper alumina G_c inversion: Bleyer-style pre-strained SENT with
AT1/Amor and a physically saner regularisation length.

Replaces the earlier ``demo_inverse_alumina_gc.py`` (l0 = 0.5 mm,
AT2/spectral, ramp traction) which produced a wide AT2 process zone
+ saturated loaded edges rather than a sharp crack. The protocol
here mirrors §3.3 of Bleyer, Roux-Langlois \\& Molinari (2017):

  Step 1: Quasi-static pre-strain to ``delta_U`` on top/bottom.
  Step 2: Hold ``delta_U``, release dynamics, crack propagates from
          stored elastic energy with no external forces.

Material (alumina, Kumar & Lopez-Pamies 2020 with phase-field length
chosen at the Bleyer 2017 PMMA scale rather than the alumina-physical
um scale, so the truth simulation runs in tens of minutes on an A100):
  E   = 335 GPa, nu = 0.25, rho = 3950 kg/m^3
  Gc  = 26.8 J/m^2 = 0.0268 N/mm
  l0  = 0.1 mm
  pf_model = AT1, energy_split = amor, plane_stress = True

Geometry: 32 x 16 mm with 4 mm edge notch at y = 8 mm (Bleyer Fig 4).

Pre-strain default: delta_U = 0.0015 mm. Critical strain for the
edge-notched plate is approximately
  sigma_inf,c = K_c / (1.12 sqrt(pi a))   with   K_c = sqrt(E_eff Gc)
  E_eff = E/(1-nu^2) ~ 357 GPa, K_c ~ 97.8 MPa sqrt(mm),
  sigma_inf,c ~ 24.7 MPa, eps_c = sigma_inf,c / E_eff ~ 6.9e-5,
  delta_U,c ~ eps_c * H/2 ~ 5.5e-4 mm.
delta_U = 0.0015 mm sits at ~2.7 x critical: enough strain energy is
stored that the inversion sees a strong d-vs-Gc signal (max psi+
~ 0.5, full crack development within ~10 us) without overdriving the
loaded edges.

Inversion: scalar G_c, log-space Adam or L-BFGS-with-strong-Wolfe.
Defaults to L-BFGS (the headline result of §4.1). Central finite
differences supply the gradient; the autograd path is exercised in
the §4.3 spatial-G_c demo.

Usage:
  python demo_inverse_alumina_proper.py --device cuda --n_iters 5
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.mesh_generator import rectangular_sent as gen_mesh
from phast.mesh import FEMMesh
from phast.material import create_material
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.device import DeviceContext


# Bleyer 2017 §3.3 geometry
W_PLATE, H_PLATE = 32.0, 16.0   # mm
A_NOTCH = 4.0                   # mm
Y_NOTCH = H_PLATE / 2.0         # = 8 mm

# Alumina material at Bleyer length scale (see header docstring).
GC_TRUE = 0.0268    # N/mm = 26.8 J/m^2
L0      = 0.1       # mm
E_GPa   = 335.0
NU      = 0.25
RHO     = 3.95e-9   # tonne/mm^3 = 3950 kg/m^3


def build_mesh(h_crack: float, h_coarse: float,
               device: str, dtype: torch.dtype) -> FEMMesh:
    msh_path = "/tmp/alumina_proper_sent.msh"
    gen_mesh(msh_path, W=W_PLATE, H=H_PLATE, a=A_NOTCH,
             l0=L0, h_crack=h_crack, h_coarse=h_coarse, branching=False)
    mesh = FEMMesh(msh_path, device=device, dtype=dtype)
    mesh.identify_boundaries()
    return mesh


def build_solver(mesh: FEMMesh, Gc: float, device: str, dtype, dt_ns):
    mat = create_material(
        E=E_GPa * 1e3, nu=NU, rho=RHO, Gc=Gc, l0=L0,
        energy_split='amor', pf_model='AT1', plane_stress=True,
        gamma_correction=True,
    )
    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)
    bcs.add(mesh.node_sets['top'],    component=1, value=+dt_ns)
    bcs.add(mesh.node_sets['bottom'], component=1, value=-dt_ns)
    bcs.fix(mesh.node_sets['left'], component=0)
    cfg = SolverConfig(
        solver_type='explicit', differentiable=False,
        damage_every=1, preconditioner='jacobi',
    )
    return StaggeredSolver(mesh, mat, bcs, config=cfg,
                            ctx=DeviceContext(device, dtype))


def run_truth(mesh, Gc, delta_U, n_steps, device, dtype):
    solver = build_solver(mesh, Gc, device, dtype, delta_U)
    solver.pre_strain(coupled=False)
    for _ in range(n_steps):
        solver.step_full()
    return solver.d.detach()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device',     type=str,   default='cpu')
    p.add_argument('--h_crack',    type=float, default=0.025,
                   help='Mesh size in fracture zone (default l0/4 = 0.025 mm)')
    p.add_argument('--h_coarse',   type=float, default=1.0)
    p.add_argument('--n_steps',    type=int,   default=2000,
                   help='Explicit dynamics steps (default 2000)')
    p.add_argument('--n_iters',    type=int,   default=5)
    p.add_argument('--Gc_init',    type=float, default=0.0536,
                   help='2x truth (default 0.0536 N/mm = 53.6 J/m^2)')
    p.add_argument('--delta_U',    type=float, default=0.0015,
                   help='Pre-strain in mm (default 0.0015 mm = ~2.7x critical)')
    p.add_argument('--optimizer',  type=str,   default='lbfgs',
                   choices=['adam', 'lbfgs'])
    p.add_argument('--lr',         type=float, default=0.05)
    p.add_argument('--output_dir', type=str,
                   default='results_inverse_alumina_proper')
    args = p.parse_args()

    out_dir = (args.output_dir if os.path.isabs(args.output_dir)
               else os.path.join(THIS_DIR, args.output_dir))
    os.makedirs(out_dir, exist_ok=True)

    device, dtype = args.device, torch.float64
    print("=" * 70)
    print("  Alumina G_c inversion (proper, Bleyer-style pre-strain)")
    print("=" * 70)

    mesh = build_mesh(args.h_crack, args.h_coarse, device, dtype)
    print(f"  Mesh: {mesh.n_nodes} nodes, {mesh.elements.shape[0]} elements")
    print(f"  Material: alumina, E={E_GPa} GPa, nu={NU}, "
          f"rho={RHO*1e9:.0f} kg/m^3")
    print(f"  Phase-field: AT1/Amor/plane-stress, l0={L0} mm, "
          f"Gc*={GC_TRUE*1e3:.1f} J/m^2")
    print(f"  Pre-strain delta_U = {args.delta_U} mm")

    # ---- Truth forward run ----
    print(f"\n[1/3] Forward sim at truth Gc = {GC_TRUE*1e3:.1f} J/m^2 "
          f"({args.n_steps} steps) ...")
    t_truth = time.time()
    d_target = run_truth(mesh, GC_TRUE, args.delta_U, args.n_steps,
                         device, dtype)
    print(f"  Truth done in {time.time()-t_truth:.1f} s, "
          f"max(d)={d_target.max().item():.3f}, "
          f"damaged nodes={(d_target>0.5).sum().item()}")

    # ---- Save truth damage field for the figure ----
    np.savez(os.path.join(out_dir, 'damage_truth.npz'),
             nodes=mesh.nodes.cpu().numpy(),
             elements=mesh.elements.cpu().numpy(),
             d_target=d_target.cpu().numpy(),
             Gc_true_Jpm2=GC_TRUE*1e3,
             delta_U_mm=args.delta_U,
             n_steps=args.n_steps,
             W_plate=W_PLATE, H_plate=H_PLATE, a_notch=A_NOTCH)

    # ---- Inversion via central FD on log_Gc ----
    log_Gc = torch.tensor(math.log(args.Gc_init),
                           dtype=dtype, device=device, requires_grad=True)
    counter = {'n': 0}

    def loss_and_grad(Gc):
        delta = Gc * 0.05
        with torch.no_grad():
            losses = []
            for g in (Gc, Gc + delta, Gc - delta):
                d = run_truth(mesh, g, args.delta_U, args.n_steps,
                              device, dtype)
                losses.append(((d - d_target) ** 2).mean().item())
                counter['n'] += 1
        loss_c, loss_p, loss_m = losses
        dL_dGc = (loss_p - loss_m) / (2 * delta)
        return loss_c, dL_dGc * Gc       # log-space chain rule

    print(f"\n[2/3] Inversion via {args.optimizer.upper()} from "
          f"Gc0 = {args.Gc_init*1e3:.1f} J/m^2 "
          f"(= {args.Gc_init/GC_TRUE:.2f} x truth) ...")
    t_inv = time.time()
    history = []

    if args.optimizer == 'adam':
        opt = torch.optim.Adam([log_Gc], lr=args.lr)
        for it in range(args.n_iters):
            opt.zero_grad()
            Gc_now = float(torch.exp(log_Gc))
            loss_c, g = loss_and_grad(Gc_now)
            log_Gc.grad = torch.tensor(g, dtype=dtype, device=device)
            opt.step()
            Gc_v = float(torch.exp(log_Gc))
            err = abs(Gc_v - GC_TRUE) / GC_TRUE
            history.append(dict(iter=it, Gc_Jpm2=Gc_v*1e3, loss=loss_c,
                                rel_err=err, forward_evals=counter['n']))
            print(f"  iter {it:3d}: Gc={Gc_v*1e3:.3f} J/m^2 "
                  f"(err {err:.2%}), loss={loss_c:.3e}, "
                  f"fwd={counter['n']}")
    else:
        opt = torch.optim.LBFGS([log_Gc], lr=1.0, max_iter=1,
                                tolerance_grad=1e-12,
                                tolerance_change=1e-12,
                                history_size=10,
                                line_search_fn='strong_wolfe')
        for it in range(args.n_iters):
            def closure():
                opt.zero_grad()
                Gc_now = float(torch.exp(log_Gc))
                loss_v, g = loss_and_grad(Gc_now)
                log_Gc.grad = torch.tensor(g, dtype=dtype, device=device)
                return torch.tensor(loss_v, dtype=dtype, device=device)
            loss_v = float(opt.step(closure))
            Gc_v = float(torch.exp(log_Gc))
            err = abs(Gc_v - GC_TRUE) / GC_TRUE
            history.append(dict(iter=it, Gc_Jpm2=Gc_v*1e3, loss=loss_v,
                                rel_err=err, forward_evals=counter['n']))
            print(f"  iter {it:2d}: Gc={Gc_v*1e3:.3f} J/m^2 "
                  f"(err {err:.2%}), loss={loss_v:.3e}, "
                  f"fwd={counter['n']}")
            if err < 1e-3:
                print(f"  Converged: rel_err < 0.1% at iter {it}")
                break

    Gc_final = float(torch.exp(log_Gc))
    err_final = abs(Gc_final - GC_TRUE) / GC_TRUE
    wall = time.time() - t_inv
    print(f"\n[3/3] Result: Gc = {Gc_final*1e3:.3f} J/m^2 "
          f"(true {GC_TRUE*1e3:.1f}), err {err_final:.2%}, "
          f"{counter['n']} forward sims, {wall:.1f} s")

    with open(os.path.join(out_dir, 'demo_inverse_alumina_proper.json'),
              'w') as fh:
        json.dump({
            'material':         'alumina (Kumar & Lopez-Pamies 2020), Bleyer-scale l0',
            'protocol':         'Bleyer-2017 pre-strain (AT1/Amor/plane stress)',
            'Gc_true_Jpm2':     GC_TRUE * 1e3,
            'Gc_init_Jpm2':     args.Gc_init * 1e3,
            'Gc_final_Jpm2':    Gc_final * 1e3,
            'delta_U_mm':       args.delta_U,
            'n_steps':          args.n_steps,
            'h_crack_mm':       args.h_crack,
            'l0_mm':            L0,
            'rel_err':          err_final,
            'forward_sims':     counter['n'],
            'wall_time_s':      wall,
            'optimizer':        args.optimizer,
            'history':          history,
        }, fh, indent=2)
    print(f"  Saved JSON: {out_dir}/demo_inverse_alumina_proper.json")
    print(f"  Saved damage NPZ: {out_dir}/damage_truth.npz")


if __name__ == '__main__':
    main()
