"""Reusable replay losses for inverse-problem observation histories.

The inverse demos often compare a simulated history against recorded or
projected observations: reaction curves, sparse DIC displacements, damage
frames, or other per-step channels.  This module centralises the bookkeeping
that is easy to get wrong in those drivers:

* align full simulated histories with sparse observation step indices;
* safely truncate the comparison when a simulation stops early;
* apply channel masks and channel weights without detaching gradients;
* report per-channel components for paper tables and diagnostics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import torch


TensorMap = Mapping[str, torch.Tensor]


@dataclass(frozen=True)
class ReplayLossResult:
    """Scalar replay loss and named component losses."""

    total: torch.Tensor
    components: dict[str, torch.Tensor]
    n_steps_used: int


@dataclass(frozen=True)
class ReplayResidualResult:
    """PDE replay residual and its mean-square loss."""

    residual: torch.Tensor
    loss: torch.Tensor


def _as_1d_long(
    step_indices: torch.Tensor | list[int] | tuple[int, ...] | None,
) -> torch.Tensor | None:
    if step_indices is None:
        return None
    steps = torch.as_tensor(step_indices, dtype=torch.long)
    if steps.ndim != 1:
        raise ValueError(f"step_indices must be 1-D, got shape {tuple(steps.shape)}")
    if steps.numel() == 0:
        raise ValueError("step_indices must not be empty")
    if bool((steps < 0).any()):
        raise ValueError("step_indices must be non-negative")
    return steps


def _masked_mean_square(
    residual: torch.Tensor,
    mask: torch.Tensor | None,
) -> torch.Tensor:
    sq = residual.pow(2)
    if mask is None:
        return sq.mean()

    m = mask.to(device=sq.device, dtype=sq.dtype)
    while m.ndim < sq.ndim:
        m = m.unsqueeze(0)
    try:
        m = torch.broadcast_to(m, sq.shape)
    except RuntimeError as exc:
        raise ValueError(
            f"mask shape {tuple(mask.shape)} cannot broadcast to residual "
            f"shape {tuple(sq.shape)}"
        ) from exc
    denom = m.sum().clamp_min(torch.finfo(sq.dtype).eps)
    return (sq * m).sum() / denom


def dirichlet_free_dof_mask(bcs) -> torch.Tensor:
    """Return ``True`` on unconstrained displacement DOFs.

    The phase-field inverse replay uses equilibrium only on free mechanical
    DOFs.  Displacement-controlled nodes instead carry reactions, so including
    them in the equilibrium norm would mix two different observations.
    """

    bc_mask, _ = bcs.get_masks_and_values()
    return ~bc_mask


def mechanics_replay_residual(
    fem,
    u: torch.Tensor,
    d: torch.Tensor,
    *,
    free_dof_mask: torch.Tensor | None = None,
    bcs=None,
    external_force: torch.Tensor | None = None,
    scale: float | torch.Tensor | None = None,
) -> ReplayResidualResult:
    """Replay the mechanical equilibrium residual for observed ``u,d``.

    This does not advance the solver.  It evaluates
    ``R_u = f_int(u,d) - f_ext`` on an observed frame and, by default, returns
    the mean-square residual on the supplied free-DOF mask.  For
    displacement-controlled quasi-static tests, pass ``bcs`` so constrained
    rows are removed and reactions can be compared separately.
    """

    f_int = fem.internal_force(u, d)
    residual = f_int if external_force is None else f_int - external_force.to(
        device=f_int.device, dtype=f_int.dtype
    )
    if free_dof_mask is None and bcs is not None:
        free_dof_mask = dirichlet_free_dof_mask(bcs)
    if scale is not None:
        scale_t = torch.as_tensor(scale, device=residual.device, dtype=residual.dtype)
        residual = residual / scale_t.clamp_min(torch.finfo(residual.dtype).eps)
    loss = _masked_mean_square(residual, free_dof_mask)
    return ReplayResidualResult(residual=residual, loss=loss)


def replay_reaction_force(
    fem,
    u: torch.Tensor,
    d: torch.Tensor,
    node_indices: torch.Tensor,
    *,
    component: int,
) -> torch.Tensor:
    """Differentiable summed reaction force on a displacement boundary."""

    nodes = torch.as_tensor(node_indices, dtype=torch.long, device=u.device)
    return fem.internal_force(u, d)[nodes, int(component)].sum()


def _as_element_field(value: float | torch.Tensor, mesh, *, dtype, device) -> torch.Tensor:
    value_t = torch.as_tensor(value, dtype=dtype, device=device)
    if value_t.ndim == 0:
        return value_t.expand(mesh.n_elems)
    if value_t.shape != (mesh.n_elems,):
        raise ValueError(
            f"element field must have shape ({mesh.n_elems},), got {tuple(value_t.shape)}"
        )
    return value_t


def _require_t3(mesh, helper_name: str) -> None:
    if getattr(mesh, "element_type", "T3") != "T3":
        raise NotImplementedError(f"{helper_name} currently supports T3 meshes")


def _laplacian_coeff_matvec(mesh, coeff_elem: torch.Tensor, nodal: torch.Tensor) -> torch.Tensor:
    """Return ``K(coeff) @ nodal`` for linear triangles."""

    _require_t3(mesh, "_laplacian_coeff_matvec")
    gp = mesh.grad_phi
    elems = mesh.elements
    nodal_e = nodal[elems]
    grad_x = (gp[:, :, 0] * nodal_e).sum(1)
    grad_y = (gp[:, :, 1] * nodal_e).sum(1)
    weighted_area = mesh.areas * coeff_elem
    contrib = weighted_area.unsqueeze(1) * (
        gp[:, :, 0] * grad_x.unsqueeze(1) + gp[:, :, 1] * grad_y.unsqueeze(1)
    )
    out = torch.zeros(mesh.n_nodes, dtype=nodal.dtype, device=nodal.device)
    out.scatter_add_(0, elems.reshape(-1), contrib.reshape(-1))
    return out


def _consistent_mass_coeff_matvec(
    mesh,
    coeff_elem: torch.Tensor,
    nodal: torch.Tensor,
) -> torch.Tensor:
    """Return ``M(coeff) @ nodal`` using the T3 consistent mass matrix."""

    _require_t3(mesh, "_consistent_mass_coeff_matvec")
    elems = mesh.elements
    nodal_e = nodal[elems]
    coeff = mesh.areas * coeff_elem / 12.0
    local = coeff.unsqueeze(1) * (nodal_e + nodal_e.sum(1, keepdim=True))
    out = torch.zeros(mesh.n_nodes, dtype=nodal.dtype, device=nodal.device)
    out.scatter_add_(0, elems.reshape(-1), local.reshape(-1))
    return out


def _consistent_mass_coeff_times_one(
    mesh,
    coeff_elem: torch.Tensor,
    dtype,
    device,
) -> torch.Tensor:
    """Return ``M(coeff) @ 1`` using the T3 consistent mass matrix."""

    _require_t3(mesh, "_consistent_mass_coeff_times_one")
    local = (mesh.areas * coeff_elem / 3.0).unsqueeze(1).expand(-1, 3)
    out = torch.zeros(mesh.n_nodes, dtype=dtype, device=device)
    out.scatter_add_(0, mesh.elements.reshape(-1), local.reshape(-1))
    return out


def damage_replay_residual(
    fem,
    H_elem: torch.Tensor,
    d: torch.Tensor,
    *,
    Gc: float | torch.Tensor,
    l0: float | torch.Tensor,
    pf_model: str = "AT2",
    d_prev: torch.Tensor | None = None,
    fixed_damage_mask: torch.Tensor | None = None,
    project_active_bounds: bool = False,
    scale: float | torch.Tensor | None = None,
) -> ReplayResidualResult:
    """Replay the phase-field damage weak-form residual for observed ``d``.

    ``H_elem`` is the element history/driving field associated with the frame.
    If observed history is unavailable, callers may compute it from observed
    displacements via ``fem.compute_psi_plus(u)`` before calling this helper.
    The residual keeps gradients to scalar or per-element ``Gc`` tensors, so
    it is the replay term that makes toughness calibration identifiable.
    """

    mesh = fem.mesh
    dtype = d.dtype
    device = d.device
    H_e = torch.as_tensor(H_elem, dtype=dtype, device=device)
    if H_e.shape != (mesh.n_elems,):
        raise ValueError(f"H_elem must have shape ({mesh.n_elems},), got {tuple(H_e.shape)}")
    Gc_e = _as_element_field(Gc, mesh, dtype=dtype, device=device)
    l0_t = torch.as_tensor(l0, dtype=dtype, device=device)
    if l0_t.ndim != 0:
        raise ValueError("l0 must be a scalar")
    model = pf_model.upper()

    if model == "AT2":
        residual = (
            _laplacian_coeff_matvec(mesh, Gc_e * l0_t, d)
            + _consistent_mass_coeff_matvec(mesh, 2.0 * H_e + Gc_e / l0_t, d)
            - _consistent_mass_coeff_times_one(mesh, 2.0 * H_e, dtype, device)
        )
    elif model == "AT1":
        at1_source = 2.0 * H_e - 3.0 * Gc_e / (8.0 * l0_t)
        residual = (
            _laplacian_coeff_matvec(mesh, 0.75 * Gc_e * l0_t, d)
            + _consistent_mass_coeff_matvec(mesh, 2.0 * H_e, d)
            - _consistent_mass_coeff_times_one(mesh, at1_source, dtype, device)
        )
    else:
        raise ValueError(f"pf_model must be 'AT1' or 'AT2', got {pf_model!r}")

    if fixed_damage_mask is not None:
        fixed = fixed_damage_mask.to(device=device, dtype=torch.bool)
        if fixed.shape != d.shape:
            raise ValueError(f"fixed_damage_mask must have shape {tuple(d.shape)}")
        residual = torch.where(fixed, torch.zeros_like(residual), residual)

    if project_active_bounds:
        if d_prev is None:
            raise ValueError("d_prev is required when project_active_bounds=True")
        lower = torch.as_tensor(d_prev, dtype=dtype, device=device)
        active = (
            ((d <= lower + 1.0e-12) & (residual < 0.0))
            | ((d >= 1.0 - 1.0e-12) & (residual > 0.0))
        )
        if fixed_damage_mask is not None:
            active = active | fixed_damage_mask.to(device=device, dtype=torch.bool)
        residual = torch.where(active, torch.zeros_like(residual), residual)

    if scale is not None:
        scale_t = torch.as_tensor(scale, dtype=dtype, device=device)
        residual = residual / scale_t.clamp_min(torch.finfo(dtype).eps)
    return ReplayResidualResult(residual=residual, loss=residual.pow(2).mean())


class ReplayLoss:
    """Compare simulated histories against stored observation histories.

    Parameters
    ----------
    target_history:
        Mapping from channel name to observed tensor.  The first dimension is
        the observation/time dimension for every channel.
    step_indices:
        Optional integer indices locating each observation row in a full
        simulated history.  If a prediction channel already has the same
        number of rows as the target channel, rows are compared directly.
        Otherwise, prediction rows are gathered at these step indices.
    masks:
        Optional per-channel masks.  A mask may have the same shape as the
        residual or omit the leading time dimension.
    weights:
        Optional scalar multiplier per channel.
    scales:
        Optional normalisation scale per channel.  By default, each channel is
        scaled by ``max(abs(target), 1)`` to make reaction and displacement
        histories comparable without hand-tuning every test.
    truncate:
        If True, ignore observations beyond the available prediction length.
        This is important for cutback/early-stop inverse runs: a short
        simulation should produce a clean prefix loss, not an indexing crash or
        zero-filled tail.  If False, missing prediction rows raise.
    """

    def __init__(
        self,
        target_history: TensorMap,
        *,
        step_indices: torch.Tensor | list[int] | tuple[int, ...] | None = None,
        masks: TensorMap | None = None,
        weights: Mapping[str, float] | None = None,
        scales: Mapping[str, float | torch.Tensor] | None = None,
        truncate: bool = True,
    ) -> None:
        if not target_history:
            raise ValueError("target_history must contain at least one channel")
        self.target_history = {
            name: target.detach().clone()
            for name, target in target_history.items()
        }
        for name, target in self.target_history.items():
            if target.ndim == 0:
                raise ValueError(f"target channel {name!r} must have a time dimension")
        self.step_indices = _as_1d_long(step_indices)
        if self.step_indices is not None:
            for name, target in self.target_history.items():
                if target.shape[0] != self.step_indices.numel():
                    raise ValueError(
                        f"target channel {name!r} has {target.shape[0]} rows but "
                        f"step_indices has {self.step_indices.numel()} entries"
                    )
        self.masks = dict(masks or {})
        self.weights = dict(weights or {})
        self.scales = dict(scales or {})
        self.truncate = bool(truncate)

    def _align_channel(
        self,
        name: str,
        pred: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        target = self.target_history[name].to(device=pred.device, dtype=pred.dtype)
        if pred.ndim == 0:
            raise ValueError(f"prediction channel {name!r} must have a time dimension")

        if self.step_indices is None or pred.shape[0] == target.shape[0]:
            n = min(pred.shape[0], target.shape[0])
            if not self.truncate and pred.shape[0] < target.shape[0]:
                raise ValueError(
                    f"prediction channel {name!r} has {pred.shape[0]} rows, "
                    f"target has {target.shape[0]}"
                )
            return pred[:n], target[:n]

        steps = self.step_indices.to(device=pred.device)
        valid = steps < pred.shape[0]
        if not bool(valid.all()) and not self.truncate:
            missing = steps[~valid].detach().cpu().tolist()
            raise ValueError(
                f"prediction channel {name!r} is missing observation steps {missing}"
            )
        if not bool(valid.any()):
            raise ValueError(
                f"prediction channel {name!r} has no rows matching observation steps"
            )
        return pred[steps[valid]], target[valid]

    def __call__(
        self,
        prediction_history: TensorMap,
        *,
        regularization: Mapping[str, torch.Tensor] | None = None,
    ) -> ReplayLossResult:
        missing = sorted(set(self.target_history) - set(prediction_history))
        if missing:
            raise KeyError(f"prediction_history missing channels: {missing}")

        components: dict[str, torch.Tensor] = {}
        total: torch.Tensor | None = None
        n_steps_used: int | None = None

        for name in self.target_history:
            pred, target = self._align_channel(name, prediction_history[name])
            n_steps_used = (
                pred.shape[0]
                if n_steps_used is None
                else min(n_steps_used, pred.shape[0])
            )
            scale = self.scales.get(name, None)
            if scale is None:
                scale_t = target.detach().abs().max().clamp_min(
                    torch.ones((), device=target.device, dtype=target.dtype)
                )
            else:
                scale_t = torch.as_tensor(
                    scale, dtype=target.dtype, device=target.device
                ).clamp_min(torch.finfo(target.dtype).eps)
            residual = (pred - target.detach()) / scale_t
            loss = _masked_mean_square(residual, self.masks.get(name))
            weighted = float(self.weights.get(name, 1.0)) * loss
            components[name] = weighted
            total = weighted if total is None else total + weighted

        for name, value in (regularization or {}).items():
            components[name] = value
            total = value if total is None else total + value

        assert total is not None
        assert n_steps_used is not None
        return ReplayLossResult(total=total, components=components, n_steps_used=n_steps_used)


__all__ = [
    "ReplayLoss",
    "ReplayLossResult",
    "ReplayResidualResult",
    "damage_replay_residual",
    "dirichlet_free_dof_mask",
    "mechanics_replay_residual",
    "replay_reaction_force",
]
