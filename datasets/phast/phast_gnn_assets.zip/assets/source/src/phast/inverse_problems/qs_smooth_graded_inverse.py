"""QS phase-field inverse recovery for smooth graded E/Gc material zones."""

from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import numpy as np
import torch

from phast.boundary_conditions import BoundaryConditions
from phast.device import DeviceContext
from phast.inverse_problems.parametrisations import (
    element_centroids,
    smooth_stiffness_field,
    smooth_toughness_field,
)
from phast.material import create_material
from phast.mesh import FEMMesh
from phast.mesh_generator import miehe_tension
from phast.staggered_solver import SolverConfig, StaggeredSolver

Mode = Literal["E", "Gc", "coupled"]


@dataclass(frozen=True)
class SmoothGradedConfig:
    """Small QS PF benchmark for smooth material-zone inverse recovery."""

    l0: float = 0.06
    h_crack: float = 0.08
    h_coarse: float = 0.22
    E_bulk: float = 210000.0
    Gc_bulk: float = 2.7
    nu: float = 0.30
    true_center: tuple[float, float] = (0.62, 0.54)
    init_center: tuple[float, float] = (0.50, 0.66)
    true_sigma: float = 0.15
    init_sigma: float = 0.23
    true_E_amplitude: float = -0.32
    init_E_amplitude: float = -0.12
    true_Gc_amplitude: float = -0.42
    init_Gc_amplitude: float = -0.15
    displacements: tuple[float, ...] = (0.002, 0.004, 0.006, 0.008)
    energy_split: str = "isotropic"
    pf_model: str = "AT2"
    backend: str = "scipy"
    stagger_tol: float = 1.0e-6
    max_stagger: int = 140
    damage_tol: float = 1.0e-8
    static_tol: float = 1.0e-9
    dic_stride: int = 18
    reaction_weight: float = 1.0
    dic_weight: float = 0.10
    damage_weight: float = 0.08
    field_h1_weight: float = 0.0


@dataclass
class SmoothRollout:
    reactions: torch.Tensor
    dic: torch.Tensor
    d_final: torch.Tensor
    u_final: torch.Tensor
    max_damage: torch.Tensor
    mean_damage: torch.Tensor
    E_field: torch.Tensor
    Gc_field: torch.Tensor


def amplitude_to_raw(
    amplitude: float,
    *,
    amplitude_min: float,
    amplitude_max: float,
) -> float:
    """Inverse of the sigmoid amplitude bound used by smooth_graded_field."""

    if not (amplitude_min < amplitude < amplitude_max):
        raise ValueError(
            f"amplitude {amplitude} must lie in ({amplitude_min}, {amplitude_max})"
        )
    z = (amplitude - amplitude_min) / (amplitude_max - amplitude_min)
    return math.log(z / (1.0 - z))


def _raw_to_amplitude(
    raw: torch.Tensor,
    *,
    amplitude_min: float,
    amplitude_max: float,
) -> torch.Tensor:
    return amplitude_min + (amplitude_max - amplitude_min) * torch.sigmoid(raw)


def build_mesh(out_dir: Path, cfg: SmoothGradedConfig, *, verbose: bool = False) -> FEMMesh:
    out_dir.mkdir(parents=True, exist_ok=True)
    mesh_path = out_dir / "smooth_graded_qs.msh"
    miehe_tension(
        str(mesh_path),
        L=1.0,
        a=0.5,
        l0=cfg.l0,
        h_crack=cfg.h_crack,
        h_coarse=cfg.h_coarse,
        verbose=verbose,
    )
    mesh = FEMMesh(str(mesh_path), device="cpu", dtype=torch.float64)
    mesh.identify_boundaries()
    return mesh


def make_solver(mesh: FEMMesh, cfg: SmoothGradedConfig) -> StaggeredSolver:
    material = create_material(
        "miehe_tension",
        E=cfg.E_bulk,
        nu=cfg.nu,
        Gc=cfg.Gc_bulk,
        l0=cfg.l0,
        pf_model=cfg.pf_model,
        energy_split=cfg.energy_split,
        gamma_correction=True,
    )
    bcs = BoundaryConditions(mesh.n_nodes, mesh.device, mesh.dtype)
    bcs.fix(mesh.node_sets["bottom"], 0)
    bcs.fix(mesh.node_sets["bottom"], 1)
    bcs.add(mesh.node_sets["top"], 1, 1.0)
    solver_cfg = SolverConfig(
        solver_type="quasi_static",
        differentiable=True,
        damage_tol=cfg.damage_tol,
        static_tol=cfg.static_tol,
        stagger_tol=cfg.stagger_tol,
        max_stagger=cfg.max_stagger,
        preconditioner="jacobi",
        use_multigrid=False,
        backend=cfg.backend,
    )
    return StaggeredSolver(
        mesh,
        material,
        bcs,
        config=solver_cfg,
        ctx=DeviceContext("cpu", torch.float64),
    )


def dic_node_indices(mesh: FEMMesh, stride: int) -> torch.Tensor:
    stride = max(1, int(stride))
    nodes = mesh.nodes
    interior = torch.where(
        (nodes[:, 0] > 0.05)
        & (nodes[:, 0] < 0.95)
        & (nodes[:, 1] > 0.05)
        & (nodes[:, 1] < 0.95)
    )[0]
    if interior.numel() == 0:
        interior = torch.arange(mesh.n_nodes, dtype=torch.long)
    return interior[::stride].long()


def make_fields(
    mesh: FEMMesh,
    cfg: SmoothGradedConfig,
    *,
    center: torch.Tensor,
    raw_log_sigma: torch.Tensor,
    raw_E_amplitude: torch.Tensor,
    raw_Gc_amplitude: torch.Tensor,
    mode: Mode,
) -> tuple[torch.Tensor, torch.Tensor]:
    coords = element_centroids(mesh)
    if mode in ("E", "coupled"):
        E_field = smooth_stiffness_field(
            coords,
            center=center,
            raw_log_sigma=raw_log_sigma,
            raw_amplitude=raw_E_amplitude,
            E_bulk=cfg.E_bulk,
            amplitude_min=-0.90,
            amplitude_max=1.50,
        )
    else:
        E_field = torch.full(
            (mesh.n_elems,), cfg.E_bulk, dtype=mesh.dtype, device=mesh.device
        )
    if mode in ("Gc", "coupled"):
        Gc_field = smooth_toughness_field(
            coords,
            center=center,
            raw_log_sigma=raw_log_sigma,
            raw_amplitude=raw_Gc_amplitude,
            Gc_bulk=cfg.Gc_bulk,
            amplitude_min=-0.95,
            amplitude_max=1.50,
        )
    else:
        Gc_field = torch.full(
            (mesh.n_elems,), cfg.Gc_bulk, dtype=mesh.dtype, device=mesh.device
        )
    return E_field, Gc_field


def rollout(
    mesh: FEMMesh,
    cfg: SmoothGradedConfig,
    *,
    E_field: torch.Tensor,
    Gc_field: torch.Tensor,
    install_E_field: bool,
) -> SmoothRollout:
    solver = make_solver(mesh, cfg)
    if install_E_field:
        solver.install_diff_E_field(E_field)
    solver.diff_Gc_field = Gc_field
    top = mesh.node_sets["top"]
    dic_idx = dic_node_indices(mesh, cfg.dic_stride)
    reactions = []
    dic_samples = []

    for disp in cfg.displacements:
        solver.bcs.load_factor = float(disp)
        solver.step_full()
        fint = solver.fem.internal_force(solver.u, solver.d)
        reactions.append(fint[top, 1].sum())
        dic_samples.append(solver.u[dic_idx].reshape(-1))

    return SmoothRollout(
        reactions=torch.stack(reactions),
        dic=torch.cat(dic_samples),
        d_final=solver.d,
        u_final=solver.u,
        max_damage=solver.d.max(),
        mean_damage=solver.d.mean(),
        E_field=E_field,
        Gc_field=Gc_field,
    )


def inverse_loss(
    pred: SmoothRollout,
    target: SmoothRollout,
    cfg: SmoothGradedConfig,
) -> torch.Tensor:
    r_scale = target.reactions.detach().abs().max().clamp_min(1.0)
    u_scale = target.dic.detach().abs().max().clamp_min(1.0e-12)
    reaction = ((pred.reactions - target.reactions.detach()) / r_scale).pow(2).mean()
    dic = ((pred.dic - target.dic.detach()) / u_scale).pow(2).mean()
    damage = (pred.d_final - target.d_final.detach()).pow(2).mean()
    return cfg.reaction_weight * reaction + cfg.dic_weight * dic + cfg.damage_weight * damage


def _param_dict(
    *,
    center: torch.Tensor,
    raw_log_sigma: torch.Tensor,
    raw_E_amplitude: torch.Tensor,
    raw_Gc_amplitude: torch.Tensor,
) -> dict[str, float]:
    return {
        "center_x": float(center.detach()[0]),
        "center_y": float(center.detach()[1]),
        "sigma": float(torch.exp(raw_log_sigma.detach())),
        "E_amplitude": float(
            _raw_to_amplitude(
                raw_E_amplitude.detach(),
                amplitude_min=-0.90,
                amplitude_max=1.50,
            )
        ),
        "Gc_amplitude": float(
            _raw_to_amplitude(
                raw_Gc_amplitude.detach(),
                amplitude_min=-0.95,
                amplitude_max=1.50,
            )
        ),
    }


def _field_errors(pred: torch.Tensor, truth: torch.Tensor) -> dict[str, float]:
    diff = pred.detach() - truth.detach()
    return {
        "relative_l2": float(diff.norm() / truth.detach().norm().clamp_min(1.0e-30)),
        "max_abs": float(diff.abs().max()),
    }


def _target_params(cfg: SmoothGradedConfig) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    return (
        torch.tensor(cfg.true_center, dtype=torch.float64),
        torch.tensor(math.log(cfg.true_sigma), dtype=torch.float64),
        torch.tensor(
            amplitude_to_raw(
                cfg.true_E_amplitude,
                amplitude_min=-0.90,
                amplitude_max=1.50,
            ),
            dtype=torch.float64,
        ),
        torch.tensor(
            amplitude_to_raw(
                cfg.true_Gc_amplitude,
                amplitude_min=-0.95,
                amplitude_max=1.50,
            ),
            dtype=torch.float64,
        ),
    )


def _initial_params(
    cfg: SmoothGradedConfig,
    *,
    requires_grad: bool,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    return (
        torch.tensor(cfg.init_center, dtype=torch.float64, requires_grad=requires_grad),
        torch.tensor(math.log(cfg.init_sigma), dtype=torch.float64, requires_grad=requires_grad),
        torch.tensor(
            amplitude_to_raw(
                cfg.init_E_amplitude,
                amplitude_min=-0.90,
                amplitude_max=1.50,
            ),
            dtype=torch.float64,
            requires_grad=requires_grad,
        ),
        torch.tensor(
            amplitude_to_raw(
                cfg.init_Gc_amplitude,
                amplitude_min=-0.95,
                amplitude_max=1.50,
            ),
            dtype=torch.float64,
            requires_grad=requires_grad,
        ),
    )


def _active_params(
    mode: Mode,
    center: torch.Tensor,
    raw_log_sigma: torch.Tensor,
    raw_E_amplitude: torch.Tensor,
    raw_Gc_amplitude: torch.Tensor,
) -> list[torch.Tensor]:
    params = [center, raw_log_sigma]
    if mode in ("E", "coupled"):
        params.append(raw_E_amplitude)
    if mode in ("Gc", "coupled"):
        params.append(raw_Gc_amplitude)
    return params


def run_inverse(
    mesh: FEMMesh,
    cfg: SmoothGradedConfig,
    *,
    mode: Mode,
    max_iter: int = 8,
) -> dict[str, object]:
    true_center, true_log_sigma, true_raw_E, true_raw_Gc = _target_params(cfg)
    E_truth, Gc_truth = make_fields(
        mesh,
        cfg,
        center=true_center,
        raw_log_sigma=true_log_sigma,
        raw_E_amplitude=true_raw_E,
        raw_Gc_amplitude=true_raw_Gc,
        mode=mode,
    )
    target = rollout(mesh, cfg, E_field=E_truth, Gc_field=Gc_truth, install_E_field=mode in ("E", "coupled"))

    center, raw_log_sigma, raw_E_amp, raw_Gc_amp = _initial_params(cfg, requires_grad=True)
    E_init, Gc_init = make_fields(
        mesh,
        cfg,
        center=center,
        raw_log_sigma=raw_log_sigma,
        raw_E_amplitude=raw_E_amp,
        raw_Gc_amplitude=raw_Gc_amp,
        mode=mode,
    )
    initial = rollout(mesh, cfg, E_field=E_init, Gc_field=Gc_init, install_E_field=mode in ("E", "coupled"))
    opt_params = _active_params(mode, center, raw_log_sigma, raw_E_amp, raw_Gc_amp)
    opt = torch.optim.LBFGS(opt_params, lr=0.45, max_iter=max_iter, line_search_fn="strong_wolfe")
    history: list[dict[str, float]] = []

    def closure() -> torch.Tensor:
        opt.zero_grad()
        E_field, Gc_field = make_fields(
            mesh,
            cfg,
            center=center,
            raw_log_sigma=raw_log_sigma,
            raw_E_amplitude=raw_E_amp,
            raw_Gc_amplitude=raw_Gc_amp,
            mode=mode,
        )
        pred = rollout(
            mesh,
            cfg,
            E_field=E_field,
            Gc_field=Gc_field,
            install_E_field=mode in ("E", "coupled"),
        )
        loss = inverse_loss(pred, target, cfg)
        loss.backward()
        row = _param_dict(
            center=center,
            raw_log_sigma=raw_log_sigma,
            raw_E_amplitude=raw_E_amp,
            raw_Gc_amplitude=raw_Gc_amp,
        )
        row.update(
            {
                "loss": float(loss.detach()),
                "grad_norm": float(
                    torch.sqrt(
                        sum(
                            p.grad.detach().pow(2).sum()
                            for p in opt_params
                            if p.grad is not None
                        )
                    )
                ),
            }
        )
        history.append(row)
        return loss

    opt.step(closure)
    E_rec, Gc_rec = make_fields(
        mesh,
        cfg,
        center=center,
        raw_log_sigma=raw_log_sigma,
        raw_E_amplitude=raw_E_amp,
        raw_Gc_amplitude=raw_Gc_amp,
        mode=mode,
    )
    recovered = rollout(mesh, cfg, E_field=E_rec, Gc_field=Gc_rec, install_E_field=mode in ("E", "coupled"))

    gradcheck = gradient_check(
        mesh,
        cfg,
        mode=mode,
        target=target,
        eps=1.0e-4,
    )
    truth_params = _param_dict(
        center=true_center,
        raw_log_sigma=true_log_sigma,
        raw_E_amplitude=true_raw_E,
        raw_Gc_amplitude=true_raw_Gc,
    )
    init_params = _param_dict(
        center=torch.tensor(cfg.init_center, dtype=torch.float64),
        raw_log_sigma=torch.tensor(math.log(cfg.init_sigma), dtype=torch.float64),
        raw_E_amplitude=torch.tensor(
            amplitude_to_raw(cfg.init_E_amplitude, amplitude_min=-0.90, amplitude_max=1.50),
            dtype=torch.float64,
        ),
        raw_Gc_amplitude=torch.tensor(
            amplitude_to_raw(cfg.init_Gc_amplitude, amplitude_min=-0.95, amplitude_max=1.50),
            dtype=torch.float64,
        ),
    )
    rec_params = _param_dict(
        center=center,
        raw_log_sigma=raw_log_sigma,
        raw_E_amplitude=raw_E_amp,
        raw_Gc_amplitude=raw_Gc_amp,
    )
    return {
        "mode": mode,
        "target": target,
        "initial": initial,
        "recovered": recovered,
        "history": history,
        "truth_params": truth_params,
        "initial_params": init_params,
        "recovered_params": rec_params,
        "field_errors": {
            "E_initial": _field_errors(E_init, E_truth),
            "E_recovered": _field_errors(E_rec, E_truth),
            "Gc_initial": _field_errors(Gc_init, Gc_truth),
            "Gc_recovered": _field_errors(Gc_rec, Gc_truth),
        },
        "response_errors": {
            "initial_loss": history[0]["loss"] if history else float("nan"),
            "final_loss": history[-1]["loss"] if history else float("nan"),
            "max_damage_target": float(target.max_damage.detach()),
            "max_damage_initial": float(initial.max_damage.detach()),
            "max_damage_recovered": float(recovered.max_damage.detach()),
        },
        "gradcheck": gradcheck,
        "claim_boundary": (
            "Full QS PF/autograd smooth graded material-zone inverse on synthetic "
            "reaction + sparse-DIC + damage observations; not lab-data validation."
        ),
    }


def gradient_check(
    mesh: FEMMesh,
    cfg: SmoothGradedConfig,
    *,
    mode: Mode,
    target: SmoothRollout,
    eps: float,
) -> dict[str, object]:
    center, raw_log_sigma, raw_E_amp, raw_Gc_amp = _initial_params(cfg, requires_grad=True)

    def loss_from_current() -> torch.Tensor:
        E_field, Gc_field = make_fields(
            mesh,
            cfg,
            center=center,
            raw_log_sigma=raw_log_sigma,
            raw_E_amplitude=raw_E_amp,
            raw_Gc_amplitude=raw_Gc_amp,
            mode=mode,
        )
        return inverse_loss(
            rollout(
                mesh,
                cfg,
                E_field=E_field,
                Gc_field=Gc_field,
                install_E_field=mode in ("E", "coupled"),
            ),
            target,
            cfg,
        )

    loss = loss_from_current()
    loss.backward()
    active = _active_params(mode, center, raw_log_sigma, raw_E_amp, raw_Gc_amp)
    names = ["center", "log_sigma"]
    if mode in ("E", "coupled"):
        names.append("raw_E_amplitude")
    if mode in ("Gc", "coupled"):
        names.append("raw_Gc_amplitude")
    ad_values = []
    fd_values = []

    # Check one scalar component per active tensor. For center, use x because
    # y can be weakly identified on very coarse smoke meshes.
    for name, param in zip(names, active):
        if param.ndim == 0:
            ad_values.append(float(param.grad.detach()))
            original = float(param.detach())
            vals = []
            for sign in (1.0, -1.0):
                with torch.no_grad():
                    param.copy_(torch.tensor(original + sign * eps, dtype=param.dtype))
                vals.append(float(loss_from_current().detach()))
            with torch.no_grad():
                param.copy_(torch.tensor(original, dtype=param.dtype))
        else:
            ad_values.append(float(param.grad.detach()[0]))
            original = float(param.detach()[0])
            vals = []
            for sign in (1.0, -1.0):
                with torch.no_grad():
                    param[0] = original + sign * eps
                vals.append(float(loss_from_current().detach()))
            with torch.no_grad():
                param[0] = original
        fd_values.append((vals[0] - vals[1]) / (2.0 * eps))

    rel_errors = [
        abs(a - f) / max(abs(f), 1.0e-30)
        for a, f in zip(ad_values, fd_values)
    ]
    return {
        "loss_at_init": float(loss.detach()),
        "names": names,
        "autograd": ad_values,
        "finite_difference": fd_values,
        "relative_errors": rel_errors,
        "max_relative_error": max(rel_errors) if rel_errors else math.nan,
    }


def save_artifacts(mesh: FEMMesh, cfg: SmoothGradedConfig, result: dict[str, object], out_dir: Path) -> dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    summary_path = out_dir / "summary.json"
    history_path = out_dir / "history.csv"
    arrays_path = out_dir / "fields_and_response.npz"
    figure_path = out_dir / "smooth_graded_inverse.png"
    pdf_path = out_dir / "smooth_graded_inverse.pdf"

    target: SmoothRollout = result["target"]
    initial: SmoothRollout = result["initial"]
    recovered: SmoothRollout = result["recovered"]
    history: list[dict[str, float]] = result["history"]

    summary = {
        "mode": result["mode"],
        "claim_boundary": result["claim_boundary"],
        "config": {
            "l0": cfg.l0,
            "h_crack": cfg.h_crack,
            "h_coarse": cfg.h_coarse,
            "displacements": list(cfg.displacements),
            "energy_split": cfg.energy_split,
            "pf_model": cfg.pf_model,
            "backend": cfg.backend,
        },
        "truth_params": result["truth_params"],
        "initial_params": result["initial_params"],
        "recovered_params": result["recovered_params"],
        "field_errors": result["field_errors"],
        "response_errors": result["response_errors"],
        "gradcheck": result["gradcheck"],
        "figures": {
            "png": str(figure_path),
            "pdf": str(pdf_path),
        },
    }
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    if history:
        with history_path.open("w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(history[0].keys()))
            writer.writeheader()
            writer.writerows(history)
    np.savez(
        arrays_path,
        nodes=mesh.nodes.detach().cpu().numpy(),
        elements=mesh.elements.detach().cpu().numpy(),
        E_truth=target.E_field.detach().cpu().numpy(),
        E_initial=initial.E_field.detach().cpu().numpy(),
        E_recovered=recovered.E_field.detach().cpu().numpy(),
        Gc_truth=target.Gc_field.detach().cpu().numpy(),
        Gc_initial=initial.Gc_field.detach().cpu().numpy(),
        Gc_recovered=recovered.Gc_field.detach().cpu().numpy(),
        d_truth=target.d_final.detach().cpu().numpy(),
        d_initial=initial.d_final.detach().cpu().numpy(),
        d_recovered=recovered.d_final.detach().cpu().numpy(),
        reactions_truth=target.reactions.detach().cpu().numpy(),
        reactions_initial=initial.reactions.detach().cpu().numpy(),
        reactions_recovered=recovered.reactions.detach().cpu().numpy(),
    )
    _save_figure(mesh, cfg, result, figure_path, pdf_path)
    return {
        "summary": str(summary_path),
        "history": str(history_path),
        "arrays": str(arrays_path),
        "figure": str(figure_path),
        "pdf": str(pdf_path),
    }


def _save_figure(
    mesh: FEMMesh,
    cfg: SmoothGradedConfig,
    result: dict[str, object],
    png: Path,
    pdf: Path,
) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.tri as mtri

    nodes = mesh.nodes.detach().cpu().numpy()
    elems = mesh.elements.detach().cpu().numpy()
    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elems)
    target: SmoothRollout = result["target"]
    initial: SmoothRollout = result["initial"]
    recovered: SmoothRollout = result["recovered"]
    disps = np.asarray(cfg.displacements)
    history: list[dict[str, float]] = result["history"]

    fig, ax = plt.subplots(4, 3, figsize=(13.0, 13.2), constrained_layout=True)
    panels = [
        ("truth E", target.E_field, "viridis"),
        ("initial E", initial.E_field, "viridis"),
        ("recovered E", recovered.E_field, "viridis"),
        ("truth Gc", target.Gc_field, "magma"),
        ("initial Gc", initial.Gc_field, "magma"),
        ("recovered Gc", recovered.Gc_field, "magma"),
        ("truth damage", target.d_final, "inferno"),
        ("initial damage", initial.d_final, "inferno"),
        ("recovered damage", recovered.d_final, "inferno"),
    ]
    for axis, (title, field, cmap) in zip(ax[:3].reshape(-1), panels):
        values = field.detach().cpu().numpy()
        if values.shape[0] == mesh.n_elems:
            artist = axis.tripcolor(tri, facecolors=values, cmap=cmap, shading="flat")
        else:
            artist = axis.tricontourf(tri, values, levels=48, cmap=cmap)
        axis.set_title(title)
        axis.set_aspect("equal")
        axis.set_xlabel("x")
        axis.set_ylabel("y")
        fig.colorbar(artist, ax=axis, shrink=0.72)

    ax[3, 0].plot(disps, target.reactions.detach().cpu().numpy(), "o-", label="truth")
    ax[3, 0].plot(disps, initial.reactions.detach().cpu().numpy(), "s--", label="initial")
    ax[3, 0].plot(disps, recovered.reactions.detach().cpu().numpy(), "^-.", label="recovered")
    ax[3, 0].set_title("reaction response")
    ax[3, 0].set_xlabel("imposed displacement")
    ax[3, 0].set_ylabel("top reaction")
    ax[3, 0].grid(alpha=0.3)
    ax[3, 0].legend()

    ax[3, 1].semilogy([row["loss"] for row in history], "o-", color="#b23a48")
    ax[3, 1].set_title("loss convergence")
    ax[3, 1].set_xlabel("closure evaluation")
    ax[3, 1].set_ylabel("loss")
    ax[3, 1].grid(alpha=0.3)

    grad = result["gradcheck"]
    names = grad["names"]
    x = np.arange(len(names))
    width = 0.38
    ax[3, 2].bar(x - width / 2, grad["autograd"], width, label="autograd")
    ax[3, 2].bar(x + width / 2, grad["finite_difference"], width, label="finite diff")
    ax[3, 2].set_xticks(x, names, rotation=25, ha="right")
    ax[3, 2].set_title(f"gradient check, max rel {grad['max_relative_error']:.2e}")
    ax[3, 2].grid(alpha=0.3)
    ax[3, 2].legend()

    mode = result["mode"]
    fig.suptitle(f"QS PF smooth graded {mode} inverse: field, response, optimisation", fontsize=14)
    fig.savefig(png, dpi=180)
    fig.savefig(pdf)
    plt.close(fig)
