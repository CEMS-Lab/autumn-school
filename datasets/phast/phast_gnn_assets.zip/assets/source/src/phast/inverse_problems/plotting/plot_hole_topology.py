#!/usr/bin/env python
"""Three-panel figure for the weak-zone shape-optimisation demo.

Reads the output directory produced by `demo_hole_topology.py` and
produces:

  (a) No-zones baseline damage field (crack reaches the target)
  (b) Initial random placement damage + initial zone centres (orange X)
  (c) Optimised placement damage + final zone centres (red O)

Plus a small second figure with the loss trajectory.

Usage
-----
    python plot_hole_topology.py --recovery_dir results_hole_topology
"""

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
import matplotlib.tri as mtri

THIS = Path(__file__).resolve()
sys.path.insert(0, str(THIS.parents[2].parent))
try:
    from phast.paper_figure_style import apply_style
    apply_style()
except ImportError:
    plt.rcParams.update({
        "font.family": "serif",
        "mathtext.fontset": "stix",
        "font.size": 10,
    })


def _triangulation(recovery_dir):
    nodes = np.load(os.path.join(recovery_dir, "mesh_nodes.npy"))
    elems = np.load(os.path.join(recovery_dir, "mesh_elements.npy"))
    return mtri.Triangulation(nodes[:, 0], nodes[:, 1], elems), nodes, elems


def _draw_damage_panel(ax, triang, damage, title, meta,
                        centres=None, centre_color=None, zone_radius=None):
    tp = ax.tripcolor(triang, damage, shading="gouraud",
                      cmap="inferno", vmin=0.0, vmax=1.0)
    ax.set_aspect("equal")
    ax.set_xlabel("x [mm]")
    ax.set_ylabel("y [mm]")
    ax.set_title(title, fontsize=11)

    # Outline the target box
    x_lo, x_hi, y_lo, y_hi = meta["target_box"]
    ax.add_patch(Rectangle((x_lo, y_lo), x_hi - x_lo, y_hi - y_lo,
                           fill=False, edgecolor="white", linewidth=1.4,
                           linestyle="--"))
    ax.text((x_lo + x_hi) / 2, y_hi + 0.3, "target",
            color="white", ha="center", va="bottom", fontsize=9)

    # Outline the design box (where zones may be placed)
    x1, x2 = meta["zones"]["bounds"]["x"]
    y1, y2 = meta["zones"]["bounds"]["y"]
    ax.add_patch(Rectangle((x1, y1), x2 - x1, y2 - y1, fill=False,
                           edgecolor="#00d0ff", linewidth=0.8,
                           linestyle=":"))

    # Zone centres (optional)
    if centres is not None and centre_color is not None:
        for c in centres:
            if zone_radius is not None:
                ax.add_patch(Circle((c[0], c[1]), zone_radius, fill=False,
                                     edgecolor=centre_color, linewidth=1.2,
                                     alpha=0.7))
            ax.plot(c[0], c[1], marker="o", color=centre_color,
                    markersize=6, markeredgecolor="white", markeredgewidth=1.0)
    return tp


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--recovery_dir", type=str, required=True,
                   help="Output directory produced by demo_hole_topology.py")
    p.add_argument("--out", type=str, default=None,
                   help="Directory to write figures to (default: recovery_dir)")
    args = p.parse_args()

    rdir = args.recovery_dir
    out = args.out or rdir
    os.makedirs(out, exist_ok=True)

    with open(os.path.join(rdir, "run_metadata.json")) as f:
        meta = json.load(f)
    with open(os.path.join(rdir, "history.json")) as f:
        history = json.load(f)

    triang, nodes, elems = _triangulation(rdir)

    d_base = np.load(os.path.join(rdir, "damage_no_zones.npy"))
    d_init = np.load(os.path.join(rdir, "damage_initial.npy"))
    d_final = np.load(os.path.join(rdir, "damage_final.npy"))
    centres_init = np.load(os.path.join(rdir, "hole_params_initial.npy"))
    centres_final = np.load(os.path.join(rdir, "hole_params_final.npy"))
    zone_radius = meta["zones"]["radius"]

    # ---- Three-panel figure ----
    fig, axes = plt.subplots(3, 1, figsize=(10, 9.5))
    tp = _draw_damage_panel(
        axes[0], triang, d_base,
        f"(a) No weak zones  (loss = {meta['loss_no_zones']:.3e})",
        meta)
    _draw_damage_panel(
        axes[1], triang, d_init,
        f"(b) Initial placement (all zones at y ≈ y_min)  "
        f"(loss = {meta['loss_initial']:.3e})",
        meta, centres=centres_init, centre_color="#ff9500",
        zone_radius=zone_radius)
    _draw_damage_panel(
        axes[2], triang, d_final,
        f"(c) After L-BFGS  "
        f"(loss = {meta['loss_final']:.3e},  "
        f"{100*(1-meta['loss_final']/meta['loss_initial']):.1f}% reduction vs. initial)",
        meta, centres=centres_final, centre_color="#ff2a2a",
        zone_radius=zone_radius)

    cbar = fig.colorbar(tp, ax=axes, shrink=0.55, label=r"damage $d$")
    fig.suptitle("Shape optimisation: weak-zone placement for crack arrest",
                 fontsize=12, y=0.995)
    out_png = os.path.join(out, "hole_topology_three_panel.png")
    fig.savefig(out_png, dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out_png}")

    # ---- Loss trajectory ----
    fig, ax = plt.subplots(figsize=(6, 4))
    loss = np.array(history["loss"])
    iters = np.array(history["iter"])
    ax.plot(iters, loss, "-o", color="#1f77b4", lw=1.6, ms=5,
            label="optimiser trajectory")
    ax.axhline(meta["loss_no_zones"], color="#888", linestyle="--",
               label=f"no-zones baseline ({meta['loss_no_zones']:.3e})")
    ax.axhline(meta["loss_initial"], color="#ff9500", linestyle=":",
               label=f"initial placement ({meta['loss_initial']:.3e})")
    ax.set_xlabel("L-BFGS iteration")
    ax.set_ylabel(r"loss: mean $d^2$ in target zone")
    ax.set_yscale("log")
    ax.set_title(f"Loss convergence "
                 f"(k = {2 * meta['zones']['n_zones']} hole-position parameters)")
    ax.legend(loc="best", fontsize=9)
    ax.grid(True, which="both", alpha=0.3)
    out_png2 = os.path.join(out, "hole_topology_loss.png")
    fig.savefig(out_png2, dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out_png2}")


if __name__ == "__main__":
    main()
