#!/usr/bin/env python
"""Render a damage-evolution GIF from a forward-only or inversion truth.

Reads the per-snapshot damage stack saved in damage_truth.npz / truth.npz
(50 frames by default) and animates the crack growth on the truth mesh,
with the truth E-field (inclusion demo) or Gc-field (Gc demo) shown as
a faint background.

Output: one GIF per call, capped at ~60 frames to stay under the
recommended 1-5 MB size budget.

Usage:
    python plot_damage_gif.py <results_dir> [--out evolution.gif]
                                              [--max_frames 60]
                                              [--fps 8]
"""
from __future__ import annotations
import argparse
import os
import sys

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.tri import Triangulation
from matplotlib.animation import FuncAnimation, PillowWriter


def main():
    p = argparse.ArgumentParser()
    p.add_argument('input_dir')
    p.add_argument('--out', default=None)
    p.add_argument('--max_frames', type=int, default=60)
    p.add_argument('--fps', type=int, default=8)
    args = p.parse_args()

    cands = ['damage_truth.npz', 'truth.npz']
    src = None
    for c in cands:
        path = os.path.join(args.input_dir, c)
        if os.path.exists(path):
            src = path
            break
    if src is None:
        sys.exit(f"No {cands} in {args.input_dir}")

    z = np.load(src, allow_pickle=True)
    if 'snapshots' not in z.files or 'snapshot_steps' not in z.files:
        print(f"WARN: no snapshots in {src}; need --save_snapshots N at "
              f"forward time.")
        sys.exit(0)

    snaps = z['snapshots']           # (n_snaps, n_nodes)
    snap_steps = z['snapshot_steps']
    nodes    = z['nodes']
    elements = z['elements']

    if 'E_truth' in z.files:
        bg = z['E_truth']
        bg_label = 'E [MPa]'
        bg_cmap  = 'gray'
        kind     = 'inclusion'
        truth_pts = z['truth_pts'] if 'truth_pts' in z.files else None
    elif 'Gc_true' in z.files:
        bg = z['Gc_true']
        bg_label = 'Gc [N/mm]'
        bg_cmap  = 'gray_r'
        kind     = 'gc'
        truth_pts = None
        x0_truth = float(z['x0_truth']) if 'x0_truth' in z.files else None
    else:
        bg = None
        kind = 'unknown'
        truth_pts = None

    # Subsample to max_frames if needed.
    n_snaps = snaps.shape[0]
    if n_snaps > args.max_frames:
        idx = np.linspace(0, n_snaps - 1, args.max_frames, dtype=int)
        snaps = snaps[idx]
        snap_steps = snap_steps[idx]
        n_snaps = len(snaps)

    # Time axis from dt (gc demo saves dt; inclusion may not).
    if 'dt' in z.files:
        dt_s = float(z['dt'])
        t_us = snap_steps * dt_s * 1e6
    elif 'snapshot_t_us' in z.files:
        t_us = z['snapshot_t_us']
        if n_snaps != len(t_us):  # we subsampled
            t_us = t_us[idx]
    else:
        t_us = None

    tri = Triangulation(nodes[:, 0], nodes[:, 1], elements)

    fig, ax = plt.subplots(figsize=(8, 4.2))
    if bg is not None:
        ax.tripcolor(tri, facecolors=bg, cmap=bg_cmap, shading='flat',
                      alpha=0.35)

    # First frame
    quad_d = ax.tripcolor(tri, snaps[0], cmap='inferno',
                            shading='gouraud', vmin=0, vmax=1)
    cbar = plt.colorbar(quad_d, ax=ax, label='damage d', shrink=0.85)

    if truth_pts is not None:
        for i, pt in enumerate(truth_pts):
            ax.plot([pt[0]], [pt[1]], 'co', ms=8, mec='k', mew=0.6)
            ax.annotate(f'{i+1}', xy=pt, xytext=(pt[0]+0.4, pt[1]+0.4),
                          color='c', fontsize=9, fontweight='bold')
    elif kind == 'gc' and x0_truth is not None:
        ax.axvline(x0_truth, color='c', ls='--', lw=1, alpha=0.7,
                    label=f'truth band x0={x0_truth:.1f}')
        ax.legend(loc='upper right', fontsize=7)

    ax.set_aspect('equal')
    ax.set_xlabel('x [mm]')
    ax.set_ylabel('y [mm]')
    title = ax.set_title(f'frame 0 / {n_snaps - 1}'
                            + (f', t={t_us[0]:.1f} us' if t_us is not None else ''))

    def update(frame_i):
        # tripcolor with shading='gouraud' uses node values; set_array
        # works directly.
        quad_d.set_array(snaps[frame_i])
        title.set_text(
            f'frame {frame_i} / {n_snaps - 1}'
            + (f', t={t_us[frame_i]:.1f} us'
                if t_us is not None else '')
            + f'  max(d)={snaps[frame_i].max():.2f}'
            + f'  #d>0.5={int((snaps[frame_i] > 0.5).sum())}'
        )
        return [quad_d, title]

    fig.tight_layout()
    out = args.out or os.path.join(args.input_dir, 'damage_evolution.gif')
    print(f"Rendering {n_snaps} frames at {args.fps} fps -> {out}")
    anim = FuncAnimation(fig, update, frames=n_snaps,
                          interval=1000 // args.fps, blit=False)
    anim.save(out, writer=PillowWriter(fps=args.fps), dpi=100)
    plt.close(fig)
    print(f"Done. Size: {os.path.getsize(out) / 1e6:.2f} MB")


if __name__ == '__main__':
    main()
