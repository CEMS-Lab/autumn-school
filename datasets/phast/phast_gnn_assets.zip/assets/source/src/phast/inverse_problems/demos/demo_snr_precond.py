"""Smoke demo: SNR preconditioner vs plain Adam on a noisy quadratic.

Reference
---------
Litman, R. & Guo, Y. (2026). *A Theory of Generalization in Deep
Learning.* arXiv:2605.01172.

Setup
-----
Recover ``a`` in ``L(x) = 1/2 * ||x - a||^2`` using stochastic
gradients ``g_t = (x - a) + sigma * eps_t``, with ``eps_t ~ N(0, I)``.
This is the simplest setting where the SNR gate has signal to act on:
the *true* gradient mean is ``x - a`` (decays to zero near the
optimum) and the *noise* is constant variance.  As ``x`` approaches
``a``, the per-coordinate SNR drops, which is exactly when SNRAdam
should attenuate updates and avoid the noise-floor "memorisation"
random walk that plain Adam exhibits.

Usage
-----
    python -m inverse_problems.demos.demo_snr_precond
"""
from __future__ import annotations

import torch

from inverse_problems.preconditioners import SNRAdam


def noisy_quadratic_run(optimizer_cls, *, sigma: float, n_steps: int, seed: int, **opt_kwargs):
    """Return per-step loss trace and final parameter."""
    torch.manual_seed(seed)
    a = torch.tensor([1.0, -2.0, 0.5, -0.7])
    x = torch.zeros(4, requires_grad=True)
    opt = optimizer_cls([x], lr=5e-2, **opt_kwargs)
    g = torch.Generator().manual_seed(seed + 1)

    losses = []
    for _ in range(n_steps):
        opt.zero_grad()
        true_grad = (x.detach() - a)
        noise = sigma * torch.randn(4, generator=g)
        x.grad = true_grad + noise
        opt.step()
        losses.append(0.5 * ((x.detach() - a) ** 2).sum().item())

    return losses, x.detach()


def main():
    n_steps = 500
    tail = 100  # window over which to measure noise-floor stability
    print(f"\nNoisy-quadratic inversion, {n_steps} steps, tail window={tail}, seed=0\n")
    print("Reporting tail-window mean and standard deviation of the loss,")
    print("which is the relevant quantity: SNRAdam aims to *suppress* the")
    print("noise-floor random walk, not to reach a tighter point estimate.\n")
    header = (
        f"{'sigma':>6} | {'Adam mean':>12} {'Adam std':>12} | "
        f"{'SNRAdam mean':>14} {'SNRAdam std':>12} | "
        f"{'std ratio':>10}"
    )
    print(header)
    print("-" * len(header))
    for sigma in [0.0, 0.1, 0.5, 1.0, 2.0]:
        adam_losses, _ = noisy_quadratic_run(
            torch.optim.Adam, sigma=sigma, n_steps=n_steps, seed=0
        )
        snr_losses, _ = noisy_quadratic_run(
            SNRAdam, sigma=sigma, n_steps=n_steps, seed=0, snr_floor=1e-3
        )
        adam_t = torch.tensor(adam_losses[-tail:])
        snr_t = torch.tensor(snr_losses[-tail:])
        adam_mean, adam_std = adam_t.mean().item(), adam_t.std().item()
        snr_mean, snr_std = snr_t.mean().item(), snr_t.std().item()
        ratio = adam_std / snr_std if snr_std > 1e-12 else float("inf")
        print(
            f"{sigma:>6.2f} | {adam_mean:>12.4e} {adam_std:>12.4e} | "
            f"{snr_mean:>14.4e} {snr_std:>12.4e} | {ratio:>10.2f}x"
        )
    print(
        "\nstd ratio > 1: SNRAdam's tail-window loss is more stable than Adam's\n"
        "(memorisation-suppression / noise-floor attenuation, the headline\n"
        "claim of Litman & Guo 2026).  Mean loss may be HIGHER for SNRAdam\n"
        "because it stops at the noise floor rather than chasing it.\n"
    )


if __name__ == "__main__":
    main()
