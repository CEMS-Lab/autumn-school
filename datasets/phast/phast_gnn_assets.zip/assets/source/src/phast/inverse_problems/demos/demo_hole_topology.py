#!/usr/bin/env python
"""Shape-optimisation demo: place weak zones to arrest or divert a crack.

This is the dolfin-adjoint-style topology-optimisation counterpart to
the spatial Gc(x) recovery demo.  Instead of recovering a known field
from observations, we *design* a spatial toughness pattern so that the
crack avoids a prescribed target region at the far end of the specimen.

Physically: think of it as optimising the placement of a
toughness-reducing treatment (laser scoring, inclusion placement)
rather than drilling physical holes.  Every weak zone is a smooth
Gaussian bump that multiplicatively reduces G_c at its location.  The
bump centres (x_i, y_i) are the design variables — k = 2 * N_zones.

Problem setup
-------------
 * Rectangular SENT plate (20 x 10 mm), pre-notch of length a=4 mm at
   y = 5.  Uniform mode-I loading via Neumann tractions on top/bottom.
 * G_c(x) = G_c_base * prod_i (1 - depth * exp(-|x - centre_i|^2 / r^2))
   with depth = 0.95, r = 0.6 mm.  Bump centres are differentiable
   w.r.t. the optimiser; a sigmoid reparameterisation keeps them
   inside a user-specified box.
 * Target zone: rectangular region at the far end of the specimen.
   Loss = mean d^2 over the elements whose centroid lies inside the
   target box.  Minimising this drives the optimiser to route the
   crack away from the target.
 * Optimiser: L-BFGS with strong Wolfe line search on the raw
   (pre-sigmoid) hole parameters.  Low-dimensional (k=10 at N=5 zones),
   well inside the regime where L-BFGS converges on phase-field
   inversions.
 * Sanity check: before optimisation, the no-zone baseline is simulated
   to verify the crack actually reaches the target (otherwise the
   gradient is identically zero and the optimiser cannot move).

Output directory contains:
 * run_metadata.json   — problem configuration
 * history.json        — loss + zone positions at every iter
 * Gc_initial.npy, Gc_final.npy     — per-element toughness fields
 * damage_no_zones.npy              — baseline crack (no treatment)
 * damage_initial.npy, damage_final.npy
 * hole_params_initial.npy, hole_params_final.npy  — (N, 2) positions
 * mesh_nodes.npy, mesh_elements.npy, mesh.msh

Use ``plot_hole_topology.py`` for the three-panel figure.

Usage
-----
Smoke test (Mac CPU, ~500 nodes, ~5 minutes):
    python demo_hole_topology.py --h_crack 0.8 --n_steps 300 \\
        --n_iters 5 --n_zones 3 --output_dir /tmp/hole_topo_smoke

HPC run (A100, moderate mesh, ~30-60 minutes):
    python demo_hole_topology.py --h_crack 0.25 --n_steps 1800 \\
        --n_iters 20 --n_zones 5 \\
        --output_dir results_hole_topology_v1 --device cuda
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
import time

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.boundary_conditions import BoundaryConditions
from phast.device import DeviceContext
from phast.material import Material
from phast.mesh import FEMMesh
from phast.staggered_solver import SolverConfig, StaggeredSolver
from phast.config import LoadingConfig
from phast.inverse_problems._tbptt import run_forward_tbptt_generic


# ---------------------------------------------------------------------------
# Geometry and solver construction
# ---------------------------------------------------------------------------
def build_mesh(h_crack: float, h_coarse: float, device, dtype,
               W: float = 20.0, H: float = 10.0, a: float = 4.0):
    """Rectangular SENT plate, edge-notch length `a` at mid-height.

    Notch is the two closely-spaced horizontal lines at y = H/2 +/- eps
    joined at x = a, i.e. a 0.02-mm-thick crack of length a.
    """
    eps = 0.01
    geo = f"""
    lc_crack = {h_crack};
    lc_coarse = {h_coarse};
    W = {W}; H = {H}; a = {a};
    Point(1) = {{0, 0, 0, lc_coarse}};
    Point(2) = {{W, 0, 0, lc_coarse}};
    Point(3) = {{W, H, 0, lc_coarse}};
    Point(4) = {{0, H, 0, lc_coarse}};
    Point(5) = {{0, H/2 - {eps}, 0, lc_crack}};
    Point(6) = {{a, H/2 - {eps}, 0, lc_crack}};
    Point(7) = {{a, H/2 + {eps}, 0, lc_crack}};
    Point(8) = {{0, H/2 + {eps}, 0, lc_crack}};
    Line(1) = {{1, 2}}; Line(2) = {{2, 3}}; Line(3) = {{3, 4}};
    Line(4) = {{4, 8}}; Line(5) = {{8, 7}}; Line(6) = {{7, 6}};
    Line(7) = {{6, 5}}; Line(8) = {{5, 1}};
    Curve Loop(1) = {{1, 2, 3, 4, 5, 6, 7, 8}};
    Plane Surface(1) = {{1}};
    Physical Surface("domain") = {{1}};
    Physical Curve("bottom") = {{1}};
    Physical Curve("right") = {{2}};
    Physical Curve("top") = {{3}};
    Physical Curve("left") = {{4, 8}};
    """
    geo_p = os.path.join(tempfile.gettempdir(), "hole_topo_demo.geo")
    msh_p = os.path.join(tempfile.gettempdir(), "hole_topo_demo.msh")
    with open(geo_p, "w") as f:
        f.write(geo)
    subprocess.run(["gmsh", "-2", geo_p, "-o", msh_p, "-format", "msh2"],
                   capture_output=True, check=True)
    mesh = FEMMesh(msh_p, device=device, dtype=dtype)
    mesh.identify_boundaries()
    return mesh, msh_p


def build_solver(mesh, device, dtype, dU: float = 0.03,
                 softmax_H_beta: float = 50.0):
    """Bleyer-PMMA-like AT2 solver with gamma_correction (per-element Gc).

    Material: E = 3090 MPa, ν = 0.35, ρ = 1.18e-9 tonne/mm^3,
    Gc = 0.3 N/mm, ℓ₀ = 0.5 mm.  Identical to Bleyer 2017 PMMA except
    for the regularisation length, which is scaled up from 0.1 mm to
    0.5 mm so that h_crack = 0.25 mm = ℓ₀/2 is a coarse-but-legal
    resolution — keeps the demo's mesh and time-step tractable at
    smoke-test scale.
    """
    mat = Material(
        E=3090.0, nu=0.35, Gc=0.3, l0=0.5, rho=1.18e-9,
        energy_split='spectral', pf_model='AT2',
        gamma_correction=True,  # required for Gc_field path
    )
    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)
    bcs.add(mesh.node_sets['top'], component=1, value=+dU)
    bcs.add(mesh.node_sets['bottom'], component=1, value=-dU)
    bcs.fix(mesh.node_sets['left'], component=0)
    cfg = SolverConfig(
        solver_type='explicit',
        differentiable=True,
        damage_every=1,
        softmax_H_beta=softmax_H_beta,
    )
    solver = StaggeredSolver(mesh, mat, bcs, config=cfg,
                              ctx=DeviceContext(device, dtype))
    solver.damage_solver.tol = 1e-9
    return solver


# ---------------------------------------------------------------------------
# Weak-zone parameterisation
# ---------------------------------------------------------------------------
def zone_centres_from_raw(raw_params: torch.Tensor, x_min: float, x_max: float,
                           y_min: float, y_max: float) -> torch.Tensor:
    """Map raw (unbounded) parameters to in-box centres via sigmoid.

    raw_params: (N, 2) tensor, any real values.
    Returns centres (N, 2) with x in [x_min, x_max], y in [y_min, y_max].
    """
    sig = torch.sigmoid(raw_params)
    out = torch.empty_like(sig)
    out[:, 0] = x_min + (x_max - x_min) * sig[:, 0]
    out[:, 1] = y_min + (y_max - y_min) * sig[:, 1]
    return out


def Gc_field_from_zones(centres: torch.Tensor, centroids: torch.Tensor,
                         Gc_base: float, radius: float, depth: float):
    """Compute per-element Gc given weak-zone centres.

    G_c(x) = G_c_base * prod_i (1 - depth * exp(-|x - c_i|^2 / r^2))

    centres:   (N, 2)  zone centres
    centroids: (E, 2)  element centroids (fixed mesh, no grad)
    Returns:   (E,)    per-element Gc, attached to autograd graph.
    """
    # (E, N, 2) pairwise differences
    diff = centroids.unsqueeze(1) - centres.unsqueeze(0)
    dist_sq = (diff ** 2).sum(dim=-1)                        # (E, N)
    bumps = torch.exp(-dist_sq / (radius ** 2))              # (E, N)
    strength = 1.0 - depth * bumps                           # (E, N)
    Gc_ratio = strength.prod(dim=-1)                         # (E,)
    # Floor to a small positive value to keep the damage solver stable.
    Gc_ratio = Gc_ratio.clamp(min=0.02)
    return Gc_base * Gc_ratio


# ---------------------------------------------------------------------------
# Forward pass + target-zone loss
# ---------------------------------------------------------------------------
def run_forward(solver, Gc_field, n_steps, u_prestrain,
                snapshot_steps=None):
    """Pre-strained dynamic release with a given per-element Gc field.

    `u_prestrain` is the quasi-static displacement solution for the
    undamaged plate under the applied Dirichlet BCs (solved ONCE outside
    this function and passed in as a constant). Starting the dynamics
    from `u_prestrain` with v=0, a=0 avoids the pathological transient
    of a sudden BC activation and matches the protocol used by the §5.6
    perforated-plate benchmarks.

    Resets state, runs `n_steps` explicit steps, returns final damage
    with the autograd graph attached from hole params to damage.
    """
    n_nodes = solver.mesh.n_nodes
    n_elem = solver.damage_solver._cg_elements.shape[0]
    device, dtype = solver.u.device, solver.u.dtype

    solver.u = u_prestrain.clone()
    solver.v = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.a = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.d = torch.zeros(n_nodes, dtype=dtype, device=device)
    solver.H_elem = torch.zeros(n_elem, dtype=dtype, device=device)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dtype, device=device)
    solver._step_count = 0

    solver.diff_Gc_field = Gc_field
    snap_set = set(int(s) for s in snapshot_steps) if snapshot_steps else set()
    snaps = [] if snap_set else None
    for step in range(n_steps):
        solver.step_full()
        if snaps is not None and (step + 1) in snap_set:
            snaps.append(solver.d.detach().cpu().numpy().copy())
    if hasattr(solver, 'diff_Gc_field'):
        del solver.diff_Gc_field
    if snaps is not None:
        return solver.d, snaps
    return solver.d


def element_target_mask(centroids: torch.Tensor, box: tuple) -> torch.Tensor:
    """Boolean mask over elements whose centroid lies inside the target box.

    box: (x_lo, x_hi, y_lo, y_hi)
    """
    x_lo, x_hi, y_lo, y_hi = box
    m = ((centroids[:, 0] >= x_lo) & (centroids[:, 0] <= x_hi) &
         (centroids[:, 1] >= y_lo) & (centroids[:, 1] <= y_hi))
    return m


def damage_in_target(d_nodal: torch.Tensor, elements: torch.Tensor,
                     mask_elem: torch.Tensor) -> torch.Tensor:
    """Element-averaged damage over target elements.

    d_nodal:   (N_n,)   nodal damage
    elements:  (N_e, 3) triangle connectivity
    mask_elem: (N_e,)   bool
    Returns a scalar = mean(d_e^2) over target elements,
    where d_e = average of the three nodal damages on element e.
    """
    d_elem = d_nodal[elements].mean(dim=1)      # (N_e,)
    d_target = d_elem[mask_elem]
    return (d_target ** 2).mean()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser()
    p.add_argument('--h_crack', type=float, default=0.4)
    p.add_argument('--h_coarse', type=float, default=1.0)
    p.add_argument('--n_steps', type=int, default=1500)
    p.add_argument('--n_iters', type=int, default=15)
    p.add_argument('--n_zones', type=int, default=5)
    p.add_argument('--zone_radius', type=float, default=0.6)
    p.add_argument('--zone_depth', type=float, default=0.95)
    p.add_argument('--dU', type=float, default=0.04,
                   help='Top/bottom prescribed displacement [mm]')
    p.add_argument('--device', type=str, default='cpu')
    p.add_argument('--output_dir', type=str, default='results_hole_topology')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--skip_no_zones_baseline', action='store_true',
                   help='Skip the no-zones baseline sanity check.')
    p.add_argument('--save_forward_viz', dest='save_forward_viz',
                   action='store_true', default=True,
                   help='Before L-BFGS, save truth/init '
                        'damage_final.png + damage_evolution.gif so '
                        'the user can sanity-check the forward setup '
                        'before committing to a long inversion '
                        '(default: enabled). The "truth" baseline '
                        'here is the no-zones forward; "init" is the '
                        'initial zone placement.')
    p.add_argument('--no_save_forward_viz', dest='save_forward_viz',
                   action='store_false',
                   help='Disable pre-inversion forward-viz.')
    p.add_argument('--n_viz_frames', type=int, default=20,
                   help='Frames in <label>_damage_evolution.gif '
                        '(default 20).')
    p.add_argument('--tbptt_chunk_size', type=int, default=0,
                   help='Truncated-BPTT chunk length (issue #288 / #301). '
                        '0 disables (default; full autograd graph). '
                        'When > 0, the n_steps explicit-dynamics loop is '
                        'split into chunks of this length. Loss is the '
                        'mean of per-chunk-end target-zone damage; biased '
                        'gradient. Pre-strain IC is preserved by an '
                        'install_fn that re-applies u_prestrain after the '
                        'helper-level state reset.')
    args = p.parse_args()

    out_dir = (os.path.join(THIS_DIR, args.output_dir)
               if not os.path.isabs(args.output_dir) else args.output_dir)
    os.makedirs(out_dir, exist_ok=True)

    device = args.device
    dtype = torch.float64
    torch.manual_seed(args.seed)

    print("=" * 70)
    print("  Shape optimisation: weak-zone placement for crack arrest")
    print("  (dolfin-adjoint-style demo — native autograd through dynamics)")
    print("=" * 70)
    print(f"  Device:      {device}, float64")
    print(f"  Mesh:        h_crack={args.h_crack}, h_coarse={args.h_coarse}")
    print(f"  Dynamics:    {args.n_steps} steps, dU={args.dU} mm")
    print(f"  Zones:       N={args.n_zones} (k={2*args.n_zones} params), "
          f"r={args.zone_radius}, depth={args.zone_depth}")
    print(f"  Optimiser:   L-BFGS, {args.n_iters} iters")
    print(f"  Output:      {out_dir}")

    # Build mesh and solver (reused across every iteration)
    mesh, msh_path = build_mesh(args.h_crack, args.h_coarse, device, dtype)
    solver = build_solver(mesh, device, dtype, dU=args.dU, softmax_H_beta=50.0)
    n_elem = solver.damage_solver._cg_elements.shape[0]
    centroids = mesh.nodes[mesh.elements].mean(dim=1).to(dtype=dtype,
                                                          device=device)
    print(f"  Mesh:        {int(mesh.n_nodes)} nodes, {n_elem} elements")

    # ---- Pre-strain: quasi-static equilibrium under Dirichlet BCs ----
    # Solve for the displacement field that balances the Dirichlet BCs
    # at d=0.  This becomes the initial condition for the dynamic
    # release; velocity and acceleration start at zero.  Reused across
    # every optimiser iteration (depends only on the mesh and BCs, not
    # on the weak-zone positions).
    print("\n[pre-strain] Solving quasi-static equilibrium (d=0) ...")
    t0 = time.time()
    solver.pre_strain()
    u_prestrain = solver.u.detach().clone()
    print(f"  Pre-strain done: max|u_y| = {u_prestrain[:, 1].abs().max().item():.6e} "
          f"mm ({time.time()-t0:.2f}s)")

    # ---- Domain box and target zone ----
    W, H, a = 20.0, 10.0, 4.0
    x_min, x_max = a + 1.0, W - 1.0        # stay out of notch and right edge
    y_min, y_max = 1.0, H - 1.0            # stay off top/bottom edges
    target_box = (W - 4.0, W - 0.5, H/2 - 1.5, H/2 + 1.5)  # right-end strip
    mask_target = element_target_mask(centroids, target_box)
    n_target = int(mask_target.sum().item())
    print(f"  Target zone: {target_box}  ({n_target} elements)")

    # Forward-viz snapshot schedule (truth = no-zones baseline, init =
    # initial zone placement). When --save_forward_viz is on, capture
    # n_viz_frames damage snapshots inside the baseline + initial
    # forwards so the helper can render the evolution gif. Snapshots
    # are detached numpy arrays (one extra forward on resume is the
    # only cost) -- inversion logic untouched.
    if args.save_forward_viz and args.n_viz_frames > 0:
        n_frames = min(args.n_viz_frames, args.n_steps)
        first = max(int(0.05 * args.n_steps), 1)
        viz_snap_steps = list(np.linspace(first, args.n_steps, n_frames,
                                            dtype=int).tolist())
    else:
        viz_snap_steps = None

    # ---- (1) No-zones baseline: does the crack reach the target? ----
    snaps_baseline = None
    if not args.skip_no_zones_baseline:
        print("\n[baseline] Running forward with no weak zones ...")
        t0 = time.time()
        with torch.no_grad():
            # Gc is uniform Gc_base everywhere (match Gc_base used by zones)
            Gc_uniform = torch.full((n_elem,), 0.3, dtype=dtype, device=device)
            if viz_snap_steps is not None:
                d_baseline, snaps_baseline = run_forward(
                    solver, Gc_uniform, args.n_steps, u_prestrain,
                    snapshot_steps=viz_snap_steps)
                d_baseline = d_baseline.detach().clone()
            else:
                d_baseline = run_forward(
                    solver, Gc_uniform, args.n_steps,
                    u_prestrain).detach().clone()
        loss_baseline = damage_in_target(d_baseline, mesh.elements,
                                          mask_target).item()
        d_target_elem = d_baseline[mesh.elements].mean(dim=1)[mask_target]
        max_d_target = d_target_elem.max().item()
        print(f"  Wall: {time.time()-t0:.1f}s")
        print(f"  Max damage in target: {max_d_target:.3f}")
        print(f"  Mean d^2 in target:   {loss_baseline:.4e}")
        np.save(os.path.join(out_dir, 'damage_no_zones.npy'),
                d_baseline.cpu().numpy())
        if max_d_target < 0.3:
            print("  WARNING: baseline damage in target is low "
                  f"({max_d_target:.2f} < 0.3).")
            print("  The gradient may be too weak for the optimiser to move "
                  "zones effectively.")
            print("  Consider increasing --dU or extending --n_steps.")

    # ---- (2) Initial zone placement: spread along x, all BELOW the crack ----
    # The crack path lies near y = H/2; the design box is y in [y_min, y_max].
    # We place the N zones at y ≈ y_min + 0.12 * (y_max - y_min)  (well
    # below the crack, so they exert essentially no influence initially)
    # and distributed in x across the left two-thirds of the design box
    # (so none starts inside the target region).  This makes the initial
    # loss close to the no-zones baseline and gives the optimiser a real
    # distance to travel.
    rng = torch.Generator(device=device).manual_seed(args.seed)
    raw_init = torch.zeros(args.n_zones, 2, dtype=dtype, device=device)
    # x: evenly spaced in raw from -3 to +1  ->  sigmoid 0.05 ... 0.73
    raw_init[:, 0] = torch.linspace(-3.0, 1.0, args.n_zones,
                                     dtype=dtype, device=device)
    # y: start near y_min (sigmoid(-2) ≈ 0.12, so y ≈ y_min + 0.12*range)
    raw_init[:, 1] = -2.0 * torch.ones(args.n_zones, dtype=dtype, device=device)
    # Add a tiny jitter so the optimiser doesn't see a symmetric landscape
    raw_init = raw_init + 0.1 * torch.randn(args.n_zones, 2, generator=rng,
                                              dtype=dtype, device=device)
    raw_params = raw_init.clone().requires_grad_(True)
    with torch.no_grad():
        centres0 = zone_centres_from_raw(raw_params, x_min, x_max,
                                          y_min, y_max)
    print(f"\n[initial] Random zone centres:")
    for i, c in enumerate(centres0.detach().cpu().numpy()):
        print(f"    zone {i}: ({c[0]:.2f}, {c[1]:.2f})")

    # Initial Gc field + forward pass (for the record, no grad)
    snaps_initial = None
    with torch.no_grad():
        Gc_initial = Gc_field_from_zones(centres0, centroids, Gc_base=0.3,
                                          radius=args.zone_radius,
                                          depth=args.zone_depth)
        if viz_snap_steps is not None:
            d_initial, snaps_initial = run_forward(
                solver, Gc_initial, args.n_steps, u_prestrain,
                snapshot_steps=viz_snap_steps)
            d_initial = d_initial.detach().clone()
        else:
            d_initial = run_forward(
                solver, Gc_initial, args.n_steps,
                u_prestrain).detach().clone()
        loss_initial = damage_in_target(d_initial, mesh.elements,
                                         mask_target).item()
    print(f"  Initial loss (mean d^2 in target): {loss_initial:.4e}")
    np.save(os.path.join(out_dir, 'Gc_initial.npy'), Gc_initial.cpu().numpy())
    np.save(os.path.join(out_dir, 'damage_initial.npy'), d_initial.cpu().numpy())
    np.save(os.path.join(out_dir, 'hole_params_initial.npy'),
            centres0.detach().cpu().numpy())

    # --- Pre-inversion forward visualisation (truth + init) ---
    # "truth" = no-zones baseline (target the optimiser must avoid).
    # "init"  = initial zone placement (starting design).
    if args.save_forward_viz:
        try:
            from inverse_problems._viz import save_forward_viz
            if not args.skip_no_zones_baseline:
                paths_t = save_forward_viz(
                    mesh.nodes, mesh.elements, d_baseline, out_dir,
                    label='truth', snapshots=snaps_baseline,
                    snap_steps=viz_snap_steps,
                    n_steps_total=args.n_steps,
                    title_prefix='Truth (no zones)',
                )
                print(f"  [forward-viz] truth png -> {paths_t['png']}")
                if paths_t['gif']:
                    print(f"  [forward-viz] truth gif -> {paths_t['gif']}")
            paths_i = save_forward_viz(
                mesh.nodes, mesh.elements, d_initial, out_dir,
                label='init', snapshots=snaps_initial,
                snap_steps=viz_snap_steps,
                n_steps_total=args.n_steps,
                title_prefix='Init (initial zones)',
            )
            print(f"  [forward-viz] init png -> {paths_i['png']}")
            if paths_i['gif']:
                print(f"  [forward-viz] init gif -> {paths_i['gif']}")
        except Exception as exc:
            print(f"  [forward-viz] failed: {exc}")

    # ---- (3) L-BFGS optimisation on raw_params ----
    optimizer = torch.optim.LBFGS(
        [raw_params], lr=0.5, max_iter=3, history_size=10,
        line_search_fn='strong_wolfe',
    )

    # TBPTT setup (issue #301): the helper resets state to zero, so the
    # install_fn must re-apply u_prestrain AFTER reset to preserve the
    # demo's pre-strained IC. Loss is mean-over-chunks of the target-zone
    # damage metric; chunk-end snapshots carry the local autograd tape.
    loading = LoadingConfig(ramp_type='constant')

    def _make_install_with_prestrain(Gc_f):
        def _install(solver):
            # Helper has just zeroed (u, v, a, d, H_*); restore prestrain.
            solver.u = u_prestrain.clone()
            solver.diff_Gc_field = Gc_f
        return _install

    if args.tbptt_chunk_size > 0:
        cs = int(args.tbptt_chunk_size)
        print(f"\n[TBPTT #301] enabled: chunk_size={cs}, "
              f"n_chunks~={(args.n_steps + cs - 1) // cs}")

    history = {
        'iter': [], 'loss': [], 'centres': [], 'wall_s': [],
    }
    closure_counter = {'n': 0, 'iter': 0}

    def closure():
        closure_counter['n'] += 1
        cc = closure_counter['n']
        it_now = closure_counter['iter']
        t_closure = time.time()
        optimizer.zero_grad()
        centres = zone_centres_from_raw(raw_params, x_min, x_max,
                                         y_min, y_max)
        print(f"  [iter {it_now} closure {cc}] forward "
              f"centres={centres.detach().cpu().numpy().round(3).tolist()}",
              flush=True)
        Gc_field = Gc_field_from_zones(centres, centroids, Gc_base=0.3,
                                        radius=args.zone_radius,
                                        depth=args.zone_depth)
        if args.tbptt_chunk_size > 0:
            _, chunk_snaps_pred, _, _ = run_forward_tbptt_generic(
                solver, loading,
                install_fn=_make_install_with_prestrain(Gc_field),
                n_steps=args.n_steps,
                tbptt_chunk_size=args.tbptt_chunk_size)
            chunk_losses = [damage_in_target(s, mesh.elements, mask_target)
                            for s in chunk_snaps_pred]
            loss = torch.stack(chunk_losses).mean()
            if hasattr(solver, 'diff_Gc_field'):
                del solver.diff_Gc_field
        else:
            d = run_forward(solver, Gc_field, args.n_steps, u_prestrain)
            loss = damage_in_target(d, mesh.elements, mask_target)
        loss.backward()
        grad_norm = float(raw_params.grad.detach().norm().item()
                          if raw_params.grad is not None else 0.0)
        print(f"  [iter {it_now} closure {cc}] loss={float(loss.detach()):.4e} "
              f"|g|={grad_norm:.3e} wall={time.time()-t_closure:.1f}s",
              flush=True)
        return loss

    print(f"\n[optimising] L-BFGS on {2*args.n_zones} parameters "
          f"({args.n_iters} iters, max_iter=3 each) ...")
    t_loop = time.time()
    for it in range(args.n_iters):
        closure_counter['iter'] = it
        t_iter = time.time()
        try:
            loss = optimizer.step(closure)
            loss_val = float(loss.item())
        except RuntimeError as e:
            print(f"  iter {it}: RuntimeError in L-BFGS: {e}")
            break
        with torch.no_grad():
            centres_cur = zone_centres_from_raw(raw_params, x_min, x_max,
                                                 y_min, y_max)
        history['iter'].append(it)
        history['loss'].append(loss_val)
        history['centres'].append(centres_cur.detach().cpu().numpy().tolist())
        history['wall_s'].append(time.time() - t_iter)
        if it == 0 or (it + 1) % max(1, args.n_iters // 10) == 0 \
                or it == args.n_iters - 1:
            print(f"  iter {it:3d}: loss = {loss_val:.4e}  "
                  f"({time.time()-t_iter:.1f}s)")

    elapsed = time.time() - t_loop
    print(f"\n[done] Total optimisation wall: {elapsed:.1f}s "
          f"({elapsed/max(1,len(history['iter'])):.1f}s/iter)")

    # ---- (4) Final forward pass for plotting ----
    with torch.no_grad():
        centres_final = zone_centres_from_raw(raw_params, x_min, x_max,
                                                y_min, y_max)
        Gc_final = Gc_field_from_zones(centres_final, centroids,
                                        Gc_base=0.3,
                                        radius=args.zone_radius,
                                        depth=args.zone_depth)
        d_final = run_forward(solver, Gc_final, args.n_steps, u_prestrain).detach().clone()
        loss_final = damage_in_target(d_final, mesh.elements, mask_target).item()
    print(f"\n  Final loss = {loss_final:.4e}  "
          f"(initial {loss_initial:.4e}, "
          f"reduction {100 * (1 - loss_final / max(loss_initial, 1e-20)):.1f}%)")

    np.save(os.path.join(out_dir, 'Gc_final.npy'), Gc_final.cpu().numpy())
    np.save(os.path.join(out_dir, 'damage_final.npy'), d_final.cpu().numpy())
    np.save(os.path.join(out_dir, 'hole_params_final.npy'),
            centres_final.detach().cpu().numpy())
    np.save(os.path.join(out_dir, 'mesh_nodes.npy'), mesh.nodes.cpu().numpy())
    np.save(os.path.join(out_dir, 'mesh_elements.npy'),
            mesh.elements.cpu().numpy())

    import shutil as _sh
    try:
        _sh.copyfile(msh_path, os.path.join(out_dir, 'mesh.msh'))
    except OSError:
        pass

    meta = {
        'problem': 'Shape optimisation — weak-zone placement for crack arrest',
        'domain': {'W': W, 'H': H, 'a': a},
        'zones': {
            'n_zones': args.n_zones, 'radius': args.zone_radius,
            'depth': args.zone_depth,
            'bounds': {'x': [x_min, x_max], 'y': [y_min, y_max]},
        },
        'target_box': list(target_box),
        'mesh': {'n_nodes': int(mesh.n_nodes), 'n_elem': n_elem,
                  'h_crack': args.h_crack, 'h_coarse': args.h_coarse},
        'dynamics': {'n_steps': args.n_steps, 'dU_mm': args.dU,
                      'softmax_H_beta': 50.0},
        'optimiser': 'L-BFGS strong_wolfe, lr=0.5, max_iter=3',
        'loss_no_zones': loss_baseline if not args.skip_no_zones_baseline else None,
        'loss_initial': loss_initial,
        'loss_final': loss_final,
        'wall_opt_s': elapsed,
    }
    with open(os.path.join(out_dir, 'run_metadata.json'), 'w') as f:
        json.dump(meta, f, indent=2)
    with open(os.path.join(out_dir, 'history.json'), 'w') as f:
        json.dump(history, f, indent=2)
    print(f"\nResults: {out_dir}/")
    print(f"  run_metadata.json, history.json")
    print(f"  Gc_initial.npy, Gc_final.npy")
    print(f"  damage_no_zones.npy, damage_initial.npy, damage_final.npy")
    print(f"  hole_params_initial.npy, hole_params_final.npy")


if __name__ == '__main__':
    main()
