"""Gradient preconditioners for noisy inverse-problem optimization.

Currently exposes:

* :class:`SNRPreconditioner` -- per-parameter signal-to-noise ratio gate
  applied to ``Adam`` (Litman & Guo 2026, arXiv:2605.01172).
"""
from .snr import SNRPreconditioner, SNRAdam

__all__ = ["SNRPreconditioner", "SNRAdam"]
