#!/usr/bin/env python
"""Hole-position initializer for the quasi-static notched-holed plate.

This is the measurement/initialisation stage for a future differentiable
quasi-static inverse demo. It treats the hole boundaries in the archived
COMSOL validation run as observed geometry features, fits circular centres
and radii, and writes a figure that can seed a fixed-mesh smooth-void or
level-set refinement.

It deliberately does not claim differentiation through Gmsh/COMSOL remeshing.
True circular holes are the reference geometry; gradient refinement must use a
fixed-mesh surrogate.
"""
from __future__ import annotations

import argparse
import csv
import json
from itertools import permutations
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np
from matplotlib.patches import Circle


DEFAULT_H5 = Path(
    "examples/quasistatic/notched_holed_plate/"
    "run_qs_matrix40_33819_notched_holed_at2_h0.30_l0.25/training_data.h5"
)
DEFAULT_OUT = Path(
    "examples/inverse_problems/qs_comsol_hole_position/run1/results"
)

HOLE_NODESETS = [
    ("big_hole.boundary", "large fracture-driving hole", (36.5, 51.0), 10.0),
    ("upper_pin.boundary", "upper loading pin", (20.0, 100.0), 5.0),
    ("lower_pin.boundary", "lower loading pin", (20.0, 20.0), 5.0),
]

INIT_GUESSES = {
    "big_hole.boundary": (30.5, 58.0),
    "upper_pin.boundary": (26.0, 94.0),
    "lower_pin.boundary": (14.0, 28.0),
}


def _hole_reference_centres() -> np.ndarray:
    return np.array([np.array([x, y], dtype=float) for _, __, (x, y), ___ in HOLE_NODESETS], dtype=float)


def _match_observed_to_reference(
    boundaries: dict[str, np.ndarray],
) -> dict[str, np.ndarray]:
    expected_names = [name for name, *_ in HOLE_NODESETS]
    expected = _hole_reference_centres()
    if all(name in boundaries for name in expected_names):
        return {name: boundaries[name] for name in expected_names}

    if len(boundaries) < len(expected_names):
        raise ValueError(
            "Need at least one observed boundary set per hole. "
            "Expected three sets for the notched holed plate case."
        )

    keys = list(boundaries.keys())
    if len(keys) > len(expected_names):
        # Keep the largest groups, to ignore tiny contour noise clusters.
        keys = sorted(keys, key=lambda k: boundaries[k].shape[0], reverse=True)[
            : len(expected_names)
        ]

    centroids = np.array([boundaries[k].mean(axis=0) for k in keys], dtype=float)
    n_candidates = centroids.shape[0]
    best_perm: tuple[int, ...] | None = None
    best_cost = float("inf")
    for perm in permutations(range(n_candidates), len(expected_names)):
        cost = 0.0
        for hi, ci in enumerate(perm):
            cost += float(np.linalg.norm(centroids[ci] - expected[hi]))
        if cost < best_cost:
            best_cost = cost
            best_perm = perm
    if best_perm is None:
        raise RuntimeError("Failed to match observed boundary groups to reference holes.")
    return {
        expected_names[i]: boundaries[keys[ci]]
        for i, ci in enumerate(best_perm)
    }


def _cluster_points(points: np.ndarray, k: int) -> list[np.ndarray]:
    n_points = int(points.shape[0])
    if n_points < k:
        raise ValueError(f"Cannot cluster {n_points} points into {k} groups.")
    if n_points == k:
        return [points[i : i + 1] for i in range(n_points)]
    rng = np.random.default_rng(0)
    centroids = points[rng.choice(n_points, k, replace=False)]
    labels = np.zeros(n_points, dtype=int)
    for _ in range(40):
        dist2 = ((points[:, None, :] - centroids[None, :, :]) ** 2).sum(axis=-1)
        new_labels = dist2.argmin(axis=1)
        new_centroids: list[np.ndarray] = []
        for i in range(k):
            mask = new_labels == i
            if not np.any(mask):
                fallback = int(np.argmax(dist2[:, i]))
                new_centroids.append(points[fallback])
                new_labels[fallback] = i
            else:
                new_centroids.append(points[mask].mean(axis=0))
        new_centroids_arr = np.vstack(new_centroids)
        if np.all(new_labels == labels):
            break
        centroids = new_centroids_arr
        labels = new_labels
    return [points[labels == i] for i in range(k)]


def _coerce_step_selector(step: str | None) -> str | None:
    if step is None:
        return None
    value = step.strip()
    return value if value else None


def _resolve_step_key(steps: list[str], selector: str | int | None) -> str:
    if selector is None:
        return steps[-1]
    if isinstance(selector, int):
        if selector < 0:
            return steps[max(0, len(steps) + selector)]
        return steps[selector]
    selector_norm = _coerce_step_selector(selector)
    if selector_norm is None or selector_norm.lower() in {"last", "final", "-1"}:
        return steps[-1]
    if selector_norm in steps:
        return selector_norm
    try:
        idx = int(selector_norm)
    except ValueError as exc:
        raise ValueError(
            f"Could not resolve damage step selector {selector!r}. "
            f"Use a named step key or integer index."
        ) from exc
    if idx < 0:
        return steps[max(0, len(steps) + idx)]
    if idx >= len(steps):
        raise ValueError(
            f"Step index {idx} is out of range for {len(steps)} available step keys."
        )
    return steps[idx]


def _path_from_observation_csv(path: Path) -> dict[str, np.ndarray]:
    rows: list[dict[str, str]] = []
    with path.open("r", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            rows.append(row)
    if not rows:
        raise ValueError(f"Observation CSV is empty: {path}")
    keys_lower = {k.strip().lower() for k in rows[0].keys()}
    if "x" not in keys_lower or "y" not in keys_lower:
        raise ValueError(
            f"Observation CSV must contain x and y columns. "
            f"Detected columns: {sorted(rows[0].keys())}"
        )
    x_col = next(k for k in rows[0].keys() if k.lower() == "x")
    y_col = next(k for k in rows[0].keys() if k.lower() == "y")
    nodeset_col = next((k for k in rows[0].keys() if k.lower() == "nodeset"), "")
    group_col = next(
        (k for k in rows[0].keys() if k.lower() in {"group", "label", "cluster", "id"}),
        "",
    )
    if nodeset_col:
        grouped: dict[str, list[list[float]]] = {}
        for row in rows:
            grouped.setdefault(row[nodeset_col], []).append(
                [float(row[x_col]), float(row[y_col])]
            )
        return _match_observed_to_reference({k: np.asarray(v, dtype=float) for k, v in grouped.items()})
    if group_col:
        grouped: dict[str, list[list[float]]] = {}
        for row in rows:
            grouped.setdefault(row[group_col], []).append(
                [float(row[x_col]), float(row[y_col])]
            )
        return _match_observed_to_reference(
            {k: np.asarray(v, dtype=float) for k, v in grouped.items()}
        )
    if len(rows) < len(HOLE_NODESETS):
        raise ValueError(
            "CSV has no nodeset/group columns and too few rows to infer boundary groups."
        )
    points = np.asarray([[float(row[x_col]), float(row[y_col])] for row in rows], dtype=float)
    clusters = _cluster_points(points, k=len(HOLE_NODESETS))
    provisional = {f"cluster_{i}": c for i, c in enumerate(clusters)}
    return _match_observed_to_reference(provisional)


def _extract_damage_contours(
    nodes: np.ndarray,
    elements: np.ndarray,
    damage: np.ndarray,
    level: float = 0.5,
) -> list[np.ndarray]:
    fig = plt.figure()
    ax = fig.add_subplot(111)
    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)
    cs = ax.tricontour(tri, damage, levels=[level], linewidths=1.0, colors="black")
    raw_paths: list[np.ndarray] = []
    for collection in cs.collections:
        for path in collection.get_paths():
            verts = np.asarray(path.vertices, dtype=float)
            if verts.shape[0] < 6:
                continue
            raw_paths.append(verts[:, :2])
    plt.close(fig)
    # Keep contour candidates with realistic hole radius scale and enough points.
    candidates = []
    for pts in raw_paths:
        c = pts.mean(axis=0)
        r = float(np.linalg.norm(pts - c, axis=1).mean())
        if 1.0 <= r <= 30.0:
            candidates.append(pts)
    return candidates


def _assign_contour_candidates(candidates: list[np.ndarray]) -> dict[str, np.ndarray]:
    if len(candidates) < len(HOLE_NODESETS):
        raise ValueError(
            "Could not extract three robust contour loops from damage field. "
            "Use --observed_boundary_csv for explicit point sets."
        )
    provisional = {f"contour_{i}": c for i, c in enumerate(candidates)}
    return _match_observed_to_reference(provisional)


def load_boundary_observations(
    h5_path: Path,
    *,
    from_damage_contour: bool = False,
    contour_level: float = 0.5,
    damage_step: str | int | None = None,
    boundary_csv: Path | None = None,
    damage_points: np.ndarray | None = None,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    fields = load_h5_fields(h5_path, damage_step=damage_step)
    if boundary_csv is not None:
        return _path_from_observation_csv(boundary_csv), fields
    if damage_points is not None:
        clusters = _cluster_points(np.asarray(damage_points, dtype=float), k=len(HOLE_NODESETS))
        return {f"cluster_{i}": c for i, c in enumerate(clusters)}, fields
    if from_damage_contour:
        candidates = _extract_damage_contours(
            fields["nodes"],
            fields["elements"],
            fields["damage"],
            level=contour_level,
        )
        return _assign_contour_candidates(candidates), fields
    # default: archived boundary node sets (measurement from the H5 file)
    return fields["boundaries"], fields

def fit_circle_least_squares(points: np.ndarray) -> tuple[np.ndarray, float]:
    """Fit ``(x-a)^2 + (y-b)^2 = r^2`` by linear least squares."""
    pts = np.asarray(points, dtype=float)
    if pts.ndim != 2 or pts.shape[1] != 2 or pts.shape[0] < 3:
        raise ValueError("points must have shape (n>=3, 2)")
    x = pts[:, 0]
    y = pts[:, 1]
    A = np.column_stack([x, y, np.ones_like(x)])
    b = -(x * x + y * y)
    alpha, beta, gamma = np.linalg.lstsq(A, b, rcond=None)[0]
    centre = np.array([-0.5 * alpha, -0.5 * beta], dtype=float)
    radius_sq = float(centre @ centre - gamma)
    if radius_sq <= 0.0:
        raise ValueError("least-squares circle produced non-positive radius")
    return centre, float(np.sqrt(radius_sq))


def load_h5_fields(path: Path, damage_step: str | int | None = None) -> dict:
    with h5py.File(path, "r") as f:
        root = f["simulation_data"]
        nodes = root["mesh/node_coordinates"][:]
        elements = root["mesh/element_connectivity"][:]
        node_sets = root["mesh/node_sets"]
        steps = sorted(root["steps"].keys())
        selected = _resolve_step_key(steps, damage_step)
        final = root["steps"][selected]
        damage = final["damage_nodal"][:]
        displacement = final["displacement"][:] if "displacement" in final else None
        boundaries = {
            name: nodes[node_sets[name][:]]
            for name, *_ in HOLE_NODESETS
            if name in node_sets
        }
    return {
        "nodes": nodes,
        "elements": elements,
        "damage": damage,
        "displacement": displacement,
        "boundaries": boundaries,
        "steps": steps,
        "selected_step": selected,
    }


def recover_holes(boundaries: dict[str, np.ndarray]) -> list[dict]:
    boundaries = _match_observed_to_reference(boundaries)
    rows = []
    for nodeset, label, truth_centre, truth_radius in HOLE_NODESETS:
        if nodeset not in boundaries:
            continue
        centre, radius = fit_circle_least_squares(boundaries[nodeset])
        init = np.array(INIT_GUESSES[nodeset], dtype=float)
        truth = np.array(truth_centre, dtype=float)
        rows.append(
            {
                "nodeset": nodeset,
                "label": label,
                "truth_x": float(truth[0]),
                "truth_y": float(truth[1]),
                "truth_radius": float(truth_radius),
                "init_x": float(init[0]),
                "init_y": float(init[1]),
                "recovered_x": float(centre[0]),
                "recovered_y": float(centre[1]),
                "recovered_radius": float(radius),
                "init_error_mm": float(np.linalg.norm(init - truth)),
                "recovered_error_mm": float(np.linalg.norm(centre - truth)),
                "radius_error_mm": float(abs(radius - truth_radius)),
                "n_boundary_points": int(boundaries[nodeset].shape[0]),
            }
        )
    return rows


def write_outputs(rows: list[dict], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "hole_position_recovery.json").write_text(
        json.dumps({"holes": rows}, indent=2) + "\n"
    )
    with (out_dir / "hole_position_recovery.csv").open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def plot_recovery(fields: dict, rows: list[dict], out_dir: Path) -> None:
    nodes = fields["nodes"]
    elements = fields["elements"]
    damage = fields["damage"]
    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)

    fig, ax = plt.subplots(figsize=(7.0, 8.2), constrained_layout=True)
    tpc = ax.tripcolor(tri, damage, shading="gouraud", cmap="magma", vmin=0, vmax=1)
    cb = fig.colorbar(tpc, ax=ax, fraction=0.035, pad=0.02)
    cb.set_label("damage $d$")

    for row in rows:
        init = (row["init_x"], row["init_y"])
        rec = (row["recovered_x"], row["recovered_y"])
        truth = (row["truth_x"], row["truth_y"])
        radius = row["truth_radius"]
        ax.add_patch(Circle(init, radius, fill=False, ec="#c7362f", lw=1.8, ls="--"))
        ax.add_patch(Circle(truth, radius, fill=False, ec="black", lw=1.4, ls=":"))
        ax.add_patch(Circle(rec, row["recovered_radius"], fill=False, ec="#2878b5", lw=1.8))
        ax.plot(*init, marker="x", ms=8, mew=2, color="#c7362f")
        ax.plot(*truth, marker="*", ms=9, color="black")
        ax.plot(*rec, marker="o", ms=5, color="#2878b5")
        ax.text(
            rec[0] + 1.0,
            rec[1] + 1.0,
            row["label"].split()[0],
            fontsize=8,
            color="#2878b5",
        )

    ax.plot([], [], color="#c7362f", lw=1.8, ls="--", label="initial wrong")
    ax.plot([], [], color="#2878b5", lw=1.8, label="recovered from observed boundary")
    ax.plot([], [], color="black", lw=1.4, ls=":", label="COMSOL/reference truth")
    ax.set_aspect("equal")
    ax.set_xlim(-2, 68)
    ax.set_ylim(-2, 123)
    ax.set_xlabel("$x$ (mm)")
    ax.set_ylabel("$y$ (mm)")
    ax.set_title(
        "Quasi-static notched-holed plate: hole-position initializer",
        fontsize=11,
    )
    ax.legend(loc="upper right", fontsize=8, framealpha=0.92)
    ax.grid(alpha=0.15)
    fig.savefig(out_dir / "qs_comsol_hole_position_recovery.png", dpi=250)
    fig.savefig(out_dir / "qs_comsol_hole_position_recovery.pdf")
    plt.close(fig)


def run(
    h5: Path = DEFAULT_H5,
    out_dir: Path = DEFAULT_OUT,
    *,
    from_damage_contour: bool = False,
    contour_level: float = 0.5,
    damage_step: str | int | None = None,
    boundary_csv: Path | None = None,
    damage_points: np.ndarray | None = None,
) -> dict:
    boundaries, fields = load_boundary_observations(
        h5,
        from_damage_contour=from_damage_contour,
        contour_level=contour_level,
        damage_step=damage_step,
        boundary_csv=boundary_csv,
        damage_points=damage_points,
    )
    rows = recover_holes(boundaries)
    if not rows:
        raise RuntimeError("no recognised hole boundary observations found")
    write_outputs(rows, out_dir)
    plot_recovery(fields, rows, out_dir)
    return {"h5": str(h5), "out_dir": str(out_dir), "holes": rows}


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Fit hole centres/radii from the QS COMSOL holed-plate H5 archive."
    )
    parser.add_argument("--h5", type=Path, default=DEFAULT_H5)
    parser.add_argument("--out_dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument(
        "--damage_step",
        type=str,
        default=None,
        help="Step key (name or index) in h5. Default is final step.",
    )
    parser.add_argument(
        "--from_damage_contour",
        action="store_true",
        help="Recover boundary loops from a damage isocontour instead of node sets.",
    )
    parser.add_argument(
        "--contour_level",
        type=float,
        default=0.5,
        help="Contour level in [0,1] for damage extraction mode.",
    )
    parser.add_argument(
        "--observed_boundary_csv",
        type=Path,
        default=None,
        help=(
            "Optional CSV with columns nodeset,x,y to recover holes from observed "
            "boundary points only."
        ),
    )
    args = parser.parse_args()
    result = run(
        args.h5,
        args.out_dir,
        from_damage_contour=args.from_damage_contour,
        contour_level=args.contour_level,
        damage_step=args.damage_step,
        boundary_csv=args.observed_boundary_csv,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
