#!/usr/bin/env python
"""Scaling study: autograd vs FD cost per gradient as k = n_elem grows.

Shows the central claim of the spatial Gc(x) recovery demo: autograd
cost is INDEPENDENT of k (2 CG solves per damage step), while FD cost
is O(k) (k+1 forwards per gradient). At some k, FD becomes infeasible.

Output: scaling_study.csv with columns
  n_elem, autograd_s, fd_extrapolated_s, fd_measured_s (or NaN if too big)

This produces the "mic drop" figure for §4 of the paper.
"""
import os
import sys
import time
import csv
import argparse
import tempfile
import subprocess

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))
sys.path.insert(0, THIS_DIR)

from phast.inverse_problems.demos.demo_spatial_gc_recovery import (
    build_sent_mesh, build_solver, run_dynamic, make_truth_field)


SCALING_FIELDNAMES = [
    'h_crack',
    'n_elem',
    'autograd_s',
    'fd_single_s',
    'fd_full_s',
    'speedup',
]

FAILURE_FIELDNAMES = ['h_crack', 'error']


def measure_one(h_crack, h_coarse, n_steps, device, dtype,
                 dU=0.005, fd_elements=3):
    """Measure autograd vs FD cost on one mesh size.

    Returns
    -------
    n_elem, t_autograd, t_fd_single (for a single-element perturbation)
        t_fd_total = (k+1) * t_forward would be the naive FD cost; we
        measure t_fd_single and report the linear extrapolation.
    """
    mesh = build_sent_mesh(h_crack, h_coarse, device, dtype)
    solver = build_solver(mesh, device, dtype, damage_every=1, dU=dU)
    solver.damage_solver.tol = 1e-9

    n_elem = solver.damage_solver._cg_elements.shape[0]
    print(f"\n--- h_crack={h_crack}, n_elem={n_elem} ---")

    Gc_true = make_truth_field(solver)

    # Warm-up (JIT, AMG coarsening, etc)
    with torch.no_grad():
        _ = run_dynamic(solver, Gc_true, n_steps)

    # ---- Autograd cost (forward + backward, one gradient) ----
    Gc = Gc_true.clone().requires_grad_(True)
    t0 = time.time()
    d_pred = run_dynamic(solver, Gc, n_steps)
    # Scalar loss, backprop
    loss = (d_pred ** 2).sum()
    loss.backward()
    t_autograd = time.time() - t0
    print(f"  Autograd (1 gradient, full k={n_elem}): {t_autograd:.3f}s")

    # ---- FD cost per element (single central FD) ----
    # Two forwards per element. Measure one pair and extrapolate.
    h = 1e-4 * Gc_true.mean().item()
    t0 = time.time()
    Gc_p = Gc_true.clone()
    Gc_p[0] += h
    with torch.no_grad():
        dp = run_dynamic(solver, Gc_p, n_steps)
    Gc_m = Gc_true.clone()
    Gc_m[0] -= h
    with torch.no_grad():
        dm = run_dynamic(solver, Gc_m, n_steps)
    t_fd_single = time.time() - t0
    t_fd_full = t_fd_single * n_elem  # O(k) extrapolation
    print(f"  FD per element (2 forwards):          {t_fd_single:.3f}s")
    print(f"  FD extrapolated (full k={n_elem} grad): {t_fd_full:.3f}s "
          f"= {t_fd_full/60:.1f} min")

    speedup = t_fd_full / t_autograd
    print(f"  Autograd speedup vs FD:  {speedup:.1f}x")

    return n_elem, t_autograd, t_fd_single, t_fd_full


def write_scaling_outputs(out_dir, results, failures):
    """Write scaling-study CSV outputs without masking all-failure sweeps."""
    csv_path = os.path.join(out_dir, 'scaling_study.csv')
    with open(csv_path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=SCALING_FIELDNAMES)
        w.writeheader()
        w.writerows(results)

    failures_path = None
    if failures:
        failures_path = os.path.join(out_dir, 'scaling_study_failures.csv')
        with open(failures_path, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=FAILURE_FIELDNAMES)
            w.writeheader()
            w.writerows(failures)
    return csv_path, failures_path


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device', type=str, default='cpu')
    p.add_argument('--n_steps', type=int, default=20)
    p.add_argument('--h_list', type=str,
                   default='0.5,0.3,0.2,0.15,0.1,0.075,0.05',
                   help='Comma-separated h_crack values')
    p.add_argument('--output_dir', type=str, default='results_scaling')
    args = p.parse_args()

    out_dir = os.path.join(THIS_DIR, args.output_dir) \
        if not os.path.isabs(args.output_dir) else args.output_dir
    os.makedirs(out_dir, exist_ok=True)

    h_list = [float(x) for x in args.h_list.split(',')]
    print("=" * 60)
    print("  Scaling study: autograd vs FD cost per gradient")
    print("=" * 60)
    print(f"  Device:  {args.device}")
    print(f"  n_steps: {args.n_steps}")
    print(f"  h_crack list: {h_list}")

    results = []
    failures = []
    for h in h_list:
        try:
            n_elem, t_ad, t_fd_one, t_fd_full = measure_one(
                h, h * 2.0, args.n_steps, args.device, torch.float64)
            results.append({
                'h_crack': h, 'n_elem': n_elem,
                'autograd_s': t_ad,
                'fd_single_s': t_fd_one,
                'fd_full_s': t_fd_full,
                'speedup': t_fd_full / t_ad,
            })
        except Exception as e:
            print(f"  FAILED at h={h}: {e}")
            failures.append({'h_crack': h, 'error': str(e)})

    # Save CSV
    csv_path, failures_path = write_scaling_outputs(out_dir, results, failures)
    print(f"\nSaved: {csv_path}")
    if failures_path:
        print(f"Saved failures: {failures_path}")
    if not results:
        print("No successful measurements; wrote header-only scaling CSV.")
        return

    # Pretty-print summary
    print(f"\n{'h':>6} | {'n_elem':>8} | {'AD (s)':>10} | "
          f"{'FD full (s)':>12} | {'speedup':>10}")
    print(f"{'-'*6} | {'-'*8} | {'-'*10} | {'-'*12} | {'-'*10}")
    for r in results:
        print(f"{r['h_crack']:>6.3f} | {r['n_elem']:>8d} | "
              f"{r['autograd_s']:>10.2f} | {r['fd_full_s']:>12.1f} | "
              f"{r['speedup']:>10.1f}x")


if __name__ == '__main__':
    main()
