"""Discrete adjoint with Griewank-style checkpointing.

Implements an O(sqrt(N)) memory backward pass for fixed-step time
integrators, equivalent in gradient to full-tape autograd up to floating
point. The algorithm is a one-level binomial/equidistant variant of
Griewank's revolve (Griewank, 1992; Griewank & Walther, 2000): store
state at K = ceil(sqrt(N)) strided indices during the forward sweep,
then in backward replay each chunk of length ~sqrt(N) under
``torch.enable_grad()`` from the prior checkpoint and apply chain rule
within that chunk via standard autograd.

This is functionally equivalent to ``torch.utils.checkpoint
.checkpoint_sequential`` with chunk count sqrt(N); we provide a custom
``autograd.Function`` because our PF stepper is stateful (the solver
mutates internal buffers in place) and we need explicit
snapshot/restore semantics rather than functional segments.

Honest framing
--------------
This does NOT cure chaotic gradient blow-up. The discrete adjoint
recurrence has the same Lyapunov spectrum (sign-flipped) as the
forward, so unstable forward implies unstable backward. The benefit is
purely *memory*: peak tape size shrinks from O(N) to O(sqrt(N)) without
changing the gradient or its conditioning. See issue #284 (reframed
2026-05-07).
"""
from __future__ import annotations

import math
from typing import Any, Callable, List, Optional, Sequence, Tuple

import torch


# ---------------------------------------------------------------------------
# State protocol
# ---------------------------------------------------------------------------
#
# A "stepper" is any callable with the contract
#
#     state_next = stepper(state, params)
#
# where ``state`` and ``params`` are tuples of torch.Tensor. The stepper
# must be deterministic and side-effect-free w.r.t. its inputs (it may
# allocate fresh tensors internally; it must not mutate ``state`` or
# ``params``). For stateful solvers like ``StaggeredSolver``, wrap the
# in-place ``step_full`` with a snapshot/restore helper (see
# ``StatefulStepper`` below).


def _detach_clone_tuple(xs: Sequence[torch.Tensor]) -> Tuple[torch.Tensor, ...]:
    return tuple(x.detach().clone() for x in xs)


def _requires_grad_clone_tuple(
    xs: Sequence[torch.Tensor],
) -> Tuple[torch.Tensor, ...]:
    out = []
    for x in xs:
        y = x.detach().clone()
        if x.is_floating_point():
            y.requires_grad_(True)
        out.append(y)
    return tuple(out)


class CheckpointedForward:
    """Run a stepper N times while saving sqrt(N)-strided checkpoints.

    Parameters
    ----------
    stepper : callable
        ``state_next = stepper(state, params)``; see module docstring.
    n_steps : int
        Total number of forward steps.
    n_checkpoints : int, optional
        Number of equally-spaced checkpoints. Defaults to ``ceil(sqrt(N))``,
        which minimises peak memory for the equidistant scheme.
    """

    def __init__(
        self,
        stepper: Callable[..., Tuple[torch.Tensor, ...]],
        n_steps: int,
        n_checkpoints: Optional[int] = None,
    ):
        if n_steps < 1:
            raise ValueError("n_steps must be >= 1")
        self.stepper = stepper
        self.n_steps = int(n_steps)
        if n_checkpoints is None:
            n_checkpoints = max(1, int(math.ceil(math.sqrt(self.n_steps))))
        self.n_checkpoints = max(1, min(int(n_checkpoints), self.n_steps))
        # Boundaries[k] is the step index where chunk k STARTS. There are
        # ``n_checkpoints`` chunks; checkpoint k is the state at
        # boundaries[k]. The final state is at index n_steps.
        self.boundaries: List[int] = self._make_boundaries(
            self.n_steps, self.n_checkpoints
        )

    @staticmethod
    def _make_boundaries(n_steps: int, n_chunks: int) -> List[int]:
        # Equidistant chunking; last chunk absorbs the remainder.
        b = [int(round(i * n_steps / n_chunks)) for i in range(n_chunks)]
        # ensure strictly increasing and starts at 0
        b[0] = 0
        for i in range(1, n_chunks):
            if b[i] <= b[i - 1]:
                b[i] = b[i - 1] + 1
        return b

    def forward_with_checkpoints(
        self,
        state0: Sequence[torch.Tensor],
        params: Sequence[torch.Tensor],
    ) -> Tuple[Tuple[torch.Tensor, ...], List[Tuple[torch.Tensor, ...]]]:
        """Forward sweep returning (final_state, checkpoints).

        All tensors in checkpoints are detached clones; no autograd graph
        is retained outside the chunk currently being processed.
        """
        ckpts: List[Tuple[torch.Tensor, ...]] = []
        state = _detach_clone_tuple(state0)
        with torch.no_grad():
            for k in range(self.n_steps):
                if k in self._boundaries_set():
                    ckpts.append(_detach_clone_tuple(state))
                state = self.stepper(state, params)
            final_state = _detach_clone_tuple(state)
        # Sanity: we should have stored exactly n_checkpoints snapshots.
        return final_state, ckpts

    def _boundaries_set(self) -> set:
        if not hasattr(self, "_b_set"):
            self._b_set = set(self.boundaries)
        return self._b_set


class _DiscreteAdjointFunction(torch.autograd.Function):
    """torch.autograd.Function wrapping the checkpointed forward.

    Backward replays each chunk under ``torch.enable_grad()`` starting
    from the saved checkpoint, then applies vector-Jacobian products via
    standard autograd within the chunk.
    """

    @staticmethod
    def forward(ctx, stepper, n_steps, n_checkpoints, n_state, n_params, *args):
        # Layout: args = state0 (n_state tensors) + params (n_params tensors)
        state0 = args[:n_state]
        params = args[n_state:]
        ck = CheckpointedForward(stepper, n_steps, n_checkpoints)
        final_state, ckpts = ck.forward_with_checkpoints(state0, params)
        # Save tensors needed for backward via save_for_backward (state
        # checkpoints + params). Stash the structural metadata on ctx.
        ctx.stepper = stepper
        ctx.boundaries = ck.boundaries
        ctx.n_steps = ck.n_steps
        ctx.n_state = n_state
        ctx.n_params = n_params
        ctx.n_checkpoints = ck.n_checkpoints
        # Save: flattened ckpts + params. Use save_for_backward where
        # safe; for dicts of tensors, autograd's save_for_backward expects
        # a flat tuple, which we have.
        flat_ckpts = tuple(t for ck_tuple in ckpts for t in ck_tuple)
        ctx.save_for_backward(*flat_ckpts, *params)
        return final_state

    @staticmethod
    def backward(ctx, *grad_outputs):
        n_state = ctx.n_state
        n_params = ctx.n_params
        n_chunks = ctx.n_checkpoints
        boundaries = ctx.boundaries
        n_steps = ctx.n_steps
        stepper = ctx.stepper

        saved = ctx.saved_tensors
        # Unpack: first n_chunks * n_state are checkpoint tensors, rest
        # are params.
        flat_ckpts = saved[: n_chunks * n_state]
        params_saved = saved[n_chunks * n_state :]
        ckpts: List[Tuple[torch.Tensor, ...]] = [
            tuple(flat_ckpts[k * n_state : (k + 1) * n_state])
            for k in range(n_chunks)
        ]

        # Cotangent on the final state (gradient of loss w.r.t. each
        # output state tensor).
        grad_state = list(grad_outputs)
        # Accumulator for parameter gradients.
        param_grads: List[Optional[torch.Tensor]] = [None] * n_params

        # Walk chunks in reverse.
        for k in reversed(range(n_chunks)):
            chunk_start = boundaries[k]
            chunk_end = boundaries[k + 1] if k + 1 < n_chunks else n_steps
            chunk_len = chunk_end - chunk_start
            if chunk_len <= 0:
                continue
            # Re-create autograd-enabled state from the saved checkpoint.
            ckpt = ckpts[k]
            with torch.enable_grad():
                state_in = tuple(
                    t.detach().clone().requires_grad_(t.is_floating_point())
                    for t in ckpt
                )
                params_in = tuple(
                    p.detach().clone().requires_grad_(p.is_floating_point())
                    for p in params_saved
                )
                state = state_in
                for _ in range(chunk_len):
                    state = stepper(state, params_in)
                # state is now the chunk-end state with a graph back to
                # state_in and params_in. Apply VJP.
                # Filter outputs / grads to floating-point tensors only —
                # autograd cannot differentiate through integer state
                # (e.g. step counters); their grad_state entries must be
                # None or zero.
                outs = []
                gs = []
                for o, g in zip(state, grad_state):
                    if o.is_floating_point() and g is not None:
                        outs.append(o)
                        gs.append(g)
                # Inputs we need gradients for: floating-point state_in
                # entries + floating-point params.
                state_in_fp_idx = [
                    i for i, t in enumerate(state_in) if t.is_floating_point()
                ]
                params_fp_idx = [
                    i for i, t in enumerate(params_in) if t.is_floating_point()
                ]
                fp_inputs = (
                    [state_in[i] for i in state_in_fp_idx]
                    + [params_in[i] for i in params_fp_idx]
                )
                grads = torch.autograd.grad(
                    outputs=outs,
                    inputs=fp_inputs,
                    grad_outputs=gs,
                    retain_graph=False,
                    create_graph=False,
                    allow_unused=True,
                )
            # Update grad_state to be the chunk-input cotangent.
            new_grad_state: List[Optional[torch.Tensor]] = [None] * n_state
            for j, i in enumerate(state_in_fp_idx):
                new_grad_state[i] = grads[j]
            grad_state = new_grad_state
            # Accumulate param grads.
            offset = len(state_in_fp_idx)
            for j, i in enumerate(params_fp_idx):
                g = grads[offset + j]
                if g is None:
                    continue
                if param_grads[i] is None:
                    param_grads[i] = g.detach().clone()
                else:
                    param_grads[i] = param_grads[i] + g.detach()

        # Prepare the gradient tuple matching the forward inputs:
        # (stepper, n_steps, n_checkpoints, n_state, n_params, *state0, *params)
        out_grads: List[Any] = [None, None, None, None, None]
        # state0 grads
        for g in grad_state:
            out_grads.append(g)
        # params grads
        for g in param_grads:
            out_grads.append(g)
        return tuple(out_grads)


class DiscreteAdjoint:
    """User-facing wrapper.

    Example
    -------
    >>> adj = DiscreteAdjoint(stepper, n_steps=100, n_checkpoints=10)
    >>> final_state = adj(state0, params)
    >>> loss = some_scalar(final_state)
    >>> loss.backward()    # gradients flow into state0[i] and params[j]
    """

    def __init__(
        self,
        stepper: Callable[..., Tuple[torch.Tensor, ...]],
        n_steps: int,
        n_checkpoints: Optional[int] = None,
    ):
        self.stepper = stepper
        self.n_steps = int(n_steps)
        if n_checkpoints is None:
            n_checkpoints = max(1, int(math.ceil(math.sqrt(self.n_steps))))
        self.n_checkpoints = int(n_checkpoints)

    def __call__(
        self,
        state0: Sequence[torch.Tensor],
        params: Sequence[torch.Tensor],
    ) -> Tuple[torch.Tensor, ...]:
        state0 = tuple(state0)
        params = tuple(params)
        return _DiscreteAdjointFunction.apply(
            self.stepper,
            self.n_steps,
            self.n_checkpoints,
            len(state0),
            len(params),
            *state0,
            *params,
        )


# ---------------------------------------------------------------------------
# Helper: stateful-solver wrapper.
# ---------------------------------------------------------------------------


class StatefulStepper:
    """Adapter that turns an in-place stepper into a functional one.

    Given a solver object whose ``step_full()`` method mutates internal
    tensor attributes, plus ``snapshot`` and ``restore`` callables, this
    presents a pure ``stepper(state, params)`` interface suitable for
    ``DiscreteAdjoint``.

    Parameters
    ----------
    solver : object
        Has a ``step_full()`` method.
    state_attrs : sequence of str
        Names of solver attributes that constitute the differentiable
        state. These will be tuple-packed/unpacked.
    params_attrs : sequence of str
        Names of solver attributes that hold the differentiable
        parameters (e.g. ``diff_Gc``, ``diff_l0``). Set on the solver
        before each step.
    """

    def __init__(self, solver, state_attrs: Sequence[str], params_attrs: Sequence[str]):
        self.solver = solver
        self.state_attrs = tuple(state_attrs)
        self.params_attrs = tuple(params_attrs)

    def snapshot(self) -> Tuple[torch.Tensor, ...]:
        return tuple(
            getattr(self.solver, n).detach().clone() for n in self.state_attrs
        )

    def restore(self, state: Sequence[torch.Tensor]) -> None:
        for n, t in zip(self.state_attrs, state):
            setattr(self.solver, n, t)

    def __call__(
        self,
        state: Sequence[torch.Tensor],
        params: Sequence[torch.Tensor],
    ) -> Tuple[torch.Tensor, ...]:
        # Inject state and params, take one step, harvest new state.
        for n, t in zip(self.state_attrs, state):
            setattr(self.solver, n, t)
        for n, p in zip(self.params_attrs, params):
            setattr(self.solver, n, p)
        self.solver.step_full()
        return tuple(getattr(self.solver, n) for n in self.state_attrs)


__all__ = [
    "CheckpointedForward",
    "DiscreteAdjoint",
    "StatefulStepper",
]
