#!/usr/bin/env python
"""Multi-parameter (E, nu, Gc, l0) joint recovery from full-field
displacement DIC observations on a Kosin-style edge-notched square
plate (advances #237).

This demo replicates the inverse-problem setup of

    Kosin V., Fau A., Jailin C., Hild F., Wick T. 2024,
    "Parameter identification of a phase-field fracture model using
    integrated digital image correlation",
    Computer Methods in Applied Mechanics and Engineering 420:116689.
    https://doi.org/10.1016/j.cma.2023.116689

and recovers the four phase-field parameters jointly via L-BFGS using
gradients computed by end-to-end autograd through the dynamic explicit
phase-field solver (no finite differences, no surrogate). Observations
are full-field displacement snapshots ``u(x, t_k)`` at a configurable
stride ``--obs_K``, mirroring DIC frame acquisition.

Architecture
------------
Forward dynamics: explicit central-difference + Kelvin-Voigt damping,
amor energy split, AT1 phase-field, gamma-corrected — same physics
stack as paper-2's other inverse demos (E_horizontal, gc_horizontal,
stiff_inclusion).

Parameter wiring: a 4-tensor parameter dict is installed on the solver
once per L-BFGS probe via ``make_install_kalthoff_params``:

    solver.material.E   = params['E']    # tensor, requires_grad
    solver.material.nu  = params['nu']   # tensor, requires_grad
    solver.diff_Gc      = params['Gc']   # 0-d tensor, requires_grad
    solver.diff_l0      = params['l0']   # 0-d tensor, requires_grad

Both ``E`` and ``nu`` enter ``FEMOperators._resolve_lame`` through
``self.material.E`` / ``self.material.nu`` reads — when those
attributes are torch tensors, the lam/mu computation stays on the
autograd tape and the gradient flows back to all four leaves. ``Gc``
and ``l0`` route through ``_AdjointDamageSolveScalar`` (implicit
differentiation through the CG damage solve) for end-to-end gradients.

Loss
----
Full-field displacement MSE, summed across snapshot times:

    L(theta) = (1 / |K|) sum_{k in K} || u_pred(x, t_k) - u_obs(x, t_k) ||^2 / N

Snapshot times are ``[K, 2K, ..., n_steps]`` for ``--obs_K K``. The
default smoke setup uses 5-10 snapshots over the loading window —
matching Kosin's typical DIC frame budget for a fracture experiment.

Optimisation
------------
L-BFGS on the log-parameters (``theta = log(E, nu, Gc, l0)``) so the
optimiser sees an unconstrained 4-vector and the parameters stay
positive by construction. Strong-Wolfe line search, history size 10.

Usage
-----
    # Local CPU smoke (~3-5 min)
    python demo_inverse_kosin_dic.py --device cpu --smoke
    # Smoke + scope test (E, Gc only)
    python demo_inverse_kosin_dic.py --device cpu --smoke --params E_Gc
    # Production GPU (Kosin-resolution mesh, short post-crack horizon)
    python demo_inverse_kosin_dic.py --device cuda --n_steps 3400 --obs_K 400

Honest scoping
--------------
At smoke resolution (h_crack ~ 0.4 mm, l0 = 0.1 mm) ``l0`` is
weakly identifiable because ``l0/h ~ 0.25`` is below the recommended
``l0/h >= 2`` for clean PF length-scale recovery. The smoke recovery
target is therefore (E, Gc, nu) at <5% rel-err and l0 at <15%; the
production HPC slurm runs at h_crack=0.05 where all four are
well-conditioned. See PR description for the production results table
once #237 HPC run lands.
"""
from __future__ import annotations
import argparse
import json
import os
import sys
import time
from dataclasses import dataclass

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.mesh_generator import rectangular_sent as gen_mesh
from phast.mesh import FEMMesh
from phast.material import create_material
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.config import LoadingConfig, compute_load_factor
from phast.device import DeviceContext


# Kosin-style PMMA-like reference parameters (close to Bleyer PMMA so
# the existing paper-2 forward stack is reused without retuning).
THETA_TRUE = dict(
    E=3090.0,    # MPa
    nu=0.35,     # -
    Gc=0.30,     # N/mm
    l0=0.10,     # mm
)
RHO = 1.18e-9    # tonne/mm^3 — fixed (Kosin treats density as known).

# Square plate edge-notched (Kosin geometry: square specimen with
# horizontal edge notch from the left face to mid-height).
W, H, A = 16.0, 16.0, 4.0
CRACK_Y = H / 2.0


def build_kosin_mesh(h_crack, h_coarse, l0, device, dtype):
    _tag = os.environ.get('SLURM_JOB_ID', f'pid{os.getpid()}')
    msh = f"/tmp/kosin_dic_{_tag}.msh"
    gen_mesh(msh, W=W, H=H, a=A, l0=l0,
             h_crack=h_crack, h_coarse=h_coarse, branching=False)
    mesh = FEMMesh(msh, device=device, dtype=dtype)
    mesh.identify_boundaries()
    return mesh, msh


def build_solver(mesh, theta_true, dU, tau_ramp, damping_zeta,
                  device, dtype):
    """Build the staggered explicit solver at the truth bulk
    parameters. Per-iteration parameter overrides are installed via
    the make_install_kalthoff_params hook on the same solver object.
    """
    mat = create_material(
        E=theta_true['E'], nu=theta_true['nu'], rho=RHO,
        Gc=theta_true['Gc'], l0=theta_true['l0'],
        energy_split='amor', pf_model='AT1', plane_stress=True,
        gamma_correction=True,
    )
    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)
    bcs.add(mesh.node_sets['top'],    component=1, value=+dU)
    bcs.add(mesh.node_sets['bottom'], component=1, value=-dU)
    bcs.fix(mesh.node_sets['left'], component=0)
    cfg = SolverConfig(
        solver_type='explicit', differentiable=True,
        damage_every=1, preconditioner='jacobi',
        damping_ratio_max=damping_zeta,
    )
    return StaggeredSolver(mesh, mat, bcs, config=cfg,
                            ctx=DeviceContext(device, dtype))


def install_params(solver, params):
    """Install (E, nu, Gc, l0) tensors onto the live solver.

    Mirrors `inverse_problems/_tbptt.py::make_install_kalthoff_params`
    (kept inline so this demo is independent of the TBPTT module).
    """
    if 'E' in params:
        solver.material.E = params['E']
    if 'nu' in params:
        solver.material.nu = params['nu']
    if 'Gc' in params:
        solver.diff_Gc = params['Gc']
    if 'l0' in params:
        solver.diff_l0 = params['l0']
    # Invalidate the FEMOperators _resolve_lame cache by clearing
    # the field-id key — when E/nu change as scalar attributes (no
    # diff_E_field) the cache_id is None throughout, so this is a
    # no-op; but if a future caller mixes E_field and scalar updates
    # the explicit reset prevents stale lam/mu reuse.
    if hasattr(solver.fem, '_E_field_cache_id'):
        solver.fem._E_field_cache_id = None


def _mesh_arrays(mesh):
    nodes = mesh.nodes.detach().cpu().numpy()
    elements = (mesh.elements.detach().cpu().numpy()
                if torch.is_tensor(mesh.elements)
                else np.asarray(mesh.elements, dtype=np.int64))
    return nodes, elements


def _save_displacement_viz(nodes, elements, u_final, u_snapshots,
                           out_dir, label='truth_dic'):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.tri as mtri

    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)
    mag_final = np.linalg.norm(u_final, axis=1)
    png_path = os.path.join(out_dir, f'{label}_displacement_final.png')
    fig, ax = plt.subplots(figsize=(6.4, 5.0), constrained_layout=True)
    pc = ax.tripcolor(tri, mag_final, shading='gouraud', cmap='viridis')
    ax.set_aspect('equal')
    ax.set_xlabel('x (mm)')
    ax.set_ylabel('y (mm)')
    ax.set_title(r'DIC displacement magnitude $|u|$')
    fig.colorbar(pc, ax=ax, label='mm')
    fig.savefig(png_path, dpi=180)
    plt.close(fig)

    gif_path = None
    if u_snapshots:
        try:
            from matplotlib.animation import PillowWriter
            gif_path = os.path.join(out_dir,
                                    f'{label}_displacement_evolution.gif')
            mags = [np.linalg.norm(u, axis=1) for u in u_snapshots]
            vmax = max(float(np.max(m)) for m in mags) or 1.0
            fig, ax = plt.subplots(figsize=(6.4, 5.0),
                                   constrained_layout=True)
            pc = ax.tripcolor(tri, mags[0], shading='gouraud',
                              cmap='viridis', vmin=0.0, vmax=vmax)
            ax.set_aspect('equal')
            ax.set_xlabel('x (mm)')
            ax.set_ylabel('y (mm)')
            fig.colorbar(pc, ax=ax, label='mm')
            writer = PillowWriter(fps=4)
            with writer.saving(fig, gif_path, dpi=140):
                for i, mag in enumerate(mags):
                    ax.clear()
                    ax.tripcolor(tri, mag, shading='gouraud',
                                 cmap='viridis', vmin=0.0, vmax=vmax)
                    ax.set_aspect('equal')
                    ax.set_xlabel('x (mm)')
                    ax.set_ylabel('y (mm)')
                    ax.set_title(f'DIC displacement magnitude, frame {i+1}')
                    writer.grab_frame()
            plt.close(fig)
        except Exception:
            gif_path = None
    return {'png': png_path, 'gif': gif_path}


@dataclass
class DICSampler:
    """Fixed camera-grid sampler for differentiable DIC observations."""

    points: np.ndarray
    node_ids: torch.Tensor
    weights: torch.Tensor


def _camera_grid(nx, ny, margin):
    xs = np.linspace(margin, W - margin, int(nx), dtype=np.float64)
    ys = np.linspace(margin, H - margin, int(ny), dtype=np.float64)
    xx, yy = np.meshgrid(xs, ys, indexing='xy')
    return np.column_stack([xx.ravel(), yy.ravel()])


def _build_dic_sampler(mesh, points, device, dtype):
    """Precompute triangle ids and barycentric weights for camera points.

    The expensive point-location step is non-differentiable but depends only
    on the fixed mesh and camera grid. The actual displacement interpolation is
    differentiable because it is a weighted sum of nodal displacement tensors.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.tri as mtri

    nodes, elements = _mesh_arrays(mesh)
    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elements)
    tri_ids = tri.get_trifinder()(points[:, 0], points[:, 1])
    valid = tri_ids >= 0
    if not np.any(valid):
        raise ValueError("No DIC camera-grid points fall inside the mesh.")
    if not np.all(valid):
        points = points[valid]
        tri_ids = tri_ids[valid]

    elem_ids = elements[tri_ids]
    p = points
    a = nodes[elem_ids[:, 0]]
    b = nodes[elem_ids[:, 1]]
    c = nodes[elem_ids[:, 2]]
    denom = ((b[:, 1] - c[:, 1]) * (a[:, 0] - c[:, 0])
             + (c[:, 0] - b[:, 0]) * (a[:, 1] - c[:, 1]))
    w0 = ((b[:, 1] - c[:, 1]) * (p[:, 0] - c[:, 0])
          + (c[:, 0] - b[:, 0]) * (p[:, 1] - c[:, 1])) / denom
    w1 = ((c[:, 1] - a[:, 1]) * (p[:, 0] - c[:, 0])
          + (a[:, 0] - c[:, 0]) * (p[:, 1] - c[:, 1])) / denom
    w2 = 1.0 - w0 - w1
    weights = np.column_stack([w0, w1, w2])
    return DICSampler(
        points=points,
        node_ids=torch.as_tensor(elem_ids, dtype=torch.long, device=device),
        weights=torch.as_tensor(weights, dtype=dtype, device=device),
    )


def _project_dic_snapshots(u_snaps, sampler):
    out = []
    ids = sampler.node_ids
    w = sampler.weights[:, :, None]
    for u in u_snaps:
        out.append((u[ids] * w).sum(dim=1))
    return out


def _split_frame_indices(n_frames, val_every):
    if int(val_every) <= 0:
        return list(range(n_frames)), []
    val = [i for i in range(n_frames) if (i + 1) % int(val_every) == 0]
    train = [i for i in range(n_frames) if i not in set(val)]
    if not train:
        raise ValueError("DIC validation split left no training frames.")
    return train, val


def _take(seq, indices):
    return [seq[i] for i in indices]


def _add_dic_noise(target, abs_std, rel_std):
    if abs_std == 0.0 and rel_std == 0.0:
        return target, 0.0
    scale = max(float(max(t.detach().abs().max() for t in target)), 1e-30)
    sigma = float(abs_std) + float(rel_std) * scale
    return [t + sigma * torch.randn_like(t) for t in target], sigma


def _set_common_dt(*solvers):
    dt = min(float(s.dt) for s in solvers if s.dt is not None)
    for s in solvers:
        if s.dt is not None:
            s.dt = dt
            if hasattr(s, 'mechanics') and hasattr(s.mechanics, 'dt'):
                s.mechanics.dt = dt
    return dt


def reaction_force_y(solver, u, d, node_indices):
    """Differentiable summed vertical reaction on selected nodes."""
    f_int = solver.fem.internal_force(u, d)
    return f_int[node_indices, 1].sum()


def run_forward(solver, loading, params, n_steps, snapshot_steps,
                record_damage=False, record_reaction=False,
                reaction_nodes=None):
    """Forward run that records solver.u at each snapshot step.

    Returns
    -------
    u_snaps : list[Tensor (N, 2)]  — autograd-attached when params have
        requires_grad, ordered by ascending step index.
    snap_steps_actual : list[int] — recorded step indices.
    """
    n_nodes = solver.mesh.n_nodes
    n_elem = solver.mesh.n_elems
    dt = solver.dtype
    dev = solver.device
    solver.u = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.v = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.a = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.d = torch.zeros(n_nodes, dtype=dt, device=dev)
    solver.H_elem = torch.zeros(n_elem, dtype=dt, device=dev)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dt, device=dev)
    solver._step_count = 0
    install_params(solver, params)

    snap_set = set(int(s) for s in snapshot_steps)
    u_snaps = []
    d_snaps = []
    reaction_snaps = []
    snap_steps_actual = []
    if record_reaction and reaction_nodes is None:
        raise ValueError("record_reaction=True requires reaction_nodes.")
    first_full_damage_step = None
    solver_dt = solver.dt
    _progress_every = max(1, min(n_steps // 10, 1000))
    _t0 = time.time()
    for step in range(n_steps):
        solver.bcs.load_factor = compute_load_factor(
            step, solver_dt, loading)
        solver.step_full()
        if (step + 1) in snap_set:
            u_snaps.append(solver.u)
            if record_damage:
                d_snaps.append(solver.d.detach().clone())
            if record_reaction:
                reaction_snaps.append(
                    reaction_force_y(solver, solver.u, solver.d,
                                     reaction_nodes))
            snap_steps_actual.append(step + 1)
        max_d = None
        if first_full_damage_step is None:
            max_d = float(solver.d.detach().max())
            if max_d >= 0.99:
                first_full_damage_step = step + 1
                print(f"    damage guard: max(d)>={max_d:.3f} at "
                      f"step {first_full_damage_step}/{n_steps}",
                      flush=True)
        if (step + 1) % _progress_every == 0:
            if max_d is None:
                max_d = float(solver.d.detach().max())
            max_u = float(solver.u.detach().abs().max())
            print(f"    step {step+1}/{n_steps} "
                  f"max(d)={max_d:.3f} "
                  f"max|u|={max_u:.4e} "
                  f"({time.time()-_t0:.1f}s)", flush=True)
    if record_damage:
        if record_reaction:
            return (u_snaps, d_snaps, reaction_snaps, snap_steps_actual,
                    solver.d.detach().clone())
        return u_snaps, d_snaps, snap_steps_actual, solver.d.detach().clone()
    if record_reaction:
        return u_snaps, reaction_snaps, snap_steps_actual
    return u_snaps, snap_steps_actual


def displacement_mse_loss(u_snaps_pred, u_snaps_target, weights=None):
    """Mean across snapshots of mean-squared per-node-component
    displacement misfit. Differentiable in the predicted snapshots.

    ``weights`` (optional): 1-D tensor of length N to apply
    ``sum(w_i * r_i) / sum(w_i)`` instead of an unweighted mean.
    Used by the time-weighted-loss path (issue #475).
    """
    assert len(u_snaps_pred) == len(u_snaps_target), (
        f"snapshot count mismatch: pred={len(u_snaps_pred)} "
        f"target={len(u_snaps_target)}"
    )
    losses = []
    for up, ut in zip(u_snaps_pred, u_snaps_target):
        losses.append(((up - ut) ** 2).mean())
    if weights is None:
        return torch.stack(losses).mean()
    from phast.inverse_problems._loss_weights import weighted_mean
    return weighted_mean(losses, weights)


def reaction_mse_loss(reaction_pred, reaction_target, weights=None):
    """Scale-free MSE for load-cell/reaction histories.

    The normalization makes ``--reaction_weight`` comparable across stages
    whose absolute loads differ by orders of magnitude.
    """
    if isinstance(reaction_pred, (list, tuple)):
        reaction_pred = torch.stack(list(reaction_pred))
    if isinstance(reaction_target, (list, tuple)):
        reaction_target = torch.stack(list(reaction_target))
    scale = reaction_target.detach().abs().max() + 1e-12
    residual = ((reaction_pred - reaction_target) / scale) ** 2
    losses = [r for r in residual]
    if weights is None:
        return torch.stack(losses).mean()
    from phast.inverse_problems._loss_weights import weighted_mean
    return weighted_mean(losses, weights)


def _fixed_theta_from_args(args):
    fixed = {}
    for name in ('E', 'nu', 'Gc', 'l0'):
        val = getattr(args, f'fixed_{name}')
        if val is not None:
            fixed[name] = float(val)
    return fixed


# ---------------------------------------------------------------- #
# CLI
# ---------------------------------------------------------------- #
def parse_param_set(arg):
    """`--params` selector: which subset of (E, nu, Gc, l0) is free."""
    if arg == '4' or arg == 'all':
        return ['E', 'nu', 'Gc', 'l0']
    if arg == 'E_Gc':
        return ['E', 'Gc']
    if arg == 'E_Gc_nu':
        return ['E', 'Gc', 'nu']
    return arg.split(',')


def _cpu_snapshots(snaps):
    return [u.detach().cpu() for u in snaps]


def _to_device_snapshots(snaps, device, dtype):
    return [u.to(device=device, dtype=dtype) for u in snaps]


def _save_checkpoint(path, it_next, log_free, optimiser, history,
                     fwd_counter_n, free, args):
    payload = {
        'it_next': int(it_next),
        'log_free': {
            k: v.detach().cpu() for k, v in log_free.items()
        },
        'optimiser': optimiser.state_dict(),
        'history': history,
        'fwd_counter_n': int(fwd_counter_n),
        'free': list(free),
        'args': vars(args),
    }
    torch.save(payload, path)
    print(f"  checkpoint saved -> {path}", flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device', type=str, default='cpu',
                   choices=['cpu', 'cuda'])
    p.add_argument('--dtype', type=str, default='float64',
                   choices=['float32', 'float64'])
    p.add_argument('--smoke', action='store_true',
                   help='Tiny mesh, ~200 steps, ~30 LBFGS iters; '
                        'CPU-feasible (~3-5 min).')
    p.add_argument('--h_crack', type=float, default=None)
    p.add_argument('--h_coarse', type=float, default=None)
    p.add_argument('--n_steps', type=int, default=None)
    p.add_argument('--n_iters', type=int, default=30)
    p.add_argument('--optimizer', type=str, default='lbfgs',
                   choices=['lbfgs', 'adam'],
                   help='Outer optimizer. Adam avoids repeated full-forward '
                        'strong-Wolfe line-search probes in diagnostic runs.')
    p.add_argument('--optimizer_lr', type=float, default=None,
                   help='Override optimizer learning rate. Defaults to 1.0 '
                        'for L-BFGS and 0.02 for Adam.')
    p.add_argument('--grad_clip_norm', type=float, default=None,
                   help='If set, clip log-parameter gradients after '
                        'backward and before the optimizer step.')
    p.add_argument('--obs_K', type=int, default=None,
                   help='Snapshot stride: u(x,t) is recorded every '
                        'obs_K steps (default n_steps/8).')
    p.add_argument('--obs_start_step', type=int, default=None,
                   help='First DIC snapshot step included in the loss. '
                        'Use for staged DIC: early elastic frames for '
                        'E/nu, crack-growth frames for Gc.')
    p.add_argument('--obs_end_step', type=int, default=None,
                   help='Last DIC snapshot step included in the loss. '
                        'Defaults to n_steps.')
    p.add_argument('--params', type=str, default='4',
                   help='Free parameters: 4 | E_Gc | E_Gc_nu | '
                        'comma-list (e.g. E,Gc).')
    p.add_argument('--fixed_E', type=float, default=None,
                   help='Override frozen E value for staged inversions.')
    p.add_argument('--fixed_nu', type=float, default=None,
                   help='Override frozen nu value for staged inversions.')
    p.add_argument('--fixed_Gc', type=float, default=None,
                   help='Override frozen Gc value for staged inversions.')
    p.add_argument('--fixed_l0', type=float, default=None,
                   help='Override frozen l0 value for staged inversions.')
    p.add_argument('--init_perturb', type=float, default=0.10,
                   help='Initial guess: theta_init = theta_true * '
                        '(1 + init_perturb) for each free param.')
    p.add_argument('--delta_U', type=float, default=2e-2)
    p.add_argument('--tau_ramp_us', type=float, default=30.0)
    p.add_argument('--damping_zeta', type=float, default=0.1)
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--time_weight_lambda', type=float, default=0.0,
                   help='Exponential snapshot down-weighting (issue '
                        '#475). Per-snapshot residual is multiplied by '
                        'exp(-lambda * t/T) where T=max(snap_steps). '
                        'Default 0.0 = uniform = byte-identical legacy.')
    p.add_argument('--dic_observable', type=str, default='nodes',
                   choices=['nodes', 'camera_grid'],
                   help='Use solver nodes (legacy synthetic inverse) or '
                        'project both target and prediction to a fixed '
                        'DIC camera grid.')
    p.add_argument('--dic_grid_nx', type=int, default=33,
                   help='Camera-grid points in x for --dic_observable '
                        'camera_grid.')
    p.add_argument('--dic_grid_ny', type=int, default=33,
                   help='Camera-grid points in y for --dic_observable '
                        'camera_grid.')
    p.add_argument('--dic_grid_margin', type=float, default=0.25,
                   help='Margin in mm between the specimen boundary and '
                        'the synthetic camera-grid points.')
    p.add_argument('--target_h_crack', type=float, default=None,
                   help='Optional independent target mesh h_crack. If set '
                        'different from h_crack, truth data are generated '
                        'on this mesh and projected to the camera grid.')
    p.add_argument('--target_h_coarse', type=float, default=None,
                   help='Optional independent target mesh h_coarse.')
    p.add_argument('--dic_noise_std', type=float, default=0.0,
                   help='Absolute Gaussian DIC displacement noise in mm.')
    p.add_argument('--dic_noise_rel', type=float, default=0.0,
                   help='Relative Gaussian DIC noise as a fraction of the '
                        'maximum target displacement magnitude.')
    p.add_argument('--dic_val_every', type=int, default=0,
                   help='Hold out every Nth DIC frame for validation loss. '
                        '0 disables the split.')
    p.add_argument('--reaction_weight', type=float, default=0.0,
                   help='If >0, add a normalized top-boundary reaction '
                        'history loss at the DIC snapshot times. This gives '
                        'a synthetic DIC+load-cell objective; default 0 keeps '
                        'legacy DIC-only behavior.')
    p.add_argument('--resume', action='store_true',
                   help='Resume from checkpoint/truth cache in output_dir.')
    p.add_argument('--checkpoint_path', type=str, default=None,
                   help='Checkpoint path. Defaults to '
                        '<output_dir>/inv_checkpoint.pt.')
    p.add_argument('--checkpoint_every', type=int, default=1,
                   help='Save checkpoint every N outer iterations.')
    p.add_argument('--output_dir', type=str,
                   default='results_inverse_kosin_dic')
    p.add_argument('--forward_only', action='store_true',
                   help='Generate the truth forward/DIC bundle and exit '
                        'before optimiser setup.')
    p.add_argument('--save_forward_viz', dest='save_forward_viz',
                   action='store_true', default=True,
                   help='Save damage and DIC displacement PNG/GIF outputs.')
    p.add_argument('--no_save_forward_viz', dest='save_forward_viz',
                   action='store_false',
                   help='Disable forward visual export.')
    p.add_argument('--n_viz_frames', type=int, default=24,
                   help='Maximum number of frames saved to review GIFs.')
    args = p.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    if args.smoke:
        h_crack  = args.h_crack  if args.h_crack  is not None else 0.4
        h_coarse = args.h_coarse if args.h_coarse is not None else 2.0
        n_steps  = args.n_steps  if args.n_steps  is not None else 200
    else:
        h_crack  = args.h_crack  if args.h_crack  is not None else 0.05
        h_coarse = args.h_coarse if args.h_coarse is not None else 0.5
        n_steps  = args.n_steps  if args.n_steps  is not None else 8000

    obs_K = args.obs_K if args.obs_K is not None else max(1, n_steps // 8)
    obs_start = 1 if args.obs_start_step is None else int(args.obs_start_step)
    obs_end = n_steps if args.obs_end_step is None else int(args.obs_end_step)
    if obs_start < 1 or obs_end < obs_start or obs_end > n_steps:
        raise ValueError(
            f"Invalid observation window [{obs_start}, {obs_end}] for "
            f"n_steps={n_steps}")
    snap_steps = [s for s in range(obs_K, n_steps + 1, obs_K)
                  if obs_start <= s <= obs_end]
    if not snap_steps or snap_steps[-1] != n_steps:
        if obs_start <= obs_end <= n_steps:
            snap_steps.append(obs_end)
    snap_steps = sorted(set(snap_steps))
    if args.n_viz_frames > 0 and len(snap_steps) > args.n_viz_frames:
        idx = np.linspace(0, len(snap_steps) - 1, args.n_viz_frames)
        snap_steps = [snap_steps[int(round(i))] for i in idx]
        snap_steps = sorted(set(snap_steps))

    out_dir = (args.output_dir if os.path.isabs(args.output_dir)
               else os.path.join(THIS_DIR, args.output_dir))
    os.makedirs(out_dir, exist_ok=True)
    truth_cache = os.path.join(out_dir, 'truth_snapshots.pt')
    checkpoint_path = (args.checkpoint_path if args.checkpoint_path
                       is not None else
                       os.path.join(out_dir, 'inv_checkpoint.pt'))

    device = args.device
    dtype = torch.float32 if args.dtype == 'float32' else torch.float64
    tau_ramp = args.tau_ramp_us * 1e-6

    free = parse_param_set(args.params)
    fixed_theta = _fixed_theta_from_args(args)
    print("=" * 72)
    print("  Kosin-DIC multi-parameter recovery (advances #237)")
    print("=" * 72)
    print(f"  Plate: {W} x {H} mm, edge notch a={A} mm, y={CRACK_Y}")
    print(f"  Mesh:  h_crack={h_crack}, h_coarse={h_coarse}; "
          f"n_steps={n_steps}, device={device}, dtype={args.dtype}")
    print(f"  Loading: smooth-cosine ramp tau_ramp={args.tau_ramp_us} us, "
          f"delta_U={args.delta_U} mm")
    print(f"  Free params: {free}")
    if fixed_theta:
        print("  Fixed overrides: "
              + ", ".join(f"{k}={v:.6g}" for k, v in fixed_theta.items()))
    print(f"  Truth: " + ", ".join(f"{k}={THETA_TRUE[k]:.4g}"
                                     for k in free))
    print(f"  DIC snapshots: {len(snap_steps)} frames "
          f"every {obs_K} steps in [{obs_start}, {obs_end}]")
    print(f"  DIC observable: {args.dic_observable}")

    # Mesh + solver
    mesh, msh_path = build_kosin_mesh(h_crack, h_coarse,
                                        THETA_TRUE['l0'], device, dtype)
    solver = build_solver(mesh, THETA_TRUE, args.delta_U, tau_ramp,
                            args.damping_zeta, device, dtype)
    reaction_enabled = bool(args.reaction_weight > 0.0)
    pred_reaction_nodes = torch.as_tensor(
        mesh.node_sets['top'], dtype=torch.long, device=device)
    loading = LoadingConfig(ramp_type='smooth', t_ramp=tau_ramp)
    target_h_crack = (args.target_h_crack if args.target_h_crack is not None
                      else h_crack)
    target_h_coarse = (args.target_h_coarse if args.target_h_coarse is not None
                       else h_coarse)
    target_is_independent = (
        abs(float(target_h_crack) - float(h_crack)) > 1e-12
        or abs(float(target_h_coarse) - float(h_coarse)) > 1e-12)
    target_mesh = mesh
    target_solver = solver
    target_reaction_nodes = pred_reaction_nodes
    if target_is_independent:
        if args.dic_observable != 'camera_grid':
            raise ValueError(
                "Independent target mesh requires --dic_observable "
                "camera_grid so target and trial fields share the same "
                "measurement coordinates.")
        target_mesh, _ = build_kosin_mesh(
            target_h_crack, target_h_coarse, THETA_TRUE['l0'],
            device, dtype)
        target_solver = build_solver(
            target_mesh, THETA_TRUE, args.delta_U, tau_ramp,
            args.damping_zeta, device, dtype)
        target_reaction_nodes = torch.as_tensor(
            target_mesh.node_sets['top'], dtype=torch.long, device=device)
        common_dt = _set_common_dt(solver, target_solver)
        print("  Independent target mesh: "
              f"h_crack={target_h_crack}, h_coarse={target_h_coarse}; "
              f"common dt={common_dt:.3e} s")
    print(f"  Mesh: {mesh.n_nodes} nodes, {mesh.n_elems} elements, "
          f"dt={solver.dt:.3e} s")
    if reaction_enabled:
        print("  DIC+reaction objective enabled: "
              f"reaction_weight={args.reaction_weight:g}, "
              f"top reaction nodes={int(pred_reaction_nodes.numel())}")
    if target_is_independent:
        print(f"  Target mesh: {target_mesh.n_nodes} nodes, "
              f"{target_mesh.n_elems} elements")

    dic_points = None
    pred_sampler = None
    target_sampler = None
    if args.dic_observable == 'camera_grid':
        dic_points = _camera_grid(
            args.dic_grid_nx, args.dic_grid_ny, args.dic_grid_margin)
        pred_sampler = _build_dic_sampler(mesh, dic_points, device, dtype)
        target_sampler = _build_dic_sampler(
            target_mesh, dic_points, device, dtype)
        print(f"  DIC camera grid: {len(pred_sampler.points)} points "
              f"({args.dic_grid_nx}x{args.dic_grid_ny}, "
              f"margin={args.dic_grid_margin} mm)")

    # ---- Truth pass (no_grad) ----
    print("\n[1/3] Forward at truth (recording DIC snapshots) ...")
    t0 = time.time()
    if (args.resume and os.path.exists(truth_cache)
            and not args.forward_only):
        cache = torch.load(truth_cache, map_location='cpu')
        u_target = _to_device_snapshots(cache['u_target'], device, dtype)
        reaction_target = None
        if reaction_enabled:
            if 'reaction_target' not in cache:
                raise RuntimeError(
                    "--resume with --reaction_weight > 0 requires a truth "
                    "cache containing reaction_target. Regenerate the cache "
                    "without --resume.")
            reaction_target = torch.as_tensor(
                cache['reaction_target'], dtype=dtype, device=device)
        snap_actual = [int(s) for s in cache['snap_actual']]
        train_frame_indices = cache.get('train_frame_indices')
        val_frame_indices = cache.get('val_frame_indices')
        if train_frame_indices is None:
            train_frame_indices, val_frame_indices = _split_frame_indices(
                len(u_target), args.dic_val_every)
        else:
            train_frame_indices = [int(i) for i in train_frame_indices]
            val_frame_indices = [int(i) for i in val_frame_indices]
        print(f"  truth cache loaded -> {truth_cache}")
        print(f"  truth: {len(u_target)} snapshots, "
              f"max|u_final|={float(u_target[-1].abs().max()):.4e}, "
              f"{time.time()-t0:.1f}s")
    else:
        with torch.no_grad():
            truth_params = {k: torch.tensor(v, dtype=dtype, device=device)
                            for k, v in THETA_TRUE.items()}
            if reaction_enabled:
                (u_snaps_truth, d_snaps_truth, reaction_truth,
                 snap_actual, d_final) = run_forward(
                    target_solver, loading, truth_params, n_steps, snap_steps,
                    record_damage=True, record_reaction=True,
                    reaction_nodes=target_reaction_nodes)
                reaction_target = torch.stack(
                    [r.detach().clone() for r in reaction_truth])
            else:
                u_snaps_truth, d_snaps_truth, snap_actual, d_final = (
                    run_forward(
                        target_solver, loading, truth_params, n_steps,
                        snap_steps, record_damage=True))
                reaction_target = None
            if args.dic_observable == 'camera_grid':
                u_obs = _project_dic_snapshots(
                    u_snaps_truth, target_sampler)
            else:
                u_obs = u_snaps_truth
            u_target = [u.detach().clone() for u in u_obs]
            u_target, dic_noise_sigma = _add_dic_noise(
                u_target, args.dic_noise_std, args.dic_noise_rel)
        train_frame_indices, val_frame_indices = _split_frame_indices(
            len(u_target), args.dic_val_every)
        torch.save({
            'u_target': _cpu_snapshots(u_target),
            'd_target': [d.detach().cpu() for d in d_snaps_truth],
            'snap_actual': list(snap_actual),
            'snap_steps': list(snap_steps),
            'n_steps': int(n_steps),
            'obs_K': int(obs_K),
            'dic_observable': args.dic_observable,
            'dic_points': None if dic_points is None else dic_points,
            'dic_noise_sigma': float(dic_noise_sigma),
            'reaction_target': (
                None if reaction_target is None
                else reaction_target.detach().cpu()),
            'reaction_weight': float(args.reaction_weight),
            'train_frame_indices': list(train_frame_indices),
            'val_frame_indices': list(val_frame_indices),
            'target_h_crack': float(target_h_crack),
            'target_h_coarse': float(target_h_coarse),
        }, truth_cache)
        print(f"  truth: {len(u_target)} snapshots, "
              f"max|u_final|={float(u_target[-1].abs().max()):.4e}, "
              f"max(d)={float(d_final.max()):.3f}, "
              f"{time.time()-t0:.1f}s")
        if reaction_target is not None:
            print("  truth top reaction samples: "
                  f"min={float(reaction_target.min()):.4e}, "
                  f"max={float(reaction_target.max()):.4e}, "
                  f"scale={float(reaction_target.abs().max()):.4e}")
        if args.dic_noise_std != 0.0 or args.dic_noise_rel != 0.0:
            print(f"  synthetic DIC noise sigma={dic_noise_sigma:.4e} mm")
        if val_frame_indices:
            print(f"  DIC split: train frames={train_frame_indices}, "
                  f"val frames={val_frame_indices}")
        print(f"  truth cache saved -> {truth_cache}")
        nodes_np, elems_np = _mesh_arrays(target_mesh)
        u_np = [u.detach().cpu().numpy() for u in u_snaps_truth]
        d_np = [d.detach().cpu().numpy() for d in d_snaps_truth]
        np.savez_compressed(
            os.path.join(out_dir, 'truth_forward_bundle.npz'),
            nodes=nodes_np,
            elements=elems_np,
            u_snapshots=np.asarray(u_np),
            d_snapshots=np.asarray(d_np),
            u_final=u_np[-1],
            d_final=d_final.detach().cpu().numpy(),
            snapshot_steps=np.asarray(snap_actual, dtype=np.int64),
            snapshot_t_us=(np.asarray(snap_actual, dtype=np.float64)
                           * float(solver.dt) * 1.0e6),
            theta_true=np.asarray([THETA_TRUE[k]
                                   for k in ('E', 'nu', 'Gc', 'l0')]),
            theta_names=np.asarray(['E', 'nu', 'Gc', 'l0']),
            h_crack=float(h_crack),
            h_coarse=float(h_coarse),
            target_h_crack=float(target_h_crack),
            target_h_coarse=float(target_h_coarse),
            dic_observable=np.asarray(args.dic_observable),
            dic_points=(np.asarray([]) if dic_points is None
                        else np.asarray(dic_points)),
            dic_noise_sigma=float(dic_noise_sigma),
            reaction_y=(np.asarray([]) if reaction_target is None
                        else reaction_target.detach().cpu().numpy()),
            reaction_weight=float(args.reaction_weight),
            train_frame_indices=np.asarray(train_frame_indices,
                                           dtype=np.int64),
            val_frame_indices=np.asarray(val_frame_indices,
                                         dtype=np.int64),
            n_steps=int(n_steps),
            obs_K=int(obs_K),
            max_damage=float(d_final.max()),
            n_damage_gt_0p5=int((d_final > 0.5).sum()),
            crack_present=bool((d_final > 0.5).any()),
        )
        manifest = {
            'status': 'ok' if bool((d_final > 0.5).any()) else 'no_crack',
            'max_damage': float(d_final.max()),
            'n_damage_gt_0p5': int((d_final > 0.5).sum()),
            'n_snapshots': len(snap_actual),
            'dic_observable': args.dic_observable,
            'dic_points': 0 if dic_points is None else int(len(dic_points)),
            'dic_noise_sigma': float(dic_noise_sigma),
            'reaction_weight': float(args.reaction_weight),
            'reaction_samples': (
                0 if reaction_target is None else int(reaction_target.numel())),
            'train_frame_indices': list(train_frame_indices),
            'val_frame_indices': list(val_frame_indices),
            'bundle': 'truth_forward_bundle.npz',
        }
        with open(os.path.join(out_dir, 'forward_bundle.json'), 'w') as fh:
            json.dump(manifest, fh, indent=2)
        print("  forward bundle saved -> "
              f"{os.path.join(out_dir, 'truth_forward_bundle.npz')}")
        if args.save_forward_viz:
            try:
                from inverse_problems._viz import save_forward_viz
                paths_d = save_forward_viz(
                    nodes_np, elems_np, d_final.detach().cpu().numpy(),
                    out_dir, label='truth', snapshots=d_np,
                    snap_steps=snap_actual, n_steps_total=n_steps)
                paths_u = _save_displacement_viz(
                    nodes_np, elems_np, u_np[-1], u_np, out_dir,
                    label='truth_dic')
                print(f"  [forward-viz] damage png -> {paths_d['png']}")
                if paths_d['gif']:
                    print(f"  [forward-viz] damage gif -> {paths_d['gif']}")
                print(f"  [forward-viz] DIC png -> {paths_u['png']}")
                if paths_u['gif']:
                    print(f"  [forward-viz] DIC gif -> {paths_u['gif']}")
            except Exception as exc:
                print(f"  WARNING: forward viz failed: {exc}")

    if args.forward_only or args.n_iters <= 0:
        print("\n[2/3] Forward-only mode: skipping optimiser.")
        return

    # ---- Inversion ----
    # Build log-parameter leaves for free vars; keep frozen vars as
    # detached tensors at the truth value.
    log_free = {}
    init_vals = {}
    for k in THETA_TRUE:
        if k in free:
            init = THETA_TRUE[k] * (1.0 + args.init_perturb)
            init_vals[k] = init
            log_free[k] = torch.tensor(
                float(np.log(init)), dtype=dtype, device=device,
                requires_grad=True)
        else:
            init_vals[k] = THETA_TRUE[k]

    opt_params = list(log_free.values())
    if args.optimizer == 'adam':
        optimiser = torch.optim.Adam(
            opt_params,
            lr=(args.optimizer_lr if args.optimizer_lr is not None else 0.02))
    else:
        optimiser = torch.optim.LBFGS(
            opt_params,
            lr=(args.optimizer_lr if args.optimizer_lr is not None else 1.0),
            max_iter=4, history_size=10, line_search_fn='strong_wolfe',
            tolerance_grad=1e-12, tolerance_change=1e-14,
        )

    history = {'iter': [], 'loss': [], 'dic_loss': [],
               'reaction_loss': [], 'val_loss': [], 'wall_s': [],
               **{k: [] for k in free},
               **{f'rel_err_{k}': [] for k in free}}
    fwd_counter = {'n': 0}
    start_iter = 0
    best_loss_record = None
    best_param_record = None
    last_eval = {'train_loss': None, 'dic_loss': None,
                 'reaction_loss': None, 'val_loss': None}

    def _record_from_history(idx):
        theta = {k: float(history[k][idx]) for k in free}
        rel = {k: float(history[f'rel_err_{k}'][idx]) for k in free}
        return {
            'iter': int(history['iter'][idx]),
            'loss': float(history['loss'][idx]),
            'theta': theta,
            'rel_err': rel,
            'param_rel_l2': float(
                sum(v * v for v in rel.values()) ** 0.5),
        }

    if args.resume and os.path.exists(checkpoint_path):
        ckpt = torch.load(checkpoint_path, map_location=device)
        if list(ckpt.get('free', free)) != list(free):
            raise ValueError(
                f"Checkpoint free params {ckpt.get('free')} do not match "
                f"requested {free}")
        for k in free:
            if k in ckpt['log_free']:
                with torch.no_grad():
                    log_free[k].copy_(ckpt['log_free'][k].to(
                        device=device, dtype=dtype))
        optimiser.load_state_dict(ckpt['optimiser'])
        history = ckpt.get('history', history)
        fwd_counter['n'] = int(ckpt.get('fwd_counter_n', 0))
        start_iter = int(ckpt.get('it_next', len(history.get('iter', []))))
        for idx in range(len(history.get('iter', []))):
            rec = _record_from_history(idx)
            if (best_loss_record is None or
                    rec['loss'] < best_loss_record['loss']):
                best_loss_record = rec
            if (best_param_record is None or
                    rec['param_rel_l2'] < best_param_record['param_rel_l2']):
                best_param_record = rec
        print(f"  checkpoint loaded -> {checkpoint_path} "
              f"(next iter {start_iter})", flush=True)

    def closure():
        optimiser.zero_grad()
        params = {}
        for k in THETA_TRUE:
            if k in free:
                params[k] = torch.exp(log_free[k])
            else:
                frozen = fixed_theta.get(k, THETA_TRUE[k])
                params[k] = torch.tensor(
                    float(frozen), dtype=dtype, device=device)
        if reaction_enabled:
            u_snaps_pred, reaction_pred, _ = run_forward(
                solver, loading, params, n_steps, snap_steps,
                record_reaction=True, reaction_nodes=pred_reaction_nodes)
        else:
            u_snaps_pred, _ = run_forward(
                solver, loading, params, n_steps, snap_steps)
            reaction_pred = None
        if args.dic_observable == 'camera_grid':
            obs_pred = _project_dic_snapshots(u_snaps_pred, pred_sampler)
        else:
            obs_pred = u_snaps_pred
        obs_train = _take(obs_pred, train_frame_indices)
        target_train = _take(u_target, train_frame_indices)
        if args.time_weight_lambda != 0.0:
            from phast.inverse_problems._loss_weights import (
                time_weights)
            _w = time_weights(snap_steps, args.time_weight_lambda,
                               dtype=dtype, device=device)
            _w_train = _w[torch.as_tensor(train_frame_indices,
                                          dtype=torch.long,
                                          device=device)]
            dic_loss = displacement_mse_loss(obs_train, target_train,
                                             weights=_w_train)
            if reaction_enabled:
                reaction_loss = reaction_mse_loss(
                    _take(reaction_pred, train_frame_indices),
                    _take(reaction_target, train_frame_indices),
                    weights=_w_train)
            else:
                reaction_loss = torch.zeros((), dtype=dtype, device=device)
        else:
            dic_loss = displacement_mse_loss(obs_train, target_train)
            if reaction_enabled:
                reaction_loss = reaction_mse_loss(
                    _take(reaction_pred, train_frame_indices),
                    _take(reaction_target, train_frame_indices))
            else:
                reaction_loss = torch.zeros((), dtype=dtype, device=device)
        loss = dic_loss + float(args.reaction_weight) * reaction_loss
        if val_frame_indices:
            with torch.no_grad():
                val_dic = displacement_mse_loss(
                    [u.detach() for u in _take(obs_pred, val_frame_indices)],
                    _take(u_target, val_frame_indices))
                if reaction_enabled:
                    val_reaction = reaction_mse_loss(
                        [r.detach() for r in _take(
                            reaction_pred, val_frame_indices)],
                        _take(reaction_target, val_frame_indices))
                else:
                    val_reaction = torch.zeros(
                        (), dtype=dtype, device=device)
                val_loss = val_dic + float(args.reaction_weight) * val_reaction
                last_eval['val_loss'] = float(val_loss.detach())
        else:
            last_eval['val_loss'] = None
        last_eval['train_loss'] = float(loss.detach())
        last_eval['dic_loss'] = float(dic_loss.detach())
        last_eval['reaction_loss'] = float(reaction_loss.detach())
        loss.backward()
        if args.grad_clip_norm is not None:
            torch.nn.utils.clip_grad_norm_(opt_params,
                                           args.grad_clip_norm)
        fwd_counter['n'] += 1
        return loss

    print(f"\n[2/3] {args.optimizer.upper()} on log({free}); init "
          + ", ".join(f"{k}={init_vals[k]:.4g}" for k in free))
    t_inv = time.time()
    for it in range(start_iter, args.n_iters):
        t_it = time.time()
        if args.optimizer == 'adam':
            loss_tensor = closure()
            optimiser.step()
            loss = float(loss_tensor.detach())
        else:
            loss = float(optimiser.step(closure))
        cur = {k: float(torch.exp(log_free[k]).detach())
               for k in free}
        rel = {k: abs(cur[k] - THETA_TRUE[k]) / abs(THETA_TRUE[k])
               for k in free}
        history['iter'].append(it)
        history['loss'].append(loss)
        history['dic_loss'].append(last_eval['dic_loss'])
        history['reaction_loss'].append(last_eval['reaction_loss'])
        history['val_loss'].append(last_eval['val_loss'])
        history['wall_s'].append(time.time() - t_it)
        for k in free:
            history[k].append(cur[k])
            history[f'rel_err_{k}'].append(rel[k])
        rec = _record_from_history(len(history['iter']) - 1)
        if (best_loss_record is None or
                rec['loss'] < best_loss_record['loss']):
            best_loss_record = rec
        if (best_param_record is None or
                rec['param_rel_l2'] < best_param_record['param_rel_l2']):
            best_param_record = rec
        line = f"  it {it:3d} | loss={loss:.3e} | "
        if reaction_enabled:
            line += (f"dic={last_eval['dic_loss']:.3e} "
                     f"react={last_eval['reaction_loss']:.3e} | ")
        line += " | ".join(f"{k}={cur[k]:.4g}({rel[k]:.2%})"
                           for k in free)
        if last_eval['val_loss'] is not None:
            line += f" | val={last_eval['val_loss']:.3e}"
        line += f" | {time.time()-t_it:.1f}s"
        print(line, flush=True)
        if args.checkpoint_every > 0:
            if ((it + 1) % args.checkpoint_every == 0 or
                    (it + 1) >= args.n_iters):
                _save_checkpoint(
                    checkpoint_path, it + 1, log_free, optimiser,
                    history, fwd_counter['n'], free, args)
        if loss < 1e-14:
            print(f"  Converged at iter {it} (loss<1e-14)")
            _save_checkpoint(
                checkpoint_path, it + 1, log_free, optimiser,
                history, fwd_counter['n'], free, args)
            break
    wall = time.time() - t_inv
    print(f"  Inversion wall: {wall:.1f}s "
          f"({fwd_counter['n']} forwards)")

    # ---- Save ----
    json_out = {
        'free':            list(free),
        'theta_true':      {k: THETA_TRUE[k] for k in free},
        'theta_init':      {k: init_vals[k] for k in free},
        'theta_fixed':     fixed_theta,
        'theta_recovered': {k: float(torch.exp(log_free[k]).detach())
                             for k in free},
        'rel_err_final':   {k: history[f'rel_err_{k}'][-1] if
                              history[f'rel_err_{k}'] else None
                             for k in free},
        'final_loss':      history['loss'][-1] if history['loss'] else None,
        'n_steps':         n_steps,
        'obs_K':           obs_K,
        'obs_start_step':  obs_start,
        'obs_end_step':    obs_end,
        'n_snapshots':     len(snap_steps),
        'dic_observable':  args.dic_observable,
        'dic_grid_nx':     args.dic_grid_nx,
        'dic_grid_ny':     args.dic_grid_ny,
        'dic_grid_margin': args.dic_grid_margin,
        'dic_points':      (0 if dic_points is None else int(len(dic_points))),
        'dic_noise_std':   args.dic_noise_std,
        'dic_noise_rel':   args.dic_noise_rel,
        'dic_val_every':   args.dic_val_every,
        'reaction_weight': args.reaction_weight,
        'train_frame_indices': list(train_frame_indices),
        'val_frame_indices': list(val_frame_indices),
        'target_h_crack':  target_h_crack,
        'target_h_coarse': target_h_coarse,
        'h_crack':         h_crack,
        'h_coarse':        h_coarse,
        'wall_s':          wall,
        'forwards_total':  fwd_counter['n'],
        'history':         history,
        'best_loss_iter': (
            None if best_loss_record is None else best_loss_record['iter']),
        'best_loss': (
            None if best_loss_record is None else best_loss_record['loss']),
        'theta_best_loss': (
            None if best_loss_record is None else best_loss_record['theta']),
        'rel_err_best_loss': (
            None if best_loss_record is None else best_loss_record['rel_err']),
        'best_param_rel_l2_iter': (
            None if best_param_record is None else best_param_record['iter']),
        'best_param_rel_l2': (
            None if best_param_record is None
            else best_param_record['param_rel_l2']),
        'theta_best_param_rel_l2': (
            None if best_param_record is None else best_param_record['theta']),
        'rel_err_best_param_rel_l2': (
            None if best_param_record is None else best_param_record['rel_err']),
    }
    out_path = os.path.join(out_dir, 'demo_inverse_kosin_dic.json')
    with open(out_path, 'w') as fh:
        json.dump(json_out, fh, indent=2)
    print(f"\n[3/3] Saved -> {out_path}")


if __name__ == '__main__':
    main()
