"""Crack-path based initial guesses for particle inverse problems.

This module implements the first stage of the preferred inverse workflow:
use the observed crack path to obtain a physically plausible particle
initialisation, then hand that initialisation to the differentiable solver
for gated local refinement.

The estimator is deliberately simple. It does not claim to solve the inverse
problem; it identifies deflection regions where a particle/heterogeneity is
likely to matter and returns centres/windows suitable for a subsequent
observability gate.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

import numpy as np


def _moving_average(values: np.ndarray, radius: int) -> np.ndarray:
    if radius <= 0:
        return values.astype(float, copy=True)
    width = 2 * radius + 1
    kernel = np.ones(width, dtype=float) / float(width)
    padded = np.pad(values.astype(float), (radius, radius), mode="edge")
    return np.convolve(padded, kernel, mode="valid")


def damage_weighted_path(
    nodes: np.ndarray,
    damage: np.ndarray,
    x_bins: np.ndarray,
    sigma: float | None = None,
    power: float = 4.0,
) -> tuple[np.ndarray, np.ndarray]:
    """Return damage-weighted crack centreline ``y(x)`` and bin mass.

    Parameters mirror the differentiable path observable used in
    ``demo_inverse_stiff_inclusion.py``, but this offline initializer uses
    NumPy and is meant only for measurement preprocessing.
    """
    nodes = np.asarray(nodes, dtype=float)
    damage = np.asarray(damage, dtype=float).reshape(-1)
    x_bins = np.asarray(x_bins, dtype=float).reshape(-1)
    if nodes.ndim != 2 or nodes.shape[1] != 2:
        raise ValueError("nodes must have shape (n_nodes, 2)")
    if damage.shape[0] != nodes.shape[0]:
        raise ValueError("damage length must match nodes")
    if x_bins.size < 2:
        raise ValueError("x_bins must contain at least two bins")
    if sigma is None:
        sigma = 0.6 * float(np.median(np.diff(np.sort(x_bins))))
    sigma = max(float(sigma), np.finfo(float).eps)
    weights_d = np.clip(damage, 0.0, None) ** float(power)
    y_path = np.empty_like(x_bins, dtype=float)
    mass = np.empty_like(x_bins, dtype=float)
    for i, xb in enumerate(x_bins):
        wx = np.exp(-0.5 * ((nodes[:, 0] - xb) / sigma) ** 2)
        w = wx * weights_d
        denom = float(w.sum())
        mass[i] = denom
        y_path[i] = float((w * nodes[:, 1]).sum() / denom) if denom > 0.0 else np.nan
    return y_path, mass


def active_path_mask(
    y_path: np.ndarray,
    mass: np.ndarray | None,
    mass_fraction: float = 0.05,
) -> np.ndarray:
    """Select path bins with usable crack signal."""
    y = np.asarray(y_path, dtype=float)
    mask = np.isfinite(y)
    if mass is not None:
        m = np.asarray(mass, dtype=float)
        if m.shape != y.shape:
            raise ValueError("mass must have the same shape as y_path")
        if np.isfinite(m).any() and float(np.nanmax(m)) > 0.0:
            mask &= m >= float(mass_fraction) * float(np.nanmax(m))
    return mask


def infer_crack_axis(y_path: np.ndarray,
                     mass: np.ndarray | None = None,
                     edge_fraction: float = 0.2) -> float:
    """Estimate the undeflected crack axis from the path edges."""
    y = np.asarray(y_path, dtype=float)
    mask = active_path_mask(y, mass)
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        raise ValueError("cannot infer crack axis from an empty path")
    n_edge = max(1, int(np.ceil(edge_fraction * idx.size)))
    edge_idx = np.concatenate([idx[:n_edge], idx[-n_edge:]])
    return float(np.nanmedian(y[edge_idx]))


def estimate_particle_initializers(
    x_bins: np.ndarray,
    y_path: np.ndarray,
    mass: np.ndarray | None = None,
    n_particles: int = 1,
    crack_axis: float | None = None,
    particle_offset: float = 1.5,
    min_separation: float = 3.0,
    smooth_radius: int = 2,
    window_half_width: float = 3.0,
    prefer_side: str = "auto",
    side_relation: str = "same",
) -> dict:
    """Estimate particle centres and observation windows from path deflection.

    Candidate x-positions are ranked by a combination of absolute deflection
    and curvature. Candidate y-position is placed on the side of the crack
    indicated by the local deflection with a user-controlled offset. For a
    stiff circular particle above a nominally horizontal crack, this produces
    the coarse centre estimate used to start gradient refinement.
    """
    x = np.asarray(x_bins, dtype=float).reshape(-1)
    y = np.asarray(y_path, dtype=float).reshape(-1)
    if x.shape != y.shape:
        raise ValueError("x_bins and y_path must have the same shape")
    if x.size < 5:
        raise ValueError("at least five path bins are needed")
    mask = active_path_mask(y, mass)
    if mask.sum() < 5:
        raise ValueError("not enough active crack-path bins")
    if crack_axis is None:
        crack_axis = infer_crack_axis(y, mass)
    y_fill = y.copy()
    y_fill[~np.isfinite(y_fill)] = float(crack_axis)
    y_s = _moving_average(y_fill, smooth_radius)
    dx = float(np.median(np.diff(x)))
    dx = max(abs(dx), np.finfo(float).eps)
    deflection = y_s - float(crack_axis)
    curvature = np.gradient(np.gradient(y_s, dx), dx)
    prefer_side = str(prefer_side).lower()
    if prefer_side not in {"auto", "above", "below"}:
        raise ValueError("prefer_side must be 'auto', 'above', or 'below'")
    side_relation = str(side_relation).lower()
    if side_relation not in {"same", "opposite"}:
        raise ValueError("side_relation must be 'same' or 'opposite'")
    side_mask = np.ones_like(mask, dtype=bool)
    if prefer_side == "above":
        side_mask = deflection >= 0.0
    elif prefer_side == "below":
        side_mask = deflection <= 0.0
    score = np.abs(deflection) + 0.5 * dx * dx * np.abs(curvature)
    score = np.where(mask & side_mask, score, -np.inf)
    order = np.argsort(score)[::-1]
    centres: list[tuple[float, float]] = []
    windows: list[tuple[float, float]] = []
    for idx in order:
        if not np.isfinite(score[idx]) or score[idx] <= 0.0:
            continue
        xi = float(x[idx])
        if any(abs(xi - cx) < min_separation for cx, _ in centres):
            continue
        side = 1.0 if deflection[idx] >= 0.0 else -1.0
        if side_relation == "opposite":
            side *= -1.0
        yi = float(crack_axis + side * abs(particle_offset))
        centres.append((xi, yi))
        windows.append((xi - window_half_width, xi + window_half_width))
        if len(centres) >= int(n_particles):
            break
    if not centres:
        raise ValueError("no nonzero crack-path deflection candidates found")
    return {
        "recovered_particles": [[float(xi), float(yi)] for xi, yi in centres],
        "observation_windows": [
            {"x_min": float(a), "x_max": float(b)} for a, b in windows
        ],
        "crack_axis": float(crack_axis),
        "particle_offset": float(particle_offset),
        "method": "crack_path_curvature_initializer_v1",
        "diagnostics": {
            "max_abs_deflection": float(np.nanmax(np.abs(deflection[mask]))),
            "n_active_bins": int(mask.sum()),
            "smooth_radius": int(smooth_radius),
            "min_separation": float(min_separation),
            "window_half_width": float(window_half_width),
            "prefer_side": prefer_side,
            "side_relation": side_relation,
        },
    }


def _load_path(path: Path, n_bins: int | None) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text())
        x = np.asarray(data["x_bins"], dtype=float)
        y = np.asarray(data["y_target_path"], dtype=float)
        mass = np.asarray(data["mass_target_path"], dtype=float) if "mass_target_path" in data else None
        return x, y, mass
    if path.suffix.lower() == ".npz":
        z = np.load(path, allow_pickle=True)
        if {"x_bins", "y_target_path"}.issubset(z.files):
            x = np.asarray(z["x_bins"], dtype=float)
            y = np.asarray(z["y_target_path"], dtype=float)
            mass = np.asarray(z["mass_target_path"], dtype=float) if "mass_target_path" in z.files else None
            return x, y, mass
        damage_key = None
        for candidate in ("d_target", "d_final", "damage", "damage_final"):
            if candidate in z.files:
                damage_key = candidate
                break
        if "nodes" in z.files and damage_key is not None:
            nodes = np.asarray(z["nodes"], dtype=float)
            damage = np.asarray(z[damage_key], dtype=float)
            if n_bins is None:
                n_bins = 40
            x = np.linspace(float(nodes[:, 0].min()), float(nodes[:, 0].max()), int(n_bins))
            y, mass = damage_weighted_path(nodes, damage, x)
            return x, y, mass
        raise ValueError(f"{path} has no supported path or damage-field keys")
    raise ValueError(f"unsupported input format: {path.suffix}")


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Estimate particle initializers from an observed crack path.")
    parser.add_argument("input", type=Path,
                        help="JSON/NPZ containing x_bins/y_target_path or nodes/d_target")
    parser.add_argument("--output", type=Path, default=None,
                        help="Output JSON path. Defaults next to input.")
    parser.add_argument("--n_particles", type=int, default=1)
    parser.add_argument("--crack_axis", type=float, default=None)
    parser.add_argument("--particle_offset", type=float, default=1.5)
    parser.add_argument("--min_separation", type=float, default=3.0)
    parser.add_argument("--window_half_width", type=float, default=3.0)
    parser.add_argument("--smooth_radius", type=int, default=2)
    parser.add_argument("--prefer_side", choices=["auto", "above", "below"],
                        default="auto",
                        help="Optionally restrict candidates to one side of the crack axis.")
    parser.add_argument("--side_relation", choices=["same", "opposite"],
                        default="same",
                        help="Place particles on the same or opposite side of the local path deflection.")
    parser.add_argument("--n_bins", type=int, default=None,
                        help="Number of x bins when deriving a path from damage.")
    args = parser.parse_args(list(argv) if argv is not None else None)
    x, y, mass = _load_path(args.input, args.n_bins)
    result = estimate_particle_initializers(
        x, y, mass=mass, n_particles=args.n_particles,
        crack_axis=args.crack_axis, particle_offset=args.particle_offset,
        min_separation=args.min_separation,
        smooth_radius=args.smooth_radius,
        window_half_width=args.window_half_width,
        prefer_side=args.prefer_side,
        side_relation=args.side_relation)
    out = args.output or args.input.with_name(args.input.stem + "_initializer.json")
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
