"""Gradient-equivalence test: DiscreteAdjoint vs full-tape autograd.

Spec target: 100 elements, 50 timesteps, max abs diff < 1e-6 (we expect
~1e-12 because both routes execute identical floating-point ops, just
with different graph retention).

Synthetic problem: a stable linear-ish recurrence

    x_{n+1} = tanh(A x_n + B theta) * 0.97

so the dynamics are bounded. Loss = sum((x_N)**2). Gradients flow into
``x_0`` and ``theta``.
"""
from __future__ import annotations

import math

import torch

from inverse_problems.adjoint import DiscreteAdjoint


def _make_stepper(A: torch.Tensor, B: torch.Tensor):
    def stepper(state, params):
        (x,) = state
        (theta,) = params
        x_next = torch.tanh(x @ A + theta @ B) * 0.97
        return (x_next,)

    return stepper


def _full_autograd_run(stepper, state0, params, n_steps):
    state = tuple(t.clone() for t in state0)
    for _ in range(n_steps):
        state = stepper(state, params)
    return state


def test_gradcheck_discrete_adjoint_matches_autograd():
    torch.manual_seed(0)
    dtype = torch.float64
    device = torch.device("cpu")

    n_dim = 100
    n_steps = 50
    n_param = 8

    # Coupling matrices (fixed, small spectral radius -> stable forward).
    A = torch.randn(n_dim, n_dim, dtype=dtype, device=device) / math.sqrt(n_dim)
    B = torch.randn(n_param, n_dim, dtype=dtype, device=device) / math.sqrt(n_param)
    stepper = _make_stepper(A, B)

    # ---- Path 1: full autograd ----
    x0_a = torch.randn(n_dim, dtype=dtype, device=device, requires_grad=True)
    theta_a = torch.randn(n_param, dtype=dtype, device=device, requires_grad=True)

    state_a = _full_autograd_run(stepper, (x0_a,), (theta_a,), n_steps)
    loss_a = (state_a[0] ** 2).sum()
    loss_a.backward()
    g_x0_full = x0_a.grad.detach().clone()
    g_theta_full = theta_a.grad.detach().clone()

    # ---- Path 2: discrete adjoint via checkpointing ----
    # Use IDENTICAL initial values for x0, theta.
    x0_b = x0_a.detach().clone().requires_grad_(True)
    theta_b = theta_a.detach().clone().requires_grad_(True)
    n_ckpts = max(1, int(math.ceil(math.sqrt(n_steps))))
    adj = DiscreteAdjoint(stepper, n_steps=n_steps, n_checkpoints=n_ckpts)
    state_b = adj((x0_b,), (theta_b,))
    loss_b = (state_b[0] ** 2).sum()
    loss_b.backward()
    g_x0_ck = x0_b.grad.detach().clone()
    g_theta_ck = theta_b.grad.detach().clone()

    # Loss values must agree exactly to floating-point precision.
    assert torch.allclose(loss_a, loss_b, rtol=0, atol=1e-12), (
        f"loss mismatch: full={loss_a.item()} ck={loss_b.item()}"
    )

    # Gradients: same ops in same order, expect ~1e-12.
    diff_x0 = (g_x0_full - g_x0_ck).abs().max().item()
    diff_theta = (g_theta_full - g_theta_ck).abs().max().item()

    print(f"max |grad x0  full - ck| = {diff_x0:.3e}")
    print(f"max |grad theta full - ck| = {diff_theta:.3e}")

    # Spec tolerance 1e-6; we expect much tighter.
    assert diff_x0 < 1e-6, f"x0 gradient mismatch {diff_x0:.3e} >= 1e-6"
    assert diff_theta < 1e-6, f"theta gradient mismatch {diff_theta:.3e} >= 1e-6"


def test_varying_checkpoint_count_yields_same_gradient():
    """Number of checkpoints should not affect the gradient."""
    torch.manual_seed(1)
    dtype = torch.float64
    n_dim, n_steps, n_param = 50, 60, 4
    A = torch.randn(n_dim, n_dim, dtype=dtype) / math.sqrt(n_dim)
    B = torch.randn(n_param, n_dim, dtype=dtype) / math.sqrt(n_param)
    stepper = _make_stepper(A, B)

    x0 = torch.randn(n_dim, dtype=dtype)
    theta = torch.randn(n_param, dtype=dtype)

    grads = []
    for nc in [1, 4, 8, 15, n_steps]:
        x = x0.clone().requires_grad_(True)
        th = theta.clone().requires_grad_(True)
        adj = DiscreteAdjoint(stepper, n_steps=n_steps, n_checkpoints=nc)
        out = adj((x,), (th,))
        loss = (out[0] ** 2).sum()
        loss.backward()
        grads.append((nc, x.grad.detach().clone(), th.grad.detach().clone()))

    g0 = grads[0]
    for nc, gx, gth in grads[1:]:
        d_x = (gx - g0[1]).abs().max().item()
        d_t = (gth - g0[2]).abs().max().item()
        print(f"n_checkpoints={nc:3d}: dx={d_x:.2e}, dtheta={d_t:.2e}")
        assert d_x < 1e-9, f"x grad varies with n_checkpoints (nc={nc}, d={d_x})"
        assert d_t < 1e-9, f"theta grad varies with n_checkpoints (nc={nc}, d={d_t})"


if __name__ == "__main__":
    test_gradcheck_discrete_adjoint_matches_autograd()
    test_varying_checkpoint_count_yields_same_gradient()
    print("All correctness tests passed.")
