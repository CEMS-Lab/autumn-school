#!/usr/bin/env python
"""
Native autograd material parameter recovery on the B2 Kalthoff benchmark.

This is the headline demonstration for the autograd story in the CMAME
paper: gradient-based recovery of phase-field material parameters
through a full validated dynamic benchmark, using *real* end-to-end
autograd via implicit differentiation through the CG damage solve
(`_AdjointDamageSolveScalar`), not finite differences.

The forward problem is the same Kalthoff-Winkler impact test that we
validated in §5.2 of the paper against Borden et al. 2012. The inverse
problem is: given a target damage field at the end of the simulation,
recover the material parameters. This is the analogue of Stanić et al.
2026's experiment, but solved with a single backward pass per
iteration instead of MCMC + gPCE surrogate over thousands of forwards.

Modes
-----
    --params Gc_l0     : recover (Gc, l0) only (k=2)
    --params 4         : recover (E, nu, Gc, l0) jointly (k=4)
    --multi_init       : run from 3 different initial guesses

Usage
-----
    # Local smoke test
    python demo_autograd_kalthoff.py --h_crack 4.0 --t_total 25 --n_iters 8
    # Production
    python demo_autograd_kalthoff.py --h_crack 1.0 --t_total 50 --n_iters 25
    # Multi-init robustness study
    python demo_autograd_kalthoff.py --multi_init --n_iters 25
    # 4-param joint recovery
    python demo_autograd_kalthoff.py --params 4 --n_iters 30
"""
import os
import sys
import time
import json
import math
import argparse
import tempfile

import numpy as np
import torch
import torch.utils.checkpoint

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.material import Material
from phast.mesh import FEMMesh
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.mesh_generator import kalthoff_winkler as gen_kalthoff_mesh
from phast.device import DeviceContext
from phast.config import LoadingConfig
from phast.inverse_problems._tbptt import (
    run_forward_tbptt_generic,
    make_install_kalthoff_params,
)


# ---------------------------------------------------------------------------
# Truth and initial guesses
# ---------------------------------------------------------------------------
THETA_TRUE = dict(
    E=190000.0,    # MPa  Borden 2012 maraging steel
    nu=0.30,
    Gc=22.13,      # N/mm
    l0=0.5,        # mm  (coarsened from 0.195 for tractable inverse)
)
INIT_FACTORS = [1.5, 2.0, 0.6]   # multi-init study


# ---------------------------------------------------------------------------
# Forward simulation
# ---------------------------------------------------------------------------

def _impact_displacement(t, v0, t_ramp):
    if t < t_ramp:
        return (v0 / (2.0 * t_ramp)) * t * t
    return v0 * t - v0 * t_ramp / 2.0


def build_kalthoff_mesh(h_crack, h_coarse, l0, device, dtype):
    mesh_path = os.path.join(tempfile.gettempdir(),
                              f'kalthoff_inverse_{h_crack:.2f}.msh')
    gen_kalthoff_mesh(
        mesh_path, W=100.0, H=200.0, a=50.0,
        notch_y1=125.0, notch_y2=75.0,
        l0=l0, h_crack=h_crack, h_coarse=h_coarse,
        verbose=False)
    mesh = FEMMesh(mesh_path, device=device, dtype=dtype)
    mesh.identify_boundaries()
    return mesh, mesh_path


def build_kalthoff_solver(mesh, dt_safety=0.5, device='cpu',
                            dtype=torch.float64, h_crack_tol=2.0,
                            damage_every=3, softmax_H_beta=None,
                            H_update_method='hard_max',
                            H_update_scale=None):
    """Build the StaggeredSolver ONCE. Material and Gc/l0 will be overridden
    per call via attribute assignment — the solver itself, the FEMOperators,
    the mechanics solver, and the damage solver are all reused.

    Returns (solver, ctx) so caller can reset state and rerun.
    """
    # Use a placeholder material — its values will be overridden per call.
    mat = Material(E=190000.0, nu=0.30, Gc=22.13, l0=0.5,
                   rho=8.0e-9, eta_residual=1e-6,
                   energy_split='spectral', pf_model='AT2',
                   plane_stress=False)
    ctx = DeviceContext(device=device, profile=False, compile_solvers=False)

    coords = mesh.nodes
    tol = h_crack_tol * 0.5
    impact_mask = ((coords[:, 0] < tol) &
                   (coords[:, 1] > 75.0 - tol) &
                   (coords[:, 1] < 125.0 + tol))
    impact_nodes = torch.where(impact_mask)[0]
    bcs = BoundaryConditions(mesh.n_nodes, device=ctx.device, dtype=ctx.dtype)
    bcs.add(impact_nodes, 0, 1.0)
    bcs.load_factor = 0.0

    cfg = SolverConfig(solver_type='explicit', dt_safety=dt_safety,
                        differentiable=True, damage_every=damage_every,
                        softmax_H_beta=softmax_H_beta,
                        H_update_method=H_update_method,
                        H_update_scale=H_update_scale)
    solver = StaggeredSolver(mesh, mat, bcs, config=cfg, ctx=ctx)
    return solver, ctx


def run_kalthoff_forward(solver, params, n_steps,
                          v0=16500.0, t_ramp=1.0e-6,
                          return_observables='damage',
                          checkpoint_chunks=0,
                          snapshot_steps=None):
    """One forward Kalthoff simulation reusing the existing `solver`.

    Resets the per-call state (u, v, a, d, H_elem, H_nodal) to zero,
    overrides material parameters from the params dict (any of which
    may be a torch tensor with requires_grad=True), and runs n_steps.

    Parameters
    ----------
    return_observables : {'damage', 'displacement', 'both'}
        - 'damage'       : return final damage tensor (N,) — MSE-on-damage loss
        - 'displacement' : return final displacement (N, 2) — smoother landscape
                           (Bleyer/Stanic use this; Powell+FD success confirmed)
        - 'both'         : return tuple (damage, displacement)
    """
    # Reset solver state to zero so each forward call is a fresh simulation
    n_nodes = solver.mesh.n_nodes
    dtype = solver.u.dtype
    device = solver.u.device
    solver.u = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.v = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.a = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.d = torch.zeros(n_nodes, dtype=dtype, device=device)
    n_elems = len(solver.mesh.elements)
    solver.H_elem = torch.zeros(n_elems, dtype=dtype, device=device)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dtype, device=device)
    if hasattr(solver, '_explicit_step_count'):
        solver._explicit_step_count = 0
    solver._step_count = 0
    dt = solver.dt

    def _install_params(E, nu, Gc, l0):
        solver.material.E = E
        solver.material.nu = nu
        solver.diff_Gc = Gc
        solver.diff_l0 = l0

    _install_params(params['E'], params['nu'], params['Gc'], params['l0'])

    snap_set = set(int(s) for s in (snapshot_steps or []))
    d_snaps = []
    u_snaps = []
    snap_actual = []

    def _record_snapshot(step_index):
        if step_index in snap_set:
            d_snaps.append(solver.d.detach().clone())
            u_snaps.append(solver.u.detach().clone())
            snap_actual.append(int(step_index))

    use_checkpoint = (
        checkpoint_chunks > 0 and torch.is_grad_enabled()
        and any(p.requires_grad for p in params.values())
    )
    if not use_checkpoint:
        for step in range(n_steps):
            t_now = step * dt
            solver.bcs.load_factor = _impact_displacement(t_now, v0, t_ramp)
            solver.step_full()
            _record_snapshot(step + 1)
    else:
        def _chunk(u_in, v_in, a_in, d_in, He_in, Hn_in,
                   E, nu, Gc, l0, base_step, k_steps):
            _install_params(E, nu, Gc, l0)
            solver.u = u_in
            solver.v = v_in
            solver.a = a_in
            solver.d = d_in
            solver.H_elem = He_in
            solver.H_nodal = Hn_in
            solver._step_count = base_step
            if hasattr(solver, '_explicit_step_count'):
                solver._explicit_step_count = base_step
            for j in range(k_steps):
                step = base_step + j
                t_now = step * dt
                solver.bcs.load_factor = _impact_displacement(
                    t_now, v0, t_ramp)
                solver.step_full()
            return (solver.u, solver.v, solver.a, solver.d,
                    solver.H_elem, solver.H_nodal)

        chunk_size = (n_steps + checkpoint_chunks - 1) // checkpoint_chunks
        u, v, a, d = solver.u, solver.v, solver.a, solver.d
        He, Hn = solver.H_elem, solver.H_nodal
        n_total_chunks = (n_steps + chunk_size - 1) // chunk_size
        chunk_progress_every = max(1, n_total_chunks // 20)
        t_chunk_start = time.time()
        chunk_idx = 0
        base = 0
        while base < n_steps:
            k_steps = min(chunk_size, n_steps - base)
            u, v, a, d, He, Hn = torch.utils.checkpoint.checkpoint(
                _chunk, u, v, a, d, He, Hn,
                params['E'], params['nu'], params['Gc'], params['l0'],
                base, k_steps,
                use_reentrant=False)
            base += k_steps
            chunk_idx += 1
            if base in snap_set:
                solver.u = u
                solver.v = v
                solver.a = a
                solver.d = d
                solver.H_elem = He
                solver.H_nodal = Hn
                _record_snapshot(base)
            if chunk_idx % chunk_progress_every == 0 or chunk_idx == n_total_chunks:
                mem_str = ""
                damage_max = float(d.detach().max())
                if torch.cuda.is_available():
                    mb = torch.cuda.max_memory_allocated() / (1024 ** 2)
                    mem_str = f", cuda_peak={mb:.0f} MB"
                    torch.cuda.reset_peak_memory_stats()
                print(
                    f"    Kalthoff checkpoint chunk {chunk_idx}/{n_total_chunks} "
                    f"(step {base}/{n_steps}, max(d)={damage_max:.3f}, "
                    f"{time.time() - t_chunk_start:.1f}s elapsed{mem_str})",
                    flush=True)
        solver.u = u
        solver.v = v
        solver.a = a
        solver.d = d
        solver.H_elem = He
        solver.H_nodal = Hn

    if snapshot_steps is not None:
        solver._last_forward_bundle = {
            'd_snapshots': d_snaps,
            'u_snapshots': u_snaps,
            'snapshot_steps': snap_actual,
            'dt': float(dt),
        }

    if return_observables == 'damage':
        return solver.d
    elif return_observables == 'displacement':
        return solver.u
    elif return_observables == 'both':
        return solver.d, solver.u
    else:
        raise ValueError(f"unknown return_observables: {return_observables}")


# ---------------------------------------------------------------------------
# Inversion driver
# ---------------------------------------------------------------------------

def make_param_tensors(theta, free, dtype, device):
    """Build tensors for the parameter dict, marking `free` ones with grad."""
    params = {}
    for k, v in theta.items():
        t = torch.tensor(float(v), dtype=dtype, device=device)
        if k in free:
            t.requires_grad_(True)
        params[k] = t
    return params


def freeze(params, free):
    """Return only the free tensors as a list (for the optimiser)."""
    return [params[k] for k in free]


def run_inversion(solver, target, theta_init, free, n_steps, n_iters,
                   device, label, output_dir, loss_type='damage',
                   tbptt_chunk_size=0,
                   checkpoint_chunks=0,
                   d_target_tbptt_chunks=None,
                   v0=16500.0, t_ramp=1.0e-6):
    """Run L-BFGS recovery of `free` parameters from theta_init using the
    pre-built `solver` (reused across all iterations).

    When ``tbptt_chunk_size > 0`` the closure routes its forward through
    ``run_forward_tbptt_generic`` (chunked-BPTT, biased gradient).
    Per-chunk damage MSE against ``d_target_tbptt_chunks`` (must match
    the same chunk schedule). Requires ``loss_type='damage'``.
    """
    dtype = torch.float64
    print(f"\n  ---- {label} ----")
    print(f"  Free: {free}")
    print(f"  Init: " + ", ".join(f"{k}={theta_init[k]:.4g}" for k in free))
    print(f"  True: " + ", ".join(f"{k}={THETA_TRUE[k]:.4g}" for k in free))

    # Build log-parameters for the optimiser
    log_free = {k: torch.tensor(float(np.log(theta_init[k])),
                                  dtype=dtype, device=device,
                                  requires_grad=True)
                 for k in free}
    optimizer = torch.optim.LBFGS(
        list(log_free.values()), lr=1.0, max_iter=4, history_size=10,
        line_search_fn='strong_wolfe')

    history = {'iter': [], 'loss': [], 'forwards': [], 'wall': [],
               **{k: [] for k in free},
               **{f'rel_err_{k}': [] for k in free}}
    fwd_counter = {'n': 1}  # 1 used for target

    # LoadingConfig that reproduces the demo's _impact_displacement(t, v0,
    # t_ramp) ramp. Demo passes v0 in mm/s directly; LoadingConfig stores
    # v0 in m/s and multiplies by 1e3 internally, so we divide by 1e3.
    loading = LoadingConfig(ramp_type='velocity_impact',
                            v0=v0 * 1e-3, t_ramp=t_ramp)

    def closure():
        optimizer.zero_grad()
        # Build current params dict (free → from log_free, fixed → from theta_init)
        params = {}
        for k in THETA_TRUE:
            if k in free:
                params[k] = torch.exp(log_free[k])
            else:
                params[k] = torch.tensor(float(theta_init[k]),
                                          dtype=dtype, device=device)
        if tbptt_chunk_size > 0:
            _, chunk_snaps_pred, _, _ = run_forward_tbptt_generic(
                solver, loading,
                install_fn=make_install_kalthoff_params(params),
                n_steps=n_steps,
                tbptt_chunk_size=tbptt_chunk_size)
            chunk_losses = [
                ((dp - dt) ** 2).mean()
                for dp, dt in zip(chunk_snaps_pred,
                                   d_target_tbptt_chunks)]
            loss = torch.stack(chunk_losses).mean()
        else:
            pred = run_kalthoff_forward(solver, params, n_steps,
                                          return_observables=loss_type,
                                          checkpoint_chunks=checkpoint_chunks)
            loss = ((pred - target) ** 2).mean()
        loss.backward()
        fwd_counter['n'] += 1
        return loss

    t_loop_start = time.time()
    for it in range(n_iters):
        t_iter = time.time()
        loss = optimizer.step(closure)
        cur = {k: float(torch.exp(log_free[k]).item()) for k in free}
        rel = {k: abs(cur[k] - THETA_TRUE[k]) / abs(THETA_TRUE[k]) for k in free}

        history['iter'].append(it)
        history['loss'].append(float(loss.item()))
        history['forwards'].append(int(fwd_counter['n']))
        history['wall'].append(time.time() - t_iter)
        for k in free:
            history[k].append(cur[k])
            history[f'rel_err_{k}'].append(rel[k])

        if it % max(1, n_iters // 15) == 0 or it == n_iters - 1:
            param_str = ", ".join(f"{k}={cur[k]:.4g}({rel[k]:.2%})" for k in free)
            print(f"  it {it:3d} | loss={loss.item():.3e} "
                  f"| fwds={fwd_counter['n']:4d} | {param_str}", flush=True)

        # Convergence: stop if loss < CG noise floor
        if loss.item() < 1e-12:
            print(f"  Converged at iter {it} (loss < 1e-12)")
            break

    elapsed = time.time() - t_loop_start
    print(f"  Wall time: {elapsed:.1f}s ({elapsed/(it+1):.1f}s/iter)")

    # Save
    out_path = os.path.join(output_dir, f'{label}_history.json')
    with open(out_path, 'w') as fp:
        json.dump({
            'label': label,
            'free': list(free),
            'theta_init': {k: theta_init[k] for k in free},
            'theta_true': {k: THETA_TRUE[k] for k in free},
            'n_steps': n_steps,
            'n_iters': len(history['iter']),
            'forwards_total': history['forwards'][-1] if history['forwards'] else 1,
            'history': history,
            'wall_time_s': elapsed,
        }, fp, indent=2)
    return history


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--h_crack', type=float, default=2.0)
    p.add_argument('--h_coarse', type=float, default=8.0)
    p.add_argument('--t_total', type=float, default=50.0,
                   help='Total simulation time [us]')
    p.add_argument('--n_iters', type=int, default=20)
    p.add_argument('--params', type=str, default='Gc_l0',
                   choices=['Gc', 'Gc_l0', '4'],
                   help="'Gc' (fix l0), 'Gc_l0', or '4' (= E, nu, Gc, l0)")
    p.add_argument('--multi_init', action='store_true',
                   help='Run from 3 initial guesses (1.5x, 2x, 0.6x truth)')
    p.add_argument('--device', type=str, default='cpu')
    p.add_argument('--output_dir', type=str, default='results_autograd_kalthoff')
    # Ablation knobs
    p.add_argument('--loss', type=str, default='damage',
                   choices=['damage', 'displacement'],
                   help='Observable for MSE loss. "displacement" is smoother '
                        '(Bleyer/Stanic/Powell+FD convention); "damage" is '
                        'what the paper currently uses (has spiky landscape).')
    p.add_argument('--softmax_H_beta', type=float, default=None,
                   help='Smooth-max for H update. None=exact torch.maximum '
                        '(default, piecewise gradient). 10-50 smoother gradients '
                        'for inversion; 1000+ ~ exact max.')
    p.add_argument('--H_update_method', type=str, default='hard_max',
                   choices=['hard_max', 'softmax', 'smooth_max',
                            'log_smooth', 'custom_subgrad'],
                   help='History update operator. Use custom_subgrad first '
                        'for inverse reruns; hard_max is a control.')
    p.add_argument('--H_update_scale', type=float, default=None,
                   help='Backward sigmoid scale for custom_subgrad. Default '
                        'uses the solver production scale.')
    p.add_argument('--damage_every', type=int, default=3,
                   help='Subcycle damage every N steps. 1=no subcycling (best '
                        'for autograd), 3=legacy default.')
    p.add_argument('--tbptt_chunk_size', type=int, default=0,
                   help='Truncated-BPTT chunk length (issue #288 / #301). '
                        '0 disables (default; full autograd graph). '
                        'When > 0, the n_steps explicit-dynamics loop is '
                        'split into chunks of this length; per-chunk damage '
                        'MSE-against-truth is the loss, biased gradient. '
                        'Requires --loss=damage; the velocity-impact ramp '
                        'is reproduced via LoadingConfig(ramp_type='
                        '"velocity_impact"). Mixed material attrs and '
                        'solver-level diff overrides (E, nu, Gc, l0) are '
                        'installed via make_install_kalthoff_params.')
    p.add_argument('--checkpoint_chunks', type=int, default=0,
                   help='Exact gradient checkpoint chunks for the explicit '
                        'time loop. Unlike --tbptt_chunk_size, this does not '
                        'detach chunk boundaries; it replays chunks during '
                        'backward to reduce activation memory. Mutually '
                        'exclusive with --tbptt_chunk_size.')
    p.add_argument('--forward_only', action='store_true',
                   help='Generate the truth forward bundle and exit before '
                        'running the inverse optimizer.')
    p.add_argument('--save_forward_viz', dest='save_forward_viz',
                   action='store_true', default=True,
                   help='Save target damage PNG/GIF for visual review.')
    p.add_argument('--no_save_forward_viz', dest='save_forward_viz',
                   action='store_false',
                   help='Disable target damage PNG/GIF export.')
    p.add_argument('--n_viz_frames', type=int, default=24,
                   help='Number of snapshots for forward bundle GIF output.')
    args = p.parse_args()

    out_dir = os.path.join(THIS_DIR, args.output_dir) \
        if not os.path.isabs(args.output_dir) else args.output_dir
    os.makedirs(out_dir, exist_ok=True)

    print("=" * 70)
    print("  DEMO: Autograd material recovery on B2 Kalthoff (Borden 2012)")
    print("=" * 70)
    print(f"  Mesh: h_crack={args.h_crack}mm, h_coarse={args.h_coarse}mm")
    print(f"  Time: T={args.t_total}us")
    print(f"  Device: {args.device}")
    print(f"  Iters per inversion: {args.n_iters}")
    print(f"  Output: {out_dir}")

    device = args.device
    dtype = torch.float64

    mesh, mesh_path = build_kalthoff_mesh(
        args.h_crack, args.h_coarse, THETA_TRUE['l0'], device, dtype)
    n_nodes = int(mesh.n_nodes)
    n_elems = int(len(mesh.elements))
    print(f"  Mesh: {n_nodes} nodes, {n_elems} elements")

    # Build the solver ONCE (this prints all the FEMOperators / DamageSolver
    # init lines exactly once instead of per-iteration).
    print("  Building solver (one-time init) ...")
    print(f"  Ablation: loss={args.loss}, softmax_H_beta={args.softmax_H_beta}, "
          f"H_update_method={args.H_update_method}, "
          f"damage_every={args.damage_every}")
    solver, ctx = build_kalthoff_solver(
        mesh, dt_safety=0.5, device=device, dtype=dtype,
        h_crack_tol=args.h_crack,
        damage_every=args.damage_every,
        softmax_H_beta=args.softmax_H_beta,
        H_update_method=args.H_update_method,
        H_update_scale=args.H_update_scale)

    # Compute n_steps from solver dt
    dt = float(solver.dt)
    n_steps = max(1, int(round(args.t_total * 1e-6 / dt)))
    print(f"  dt={dt*1e9:.1f}ns, n_steps={n_steps}")

    # ---- TBPTT setup (issue #301) ----
    # The demo's _impact_displacement ramp is reproduced via a
    # LoadingConfig with ramp_type='velocity_impact' (mathematically
    # identical; v0 unit gotcha handled inside run_inversion).
    d_target_tbptt_chunks = None
    if args.tbptt_chunk_size > 0 and args.checkpoint_chunks > 0:
        raise SystemExit(
            "--tbptt_chunk_size and --checkpoint_chunks are mutually "
            "exclusive.")
    if args.tbptt_chunk_size > 0:
        if args.loss != 'damage':
            raise SystemExit(
                "--tbptt_chunk_size > 0 requires --loss=damage "
                "(per-chunk damage MSE). displacement-loss + TBPTT is "
                "not wired here.")
        cs = int(args.tbptt_chunk_size)
        print(f"\n[TBPTT #301] enabled: chunk_size={cs}, "
              f"n_chunks~={(n_steps + cs - 1) // cs}")

    # ---- Generate target ----
    print(f"\n[1/2] Generating target {args.loss} field at truth ...")
    t0 = time.time()
    target_params = {k: torch.tensor(float(THETA_TRUE[k]),
                                      dtype=dtype, device=device)
                      for k in THETA_TRUE}
    snapshot_steps = None
    if args.save_forward_viz and args.n_viz_frames > 0:
        n_frames = min(args.n_viz_frames, n_steps)
        snapshot_steps = sorted(set(
            int(s) for s in np.linspace(1, n_steps, n_frames)))
    with torch.no_grad():
        if args.tbptt_chunk_size > 0:
            loading_truth = LoadingConfig(
                ramp_type='velocity_impact', v0=16.5, t_ramp=1.0e-6)
            _, truth_chunk_snaps, _, _ = run_forward_tbptt_generic(
                solver, loading_truth,
                install_fn=make_install_kalthoff_params(target_params),
                n_steps=n_steps,
                tbptt_chunk_size=args.tbptt_chunk_size)
            d_target_tbptt_chunks = [s.detach().clone()
                                      for s in truth_chunk_snaps]
            target = d_target_tbptt_chunks[-1]
        else:
            target = run_kalthoff_forward(
                solver, target_params, n_steps,
                return_observables=args.loss,
                snapshot_steps=snapshot_steps).detach().clone()
    if args.loss == 'damage':
        print(f"  Target: max(d)={target.max().item():.4f}, "
              f"d>0.5: {(target>0.5).sum().item()}, "
              f"forward time {time.time()-t0:.1f}s")
    else:
        print(f"  Target: |u|_max={target.abs().max().item():.4e}mm, "
              f"mean|u|={target.abs().mean().item():.4e}mm, "
              f"forward time {time.time()-t0:.1f}s")

    # Save target snapshot for plotting
    np.save(os.path.join(out_dir, f'target_{args.loss}.npy'), target.cpu().numpy())
    bundle = getattr(solver, '_last_forward_bundle', None)
    if bundle is not None:
        elements_np = (mesh.elements.detach().cpu().numpy()
                       if torch.is_tensor(mesh.elements)
                       else np.asarray(mesh.elements))
        elements_np = elements_np.astype(np.int64, copy=False)
        d_snaps = [d.cpu().numpy() for d in bundle['d_snapshots']]
        u_snaps = [u.cpu().numpy() for u in bundle['u_snapshots']]
        np.savez_compressed(
            os.path.join(out_dir, 'truth_forward_bundle.npz'),
            nodes=mesh.nodes.detach().cpu().numpy(),
            elements=elements_np,
            d_final=solver.d.detach().cpu().numpy(),
            u_final=solver.u.detach().cpu().numpy(),
            d_snapshots=np.asarray(d_snaps),
            u_snapshots=np.asarray(u_snaps),
            snapshot_steps=np.asarray(bundle['snapshot_steps'], dtype=np.int64),
            snapshot_t_us=(np.asarray(bundle['snapshot_steps'], dtype=np.float64)
                           * float(bundle['dt']) * 1.0e6),
            theta_true=np.asarray([THETA_TRUE[k] for k in ('E', 'nu', 'Gc', 'l0')]),
            theta_names=np.asarray(['E', 'nu', 'Gc', 'l0']),
        )
        print("  Forward bundle saved -> "
              f"{os.path.join(out_dir, 'truth_forward_bundle.npz')}")
        if args.save_forward_viz:
            try:
                from inverse_problems._viz import save_forward_viz
                paths = save_forward_viz(
                    mesh.nodes.detach().cpu().numpy(),
                    elements_np,
                    solver.d.detach().cpu().numpy(),
                    out_dir,
                    label='truth',
                    snapshots=d_snaps,
                    snap_steps=bundle['snapshot_steps'],
                    n_steps_total=n_steps)
                print(f"  [forward-viz] truth png -> {paths['png']}")
                if paths['gif']:
                    print(f"  [forward-viz] truth gif -> {paths['gif']}")
            except Exception as exc:
                print(f"  WARNING: forward viz failed: {exc}")

    if args.forward_only:
        print("\n=== FORWARD ONLY DONE ===")
        print(f"Results in: {out_dir}")
        return

    # ---- Inversion ----
    print("\n[2/2] Running inversion(s) ...")
    if args.params == '4':
        free = ['E', 'nu', 'Gc', 'l0']
    elif args.params == 'Gc':
        free = ['Gc']
    else:
        free = ['Gc', 'l0']

    if args.multi_init:
        for factor in INIT_FACTORS:
            theta_init = {k: THETA_TRUE[k] * factor for k in THETA_TRUE}
            label = f"init_{factor:.1f}x".replace('.', 'p')
            run_inversion(solver, target, theta_init, free,
                          n_steps, args.n_iters, device, label, out_dir,
                          loss_type=args.loss,
                          tbptt_chunk_size=args.tbptt_chunk_size,
                          checkpoint_chunks=args.checkpoint_chunks,
                          d_target_tbptt_chunks=d_target_tbptt_chunks)
    else:
        theta_init = {k: THETA_TRUE[k] * 1.5 for k in THETA_TRUE}
        run_inversion(solver, target, theta_init, free,
                      n_steps, args.n_iters, device, 'main', out_dir,
                      loss_type=args.loss,
                      tbptt_chunk_size=args.tbptt_chunk_size,
                      checkpoint_chunks=args.checkpoint_chunks,
                      d_target_tbptt_chunks=d_target_tbptt_chunks)

    print("\n=== DONE ===")
    print(f"Results in: {out_dir}")


if __name__ == '__main__':
    main()
