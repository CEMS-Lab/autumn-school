"""Spatial regularisers for inverse parameter-field recovery.

Implements two standard regularisers for piecewise-constant per-element
fields on triangular meshes:

* ``h1_seminorm``  -- discrete H^1 (Dirichlet) energy via edge-jump
                      penalty. Promotes smooth fields.
* ``tv_seminorm``  -- (smoothed) discrete total variation via |jump|
                      across shared edges. Preserves sharp transitions
                      (piecewise-constant-ish).

Both are computed on shared interior edges of the triangulation: for
each pair of adjacent elements ``(e_i, e_j)`` sharing edge of length
``L_ij``,

    H1_seminorm(g) = sum_{(i,j)} L_ij * (g_i - g_j)^2
    TV_seminorm(g) = sum_{(i,j)} L_ij * sqrt((g_i - g_j)^2 + eps^2)

The sqrt smoothing in TV ensures differentiability at zero jump (the
``eps`` term is tiny relative to typical jumps but keeps the gradient
well-defined).

For a *constant* field both seminorms vanish exactly. Tests cover this.

Issue tracker: #236 (Paper 2 carry-over demo 1).
"""
from __future__ import annotations

import torch


def _build_edge_adjacency(elements: torch.Tensor, nodes: torch.Tensor):
    """Return (e1, e2, edge_length) for every shared interior edge.

    Parameters
    ----------
    elements : (E, 3) long tensor of node indices
    nodes    : (N, 2) float tensor of node coordinates

    Returns
    -------
    e1, e2       : (M,) long tensors of element indices for each shared edge
    edge_length  : (M,) float tensor of edge lengths
    """
    elements = elements.detach().to(torch.long)
    E = elements.shape[0]
    # Build (3*E, 2) array of (sorted) edge node-pairs and parent-element id.
    # Triangle local edges: (n0, n1), (n1, n2), (n2, n0)
    e_idx = torch.arange(E, device=elements.device).repeat_interleave(3)
    edge_pairs = torch.stack(
        [
            torch.stack([elements[:, 0], elements[:, 1]], dim=1),
            torch.stack([elements[:, 1], elements[:, 2]], dim=1),
            torch.stack([elements[:, 2], elements[:, 0]], dim=1),
        ],
        dim=1,
    ).reshape(-1, 2)  # (3E, 2)
    edge_pairs, _ = edge_pairs.sort(dim=1)  # canonical (min, max)

    # Lexicographic key per edge for grouping
    n_nodes = int(nodes.shape[0])
    key = edge_pairs[:, 0].to(torch.int64) * (n_nodes + 1) + edge_pairs[:, 1].to(torch.int64)
    sort_idx = torch.argsort(key)
    key_s = key[sort_idx]
    pairs_s = edge_pairs[sort_idx]
    e_idx_s = e_idx[sort_idx]

    # Find consecutive duplicates -> shared edges (interior).
    same = key_s[:-1] == key_s[1:]
    matched = same.nonzero(as_tuple=False).flatten()
    if matched.numel() == 0:
        empty_l = torch.zeros(0, dtype=torch.long, device=elements.device)
        empty_f = torch.zeros(0, dtype=nodes.dtype, device=elements.device)
        return empty_l, empty_l, empty_f

    e1 = e_idx_s[matched]
    e2 = e_idx_s[matched + 1]
    pair_nodes = pairs_s[matched]  # (M, 2)
    p0 = nodes[pair_nodes[:, 0]]
    p1 = nodes[pair_nodes[:, 1]]
    edge_length = (p1 - p0).norm(dim=1).to(nodes.dtype)
    return e1, e2, edge_length


def _get_adjacency(mesh):
    """Cached wrapper around ``_build_edge_adjacency``.

    The triple is stored on the mesh as ``_inv_edge_adj`` so a long
    optimisation loop only pays the assembly cost once.
    """
    cached = getattr(mesh, "_inv_edge_adj", None)
    if cached is not None:
        return cached
    e1, e2, L = _build_edge_adjacency(mesh.elements, mesh.nodes)
    mesh._inv_edge_adj = (e1, e2, L)
    return mesh._inv_edge_adj


def h1_seminorm(field: torch.Tensor, mesh) -> torch.Tensor:
    """Discrete H^1 seminorm for a per-element field.

    R_H1(g) = sum_{(i,j) in interior edges} L_ij * (g_i - g_j)^2

    Differentiable in ``field``; returns a scalar tensor on the field's
    device/dtype.
    """
    if field.dim() != 1:
        raise ValueError(f"field must be 1-D (n_elem,); got {tuple(field.shape)}")
    e1, e2, L = _get_adjacency(mesh)
    if e1.numel() == 0:
        return field.sum() * 0.0
    L = L.to(device=field.device, dtype=field.dtype)
    diff = field[e1] - field[e2]
    return (L * diff * diff).sum()


def tv_seminorm(field: torch.Tensor, mesh, eps: float = 1.0e-8) -> torch.Tensor:
    """Smoothed total-variation seminorm for a per-element field.

    R_TV(g) = sum_{(i,j) in interior edges} L_ij * sqrt((g_i - g_j)^2 + eps^2)

    The ``eps`` smoothing keeps the gradient w.r.t. ``field`` well-defined
    at zero jump (Huber-like behaviour near 0). For ``eps=0`` and a
    constant field the seminorm vanishes identically; for ``eps > 0``
    the per-edge contribution at zero jump is ``L_ij * eps`` and we
    subtract this baseline so a constant field still returns 0.
    """
    if field.dim() != 1:
        raise ValueError(f"field must be 1-D (n_elem,); got {tuple(field.shape)}")
    if eps < 0.0:
        raise ValueError(f"eps must be >= 0; got {eps}")
    e1, e2, L = _get_adjacency(mesh)
    if e1.numel() == 0:
        return field.sum() * 0.0
    L = L.to(device=field.device, dtype=field.dtype)
    diff = field[e1] - field[e2]
    if eps == 0.0:
        return (L * diff.abs()).sum()
    eps_t = torch.tensor(eps, device=field.device, dtype=field.dtype)
    smoothed = torch.sqrt(diff * diff + eps_t * eps_t)
    # Subtract baseline L_ij * eps so a constant field returns exactly 0.
    return (L * (smoothed - eps_t)).sum()


def combine(field, mesh, *, alpha_h1: float = 0.0, alpha_tv: float = 0.0,
            tv_eps: float = 1.0e-8) -> torch.Tensor:
    """Convenience: alpha_h1 * H1(field) + alpha_tv * TV(field).

    Returns a scalar tensor (zero if both alphas are 0).
    """
    if alpha_h1 == 0.0 and alpha_tv == 0.0:
        return field.sum() * 0.0
    out = field.sum() * 0.0
    if alpha_h1 != 0.0:
        out = out + alpha_h1 * h1_seminorm(field, mesh)
    if alpha_tv != 0.0:
        out = out + alpha_tv * tv_seminorm(field, mesh, eps=tv_eps)
    return out
