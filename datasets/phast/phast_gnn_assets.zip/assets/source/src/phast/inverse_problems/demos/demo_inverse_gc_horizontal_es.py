#!/usr/bin/env python
"""ES (Evolutionary Strategies) baseline for the horizontal-Gc(x)
inverse problem (issue #315).

This is the gradient-free counterpart to ``demo_inverse_gc_horizontal.py``.
We import the helpers from that demo (geometry constants, ``build_sent_mesh``,
``build_solver``, ``horizontal_band_field``, ``run_forward``,
``differentiable_crack_path``, ``soft_tip_x_np``) so the *forward* model
and the path observable are bit-identical to the autograd demo. Only the
optimizer changes.

Why ES
------
``demo_inverse_gc_horizontal.py`` (L-BFGS + autograd, full-BPTT) is
known-divergent at production-scale ``n_steps = 20000`` even with the
TBPTT (#288, #301) and path-mode (#312) mitigations. PR #297 added
``inverse_problems/optimizers/es_optimizer.py``; PR #317 wrapped
``demo_inverse_stiff_inclusion_es.py`` around it with path-mode and
multi-particle support. This demo is the analogous wrapper for
gc_horizontal: same forward, same observables, gradient-free
optimizer. ES is bounded by ``O(|L| / sigma)`` regardless of any
chaotic eigenvalue blow-up in the unrolled forward map (Salimans 2017;
Suh 2022 §5), so it is the floor below which any "differentiable
simulator" claim must show a real win at production scale.

Parameter modes (``--param``)
-----------------------------
- ``low_rank`` (default): 3 unknowns ``(x0, sigma, wf)`` per the
  L-BFGS demo's Gaussian-bump formula

      Gc(x) = Gc_nominal * (1 - wf * exp(-(x_c - x0)^2 / (2 sigma^2)))

  ES does not need a log-parametrization for sigma -- the rank-shaped
  estimator is invariant to monotone transforms of the loss; we let
  sigma vary linearly and clip to ``[1e-3, W/2]`` inside the closure
  so a noisy ES sample cannot push sigma negative or huge.

- ``full_field``: per-element Gc field, ``k = n_elem`` unknowns. ES
  will struggle at this dimensionality (Salimans-style ES is
  empirically O(d) sample-inefficient; n_elem on a production mesh
  is ~10^5). We optimize ``log(Gc_e)`` so positivity is preserved
  under Gaussian perturbation. This mode is provided for completeness
  / negative-result documentation -- the headline ES result is
  low_rank.

Observation modes (``--obs_mode``)
----------------------------------
- ``full`` (default): final-time damage MSE. Saturation-degenerate at
  large ``n_steps`` (entire crack saturates to ``d=1`` outside the band
  so the loss surface collapses) -- same caveat as the L-BFGS demo and
  ``demo_inverse_stiff_inclusion_es.py``.
- ``path``: damage-weighted crack centerline ``y(x)`` on a fixed
  x-grid. Mass-weighted MSE so bins with no truth crack carry zero
  weight. Uses the *same* ``differentiable_crack_path`` soft-bin
  formula as the L-BFGS demo so the two are directly comparable. The
  smoothing is irrelevant for ES (we read out a scalar per forward,
  not a gradient) but keeping the same observable makes the
  gradient-vs-gradient-free head-to-head apples-to-apples.
- ``tips``: hard-argmax crack-tip x-positions at ``n_tips``
  evenly-spaced timesteps. ES does not need a differentiable extractor.
  Note: hard-argmax is plateau-flat between element boundaries; at
  fine meshes (h_crack 0.05 mm) bump ``--sigma`` above ``h_crack`` to
  avoid stalling. The L-BFGS gc_horizontal demo does NOT support tips
  mode -- ES gets it for free because no differentiability constraint.

Usage
-----
    # Default (low_rank, full damage MSE)
    python demo_inverse_gc_horizontal_es.py --device cpu --smoke

    # Path-mode (matches L-BFGS path observable)
    python demo_inverse_gc_horizontal_es.py --device cpu --smoke \
        --obs_mode path --n_path_bins 40

    # Tips-mode
    python demo_inverse_gc_horizontal_es.py --device cpu --smoke \
        --obs_mode tips --n_tips 10

    # Legacy long-horizon ES production diagnostic (gradient-free).
    # For L-BFGS/autograd inversion, use the short-horizon path-mode
    # recipes in scripts/slurm/inverse/hpc_inv_pair_B_inversion.slurm.
    python demo_inverse_gc_horizontal_es.py --device cuda \
        --n_steps 20000 --n_iter 200 --n_samples 16 --obs_mode path
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(THIS_DIR, '..', '..'))
sys.path.insert(0, os.path.dirname(REPO_ROOT))
sys.path.insert(0, REPO_ROOT)

# The autograd demo does ``from phast.mesh_generator import ...``
# This works in the canonical checkout because the repo's parent
# (``neural_operator/``) holds a ``phast/`` directory. In a
# git-worktree the worktree path is the repo, but its parent
# (``worktrees/``) has no such package. Register the repo itself under
# the alias ``phast`` in ``sys.modules`` so the autograd demo
# import resolves whichever path we are run from. Mirrors
# ``demo_inverse_stiff_inclusion_es.py`` lines 105-119.
if 'phast' not in sys.modules:
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        'phast', os.path.join(REPO_ROOT, '__init__.py'),
        submodule_search_locations=[REPO_ROOT])
    if spec is not None and spec.loader is not None:
        mod = importlib.util.module_from_spec(spec)
        sys.modules['phast'] = mod
        try:
            spec.loader.exec_module(mod)
        except Exception:
            # Best-effort: if root __init__ has bugs we still let
            # later imports try -- the autograd demo only needs a few
            # submodules that may import individually.
            pass

# Import helpers from the autograd demo (do NOT modify it). gc_horizontal's
# ``run_forward`` returns a 2-tuple ``(d, snaps)`` (NOT 3-tuple like
# stiff_inclusion's), and ``build_solver(mesh, dU, tau_ramp, damping_zeta,
# device, dtype)`` takes a pre-built mesh -- different signature from
# stiff_inclusion's. We honour those differences here.
from inverse_problems.demos.demo_inverse_gc_horizontal import (  # noqa: E402
    GC, W, H, A, CRACK_Y,
    DEFAULT_X0, DEFAULT_SIGMA, DEFAULT_WEAK_FRACTION,
    build_sent_mesh, build_solver,
    horizontal_band_field, run_forward,
    differentiable_crack_path, soft_tip_x_np,
)
from phast.config import LoadingConfig  # noqa: E402
from inverse_problems.optimizers import ESOptimizer  # noqa: E402


import matplotlib  # noqa: E402
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402


# Stable serif rcParams (memory: feedback_paper_font.md)
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['STIX', 'Times New Roman', 'DejaVu Serif'],
    'mathtext.fontset': 'stix',
    'pdf.fonttype': 42,
})


# ----------------------------------------------------------------------
# Tip extractors (ES doesn't need differentiability)
# ----------------------------------------------------------------------

def hard_tip_x_np(d_node, node_x_np):
    """Rightmost x where d > 0.5; returns -inf if no node above 0.5.

    Hard-argmax tip extractor. Plateau-flat between element widths --
    safe at smoke meshes (h_crack 0.4 mm), tune ES sigma >= h_crack at
    fine meshes (h_crack 0.05 mm) to avoid stalling.
    """
    mask = d_node > 0.5
    if not np.any(mask):
        return -np.inf
    return float(node_x_np[mask].max())


# ----------------------------------------------------------------------
# Loss closures
# ----------------------------------------------------------------------

def _make_loss_fn(solver, loading, centroids, n_steps, *,
                   param_mode, n_elem,
                   obs_mode, d_target_full,
                   weak_fraction_held=None,
                   node_x=None, node_y=None,
                   x_bins=None, path_sigma=None,
                   y_target_path=None, mass_target_path=None,
                   snap_steps=None, tips_target=None):
    """Build a closure ``loss_fn(theta) -> float`` for the requested
    ``(param_mode, obs_mode)`` combination.

    Everything runs under ``torch.no_grad`` -- ES does not need
    autograd, and skipping tape construction halves the per-forward
    cost relative to the L-BFGS demo.

    param_mode dispatch
    -------------------
    - ``low_rank``: ``theta = [x0, sigma, wf]`` (length 3). sigma is
      clipped to ``[1e-3, W/2]`` and wf to ``[0, 1]`` so a noisy ES
      sample cannot push the parameters into nonsense regions where
      ``horizontal_band_field`` would explode.
    - ``full_field``: ``theta = log(Gc_e)`` (length n_elem). Positivity
      is preserved under Gaussian perturbation by exponentiating
      inside the closure.

    Loss formulas
    -------------
    - ``full``: ``loss = mean((d_pred - d_target)**2)`` over all nodes.
      Saturation-degenerate at large n_steps.
    - ``path``: same as L-BFGS ``crack_path_loss`` --
      ``loss = sum(mass_target * (y_pred - y_target)**2) / sum(mass_target)``
      where ``y_pred, _ = differentiable_crack_path(d_pred, ...)``.
      Mass-weighted so bins with no truth crack carry zero weight.
    - ``tips``: ``loss = mean((tip_pred - tip_target)**2)`` where
      ``tip(d) = max(node_x[d > 0.5])`` (hard-argmax, non-differentiable).
      Computed at each step in ``snap_steps``.
    """
    dtype = centroids.dtype
    device = centroids.device

    if obs_mode == 'path':
        assert x_bins is not None and y_target_path is not None
    elif obs_mode == 'tips':
        assert snap_steps is not None and tips_target is not None
    elif obs_mode != 'full':
        raise ValueError(f"unknown obs_mode {obs_mode!r}")
    if param_mode not in ('low_rank', 'full_field'):
        raise ValueError(f"unknown param_mode {param_mode!r}")
    if param_mode == 'low_rank' and weak_fraction_held is None:
        # Even though theta carries wf, we hold a sentinel default for
        # downstream code that may want to recover wf=truth.
        weak_fraction_held = float(DEFAULT_WEAK_FRACTION)

    node_x_np = node_x.detach().cpu().numpy() if node_x is not None else None

    def _theta_to_Gc(theta):
        """Map ES parameter vector to a per-element Gc field."""
        if param_mode == 'low_rank':
            # Clip to physical ranges so out-of-bounds ES samples don't
            # blow up the forward. sigma > 0 enforces a finite Gaussian
            # bump; wf in [0, 1] keeps Gc(x) >= 0 everywhere.
            x0 = theta[0]
            sigma = theta[1].clamp(min=1e-3, max=W / 2.0)
            wf = theta[2].clamp(min=0.0, max=1.0)
            return horizontal_band_field(centroids, x0, sigma, wf)
        # full_field: log(Gc_e) -> Gc_e
        return torch.exp(theta)

    def loss_fn(theta):
        with torch.no_grad():
            theta_t = theta.to(dtype=dtype, device=device)
            if param_mode == 'full_field' and theta_t.numel() != n_elem:
                raise ValueError(
                    f"full_field theta has {theta_t.numel()} entries, "
                    f"expected n_elem = {n_elem}")
            if param_mode == 'low_rank' and theta_t.numel() != 3:
                raise ValueError(
                    f"low_rank theta has {theta_t.numel()} entries, "
                    f"expected 3 (x0, sigma, wf)")
            Gc_field = _theta_to_Gc(theta_t)
            d_pred, snaps_pred = run_forward(
                solver, loading, Gc_field, n_steps,
                snapshot_steps=snap_steps if obs_mode == 'tips' else None)
            if obs_mode == 'full':
                loss = ((d_pred - d_target_full) ** 2).mean()
            elif obs_mode == 'path':
                y_pred, _ = differentiable_crack_path(
                    d_pred, node_x, node_y, x_bins, path_sigma, p=4)
                sq = (y_pred - y_target_path) ** 2
                loss = (mass_target_path * sq).sum() / (
                    mass_target_path.sum() + 1e-12)
            else:  # tips
                # Hard-argmax tip extractor -- read out per-snapshot
                # rightmost x with d > 0.5. Non-differentiable; ES OK.
                tips_pred_np = np.array([
                    hard_tip_x_np(s.detach().cpu().numpy()
                                    if torch.is_tensor(s) else s,
                                    node_x_np)
                    for _, s in snaps_pred
                ], dtype=np.float64)
                # If the predicted crack hasn't propagated yet
                # (hard_tip_x_np returns -inf), substitute the notch tip
                # so the loss is well-defined.
                tips_pred_np = np.where(np.isfinite(tips_pred_np),
                                         tips_pred_np, 0.0)
                tips_pred = torch.tensor(tips_pred_np, dtype=dtype,
                                          device=device)
                loss = ((tips_pred - tips_target) ** 2).mean()
        return float(loss.item())

    return loss_fn


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device', type=str, default='cpu',
                   choices=['cuda', 'cpu'])
    p.add_argument('--smoke', action='store_true', default=True,
                   help='Smoke-tier mesh and timesteps (CPU-friendly).')
    p.add_argument('--full', action='store_true',
                   help='Production resolution. Hours on CPU; HPC only.')
    p.add_argument('--n_steps', type=int, default=None,
                   help='Override timestep count.')
    p.add_argument('--n_iter', type=int, default=12,
                   help='ES outer iterations. Default keeps the demo '
                        'inside the ~10 min CPU budget; 200 iters '
                        'requires --device cuda or HPC.')
    p.add_argument('--n_samples', type=int, default=4,
                   help='ES samples per step (forward count = 2 * n_samples '
                        'with antithetic). Default 4 is the smallest '
                        'count where the rank-shaped estimator is '
                        'meaningful; bump to 16-32 on HPC.')
    p.add_argument('--sigma', type=float, default=0.5,
                   help='ES perturbation scale. For --param low_rank '
                        'this is in mixed units (mm for x0/sigma, '
                        'dimensionless for wf); 0.5 is a reasonable '
                        'compromise on the smoke geometry. With '
                        '--obs_mode tips on a fine mesh (h_crack '
                        '0.05 mm), bump sigma above h_crack to avoid '
                        'plateau-flat hard-argmax responses.')
    p.add_argument('--lr', type=float, default=0.5,
                   help='ES learning rate.')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--out_dir', type=str, default=None)

    # ---- #315: parameter mode (mirrors L-BFGS demo) -------------------
    p.add_argument('--param', type=str, default='low_rank',
                   choices=['low_rank', 'full_field'],
                   help='low_rank = 3 unknowns (x0, sigma, wf); '
                        'full_field = per-element Gc, k = n_elem '
                        'unknowns (ES will struggle at this scale -- '
                        'documented as negative result).')

    # ---- observation mode (mirrors stiff_inclusion_es) ---------------
    p.add_argument('--obs_mode', type=str, default='full',
                   choices=['full', 'path', 'tips'],
                   help='full = MSE on final damage field (saturation-'
                        'degenerate at large n_steps); '
                        'path = mass-weighted MSE on damage-weighted '
                        'crack centerline y(x) on n_path_bins (matches '
                        'L-BFGS path observable); '
                        'tips = MSE on hard-argmax crack-tip x at n_tips '
                        'snapshots. ES does not need a differentiable '
                        'extractor so the tip is plain rightmost d>0.5 '
                        'x. Note: the L-BFGS gc_horizontal demo does '
                        'not expose tips; ES gets it for free.')
    p.add_argument('--n_path_bins', type=int, default=40,
                   help='Number of x-bins for --obs_mode path.')
    p.add_argument('--path_sigma_factor', type=float, default=0.6,
                   help='Bin width as a fraction of inter-bin spacing '
                        '(--obs_mode path). Default 0.6 matches the '
                        'L-BFGS demo so the truth/predicted paths are '
                        'binned identically.')
    p.add_argument('--n_tips', type=int, default=10,
                   help='Number of tip snapshots when --obs_mode tips.')

    # ---- truth defaults (mirror L-BFGS demo) -------------------------
    p.add_argument('--x0_truth', type=float, default=DEFAULT_X0)
    p.add_argument('--sigma_truth', type=float, default=DEFAULT_SIGMA)
    p.add_argument('--weak_fraction', type=float,
                   default=DEFAULT_WEAK_FRACTION,
                   help='Truth weak-fraction (held fixed for path/tips '
                        'reference; recovered as theta[2] in low_rank).')
    p.add_argument('--x0_init', type=float, default=None,
                   help='Init x0 for low_rank (default x0_truth + 1.5).')
    p.add_argument('--sigma_init', type=float, default=None,
                   help='Init sigma for low_rank (default 1.0).')
    p.add_argument('--wf_init', type=float, default=None,
                   help='Init weak-fraction for low_rank '
                        '(default 0.3, off-truth so ES has to '
                        'recover all 3 axes).')

    args = p.parse_args()

    if args.full:
        args.smoke = False

    device = torch.device(args.device)
    dtype = torch.float64

    if args.smoke:
        h_crack, h_coarse = 0.4, 2.0
        # 800 steps lands in the propagation phase but well before
        # full saturation -- enough signal for the loss surface,
        # CPU-friendly. The autograd demo uses 2500; ES doesn't need
        # the long settling tail because there's no L-BFGS line search.
        n_steps = args.n_steps if args.n_steps is not None else 800
    else:
        h_crack, h_coarse = 0.05, 0.5
        n_steps = args.n_steps if args.n_steps is not None else 9000
    delta_U = 5e-2
    tau_ramp = 30e-6
    damping_zeta = 0.1

    # ---- init defaults --------------------------------------------------
    x0_init = args.x0_init if args.x0_init is not None else args.x0_truth + 1.5
    sigma_init = args.sigma_init if args.sigma_init is not None else 1.0
    wf_init = args.wf_init if args.wf_init is not None else 0.3

    out_dir = args.out_dir or os.path.join(
        THIS_DIR, 'results_inverse_gc_horizontal_es')
    os.makedirs(out_dir, exist_ok=True)

    print("=" * 72)
    print("  Horizontal Gc(x) ES inversion (Salimans 2017 / Suh 2022 §5)")
    print("=" * 72)
    print(f"  Plate: {W} x {H} mm, notch a = {A} mm, crack axis y = {CRACK_Y}")
    print(f"  Truth band: x0 = {args.x0_truth} mm, sigma = {args.sigma_truth} mm,"
          f" weak_fraction = {args.weak_fraction}")
    print(f"  param mode: {args.param}; obs mode: {args.obs_mode}")
    print(f"  ES: n_iter={args.n_iter}, n_samples={args.n_samples}, "
          f"sigma={args.sigma}, lr={args.lr}, seed={args.seed}")
    print(f"  Mesh: h_crack={h_crack}, h_coarse={h_coarse}; "
          f"n_steps={n_steps}, device={args.device}")
    print(f"  out_dir = {out_dir}")

    # ---- forward setup -------------------------------------------------
    mesh, _msh_path = build_sent_mesh(h_crack, h_coarse, args.device, dtype)
    solver = build_solver(mesh, delta_U, tau_ramp, damping_zeta,
                            args.device, dtype)
    centroids = mesh.nodes[mesh.elements].mean(dim=1)
    n_elem = mesh.n_elems
    n_nodes = mesh.n_nodes
    loading = LoadingConfig(ramp_type='smooth', t_ramp=tau_ramp)
    print(f"  Mesh: {n_nodes} nodes, {n_elem} elements; "
          f"dt = {solver.dt:.3e} s")

    node_x = mesh.nodes[:, 0]
    node_y = mesh.nodes[:, 1]

    # Path-mode bin grid -- same convention as L-BFGS demo.
    if args.obs_mode == 'path':
        x_bins = torch.linspace(A, W, args.n_path_bins,
                                  dtype=dtype, device=device)
        bin_dx = float(x_bins[1] - x_bins[0])
        path_sigma = args.path_sigma_factor * bin_dx
        print(f"  Path bins: {args.n_path_bins} from x={A} to x={W}, "
              f"sigma_bin = {path_sigma:.3f} mm")
    else:
        x_bins = None
        path_sigma = None

    # Tips-mode snapshot steps.
    if args.obs_mode == 'tips':
        first = max(int(0.05 * n_steps), 1)
        snap_steps = list(np.linspace(first, n_steps, args.n_tips,
                                        dtype=int).tolist())
        print(f"  Tip snapshots at {args.n_tips} steps: "
              f"{snap_steps[0]}..{snap_steps[-1]}")
    else:
        snap_steps = None

    # ---- truth forward (no_grad) --------------------------------------
    print("\n[1/3] Truth forward (no-grad) ...")
    t0 = time.time()
    with torch.no_grad():
        Gc_true = horizontal_band_field(
            centroids,
            torch.tensor(args.x0_truth, dtype=dtype, device=device),
            torch.tensor(args.sigma_truth, dtype=dtype, device=device),
            torch.tensor(args.weak_fraction, dtype=dtype, device=device),
        )
        d_target_full, snaps_truth = run_forward(
            solver, loading, Gc_true, n_steps,
            snapshot_steps=snap_steps if args.obs_mode == 'tips' else None)
        d_target_full = d_target_full.detach().clone()
    truth_wall = time.time() - t0
    print(f"  truth wall: {truth_wall:.1f}s; max(d) = "
          f"{float(d_target_full.max()):.3f}; "
          f"#d>0.5 = {int((d_target_full > 0.5).sum())}; "
          f"Gc range [{Gc_true.min():.4e}, {Gc_true.max():.4e}]")

    # ---- obs-mode-specific truth observables --------------------------
    y_target_path = None
    mass_target_path = None
    tips_target = None
    if args.obs_mode == 'path':
        with torch.no_grad():
            y_target_path, mass_target_path = differentiable_crack_path(
                d_target_full, node_x, node_y, x_bins, path_sigma, p=4)
        signal_bins = (mass_target_path > mass_target_path.max() * 0.05)
        if signal_bins.any():
            print(f"  Truth path y(x) range over signal bins: "
                  f"y_min={y_target_path[signal_bins].min().item():.3f}, "
                  f"y_max={y_target_path[signal_bins].max().item():.3f} mm "
                  f"(total mass = {float(mass_target_path.sum()):.3e})")
    elif args.obs_mode == 'tips':
        node_x_np = node_x.detach().cpu().numpy()
        tips_np = np.array([
            hard_tip_x_np(
                s.detach().cpu().numpy() if torch.is_tensor(s) else s,
                node_x_np)
            for _, s in snaps_truth
        ], dtype=np.float64)
        tips_np = np.where(np.isfinite(tips_np), tips_np, 0.0)
        tips_target = torch.tensor(tips_np, dtype=dtype, device=device)
        print(f"  Truth hard tip x at {args.n_tips} snapshots: "
              + ", ".join(f"{t:.2f}" for t in tips_np))

    # ---- build closure ------------------------------------------------
    loss_fn = _make_loss_fn(
        solver, loading, centroids, n_steps,
        param_mode=args.param, n_elem=n_elem,
        obs_mode=args.obs_mode,
        d_target_full=d_target_full,
        weak_fraction_held=args.weak_fraction,
        node_x=node_x, node_y=node_y,
        x_bins=x_bins, path_sigma=path_sigma,
        y_target_path=y_target_path,
        mass_target_path=mass_target_path,
        snap_steps=snap_steps, tips_target=tips_target,
    )

    # ---- init theta ---------------------------------------------------
    if args.param == 'low_rank':
        init_flat = torch.tensor(
            [x0_init, sigma_init, wf_init], dtype=dtype, device=device)
        truth_flat = torch.tensor(
            [args.x0_truth, args.sigma_truth, args.weak_fraction],
            dtype=dtype, device=device)
        param_dim = 3
        print(f"  low_rank init: x0={x0_init:.3f}, sigma={sigma_init:.3f}, "
              f"wf={wf_init:.3f}")
        print(f"  low_rank truth: x0={args.x0_truth:.3f}, "
              f"sigma={args.sigma_truth:.3f}, wf={args.weak_fraction:.3f}")
    else:  # full_field
        # Init log(Gc) at log(GC) -- uniform field; ES will perturb
        # element-wise. Truth is log(Gc_true) for reporting only.
        init_flat = torch.full((n_elem,), float(np.log(GC)),
                                 dtype=dtype, device=device)
        truth_flat = torch.log(Gc_true.detach()).clone()
        param_dim = n_elem
        print(f"  full_field: k = {n_elem} unknowns (ES expected to "
              f"struggle at this dimensionality; documented as "
              f"negative result)")

    print("\n[2/3] Init forward sanity ...")
    t0 = time.time()
    init_loss = loss_fn(init_flat)
    init_wall = time.time() - t0
    print(f"  init loss = {init_loss:.6e}  ({init_wall:.1f}s/eval)")

    print(f"\n[3/3] ES inversion ({args.n_iter} iters, "
          f"{2*args.n_samples} forwards/iter; param dim = {param_dim}) ...")
    opt = ESOptimizer(
        params=init_flat,
        lr=args.lr,
        sigma=args.sigma,
        n_samples=args.n_samples,
        antithetic=True,
        fitness_shaping=True,
        seed=args.seed,
        dtype=dtype,
        device=device,
    )

    history = []
    t_start = time.time()
    for it in range(args.n_iter):
        t_it = time.time()
        loss_here = opt.step(loss_fn)
        wall = time.time() - t_it
        if args.param == 'low_rank':
            cur = opt.theta.detach().cpu().numpy()
            err_x0 = float(abs(cur[0] - args.x0_truth))
            err_sigma = float(abs(cur[1] - args.sigma_truth))
            err_wf = float(abs(cur[2] - args.weak_fraction))
            history.append({
                'iter': it, 'loss': loss_here,
                'theta': cur.tolist(),
                'x0': float(cur[0]), 'sigma': float(cur[1]),
                'wf': float(cur[2]),
                'err_x0_mm': err_x0, 'err_sigma_mm': err_sigma,
                'err_wf': err_wf,
                'grad_norm': opt.last_grad_norm,
                'wall_s': wall,
            })
            if it < 5 or (it + 1) % max(1, args.n_iter // 20) == 0:
                print(f"  it {it:4d}  loss={loss_here:.4e}  "
                      f"x0={cur[0]:.3f} (err {err_x0:.3f})  "
                      f"sigma={cur[1]:.3f} (err {err_sigma:.3f})  "
                      f"wf={cur[2]:.3f} (err {err_wf:.3f})  "
                      f"|g|={opt.last_grad_norm:.3e}  "
                      f"wall={wall:.1f}s  cum={time.time()-t_start:.1f}s",
                      flush=True)
        else:  # full_field
            with torch.no_grad():
                Gc_cur = torch.exp(opt.theta).detach()
                err_L2 = (Gc_cur - Gc_true).norm().item() / Gc_true.norm().item()
            history.append({
                'iter': it, 'loss': loss_here,
                'err_L2_rel': err_L2,
                'grad_norm': opt.last_grad_norm,
                'wall_s': wall,
            })
            if it < 5 or (it + 1) % max(1, args.n_iter // 20) == 0:
                print(f"  it {it:4d}  loss={loss_here:.4e}  "
                      f"||Gc-Gc*||/||Gc*|| = {err_L2:.4e}  "
                      f"|g|={opt.last_grad_norm:.3e}  "
                      f"wall={wall:.1f}s  cum={time.time()-t_start:.1f}s",
                      flush=True)

    final_loss = float(loss_fn(opt.theta))
    total_wall = time.time() - t_start

    print(f"\n  ES finished: {args.n_iter} iters in {total_wall:.1f}s")
    print(f"  loss: {init_loss:.4e} -> {final_loss:.4e} "
          f"({init_loss/max(final_loss,1e-30):.2f}x reduction)")

    if args.param == 'low_rank':
        cur = opt.theta.detach().cpu().numpy()
        print(f"  recovered: x0={cur[0]:.3f} (truth {args.x0_truth:.3f}), "
              f"sigma={cur[1]:.3f} (truth {args.sigma_truth:.3f}), "
              f"wf={cur[2]:.3f} (truth {args.weak_fraction:.3f})")
        record = {
            'param_mode':       'low_rank',
            'obs_mode':         args.obs_mode,
            'n_path_bins':      args.n_path_bins if args.obs_mode == 'path' else None,
            'n_tips':           args.n_tips if args.obs_mode == 'tips' else None,
            'x0_truth':         float(args.x0_truth),
            'sigma_truth':      float(args.sigma_truth),
            'weak_fraction':    float(args.weak_fraction),
            'x0_recovered':     float(cur[0]),
            'sigma_recovered':  float(cur[1]),
            'wf_recovered':     float(cur[2]),
            'x0_err_mm':        float(abs(cur[0] - args.x0_truth)),
            'sigma_err_mm':     float(abs(cur[1] - args.sigma_truth)),
            'wf_err':           float(abs(cur[2] - args.weak_fraction)),
            'init_loss':        float(init_loss),
            'final_loss':       float(final_loss),
            'n_iter':           args.n_iter,
            'n_samples':        args.n_samples,
            'sigma':            args.sigma,
            'lr':               args.lr,
            'seed':             args.seed,
            'n_steps':          n_steps,
            'wall_total_s':     total_wall,
            'truth_wall_s':     truth_wall,
            'mesh':             {'h_crack': h_crack, 'h_coarse': h_coarse,
                                  'n_nodes': n_nodes, 'n_elems': n_elem},
            'history':          history,
        }
    else:
        with torch.no_grad():
            Gc_rec = torch.exp(opt.theta).detach()
            err_L2 = (Gc_rec - Gc_true).norm().item() / Gc_true.norm().item()
        np.save(os.path.join(out_dir, 'Gc_recovered.npy'),
                Gc_rec.cpu().numpy())
        print(f"  ||Gc - Gc*|| / ||Gc*|| = {err_L2:.4e}")
        record = {
            'param_mode':       'full_field',
            'obs_mode':         args.obs_mode,
            'n_path_bins':      args.n_path_bins if args.obs_mode == 'path' else None,
            'n_tips':           args.n_tips if args.obs_mode == 'tips' else None,
            'k_unknowns':       n_elem,
            'x0_truth':         float(args.x0_truth),
            'sigma_truth':      float(args.sigma_truth),
            'weak_fraction':    float(args.weak_fraction),
            'final_err_L2_rel': float(err_L2),
            'init_loss':        float(init_loss),
            'final_loss':       float(final_loss),
            'n_iter':           args.n_iter,
            'n_samples':        args.n_samples,
            'sigma':            args.sigma,
            'lr':               args.lr,
            'seed':             args.seed,
            'n_steps':          n_steps,
            'wall_total_s':     total_wall,
            'truth_wall_s':     truth_wall,
            'mesh':             {'h_crack': h_crack, 'h_coarse': h_coarse,
                                  'n_nodes': n_nodes, 'n_elems': n_elem},
            'history':          history,
        }

    json_path = os.path.join(out_dir, 'es_run.json')
    with open(json_path, 'w') as fh:
        json.dump(record, fh, indent=2)
    print(f"  -> {json_path}")

    # ---- loss curve plot ----------------------------------------------
    fig, ax = plt.subplots(1, 1, figsize=(4.5, 3.0), constrained_layout=True)
    iters = np.array([h['iter'] for h in history])
    losses = np.array([h['loss'] for h in history])
    obs_label = {'full': r'Damage MSE',
                  'path': r'Path mass-MSE',
                  'tips': r'Tip-x MSE'}[args.obs_mode]
    ax.semilogy(iters, losses, '-', color='C2', lw=1.4,
                 label=f'ES (rank-shaped, obs={args.obs_mode})')
    ax.set_xlabel('ES iteration')
    ax.set_ylabel(obs_label)
    ax.set_title(f'ES inverse: Gc(x) horizontal band  '
                  f'(param={args.param}, n_samples={args.n_samples}, '
                  f'sigma={args.sigma})')
    ax.grid(True, which='both', ls=':', lw=0.5, alpha=0.6)
    ax.legend(loc='best', frameon=False)
    png_path = os.path.join(out_dir, 'es_loss_curve.png')
    fig.savefig(png_path, dpi=200)
    plt.close(fig)
    sz_kb = os.path.getsize(png_path) / 1024
    print(f"  -> {png_path}  ({sz_kb:.0f} kB)")


if __name__ == '__main__':
    main()
