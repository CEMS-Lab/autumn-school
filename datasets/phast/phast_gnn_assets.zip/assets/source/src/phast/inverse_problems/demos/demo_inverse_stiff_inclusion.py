#!/usr/bin/env python
"""Geometric inversion: locate a stiff Gaussian inclusion from the
deflected crack pattern in a Bleyer-PMMA SENT plate.

Physical regime (after Ponnusami et al., Eng Frac Mech 268, 2022,
108431). Their normalised process zone l_fpz_norm = (E*Gc)/(sigma_c^2 * r)
governs how strongly a particle perturbs the crack driving force:
small l_fpz_norm -> maximum particle effect, large l_fpz_norm ->
particle becomes invisible to the crack. Phase-field is not their
XFEM cohesive-zone formulation, so the equivalence is qualitative,
not quantitative; cited here as physical motivation only. Our
Bleyer-PMMA at l_0 = 0.1 mm with sigma_inc = 1.6 mm sits in a
regime where the inclusion contrast (alpha = 4) should produce
a clearly observable crack-path perturbation.


Design (clean-crack version, replaces the small-plate boundary-affected
smoke setup):

  Geometry
    32 x 16 mm SENT plate (Bleyer scale), 4 mm edge notch at y = 8 mm
    (mid-height). The crack propagates from the notch tip along
    y ~ 8 toward the right edge.

  Inclusion
    Default: stiff Gaussian E-field bump at unknown centre (x_h, y_h):
        E(x) = E_bulk * (1 + alpha * exp(-||x - x_h||^2 / (2 sigma^2)))
    Truth (x_h*, y_h*) = (16, 9.5) mm with alpha = 4 (peak modulus
    5 * E_bulk), sigma = 1.6 mm.

    Optional: differentiable circular level-set inclusion:
        chi = sigmoid((r - ||x - x_h||) / eps)
        E(x) = E_bulk * (1 + alpha * chi)
    This is a diffuse-interface circular particle on the fixed finite-element
    mesh. It approximates a sharp circular inclusion as eps -> 0 while keeping
    (x_h, y_h) in the PyTorch autograd graph. It is not a conforming remeshed
    Gmsh particle; that true-geometry path is forward validation only.

    Inclusion sizing follows the engineering rule for crack-path
    deflection in a heterogeneous medium:
      (a) Inclusion diameter ~ 1/5 of the plate dimension (the "2:10"
          rule). For H = 16 mm the diameter is 3.2 mm and sigma = 1.6
          mm taking radius ~ 1 sigma; smaller and the crack ignores
          the inclusion, larger and the inclusion fills enough of the
          plate that the deflection observable becomes a uniform
          stiffening.
      (b) The inclusion centre must lie within 6 r of the unperturbed
          crack path; otherwise the crack does not deflect
          measurably. With r ~ sigma = 1.6 mm the allowance is
          ~9.6 mm in y. The truth offset 1.5 mm above the crack axis
          (y = 8) is well within this band, and the initial-guess
          offset 3.5 mm is also inside.
      (c) Boundary clearance: 3 sigma (= 4.8 mm) leaves room around
          the inclusion before the loaded edges. Truth y = 9.5 mm,
          top boundary y = 16 mm -> 6.5 mm clearance > 3 sigma.

  Material / model
    Bleyer PMMA (E_bulk = 3.09 GPa, nu = 0.35, rho = 1180 kg/m^3,
    Gc = 0.3 N/mm, l_0 = 0.1 mm). AT1 phase-field with Amor energy
    split, plane stress. AT1's finite nucleation barrier
    (psi_c = 3 Gc / (16 l_0)) keeps damage at zero outside the
    loaded zone -> visibly clean crack outside the propagation path.
    The Amor (volumetric-deviatoric) split is selected on three
    grounds: (i) smoothest gradient through autograd of the three
    available splits, since spectral incurs an algebraic-projection
    bias at degenerate eigenvalues (the ~1e-6 floor in Fig 17) and
    star-convex uses a piecewise non-smooth ``where(tr >= 0)``
    switch; (ii) the Bleyer 2017 PMMA reference simulations we are
    matching here use Amor, and the published crack patterns are
    reproduced by the present solver under Amor; (iii) the crack
    is dominantly tensile mode-I in this geometry, so the slight
    over-degradation Amor exhibits in pure shear (its known weakness
    relative to spectral) is not exercised. Plane stress matches
    Bleyer 2017's thin-plate experimental setup.

  Loading
    Smooth-cosine ramp on top/bottom edges:
        u_top(t) = +dU * 0.5 * (1 - cos(pi * t / tau_ramp))     for t < tau_ramp
        u_top(t) = +dU                                          for t >= tau_ramp
    tau_ramp = 30 us  (>= 3 * vertical wave-traversal time
                       16 mm / 1.7 mm/us = 9.4 us; advisor flagged
                       that shorter ramps re-inject boundary
                       asymmetry as the wave equilibrates).
    Loading is fully differentiable end-to-end (no @torch.no_grad
    pre-strain). The static-pre-strain Bleyer protocol is
    paper-2 work because StaticSolver.solve is wrapped in
    @torch.no_grad; the smooth-ramp variant exercises the same
    physics (stored elastic energy released through dynamics) but
    keeps the autograd graph intact through every time step.

  Damping
    Kelvin-Voigt zeta_max = 0.05 — belt-and-braces against residual
    high-frequency content from the ramp; small enough not to
    smear the deflection signal.

  Inversion
    L-BFGS-strong-Wolfe on (x_h, y_h) starting from (13.0, 11.5) mm
    (~3.6 mm initial offset). Expected ~5-10 outer iterations.

Usage
-----
    # Mac CPU smoke test (coarser mesh + fewer steps, ~5-15 min)
    python demo_inverse_stiff_inclusion.py --device cpu --smoke

    # Full HPC figure run (~3-7 h on A100)
    python demo_inverse_stiff_inclusion.py --device cuda
"""
from __future__ import annotations

import argparse
import gc
import itertools
import json
import math
import os
import sys
import time

import numpy as np
import torch


# ---- Pair A OOM mitigation (issue tracked in P3-C4 sweep) ------------
# Job 29517 OOM'd at the first L-BFGS closure call after a no-grad init
# forward at N=20000 left ~160k damaged elements + tape-free state on the
# GPU. The closure then tried to allocate the first 50-step TBPTT chunk's
# autograd graph on top of that residue and ran the A100 80GB out.
# Empty-cache cycles do not change forward semantics; they only return
# CUDA-cached but unreferenced blocks to the allocator pool so the next
# allocation does not have to grow the working set.
def _free_cuda(label: str = "", verbose: bool = False) -> None:
    """gc + empty_cache cycle. No-op when CUDA is unavailable.

    When ``verbose`` is True (controlled by ``--memlog`` on the demo CLI),
    prints ``torch.cuda.memory_allocated`` and ``max_memory_allocated``
    around the cycle so the OOM origin can be localised in production
    logs. Cheap (sub-millisecond) outside the print path.
    """
    gc.collect()
    if torch.cuda.is_available():
        if verbose:
            before = torch.cuda.memory_allocated() / 1024 ** 3
        torch.cuda.empty_cache()
        if verbose:
            after = torch.cuda.memory_allocated() / 1024 ** 3
            peak = torch.cuda.max_memory_allocated() / 1024 ** 3
            print(f"  [memlog {label}] alloc={before:.2f}GiB -> "
                  f"{after:.2f}GiB  peak={peak:.2f}GiB", flush=True)

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.mesh_generator import rectangular_sent as gen_mesh
from phast.mesh import FEMMesh
from phast.material import create_material
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.config import LoadingConfig, compute_load_factor
from phast.device import DeviceContext


# Bleyer PMMA + stiff inclusion truth parameters
NU = 0.35
RHO = 1.18e-9          # tonne/mm^3
GC = 0.3               # N/mm
L0 = 0.1               # mm
E_BULK = 3090.0        # MPa = 3.09 GPa

ALPHA_TRUTH = 4.0
SIGMA_INC = 1.6         # mm  (radius ~ 1 sigma; 2 sigma = 3.2 mm; 3 sigma = 4.8 mm)
# Sigma = 1.6 mm follows the 2:10 sizing rule (inclusion diameter is
# 1/5 of the plate height H = 16 mm, so radius = 1.6 mm). At the offset
# initial guess (13, 11.5) the inclusion bump raises the modulus along
# the crack centerline y = 8 by ~37%, well within the 6 r influence
# band, so the L-BFGS line search has a meaningful signal from probe 1.
LEVEL_SET_RADIUS = SIGMA_INC
LEVEL_SET_EPSILON = 0.20 * SIGMA_INC

# CLI-selected inclusion parametrisation. Kept module-global so all legacy
# call sites of gaussian_E_field_multi inherit the same field definition.
INCLUSION_PROFILE = 'gaussian'
INCLUSION_LEVEL_SET_RADIUS = LEVEL_SET_RADIUS
INCLUSION_LEVEL_SET_EPSILON = LEVEL_SET_EPSILON


def gaussian_E_field(centroids, x_h, y_h, E_bulk, alpha, sigma):
    """Per-element E with a single stiff Gaussian bump."""
    dx = centroids[:, 0] - x_h
    dy = centroids[:, 1] - y_h
    bump = torch.exp(-(dx ** 2 + dy ** 2) / (2.0 * sigma ** 2))
    return E_bulk * (1.0 + alpha * bump)


def level_set_circular_indicator(centroids, particles, radius, epsilon):
    """Smooth fixed-mesh circular-particle indicator.

    The zero level set of ``radius - distance`` is the circular interface.
    ``epsilon`` is the diffuse-interface width in mm. A smaller value is
    closer to a sharp material jump but gives steeper gradients and needs a
    finer mesh across the interface.
    """
    if particles.dim() == 1:
        particles = particles.view(-1, 2)
    if epsilon <= 0.0:
        raise ValueError("level-set epsilon must be positive")
    chi_union = torch.zeros(
        centroids.shape[0], dtype=centroids.dtype, device=centroids.device)
    for i in range(particles.shape[0]):
        dx = centroids[:, 0] - particles[i, 0]
        dy = centroids[:, 1] - particles[i, 1]
        dist = torch.sqrt(dx * dx + dy * dy + 1e-24)
        chi_i = torch.sigmoid((radius - dist) / epsilon)
        # Smooth union; caps the material contrast at one particle instead of
        # adding artificial extra stiffness if diffuse shells overlap.
        chi_union = 1.0 - (1.0 - chi_union) * (1.0 - chi_i)
    return chi_union


def gaussian_E_field_multi(centroids, particles, E_bulk, alpha, sigma):
    """Per-element E with N superposed stiff Gaussian bumps.

    ``particles`` is a flat tensor of length 2N or shape (N, 2) carrying
    the (x_h, y_h) centres in mm. Bumps superpose linearly on the
    *(1 + alpha * bump)* multiplier, so a region inside two bumps is
    stiffer than a single-bump region by design.
    """
    if particles.dim() == 1:
        particles = particles.view(-1, 2)
    if INCLUSION_PROFILE == 'level_set':
        chi = level_set_circular_indicator(
            centroids, particles,
            radius=INCLUSION_LEVEL_SET_RADIUS,
            epsilon=INCLUSION_LEVEL_SET_EPSILON,
        )
        return E_bulk * (1.0 + alpha * chi)
    if INCLUSION_PROFILE != 'gaussian':
        raise ValueError(f"unknown inclusion profile: {INCLUSION_PROFILE!r}")
    n = particles.shape[0]
    bumps = torch.zeros(centroids.shape[0],
                         dtype=centroids.dtype, device=centroids.device)
    inv_2s2 = 1.0 / (2.0 * sigma * sigma)
    for i in range(n):
        dx = centroids[:, 0] - particles[i, 0]
        dy = centroids[:, 1] - particles[i, 1]
        bumps = bumps + torch.exp(-(dx * dx + dy * dy) * inv_2s2)
    return E_bulk * (1.0 + alpha * bumps)


def soft_tip_x(d_node, node_x, p=8):
    """Damage-weighted x-position of the crack tip (differentiable).

    For p large the d^p weighting concentrates on the most-damaged
    nodes and the result tracks the rightmost crack tip; for p = 1 it
    is the centre-of-mass of the damaged region. NOTE this extractor
    averages over the entire damaged region, so for a long broad
    damage track behind a thin advancing front it under-reports the
    tip position. Use ``hard_tip_x`` for honest reporting.
    """
    w = torch.clamp(d_node, min=0.0) ** p
    return (w * node_x).sum() / (w.sum() + 1e-12)


def hard_tip_x(d_node_np, node_x_np, threshold=0.5):
    """Rightmost x where damage exceeds threshold (non-differentiable).

    For diagnostic / reporting use only -- NOT for backprop. Returns
    -inf if no node exceeds threshold.
    """
    mask = d_node_np > threshold
    return float(node_x_np[mask].max()) if mask.any() else float('-inf')


def reaction_force_y(solver, u, d, top_idx):
    """Sum of internal-force y-component at the loaded top boundary.

    For Bleyer SENT prescribed-displacement loading, this is what a
    laboratory load cell measures (engineering force). Differentiable
    via the standard FEM internal-force assembly.

    Returns a scalar tensor on the autograd tape.
    """
    f_int = solver.fem.internal_force(u, d)
    return f_int[top_idx, 1].sum()


def differentiable_crack_path(d_node, node_x, node_y, x_bins,
                                 sigma_bin, p=4):
    """Soft-binned damage-weighted centerline y(x), differentiable.

    For each bin centre x_b, computes
        y_b = sum_n w_n * y_n / sum_n w_n
    with weight  w_n(x_b) = d_n^p * exp(-(x_n - x_b)^2 / (2 sigma_bin^2)).

    Args:
      d_node:     (n_nodes,) damage field; on autograd tape if predicted.
      node_x,
      node_y:     (n_nodes,) node coordinates; constant.
      x_bins:     (n_bins,) bin centres along the crack-propagation
                  direction (constant; cover the expected crack span).
      sigma_bin:  scalar bin width; set to ~ (x_bins[1] - x_bins[0]) / 2.
      p:          damage-power weighting; p = 4 emphasises the active
                  crack lobes without being so peaky that bins go silent.

    Returns:
      y_pred:     (n_bins,) the centerline at each bin
      mass:       (n_bins,) total weight per bin (use to mask bins where
                  no damage signal exists)
    """
    # (n_bins, n_nodes) broadcast
    diff = node_x.unsqueeze(0) - x_bins.unsqueeze(1)
    spatial_w = torch.exp(-(diff ** 2) / (2.0 * sigma_bin ** 2))
    damage_w = torch.clamp(d_node, min=0.0).pow(p)
    w = spatial_w * damage_w.unsqueeze(0)
    mass = w.sum(dim=1)
    y_w = (w * node_y.unsqueeze(0)).sum(dim=1)
    y_pred = y_w / (mass + 1e-12)
    return y_pred, mass


def add_path_observation_noise(y_path, mass_path, sigma_mm, seed,
                               *, label='target'):
    """Add reproducible Gaussian noise to active crack-path bins."""
    sigma_mm = float(sigma_mm)
    if sigma_mm <= 0.0:
        return y_path, {
            'label': label,
            'requested_sigma_mm': 0.0,
            'realized_active_sigma_mm': 0.0,
            'seed': int(seed),
            'active_bins': 0,
        }

    active = mass_path > mass_path.max() * 0.05
    noise_np = np.zeros(tuple(y_path.shape), dtype=np.float64)
    active_np = active.detach().cpu().numpy().astype(bool)
    rng = np.random.default_rng(int(seed))
    noise_np[active_np] = rng.normal(
        loc=0.0, scale=sigma_mm, size=int(active_np.sum()))
    noise = torch.as_tensor(noise_np, dtype=y_path.dtype, device=y_path.device)
    y_noisy = y_path + noise
    active_noise = noise[active]
    realized = float(active_noise.std(unbiased=False).detach().cpu()) \
        if active_noise.numel() else 0.0
    return y_noisy, {
        'label': label,
        'requested_sigma_mm': sigma_mm,
        'realized_active_sigma_mm': realized,
        'seed': int(seed),
        'active_bins': int(active_np.sum()),
    }


def crack_path_loss(d_pred, d_target, node_x, node_y,
                      x_bins, sigma_bin, p=4):
    """Mass-weighted MSE between predicted and target crack centerlines.

    The truth path's per-bin mass acts as the weight, so bins where
    the truth crack actually exists dominate the loss; bins beyond
    the truth tip carry zero weight and don't penalise the predicted
    crack overshooting (good for early L-BFGS iterates whose tip
    location may differ).
    """
    y_pred, _         = differentiable_crack_path(d_pred,   node_x, node_y,
                                                    x_bins, sigma_bin, p=p)
    with torch.no_grad():
        y_target, mass_target = differentiable_crack_path(
            d_target, node_x, node_y, x_bins, sigma_bin, p=p)
    sq = (y_pred - y_target) ** 2
    return (mass_target * sq).sum() / (mass_target.sum() + 1e-12)


def front_localised_path_features(d_node, d_prev, node_x, node_y, x_bins,
                                  sigma_bin, crack_y, p=2):
    """Soft active-front features for multi-particle inverse recovery.

    Plain full-field damage losses are dominated by the saturated crack
    wake. This extractor uses only newly accumulated damage,
    ``clamp(d_n - d_{n-1}, 0)``, so each chunk compares the active
    process zone where the crack is currently interacting with an
    inclusion.
    """
    diff = node_x.unsqueeze(0) - x_bins.unsqueeze(1)
    spatial_w = torch.exp(-(diff ** 2) / (2.0 * sigma_bin ** 2))
    new_damage = torch.clamp(d_node - d_prev, min=0.0)
    damage_w = new_damage * torch.clamp(d_node, min=0.0).pow(p)
    w = spatial_w * damage_w.unsqueeze(0)
    mass = w.sum(dim=1)
    y_mean = (w * node_y.unsqueeze(0)).sum(dim=1) / (mass + 1e-12)
    y_signed = y_mean - crack_y
    return y_mean, y_signed, mass


def front_localised_path_loss(d_pred, d_prev_pred, d_target, d_prev_target,
                              node_x, node_y, x_bins, sigma_bin, crack_y,
                              p=2):
    """Compare active-front position and mass against a truth chunk."""
    y_pred, ys_pred, mass_pred = front_localised_path_features(
        d_pred, d_prev_pred, node_x, node_y, x_bins, sigma_bin, crack_y, p=p)
    with torch.no_grad():
        y_t, ys_t, mass_t = front_localised_path_features(
            d_target, d_prev_target, node_x, node_y, x_bins, sigma_bin,
            crack_y, p=p)
        mass_scale = mass_t.max().clamp_min(1e-12)
        active = mass_t > 0.02 * mass_scale
    if bool(active.any().item()):
        y_loss = (mass_t[active] * (y_pred[active] - y_t[active]) ** 2).sum()
        y_loss = y_loss / (mass_t[active].sum() + 1e-12)
        signed_loss = (
            mass_t[active] * (ys_pred[active] - ys_t[active]) ** 2
        ).sum() / (mass_t[active].sum() + 1e-12)
    else:
        y_loss = torch.zeros((), dtype=d_pred.dtype, device=d_pred.device)
        signed_loss = torch.zeros((), dtype=d_pred.dtype, device=d_pred.device)
    mass_loss = (((mass_pred - mass_t) / mass_scale) ** 2).mean()
    return y_loss + 0.25 * signed_loss + 0.05 * mass_loss


def front_dic_loss(u_pred, u_target, d_target, d_prev_target,
                   node_x, node_y, x_bins, sigma_bin, crack_y):
    """DIC-style displacement loss in the target active-front ROI.

    The ROI is defined from the target new-damage increment, then held
    fixed for the predicted field. This keeps the objective focused on
    what a camera would observe near the process zone without letting
    the predicted damage wake dominate the loss.
    """
    diff = node_x.unsqueeze(0) - x_bins.unsqueeze(1)
    spatial_w = torch.exp(-(diff ** 2) / (2.0 * sigma_bin ** 2))
    with torch.no_grad():
        new_damage = torch.clamp(d_target - d_prev_target, min=0.0)
        front_w = spatial_w * new_damage.unsqueeze(0)
        mass = front_w.sum(dim=1)
        if float(mass.max()) <= 1e-12:
            return u_pred.sum() * 0.0
        active = mass > 0.02 * mass.max()
        w = front_w[active]
        mass_active = mass[active]
        y_signed = (
            (w * (node_y - crack_y).unsqueeze(0)).sum(dim=1)
            / (mass_active + 1e-12)
        )
        upper = (y_signed >= 0.0).to(u_pred.dtype).unsqueeze(1)
        lower = 1.0 - upper

    node_w = front_w.sum(dim=0)
    node_w = node_w / (node_w.sum() + 1e-12)
    du = u_pred - u_target
    scale = (
        (node_w.unsqueeze(1) * u_target.detach().square()).sum().sqrt()
        .clamp_min(1e-9)
    )
    nodewise = (node_w.unsqueeze(1) * (du / scale).square()).sum()

    # Keep coarse above/below binned moments as a small auxiliary term so
    # the lower particle cannot be traded against the two upper particles.
    def _binned_u(u):
        ux = (w * u[:, 0].unsqueeze(0)).sum(dim=1) / (mass_active + 1e-12)
        uy = (w * u[:, 1].unsqueeze(0)).sum(dim=1) / (mass_active + 1e-12)
        return torch.stack([ux, uy], dim=1)

    feat_pred = _binned_u(u_pred)
    feat_target = _binned_u(u_target)
    moment = ((feat_pred - feat_target) / scale).square().mean()
    upper_loss = ((((feat_pred - feat_target) * upper) / scale).square().sum()
                  / (upper.sum() * 2.0 + 1e-12))
    lower_loss = ((((feat_pred - feat_target) * lower) / scale).square().sum()
                  / (lower.sum() * 2.0 + 1e-12))
    return nodewise + 0.05 * moment + 0.05 * upper_loss + 0.05 * lower_loss


def dic_band_loss(u_pred, u_target, node_x, node_y, crack_y,
                  notch_x=4.0, sigma_y=4.0):
    """Near-crack DIC displacement loss for particle recovery.

    The active-front DIC term is zero before damage grows and weak after
    the front passes. This auxiliary term uses the experimentally
    available displacement field in the crack/inclusion band, so stiff
    particles can be identified from pre-crack and early-crack frames.
    """
    y_w = torch.exp(-((node_y - crack_y) ** 2) / (2.0 * sigma_y ** 2))
    x_gate = torch.sigmoid((node_x - notch_x) / 1.0)
    node_w = y_w * x_gate
    node_w = node_w / (node_w.sum() + 1e-12)
    du = u_pred - u_target
    scale = (
        (node_w.unsqueeze(1) * u_target.detach().square()).sum().sqrt()
        .clamp_min(1e-9)
    )
    return (node_w.unsqueeze(1) * (du / scale).square()).sum()


def sensor_strain_dic_loss(u_pred, u_target, node_x, node_y,
                           sensor_xs, sensor_ys,
                           sigma_x=1.2, sigma_y=1.2):
    """Patch-DIC loss using local displacement and affine-strain features."""
    pred = sensor_strain_dic_features(
        u_pred, node_x, node_y, sensor_xs, sensor_ys, sigma_x, sigma_y)
    target = sensor_strain_dic_features(
        u_target, node_x, node_y, sensor_xs, sensor_ys, sigma_x, sigma_y)
    scale = target.detach().abs().amax(dim=0).clamp_min(1e-9)
    return (((pred - target) / scale) ** 2).mean()


def sensor_strain_dic_features(u, node_x, node_y, sensor_xs, sensor_ys,
                               sigma_x=1.2, sigma_y=1.2):
    """Local displacement and affine-strain patch features.

    Shape is ``(n_sensor_x * n_sensor_y, 6)`` with columns
    ``ux, uy, dux/dx, dux/dy, duy/dx, duy/dy``. Keeping this as a
    separate observable makes it possible to form finite-difference
    Jacobians for identifiability gates before launching an inverse run.
    """
    features_pred = []
    for sx in sensor_xs:
        for sy in sensor_ys:
            wx = torch.exp(-((node_x - sx) ** 2) / (2.0 * sigma_x ** 2))
            wy = torch.exp(-((node_y - sy) ** 2) / (2.0 * sigma_y ** 2))
            w = wx * wy
            w = w / (w.sum() + 1e-12)
            x0 = (w * node_x).sum()
            y0 = (w * node_y).sum()
            dx = node_x - x0
            dy = node_y - y0
            var_x = (w * dx.square()).sum().clamp_min(1e-12)
            var_y = (w * dy.square()).sum().clamp_min(1e-12)

            def _features(u):
                ux = u[:, 0]
                uy = u[:, 1]
                ux0 = (w * ux).sum()
                uy0 = (w * uy).sum()
                return torch.stack([
                    ux0,
                    uy0,
                    (w * (ux - ux0) * dx).sum() / var_x,
                    (w * (ux - ux0) * dy).sum() / var_y,
                    (w * (uy - uy0) * dx).sum() / var_x,
                    (w * (uy - uy0) * dy).sum() / var_y,
                ])

            features_pred.append(_features(u))
    return torch.stack(features_pred)


def _parse_float_csv(s):
    return [float(v) for v in s.split(',') if v.strip()]


def build_solver(W, H, a, h_crack, h_coarse, dU, tau_ramp,
                  damping_zeta, device, dtype, enable_damage=True,
                  softmax_H_beta=None, H_cap=None,
                  H_update_method='hard_max',
                  H_update_scale=None,
                  energy_split='amor', pf_model='AT1',
                  plane_stress=True):
    # Per-process scratch path so concurrent Pair A / Pair B jobs that
    # share /tmp on the same node do not race on the same .msh file.
    _tag = os.environ.get('SLURM_JOB_ID', f'pid{os.getpid()}')
    msh = f"/tmp/stiff_inclusion_sent_{_tag}.msh"
    # branching=True forces UNIFORM h_crack throughout the entire right
    # half of the plate (x > a - 5 mm), which is the only region the
    # crack and the inclusion actually live in. The default refinement
    # band (5*l0 = 0.5 mm half-width around y = H/2) is far too narrow
    # for an inclusion at y = 9.5 with sigma = 1.6 mm: 3 sigma reach is
    # 4.8 mm, so the inclusion sits in coarse mesh and any deflection
    # of the crack toward it would be biased by element size jumps.
    # Using "branching" mode here despite the name (no actual branching
    # is expected) -- it is the right primitive for "uniform fine mesh
    # over the entire crack-propagation + inclusion band."
    gen_mesh(msh, W=W, H=H, a=a, l0=L0,
             h_crack=h_crack, h_coarse=h_coarse, branching=True)
    mesh = FEMMesh(msh, device=device, dtype=dtype)
    mesh.identify_boundaries()
    mat = create_material(
        E=E_BULK, nu=NU, rho=RHO, Gc=GC, l0=L0,
        energy_split=energy_split, pf_model=pf_model,
        plane_stress=plane_stress,
        gamma_correction=True,
    )
    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)
    bcs.add(mesh.node_sets['top'],    component=1, value=+dU)
    bcs.add(mesh.node_sets['bottom'], component=1, value=-dU)
    bcs.fix(mesh.node_sets['left'], component=0)
    cfg = SolverConfig(
        solver_type='explicit', differentiable=True,
        damage_every=1, preconditioner='jacobi',
        damping_ratio_max=damping_zeta,
        enable_damage=enable_damage,
        softmax_H_beta=softmax_H_beta,
        H_cap=H_cap,
        H_update_method=H_update_method,
        H_update_scale=H_update_scale,
    )
    solver = StaggeredSolver(mesh, mat, bcs, config=cfg,
                              ctx=DeviceContext(device, dtype))
    centroids = mesh.nodes[mesh.elements].mean(dim=1)
    loading = LoadingConfig(ramp_type='smooth', t_ramp=tau_ramp)
    return solver, centroids, loading


def run_forward_tbptt(solver, loading, E_field, n_steps,
                       tbptt_chunk_size,
                       snapshot_steps=None,
                       load_steps=None, top_idx=None,
                       eager_loss_fn=None,
                       eager_backward_scale=1.0,
                       record_u_chunks=False):
    """Truncated-BPTT forward (issue #288).

    Thin wrapper around the shared
    :func:`phast.inverse_problems._tbptt.run_forward_tbptt_generic`
    helper (promoted in #301). Behaviour is identical to PR #291's
    original; the install of the controllable parameter
    (``solver.install_diff_E_field(E_field)``) is now expressed via
    an ``install_fn`` callback so the same helper can be reused by
    every other inverse demo (Gc field, scalar Gc, Gaussian-bump Gc,
    etc.).
    """
    from phast.inverse_problems._tbptt import (
        run_forward_tbptt_generic,
        make_install_E_field,
    )
    return run_forward_tbptt_generic(
        solver, loading,
        install_fn=make_install_E_field(E_field),
        n_steps=n_steps,
        tbptt_chunk_size=tbptt_chunk_size,
        snapshot_steps=snapshot_steps,
        load_steps=load_steps,
        top_idx=top_idx,
        eager_loss_fn=eager_loss_fn,
        eager_backward_scale=eager_backward_scale,
        record_u_chunks=record_u_chunks,
    )


def run_forward(solver, loading, E_field, n_steps, snapshot_steps=None,
                checkpoint_chunks=0,
                load_steps=None, top_idx=None,
                use_custom_adjoint=False,
                record_u_snapshots=False):
    """Reset state, install E_field, run n_steps explicit with smooth
    ramp loading.

    Returns ``(d_final, snapshots, loads)``:
      - ``snapshots``: list of damage tensors (one per timestep listed
        in ``snapshot_steps``), or ``None`` if not requested.
      - ``loads``: list of scalar reaction-force tensors (one per
        timestep listed in ``load_steps``), or ``None`` if not
        requested. Requires ``top_idx`` to be the node indices of the
        loaded boundary.
    All extra outputs stay on the autograd tape so downstream sparse
    losses (softmax tip, load--displacement) can backprop into
    ``E_field``.

    When ``checkpoint_chunks > 0`` and a backward pass is required, the
    time loop is split into ``checkpoint_chunks`` segments and wrapped
    in ``torch.utils.checkpoint`` so only chunk endpoints (plus snaps
    inside each chunk) retain activations. The forward graph shrinks
    by ~K, at the cost of one extra forward per chunk in backward.
    Numerics are unchanged: gradients are bit-identical to full-graph
    autograd up to recompute determinism.
    """
    n_nodes = solver.mesh.n_nodes
    n_elem = solver.mesh.n_elems
    dt = solver.dtype
    dev = solver.device
    solver.u = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.v = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.a = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.d = torch.zeros(n_nodes, dtype=dt, device=dev)
    solver.H_elem = torch.zeros(n_elem, dtype=dt, device=dev)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dt, device=dev)
    solver._step_count = 0
    solver.install_diff_E_field(E_field)
    solver._last_u_snapshots = [] if record_u_snapshots else None
    solver_dt = solver.dt
    snap_set = set(snapshot_steps) if snapshot_steps else set()
    load_set = set(load_steps) if load_steps else set()

    use_checkpoint = (
        checkpoint_chunks > 0 and torch.is_grad_enabled()
        and E_field.requires_grad
    )
    use_adjoint = (
        use_custom_adjoint and torch.is_grad_enabled()
        and E_field.requires_grad
    )
    if use_adjoint and not use_checkpoint:
        # Single-chunk custom adjoint covers the no-checkpoint path too;
        # this is the v1 wiring used by Gate A1 gradcheck (issue #228).
        use_checkpoint = True
        if checkpoint_chunks <= 0:
            checkpoint_chunks = 1
    # Progress print interval: every ~5% of the run, capped at every 1000
    # steps. Cheap (one print per 1k steps) and gives visible heartbeat
    # during the 5-15 minute production-resolution forward.
    _progress_every = max(1, min(n_steps // 20, 1000))
    _t_loop_start = time.time()
    if not use_checkpoint:
        snaps = [] if snapshot_steps else None
        loads = [] if load_steps else None
        for step in range(n_steps):
            solver.bcs.load_factor = compute_load_factor(step, solver_dt, loading)
            solver.step_full()
            if step + 1 in snap_set:
                snaps.append(solver.d)
                if record_u_snapshots:
                    solver._last_u_snapshots.append(solver.u)
            if step + 1 in load_set:
                loads.append(reaction_force_y(
                    solver, solver.u, solver.d, top_idx))
            if (step + 1) % _progress_every == 0:
                _max_d = float(solver.d.max().detach())
                print(f"    forward step {step+1}/{n_steps} "
                      f"max(d)={_max_d:.3f} "
                      f"({time.time() - _t_loop_start:.1f}s elapsed)",
                      flush=True)
        return solver.d, snaps, loads

    # --- Checkpointed path ---------------------------------------------
    # Each chunk is a pure tensor-in/tensor-out function for autograd.
    # Non-tensor args (offsets, base_step, k_steps) are fine for the
    # use_reentrant=False API.
    def _chunk_core(u_in, v_in, a_in, d_in, He_in, Hn_in, E_field_arg,
                    base_step, k_steps, snap_offsets, load_offsets):
        # Re-install E_field (matters when the custom-adjoint backward
        # rebinds a fresh leaf E_field for cotangent collection; harmless
        # on the standard checkpoint path where E_field is already
        # installed).
        solver.install_diff_E_field(E_field_arg)
        solver.u = u_in
        solver.v = v_in
        solver.a = a_in
        solver.d = d_in
        solver.H_elem = He_in
        solver.H_nodal = Hn_in
        solver._step_count = base_step
        snap_set_local = set(snap_offsets)
        load_set_local = set(load_offsets)
        out_snaps = []
        out_loads = []
        for j in range(k_steps):
            step = base_step + j
            solver.bcs.load_factor = compute_load_factor(
                step, solver_dt, loading)
            solver.step_full()
            if (j + 1) in snap_set_local:
                out_snaps.append(solver.d)
            if (j + 1) in load_set_local:
                out_loads.append(reaction_force_y(
                    solver, solver.u, solver.d, top_idx))
        return (solver.u, solver.v, solver.a, solver.d,
                solver.H_elem, solver.H_nodal,
                len(out_snaps), *out_snaps, *out_loads)

    def _chunk(u_in, v_in, a_in, d_in, He_in, Hn_in,
               base_step, k_steps, snap_offsets, load_offsets):
        # Backwards-compat wrapper for torch.utils.checkpoint path
        # (no E_field plumbed; reuses solver.fem.diff_E_field).
        return _chunk_core(u_in, v_in, a_in, d_in, He_in, Hn_in,
                           solver.fem.diff_E_field,
                           base_step, k_steps, snap_offsets, load_offsets)

    chunk_size = (n_steps + checkpoint_chunks - 1) // checkpoint_chunks
    u, v, a, d = solver.u, solver.v, solver.a, solver.d
    He, Hn = solver.H_elem, solver.H_nodal
    snaps = [] if snapshot_steps else None
    loads = [] if load_steps else None
    # Print one heartbeat every ~5% of chunks (saturated to >=1 chunks)
    n_total_chunks = (n_steps + chunk_size - 1) // chunk_size
    chunk_progress_every = max(1, n_total_chunks // 20)
    _chunk_idx = 0
    base = 0
    while base < n_steps:
        k = min(chunk_size, n_steps - base)
        chunk_snap_offsets = tuple(s - base for s in snap_set
                                   if base < s <= base + k)
        chunk_load_offsets = tuple(s - base for s in load_set
                                   if base < s <= base + k)
        if use_adjoint:
            # Bake non-tensor args into a closure so the autograd Function
            # sees a uniform tensor-in/tensor-out signature.
            _base, _k = base, k
            _so, _lo = chunk_snap_offsets, chunk_load_offsets
            def _chunk_adj(u_, v_, a_, d_, He_, Hn_, E_):
                return _chunk_core(u_, v_, a_, d_, He_, Hn_, E_,
                                    _base, _k, _so, _lo)
            from phast.mechanics_solver import ChunkedExplicitDynamicsAutograd
            outs = ChunkedExplicitDynamicsAutograd.apply(
                _chunk_adj, None, E_field,
                u, v, a, d, He, Hn,
            )
        else:
            outs = torch.utils.checkpoint.checkpoint(
                _chunk, u, v, a, d, He, Hn,
                base, k, chunk_snap_offsets, chunk_load_offsets,
                use_reentrant=False,
            )
        u, v, a, d, He, Hn = outs[:6]
        n_chunk_snaps = int(outs[6])
        chunk_snaps = outs[7 : 7 + n_chunk_snaps]
        chunk_loads = outs[7 + n_chunk_snaps :]
        if snaps is not None:
            snaps.extend(chunk_snaps)
        if loads is not None:
            loads.extend(chunk_loads)
        base += k
        _chunk_idx += 1
        if (_chunk_idx % chunk_progress_every == 0
                or _chunk_idx == n_total_chunks):
            mem_str = ""
            if torch.cuda.is_available():
                mb = torch.cuda.max_memory_allocated() / (1024 ** 2)
                mem_str = f", cuda_peak={mb:.0f} MB"
                torch.cuda.reset_peak_memory_stats()
            print(f"    forward chunk {_chunk_idx}/{n_total_chunks} "
                  f"(step {base}/{n_steps}, max(d)={float(d.detach().max()):.3f}, "
                  f"{time.time() - _t_loop_start:.1f}s elapsed{mem_str})",
                  flush=True)

    solver.u = u
    solver.v = v
    solver.a = a
    solver.d = d
    solver.H_elem = He
    solver.H_nodal = Hn
    return solver.d, snaps, loads


def _parse_particles(s, default):
    """Parse a CSV "x1,y1,x2,y2,..." into a list of (x, y) pairs."""
    if s is None:
        return default
    vals = [float(v) for v in s.split(',') if v.strip()]
    if len(vals) % 2 != 0:
        raise ValueError(f"--*-particles needs an even count, got {len(vals)}")
    return [(vals[2 * i], vals[2 * i + 1]) for i in range(len(vals) // 2)]


def _check_six_sigma(particles, sigma, crack_y, label):
    """Honour the 6 sigma observability rule on the unperturbed crack path."""
    band = 6.0 * sigma
    for (x_h, y_h) in particles:
        if abs(y_h - crack_y) > band:
            raise ValueError(
                f"{label} particle at ({x_h:.3f}, {y_h:.3f}) is "
                f"{abs(y_h - crack_y):.3f} mm off the crack axis (y={crack_y}), "
                f"outside the 6 sigma = {band:.2f} mm influence band; "
                f"the crack will not deflect measurably.")


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device', type=str, default='cpu')
    p.add_argument('--dtype', type=str, default='float64',
                   choices=['float32', 'float64'],
                   help='Halve activation memory on CUDA with float32. '
                        'CPU/MPS still need float64 (project_mps_float32_bug). '
                        'For inversion gradient quality, prefer float64 + '
                        '--checkpoint_chunks.')
    p.add_argument('--tbptt_chunk_size', type=int, default=0,
                   help='Truncated BPTT chunk length (issue #288). 0 '
                        '(default) = full BPTT (current behaviour). '
                        'When > 0 the time loop is split into chunks of '
                        'this many steps; the autograd tape is detached '
                        'at each chunk boundary, and the loss is summed '
                        'over chunk-end damage snapshots. This bounds '
                        'the gradient propagation horizon and mitigates '
                        'the chaotic-amplification pathology documented '
                        'in #287 / Suh et al. 2022 ICML §5.4. NOTE: '
                        'TBPTT gradients are biased relative to full '
                        'BPTT; this is a workaround, not a fix '
                        '(see #284 for the principled continuous-'
                        'adjoint approach). Compatible with '
                        '--obs_mode in {full, path, front, front_dic, tips} '
                        '(per-chunk observation; #301-followup). '
                        'Incompatible with --obs_mode=load_disp and '
                        '--checkpoint_chunks > 0.')
    p.add_argument('--tbptt_optimizer', type=str, default='adam',
                   choices=['adam', 'sgd', 'sgd_backtrack', 'lbfgs'],
                   help='Outer optimiser. Default adam for TBPTT: TBPTT '
                        'gradients are biased so L-BFGS Wolfe conditions '
                        'can be brittle. For full-BPTT front_dic with very '
                        'large gradients, sgd plus --grad_clip_norm '
                        'preserves relative gradient magnitudes better than '
                        'Adam sign-normalisation. sgd_backtrack evaluates '
                        'a small accept/reject line search after each '
                        'gradient and is intended for D2 front_dic.')
    p.add_argument('--tbptt_lr', type=float, default=0.1,
                   help='Learning rate for adam/sgd outer optimisers. '
                        'Particle positions are in mm; default 0.1 '
                        'mm/iter is comparable to a single L-BFGS step.')
    p.add_argument('--line_search_trials', type=int, default=4,
                   help='Number of halving trials for '
                        '--tbptt_optimizer sgd_backtrack.')
    p.add_argument('--front_dic_elastic_weight', type=float, default=0.0,
                   help='Auxiliary near-crack displacement-band DIC loss '
                        'weight for --obs_mode front_dic. Adds pre-crack '
                        'and early-crack displacement information so D2 '
                        'does not rely only on the active damage front.')
    p.add_argument('--sensor_xs', type=str, default='13,19,25',
                   help='CSV x-locations for --obs_mode sensor_strain_dic.')
    p.add_argument('--sensor_ys', type=str, default='6.5,9.5',
                   help='CSV y-locations for --obs_mode sensor_strain_dic.')
    p.add_argument('--sensor_sigma_x', type=float, default=1.2,
                   help='Gaussian patch width in x for sensor-strain DIC.')
    p.add_argument('--sensor_sigma_y', type=float, default=1.2,
                   help='Gaussian patch width in y for sensor-strain DIC.')
    p.add_argument('--sensor_extent_weight', type=float, default=0.1,
                   help='Auxiliary active-front loss weight for '
                        '--obs_mode sensor_strain_dic.')
    p.add_argument('--checkpoint_chunks', type=int, default=0,
                   help='Split time loop into N gradient-checkpoint segments. '
                        '0 disables. Memory drops ~N, backward ~2x slower. '
                        'Gradients identical to full-graph autograd.')
    p.add_argument('--smoke', action='store_true',
                   help='Smoke-test parameters (coarser mesh, fewer steps)')
    p.add_argument('--mid', action='store_true',
                   help='Mid-resolution params (h_crack=0.1, n_steps=4500); '
                        'physics-validation tier between smoke and full HPC.')
    p.add_argument('--n_steps', type=int, default=None)
    p.add_argument('--n_iters', type=int, default=10)
    p.add_argument('--delta_U', type=float, default=None)
    p.add_argument('--init_xh', type=float, default=None,
                   help='Single-particle init x (legacy; prefer --init_particles)')
    p.add_argument('--init_yh', type=float, default=None,
                   help='Single-particle init y (legacy; prefer --init_particles)')
    p.add_argument('--n_particles', type=int, default=1, choices=[1, 3],
                   help='1 (legacy single-bump) or 3 (two above + one below crack).')
    p.add_argument('--inclusion_profile', type=str, default='gaussian',
                   choices=['gaussian', 'level_set'],
                   help='Particle material parametrisation. gaussian is the '
                        'legacy smooth bump. level_set uses a fixed-mesh '
                        'soft circular indicator chi=sigmoid((r-dist)/eps), '
                        'which is closer to a physical circular particle '
                        'while keeping centre coordinates differentiable.')
    p.add_argument('--level_set_radius', type=float, default=LEVEL_SET_RADIUS,
                   help='Radius in mm for --inclusion_profile level_set.')
    p.add_argument('--level_set_epsilon', type=float,
                   default=LEVEL_SET_EPSILON,
                   help='Diffuse interface width in mm for '
                        '--inclusion_profile level_set. Smaller is sharper '
                        'but requires finer mesh and can make gradients stiff.')
    p.add_argument('--truth_particles', type=str, default=None,
                   help='Override truth centres as CSV "x1,y1,x2,y2,...". '
                        'Defaults: 1p=(16,9.5); 3p=(13,9.5),(25,9.5),(19,6.5).')
    p.add_argument('--init_particles', type=str, default=None,
                   help='Override initial guesses as CSV "x1,y1,x2,y2,...".')
    p.add_argument('--init_from_json', type=str, default=None,
                   help='Initialise particles from a previous '
                        'demo_inverse_stiff_inclusion.json recovered_particles '
                        'entry. Explicit --init_particles takes precedence.')
    p.add_argument('--free_particle_indices', type=str, default=None,
                   help='CSV zero-based particle indices to optimise. '
                        'Other particles stay fixed at their initial values. '
                        'Example for staged D2: 0, then 2, then 1.')
    p.add_argument('--free_coord_indices', type=str, default=None,
                   help='CSV zero-based flat coordinate indices to optimise. '
                        'Overrides --free_particle_indices. Example for D2 '
                        'y-only recovery: 1,3,5.')
    p.add_argument('--obs_x_min', type=float, default=None,
                   help='Left edge of path/front/front_dic observation window.')
    p.add_argument('--obs_x_max', type=float, default=None,
                   help='Right edge of path/front/front_dic observation window.')
    p.add_argument('--resume', action='store_true',
                   help='If --output_dir already contains inv_checkpoint.pt '
                        'and damage_truth.npz from a previous run, skip the '
                        'truth pass, reload L-BFGS state and parameter '
                        'vector, and continue from the next outer iteration.')
    p.add_argument('--obs_mode', type=str, default='full',
                   choices=['full', 'tips', 'path', 'front', 'front_dic',
                            'sensor_strain_dic', 'load_disp'],
                   help='full = MSE on final damage field; '
                        'tips = MSE on softargmax-extracted crack-tip x at '
                        'n_tips evenly-spaced timesteps; '
                        'path = MSE on damage-weighted crack centerline '
                        'y(x) on a fixed x-grid (differentiable, n_path_bins '
                        'samples). Truth-mass-weighted so bins beyond the '
                        'truth tip do not penalise overshoot; '
                        'front = TBPTT-only MSE on active new-damage '
                        'front features, for multi-particle recovery; '
                        'front_dic = displacement/DIC features inside the '
                        'target active-front ROI; '
                        'sensor_strain_dic = local displacement/affine-strain '
                        'patch features near known sensor/inclusion stations; '
                        'load_disp = MSE on the integrated reaction force on '
                        'the loaded boundary at n_load_samples timesteps.')
    p.add_argument('--n_tips', type=int, default=10,
                   help='Number of tip snapshots when --obs_mode tips.')
    p.add_argument('--n_load_samples', type=int, default=40,
                   help='Number of timesteps at which to sample the '
                        'load-displacement curve under --obs_mode load_disp.')
    p.add_argument('--n_path_bins', type=int, default=40,
                   help='Number of x-bins for --obs_mode path.')
    p.add_argument('--path_sigma_factor', type=float, default=0.6,
                   help='Bin width as a fraction of inter-bin spacing '
                        '(--obs_mode path). Default 0.6 keeps bins '
                        'overlap-smooth without bleeding.')
    p.add_argument('--path_noise_std', type=float, default=0.0,
                   help='Absolute Gaussian noise sigma [mm] added to active '
                        'truth crack-path bins for --obs_mode path. The noise '
                        'is synthetic observation noise; it is not added to '
                        'the forward damage field.')
    p.add_argument('--path_noise_seed', type=int, default=1234,
                   help='Random seed for --path_noise_std.')
    p.add_argument('--tip_p', type=float, default=8.0,
                   help='Power for damage-weighted softargmax tip extractor.')
    p.add_argument('--save_snapshots', type=int, default=0,
                   help='Save N evenly-spaced damage snapshots in truth.npz '
                        'for validation-style telemetry. Independent of '
                        'obs_mode; works for both full and tips observation.')
    p.add_argument('--forward_only', action='store_true',
                   help='Run truth forward, save outputs (with snapshots if '
                        'tips mode), exit before inversion. For visual smoke '
                        'tests of the truth crack pattern.')
    p.add_argument('--gradcheck', action='store_true',
                   help='After truth pass, compute dL/d(particle pts) at the '
                        'init guess by autograd and by central finite '
                        'differences at h in {1e-3, 1e-5, 1e-7} mm; emit '
                        'gradcheck.csv. Skips the L-BFGS inversion.')
    p.add_argument('--loss_probe_line', action='store_true',
                   help='After truth pass, evaluate the selected observable '
                        'along p(alpha)=init+alpha*(truth-init), write '
                        'loss_probe_line.csv, and exit before optimisation. '
                        'Use this before new D2 optimiser runs.')
    p.add_argument('--probe_alphas', type=str,
                   default='-0.5,0.0,0.25,0.5,0.75,1.0,1.25',
                   help='Comma-separated alpha values for --loss_probe_line.')
    p.add_argument('--grad_projection_probe', action='store_true',
                   help='Run one differentiable closure at the initial '
                        'particle centres, report whether -grad points '
                        'toward the truth vector, write '
                        'grad_projection_probe.json, and exit.')
    p.add_argument('--observability_gate', action='store_true',
                   help='Before optimisation, run a D2-style identifiability '
                        'gate: compute the scalar loss gradient at the '
                        'initial centres, a finite-difference Jacobian of '
                        'the selected observable, column norms, condition '
                        'number, and an init-to-truth line probe. Currently '
                        'implemented for --obs_mode sensor_strain_dic.')
    p.add_argument('--observability_fd_h', type=float, default=1e-2,
                   help='Central finite-difference step in mm for '
                        '--observability_gate Jacobian columns.')
    p.add_argument('--observability_probe_alphas', type=str,
                   default='0.0,0.25,0.5,0.75,1.0',
                   help='Comma-separated init-to-truth line alphas for '
                        '--observability_gate.')
    p.add_argument('--tau_ramp_us', type=float, default=30.0,
                   help='Smooth-ramp duration (us). >= 3x H/c_p; default 30 us '
                        'for 16 mm Bleyer-PMMA height (c_p ~ 1.7 mm/us).')
    p.add_argument('--damping_zeta', type=float, default=0.05)
    p.add_argument('--softmax_H_beta', type=float, default=None,
                   help='Smooth-max β for the H update '
                        '(SolverConfig.softmax_H_beta). None = sharp '
                        'torch.maximum (default, exact physics). '
                        '10-100 recommended for inversion gradient '
                        'smoothness; see #270 / W3C diagnostic.')
    p.add_argument('--H_update_method', type=str, default='hard_max',
                   choices=['hard_max', 'softmax', 'smooth_max',
                            'log_smooth', 'custom_subgrad'],
                   help='H-update operator dispatcher (issue #360). '
                        '"hard_max" (default) is byte-identical to '
                        'torch.maximum. "softmax", "smooth_max", '
                        '"log_smooth" (#361), and "custom_subgrad" '
                        '(#362) are opt-in differentiable alternatives.')
    p.add_argument('--H_update_scale', type=float, default=None,
                   help='Backward sigmoid scale for --H_update_method '
                        'custom_subgrad. Default None uses the production '
                        '1e10 scale. Smaller values smooth the custom '
                        'backward and can prevent enormous inverse gradients '
                        'in smoke-scale particle recovery.')
    p.add_argument('--energy_split', type=str, default='amor',
                   choices=['amor', 'spectral', 'star_convex'],
                   help='Tensile/compressive energy split for the particle '
                        'SENT demo. Default amor. Use this for Paper 2 '
                        'particle-deflection split studies.')
    p.add_argument('--pf_model', type=str, default='AT1',
                   choices=['AT1', 'AT2'],
                   help='Phase-field crack-density model. Default AT1 keeps '
                        'clean finite-threshold cracks for particle demos.')
    p.add_argument('--plane_strain', action='store_true',
                   help='Use plane strain instead of the default plane stress.')
    p.add_argument('--backprop_probe', action='store_true',
                   help='After the truth pass, compute a scalar particle-'
                        'coordinate loss at the init guess and report whether '
                        'autograd returns finite gradients. Unlike '
                        '--gradcheck, this is compatible with custom_subgrad '
                        'because it tests backprop availability, not finite-'
                        'difference equality.')
    p.add_argument('--H_cap', type=float, default=None,
                   help='Cap on H driving force (SolverConfig.H_cap). '
                        'None = no cap (default). Advisor #NEW-C: at '
                        'β=10 the cap is generally unnecessary and may '
                        'over-correct toward bulk damage; leave None '
                        'unless ablating.')
    p.add_argument('--obs_step', type=int, default=None,
                   help='Compute the loss against the damage field at '
                        'this intermediate step rather than the final '
                        'step. Use with --obs_mode full to escape '
                        'forward-saturation degeneracy on smoke '
                        '(W3C diagnostic). None = loss at final step '
                        '(default).')
    p.add_argument('--no_damage', action='store_true',
                   help='Disable damage solve (pure elastic Verlet). Used '
                        'for the elastic-only Gate A1 gradcheck of issue '
                        '#228 custom-adjoint v1.')
    p.add_argument('--use_custom_adjoint', action='store_true',
                   help='Wrap the chunked explicit-dynamics forward in a '
                        'torch.autograd.Function with a custom adjoint '
                        '(issue #228 v1; elastic-only path correct, damage '
                        'path falls back to autograd / checkpoint).')
    p.add_argument('--output_dir', type=str,
                   default='results_inverse_stiff_inclusion')
    p.add_argument('--save_forward_viz', dest='save_forward_viz',
                   action='store_true', default=True,
                   help='Before L-BFGS, save damage_final.png + '
                        'damage_evolution.gif for both the truth and '
                        'init forwards so the user can sanity-check '
                        'the forward setup before committing to a '
                        'long inversion (default: enabled).')
    p.add_argument('--no_save_forward_viz', dest='save_forward_viz',
                   action='store_false',
                   help='Disable pre-inversion forward-viz '
                        '(saves one extra forward pass at init).')
    p.add_argument('--tbptt_eager_backward', action='store_true',
                   default=True,
                   help='Run backward inside the TBPTT helper after '
                        'each chunk, rather than stacking all chunk '
                        'snapshots and backwarding once at the end. '
                        'Bounds peak memory at one chunk\'s autograd '
                        'graph (vs O(n_chunks) in lazy mode). The '
                        'gradient is mathematically identical -- '
                        'sum-of-(scaled) per-chunk backwards equals '
                        'one mean-of-chunks backward (default: '
                        'enabled, required for n_chunks > ~10 at '
                        'production mesh size; see Pair A OOM '
                        'mitigation).')
    p.add_argument('--no_tbptt_eager_backward', dest='tbptt_eager_backward',
                   action='store_false',
                   help='Use the legacy lazy-backward TBPTT path. Will '
                        'OOM at production scale; kept for the '
                        'gradient-equivalence regression test.')
    p.add_argument('--memlog', action='store_true', default=False,
                   help='Print torch.cuda.memory_allocated around the '
                        'no-grad init pass and at the top + bottom of '
                        'each L-BFGS closure call. For diagnosing the '
                        'Pair A OOM (job 29517).')
    p.add_argument('--time_weight_lambda', type=float, default=0.0,
                   help='Exponential snapshot down-weighting (issue '
                        '#475). Per-snapshot residual is multiplied by '
                        'exp(-lambda * t/T) where T=max(snapshot_steps). '
                        'Default 0.0 = uniform = byte-identical legacy.')
    p.add_argument('--grad_clip_norm', type=float, default=None,
                   help='Clip particle-coordinate gradients to this L2 norm '
                        'inside the inverse closure. Intended for Adam/TBPTT '
                        'particle recovery when custom_subgrad returns huge '
                        'but finite gradients.')
    p.add_argument('--n_viz_frames', type=int, default=20,
                   help='Number of evolution frames in '
                        '<label>_damage_evolution.gif (default 20). '
                        'When --save_forward_viz is on this is the '
                        'lower bound on snap_count for the truth pass.')
    args = p.parse_args()

    global INCLUSION_PROFILE
    global INCLUSION_LEVEL_SET_RADIUS
    global INCLUSION_LEVEL_SET_EPSILON
    INCLUSION_PROFILE = args.inclusion_profile
    INCLUSION_LEVEL_SET_RADIUS = float(args.level_set_radius)
    INCLUSION_LEVEL_SET_EPSILON = float(args.level_set_epsilon)
    if args.inclusion_profile == 'level_set':
        if args.level_set_radius <= 0.0:
            raise ValueError("--level_set_radius must be positive")
        if args.level_set_epsilon <= 0.0:
            raise ValueError("--level_set_epsilon must be positive")

    # --- TBPTT (#288) compatibility checks ---
    if args.tbptt_chunk_size > 0:
        if args.checkpoint_chunks > 0:
            raise ValueError(
                "--tbptt_chunk_size and --checkpoint_chunks are mutually "
                "exclusive: TBPTT detaches the tape at chunk boundaries, "
                "while gradient checkpointing recomputes inside chunks. "
                "They partition the time loop with incompatible semantics.")
        if args.obs_mode == 'load_disp':
            # Per-chunk reaction-force sampling would require running
            # ``reaction_force_y`` inside the helper at chunk-internal
            # timesteps; that means modifying the shared TBPTT helper
            # (#301) and is out of scope. The path/tips modes are now
            # handled below by computing per-chunk observations from the
            # chunk-end damage snapshots that ``run_forward_tbptt``
            # already returns -- no helper change required.
            raise NotImplementedError(
                f"--tbptt_chunk_size > 0 is not implemented for "
                f"--obs_mode=load_disp; the per-chunk reaction-force "
                f"observable would need a different sampling strategy "
                f"(snapshots are damage fields, not load measurements). "
                f"path and tips modes are supported.")
        if args.use_custom_adjoint:
            raise ValueError(
                "--tbptt_chunk_size and --use_custom_adjoint are mutually "
                "exclusive (custom adjoint owns the entire chunked tape).")
        if args.gradcheck:
            # Gradcheck path bakes in run_forward -> single tape; not
            # the right place to test TBPTT bias.
            raise ValueError(
                "--gradcheck is incompatible with --tbptt_chunk_size > 0. "
                "Use tests/test_tbptt_inversion.py for TBPTT gradient "
                "diagnostics.")

    out_dir = (args.output_dir if os.path.isabs(args.output_dir)
               else os.path.join(THIS_DIR, args.output_dir))
    os.makedirs(out_dir, exist_ok=True)

    device = args.device
    dtype = torch.float32 if args.dtype == 'float32' else torch.float64

    # Common geometry: 32 x 16 mm Bleyer scale, 4 mm edge notch.
    # Single-particle truth (16, 9.5) sits 1.5 mm above the crack axis
    # (y = 8) and 6.5 mm below the top edge (y = 16); 3 sigma = 3 mm
    # leaves 3.5 mm of clearance to the top boundary.
    # Three-particle truth places two stiff bumps above the crack
    # (y = 9.5) at x = 13 and x = 25, with a third bump below
    # (y = 6.5) at x = 19. All three sit 1.5 mm off the crack axis,
    # well inside the 6 sigma = 9.6 mm observability band; they are
    # 6 mm apart in x so the crack interacts with each one in turn,
    # and 3 sigma = 4.8 mm from the loaded boundaries.
    W, H, a = 32.0, 16.0, 4.0
    crack_y = H / 2.0  # = 8 mm

    if args.n_particles == 1:
        default_truth = [(16.0, 9.5)]
        default_init  = [(13.0, 11.5)]
    else:
        default_truth = [(13.0, 9.5), (25.0, 9.5), (19.0, 6.5)]
        default_init  = [(11.0, 11.0), (27.0, 11.0), (21.0, 4.5)]

    truth_pts = _parse_particles(args.truth_particles, default_truth)
    init_pts  = _parse_particles(args.init_particles,  default_init)
    if args.init_from_json and args.init_particles is None:
        with open(args.init_from_json) as fh:
            prev = json.load(fh)
        if 'recovered_particles' not in prev:
            raise ValueError("--init_from_json file has no recovered_particles")
        init_pts = [tuple(map(float, p)) for p in prev['recovered_particles']]

    if args.init_xh is not None or args.init_yh is not None:
        # Legacy single-particle init scalars override --init_particles.
        ix = args.init_xh if args.init_xh is not None else default_init[0][0]
        iy = args.init_yh if args.init_yh is not None else default_init[0][1]
        init_pts = [(ix, iy)]

    if len(truth_pts) != args.n_particles:
        raise ValueError(f"--n_particles {args.n_particles} but "
                         f"--truth_particles has {len(truth_pts)} centres")
    if len(init_pts) != args.n_particles:
        raise ValueError(f"--n_particles {args.n_particles} but "
                         f"--init_particles has {len(init_pts)} centres")

    free_coord_indices = None
    if args.free_coord_indices is not None:
        free_coord_indices = [
            int(s) for s in args.free_coord_indices.split(',')
            if s.strip()
        ]
        n_coords = 2 * args.n_particles
        bad = [i for i in free_coord_indices if i < 0 or i >= n_coords]
        if bad:
            raise ValueError(f"invalid --free_coord_indices: {bad}")
        if not free_coord_indices:
            raise ValueError("--free_coord_indices cannot be empty")
        free_particle_indices = sorted(set(i // 2 for i in free_coord_indices))
    elif args.free_particle_indices is None:
        free_particle_indices = list(range(args.n_particles))
    else:
        free_particle_indices = [
            int(s) for s in args.free_particle_indices.split(',')
            if s.strip()
        ]
        bad = [i for i in free_particle_indices
               if i < 0 or i >= args.n_particles]
        if bad:
            raise ValueError(f"invalid --free_particle_indices: {bad}")
        if not free_particle_indices:
            raise ValueError("--free_particle_indices cannot be empty")

    _check_six_sigma(truth_pts, SIGMA_INC, crack_y, 'truth')
    _check_six_sigma(init_pts,  SIGMA_INC, crack_y, 'init')

    if args.smoke:
        h_crack, h_coarse = 0.4, 2.0
        n_steps = args.n_steps if args.n_steps is not None else 2500
        # Critical pre-strain for SENT, a/H = 4/16 = 0.25:
        #   K_Ic ~ sqrt(E*Gc) = sqrt(3090*0.3) = 30.4 MPa sqrt(mm)
        #   sigma_c = K_Ic / (1.12*sqrt(pi*a)) = 30.4 / 3.97 ~ 7.66 MPa
        #   eps_c = sigma_c / E = 2.48e-3, dU_c = eps_c * H/2 = 0.020 mm
        # Use 2.5x critical for clean propagation through the inclusion
        # without overdriving the loaded edges (matches alumina-demo
        # prescription).
        delta_U = args.delta_U if args.delta_U is not None else 5e-2
    elif args.mid:
        h_crack, h_coarse = 0.1, 0.8
        n_steps = args.n_steps if args.n_steps is not None else 4500
        delta_U = args.delta_U if args.delta_U is not None else 5e-2
    else:
        h_crack, h_coarse = 0.05, 0.5
        n_steps = args.n_steps if args.n_steps is not None else 9000
        delta_U = args.delta_U if args.delta_U is not None else 5e-2

    tau_ramp = args.tau_ramp_us * 1e-6  # us -> s

    print("=" * 70)
    print("  Stiff-inclusion geometric inversion (Bleyer PMMA, clean-crack)")
    print("=" * 70)
    print(f"  Plate: {W} x {H} mm, notch {a} mm at y = {crack_y}")
    print(f"  N particles: {args.n_particles}; obs mode: {args.obs_mode}")
    for i, (xt, yt) in enumerate(truth_pts):
        print(f"    truth[{i}] = ({xt:.2f}, {yt:.2f}) mm  "
              f"(off-axis {abs(yt - crack_y):.2f} mm, 6sigma band {6*SIGMA_INC:.2f})")
    if not args.forward_only:
        for i, (xi, yi) in enumerate(init_pts):
            xt, yt = truth_pts[i]
            print(f"    init [{i}] = ({xi:.2f}, {yi:.2f}) mm  "
                  f"(offset {math.hypot(xi-xt, yi-yt):.2f} mm)")
    print(f"  E_bulk={E_BULK} MPa, alpha={ALPHA_TRUTH}, sigma={SIGMA_INC} mm")
    if args.inclusion_profile == 'level_set':
        print("  Inclusion: fixed-mesh circular level set "
              f"(r={args.level_set_radius} mm, "
              f"eps={args.level_set_epsilon} mm)")
    else:
        print("  Inclusion: Gaussian stiffness bump on fixed mesh")
    print(f"  Phase-field: {args.pf_model}, split={args.energy_split}, "
          f"{'plane strain' if args.plane_strain else 'plane stress'}")
    print(f"  Loading: smooth-cosine ramp, tau_ramp = {args.tau_ramp_us} us, "
          f"delta_U = {delta_U} mm")
    print(f"  Damping: zeta_max = {args.damping_zeta}")
    print(f"  Mesh: h_crack = {h_crack}, h_coarse = {h_coarse}")
    print(f"  n_steps = {n_steps}, device = {device}")
    if free_coord_indices is not None:
        print(f"  Free coordinate indices: {free_coord_indices}")

    if args.softmax_H_beta is not None or args.H_cap is not None:
        print(f"  Regularisers: softmax_H_beta={args.softmax_H_beta}, "
              f"H_cap={args.H_cap}")
    if args.obs_step is not None:
        if not (0 < args.obs_step <= n_steps):
            raise ValueError(f"--obs_step {args.obs_step} must be in "
                             f"(0, n_steps={n_steps}]")
        print(f"  Observation step: loss at step {args.obs_step} "
              f"(of {n_steps} total) -- pre-saturation regime")

    solver, centroids, loading = build_solver(
        W, H, a, h_crack, h_coarse, delta_U, tau_ramp,
        args.damping_zeta, device, dtype,
        enable_damage=not args.no_damage,
        softmax_H_beta=args.softmax_H_beta,
        H_cap=args.H_cap,
        H_update_method=args.H_update_method,
        H_update_scale=args.H_update_scale,
        energy_split=args.energy_split,
        pf_model=args.pf_model,
        plane_stress=not args.plane_strain)
    if args.no_damage:
        print("  --no_damage: pure-elastic Verlet (issue #228 Gate A1).")
    print(f"  Mesh: {solver.mesh.n_nodes} nodes, "
          f"{solver.mesh.n_elems} elements")
    print(f"  Solver dt = {solver.dt:.3e} s; "
          f"total simulated time = {solver.dt * n_steps * 1e6:.1f} us")

    # Snapshot timesteps. Used by --obs_mode tips for the sparse loss
    # AND/OR --save_snapshots N for validation-style telemetry. If both
    # are requested we take the larger count (so the tip-loss closure
    # always has at least n_tips samples available).
    snap_count = max(
        args.n_tips if args.obs_mode == 'tips' else 0,
        15 if args.obs_mode in ('front_dic', 'sensor_strain_dic') else 0,
        args.save_snapshots,
        args.n_viz_frames if args.save_forward_viz else 0,
    )
    if snap_count > 0:
        first = max(int(0.05 * n_steps), 1)
        snap_steps = list(np.linspace(first, n_steps, snap_count,
                                       dtype=int).tolist())
        print(f"  Snapshots at {snap_count} steps: "
              f"{snap_steps[0]}..{snap_steps[-1]}")
    else:
        snap_steps = None

    # If --obs_step is set, ensure that step is in the snapshot list so
    # both the truth forward and the closure forward capture d there.
    if args.obs_step is not None:
        if snap_steps is None:
            snap_steps = [int(args.obs_step)]
        elif int(args.obs_step) not in snap_steps:
            snap_steps = sorted(set(snap_steps) | {int(args.obs_step)})

    # TBPTT (#288): the truth pass must record damage at every chunk
    # boundary so the closure can sum per-chunk losses. Inject those
    # boundary steps into snap_steps; cache the corresponding step list
    # for use in the closure.
    tbptt_chunk_steps = None
    if args.tbptt_chunk_size > 0:
        cs = int(args.tbptt_chunk_size)
        tbptt_chunk_steps = list(range(cs, n_steps, cs))
        if not tbptt_chunk_steps or tbptt_chunk_steps[-1] != n_steps:
            tbptt_chunk_steps.append(n_steps)
        if snap_steps is None:
            snap_steps = list(tbptt_chunk_steps)
        else:
            snap_steps = sorted(set(snap_steps) | set(tbptt_chunk_steps))
        n_tbptt_chunks = len(tbptt_chunk_steps)
        print(f"  [TBPTT #288] chunk_size={cs} -> "
              f"{n_tbptt_chunks} chunks ending at "
              f"{tbptt_chunk_steps[0]}..{tbptt_chunk_steps[-1]}; "
              f"outer optimiser={args.tbptt_optimizer}")

    node_x = solver.mesh.nodes[:, 0]
    node_y = solver.mesh.nodes[:, 1]

    # Path-mode bin grid: covers crack-propagation strip from the notch
    # tip (x = a) to the right edge (x = W). Constant for both truth and
    # all closure forwards, so the loss surface is well-defined.
    if args.obs_mode in ('path', 'front', 'front_dic',
                         'sensor_strain_dic'):
        obs_x_min = a if args.obs_x_min is None else args.obs_x_min
        obs_x_max = W if args.obs_x_max is None else args.obs_x_max
        if obs_x_min >= obs_x_max:
            raise ValueError("--obs_x_min must be smaller than --obs_x_max")
        x_bins = torch.linspace(obs_x_min, obs_x_max, args.n_path_bins,
                                  dtype=dtype, device=device)
        bin_dx = float(x_bins[1] - x_bins[0])
        path_sigma = args.path_sigma_factor * bin_dx
        print(f"  Path/front bins: {args.n_path_bins} from "
              f"x={obs_x_min} to x={obs_x_max}, "
              f"sigma_bin = {path_sigma:.3f} mm")
    else:
        x_bins = None
        path_sigma = None

    # Load--displacement mode: pick evenly-spaced sample timesteps
    # spanning past the loading ramp into the propagation phase.
    if args.obs_mode == 'load_disp':
        first = max(int(0.05 * n_steps), 1)
        load_steps = list(np.linspace(first, n_steps, args.n_load_samples,
                                       dtype=int).tolist())
        top_idx = solver.mesh.node_sets['top']
        print(f"  Load samples at {args.n_load_samples} steps: "
              f"{load_steps[0]}..{load_steps[-1]}; "
              f"|top_idx|={len(top_idx)}")
    else:
        load_steps = None
        top_idx = None

    # --- Truth forward (or resume from cached truth) ---
    truth_t = torch.tensor([list(p) for p in truth_pts],
                            dtype=dtype, device=device)
    truth_npz_path = os.path.join(out_dir, 'damage_truth.npz')
    ckpt_path = os.path.join(out_dir, 'inv_checkpoint.pt')
    # Split into two independent gates (advisor 2026-05-05). Three
    # consecutive OOMs all died at the first L-BFGS closure -> no
    # inv_checkpoint.pt was ever written. With the old combined gate,
    # --resume on those run dirs falsely fell back to a fresh truth
    # pass and burned 7 minutes per submission for nothing.
    truth_cached = args.resume and os.path.exists(truth_npz_path)
    inv_resume = args.resume and os.path.exists(ckpt_path)
    resume_active = truth_cached  # legacy local alias used below
    u_snaps_truth = None
    u_snaps_truth_np = None
    path_noise_info = None

    if truth_cached:
        print(f"\n[1/3] Resuming from existing truth + checkpoint ...")
        z = np.load(truth_npz_path, allow_pickle=True)
        d_target_full = torch.tensor(z['d_target'], dtype=dtype, device=device)
        E_truth       = torch.tensor(z['E_truth'],   dtype=dtype, device=device)
        snaps_truth_np = z['snapshots'] if 'snapshots' in z.files else None
        u_snaps_truth_np = z['u_snapshots'] if 'u_snapshots' in z.files else None
        if 'tips_target' in z.files:
            tips_target = torch.tensor(z['tips_target'], dtype=dtype, device=device)
        else:
            tips_target = None
        if 'loads_target' in z.files:
            loads_target = torch.tensor(z['loads_target'], dtype=dtype, device=device)
        else:
            loads_target = None
        if 'd_target_obs' in z.files:
            d_target_obs = torch.tensor(z['d_target_obs'], dtype=dtype, device=device)
        else:
            d_target_obs = None
        if 'y_target_path' in z.files:
            y_target_path    = torch.tensor(z['y_target_path'],    dtype=dtype, device=device)
            mass_target_path = torch.tensor(z['mass_target_path'], dtype=dtype, device=device)
            if 'path_noise_requested_sigma_mm' in z.files:
                path_noise_info = {
                    'label': 'target',
                    'requested_sigma_mm': float(z['path_noise_requested_sigma_mm']),
                    'realized_active_sigma_mm': float(
                        z['path_noise_realized_active_sigma_mm']),
                    'seed': int(z['path_noise_seed']),
                    'active_bins': int(z['path_noise_active_bins']),
                }
        else:
            y_target_path = None
            mass_target_path = None
        print(f"  reloaded targets: d_target.shape={tuple(d_target_full.shape)}, "
              f"obs_mode={args.obs_mode}", flush=True)
    else:
        if args.resume:
            print(f"  --resume requested but {truth_npz_path} or "
                  f"{ckpt_path} missing; running fresh truth pass.",
                  flush=True)
        print(f"\n[1/{'2' if args.forward_only else '3'}] "
              f"Forward at truth ({n_steps} steps) ...")
    t0 = time.time()
    if not resume_active:
        with torch.no_grad():
            E_truth = gaussian_E_field_multi(centroids, truth_t,
                                              E_BULK, ALPHA_TRUTH, SIGMA_INC)
            d_target_full, snaps_truth, loads_truth = run_forward(
                solver, loading, E_truth, n_steps,
                snapshot_steps=snap_steps,
                load_steps=load_steps, top_idx=top_idx,
                record_u_snapshots=(args.obs_mode in (
                    'front_dic', 'sensor_strain_dic')))
            d_target_full = d_target_full.detach().clone()
            if args.obs_mode in ('front_dic', 'sensor_strain_dic'):
                u_snaps_truth = [
                    u.detach().clone() for u in solver._last_u_snapshots
                ]
            else:
                u_snaps_truth = None
            if snaps_truth is not None:
                tips_target = torch.stack(
                    [soft_tip_x(s, node_x, p=args.tip_p).detach() for s in snaps_truth])
                snaps_truth_np = np.stack([s.detach().cpu().numpy() for s in snaps_truth])
            else:
                tips_target = None
                snaps_truth_np = None
            # If --obs_step was requested, snap_steps is guaranteed to
            # contain it. Pull the matching truth-d snapshot.
            if args.obs_step is not None and snaps_truth is not None:
                obs_idx = snap_steps.index(int(args.obs_step))
                d_target_obs = snaps_truth[obs_idx].detach().clone()
                print(f"  Truth d at obs_step={args.obs_step}: "
                      f"max={float(d_target_obs.max()):.3f}, "
                      f"mean={float(d_target_obs.mean()):.3f}, "
                      f"#d>0.5={(d_target_obs>0.5).sum().item()}")
            else:
                d_target_obs = None
            if loads_truth is not None:
                loads_target = torch.stack([P.detach() for P in loads_truth])
                print(f"  Truth load--disp at sampled steps (N): "
                      f"min={loads_target.min().item():.3e}, "
                      f"max={loads_target.max().item():.3e}")
            else:
                loads_target = None
        print(f"  Truth done in {time.time()-t0:.1f} s, "
              f"max(d)={d_target_full.max().item():.3f}, "
              f"#d>0.5 = {(d_target_full>0.5).sum().item()}")
    else:
        # On resume the variables are already populated from damage_truth.npz.
        snaps_truth = None  # numpy snapshots are in snaps_truth_np
        u_snaps_truth = None
        print(f"  Truth resume: max(d)={d_target_full.max().item():.3f}, "
              f"#d>0.5={(d_target_full>0.5).sum().item()}")
    # Path-mode: pre-compute the truth path and per-bin mass once so
    # the closure doesn't redo it every forward.
    d_target_path = d_target_obs if args.obs_step is not None else d_target_full
    if resume_active and args.obs_step is not None and d_target_obs is None:
        raise RuntimeError(
            "--resume with --obs_step requires a cached d_target_obs. "
            "Rerun without --resume or use a cache created with --obs_step.")

    if args.obs_mode == 'path' and (not resume_active or args.obs_step is not None):
        with torch.no_grad():
            y_target_path, mass_target_path = differentiable_crack_path(
                d_target_path, node_x, node_y, x_bins, path_sigma, p=4)
            y_target_path, path_noise_info = add_path_observation_noise(
                y_target_path, mass_target_path, args.path_noise_std,
                args.path_noise_seed)
        active_path = mass_target_path > mass_target_path.max() * 0.05
        if bool(active_path.any().item()):
            print(f"  Truth path y(x) range: "
                  f"y_min={y_target_path[active_path].min():.3f}, "
                  f"y_max={y_target_path[active_path].max():.3f} mm")
            if path_noise_info and path_noise_info['requested_sigma_mm'] > 0.0:
                print("  Truth path observation noise: "
                      f"sigma={path_noise_info['requested_sigma_mm']:.4g} mm, "
                      f"realized={path_noise_info['realized_active_sigma_mm']:.4g} mm, "
                      f"active_bins={path_noise_info['active_bins']}, "
                      f"seed={path_noise_info['seed']}")
        else:
            print("  Truth path y(x): no active damage-weighted bins; "
                  "increase n_steps/load or use a non-damage observable.")
    elif not resume_active:
        y_target_path = None
        mass_target_path = None
    if not resume_active:
        if tips_target is not None and args.obs_mode == 'tips':
            print(f"  Truth soft tip x over {args.n_tips} snapshots: "
                  + ", ".join(f"{t.item():.2f}" for t in tips_target))
            node_x_np = solver.mesh.nodes[:, 0].cpu().numpy()
            hard_tips = [hard_tip_x(s.detach().cpu().numpy(), node_x_np)
                           for s in snaps_truth]
            print(f"  Truth hard tip x (rightmost d>0.5): "
                  + ", ".join(f"{t:.2f}" for t in hard_tips))
    # TBPTT (#288): pull the truth damage at each chunk boundary out
    # of the truth-pass snapshots, in tbptt_chunk_steps order. These
    # are the per-chunk loss targets the closure will compare against.
    d_target_tbptt_chunks = None
    if args.tbptt_chunk_size > 0:
        if resume_active and snaps_truth_np is not None:
            # Resume: numpy snapshots cached in the npz; index by step.
            snap_steps_cached = list(snap_steps)
            chunk_idxs = [snap_steps_cached.index(s) for s in tbptt_chunk_steps]
            d_target_tbptt_chunks = [
                torch.tensor(snaps_truth_np[i], dtype=dtype, device=device)
                for i in chunk_idxs
            ]
        elif snaps_truth is not None:
            chunk_idxs = [snap_steps.index(s) for s in tbptt_chunk_steps]
            d_target_tbptt_chunks = [snaps_truth[i].detach().clone()
                                      for i in chunk_idxs]
        else:
            raise RuntimeError(
                "TBPTT mode active but truth snapshots are unavailable; "
                "this should not happen because tbptt_chunk_steps were "
                "merged into snap_steps before the truth forward.")
        print(f"  [TBPTT #288] cached {len(d_target_tbptt_chunks)} "
              f"chunk-boundary truth damage fields.")

    # Path-mode TBPTT: per-chunk truth path y(x) and per-bin mass.
    # IMPORTANT: each chunk uses its own per-chunk mass weighting, NOT
    # the final-state mass from ``mass_target_path``. Early chunks have
    # not yet seen any crack growth, so reusing the final-state mass
    # would zero-weight bins beyond the early-chunk tip and break the
    # gradient signal there. Per-chunk mass keeps every chunk's loss
    # well-defined: bins where the truth crack does exist at chunk k
    # dominate the per-chunk MSE; bins beyond the truth tip at chunk k
    # carry zero weight and don't penalise overshoot.
    y_target_path_chunks = None
    mass_target_path_chunks = None
    if args.tbptt_chunk_size > 0 and args.obs_mode in ('path', 'front'):
        with torch.no_grad():
            chunk_pairs = [
                differentiable_crack_path(
                    d_chunk, node_x, node_y, x_bins, path_sigma, p=4)
                for d_chunk in d_target_tbptt_chunks
            ]
        y_target_path_chunks = []
        path_noise_chunks = []
        for idx, (y, m) in enumerate(chunk_pairs):
            y_noisy, info = add_path_observation_noise(
                y.detach().clone(), m.detach().clone(), args.path_noise_std,
                args.path_noise_seed + idx + 1, label=f'chunk_{idx}')
            y_target_path_chunks.append(y_noisy)
            path_noise_chunks.append(info)
        mass_target_path_chunks = [m.detach().clone() for _, m in chunk_pairs]
        # Sanity print: per-chunk mass total tells us how much crack has
        # propagated by each chunk boundary. Mass=0 means the truth has
        # no damage signal at that chunk -- backward will zero out for
        # that chunk and the overall gradient is dominated by later
        # chunks. That is acceptable; document it for the user.
        masses_str = ", ".join(f"{float(m.sum()):.2e}"
                                for m in mass_target_path_chunks)
        print(f"  [TBPTT path #301-followup] per-chunk truth path mass "
              f"totals: ({masses_str})")
        empty_chunks = sum(1 for m in mass_target_path_chunks
                           if float(m.sum()) < 1e-12)
        if empty_chunks > 0:
            print(f"    note: {empty_chunks}/{len(mass_target_path_chunks)} "
                  f"early chunks have empty truth path (no crack yet); "
                  f"their per-chunk loss is degenerate (zero) and the "
                  f"gradient is supplied by later chunks. Use a smaller "
                  f"--tbptt_chunk_size if you need signal earlier.")
        if args.path_noise_std > 0.0:
            active_noisy = [info for info in path_noise_chunks
                            if info['active_bins'] > 0]
            realized = [info['realized_active_sigma_mm']
                        for info in active_noisy]
            mean_realized = float(np.mean(realized)) if realized else 0.0
            print("  [TBPTT path] observation noise applied per active chunk: "
                  f"sigma={args.path_noise_std:.4g} mm, "
                  f"mean_realized={mean_realized:.4g} mm, "
                  f"active_chunks={len(active_noisy)}/{len(path_noise_chunks)}")

    d_target_prev_tbptt_chunks = None
    if args.tbptt_chunk_size > 0 and args.obs_mode in ('front', 'front_dic'):
        zero_d = torch.zeros_like(d_target_tbptt_chunks[0])
        d_target_prev_tbptt_chunks = [zero_d] + [
            d.detach().clone() for d in d_target_tbptt_chunks[:-1]
        ]
        print("  [TBPTT front/DIC] using active new-damage increments "
              "between chunk boundaries.")

    u_target_tbptt_chunks = None
    u_target_front_chunks = None
    u_target_sensor_chunks = None
    d_target_front_chunks = None
    d_target_prev_front_chunks = None
    if args.tbptt_chunk_size > 0 and args.obs_mode == 'front_dic':
        if resume_active and u_snaps_truth_np is not None:
            snap_steps_cached = list(snap_steps)
            chunk_idxs = [snap_steps_cached.index(s) for s in tbptt_chunk_steps]
            u_target_tbptt_chunks = [
                torch.tensor(u_snaps_truth_np[i], dtype=dtype, device=device)
                for i in chunk_idxs
            ]
        elif u_snaps_truth is not None:
            chunk_idxs = [snap_steps.index(s) for s in tbptt_chunk_steps]
            u_target_tbptt_chunks = [u_snaps_truth[i].detach().clone()
                                      for i in chunk_idxs]
        else:
            raise RuntimeError(
                "--obs_mode front_dic requires displacement snapshots from "
                "the truth forward. Rerun without --resume or use a cache "
                "created with --obs_mode front_dic.")
        print(f"  [TBPTT front_dic] cached {len(u_target_tbptt_chunks)} "
              f"chunk-boundary truth displacement fields.")
    elif args.obs_mode == 'front_dic':
        if resume_active and snaps_truth_np is not None:
            d_target_front_chunks = [
                torch.tensor(s, dtype=dtype, device=device)
                for s in snaps_truth_np
            ]
        elif snaps_truth is not None:
            d_target_front_chunks = [
                s.detach().clone() for s in snaps_truth
            ]
        else:
            raise RuntimeError(
                "--obs_mode front_dic requires truth damage snapshots.")
        if resume_active and u_snaps_truth_np is not None:
            u_target_front_chunks = [
                torch.tensor(s, dtype=dtype, device=device)
                for s in u_snaps_truth_np
            ]
        elif u_snaps_truth is not None:
            u_target_front_chunks = [
                s.detach().clone() for s in u_snaps_truth
            ]
        else:
            raise RuntimeError(
                "--obs_mode front_dic requires displacement snapshots from "
                "the truth forward. Rerun without --resume or use a cache "
                "created with --obs_mode front_dic.")
        zero_d = torch.zeros_like(d_target_front_chunks[0])
        d_target_prev_front_chunks = [zero_d] + [
            d.detach().clone() for d in d_target_front_chunks[:-1]
        ]
        print(f"  [front_dic] cached {len(u_target_front_chunks)} "
              "full-BPTT truth displacement fields.")

    if args.obs_mode == 'sensor_strain_dic':
        if resume_active and snaps_truth_np is not None:
            d_target_front_chunks = [
                torch.tensor(s, dtype=dtype, device=device)
                for s in snaps_truth_np
            ]
        elif snaps_truth is not None:
            d_target_front_chunks = [
                s.detach().clone() for s in snaps_truth
            ]
        else:
            raise RuntimeError(
                "--obs_mode sensor_strain_dic requires truth damage snapshots.")
        if resume_active and u_snaps_truth_np is not None:
            u_target_sensor_chunks = [
                torch.tensor(s, dtype=dtype, device=device)
                for s in u_snaps_truth_np
            ]
        elif u_snaps_truth is not None:
            u_target_sensor_chunks = [
                s.detach().clone() for s in u_snaps_truth
            ]
        else:
            raise RuntimeError(
                "--obs_mode sensor_strain_dic requires displacement "
                "snapshots from the truth forward. Rerun without --resume "
                "or use a cache created with this obs_mode.")
        print(f"  [sensor_strain_dic] cached "
              f"{len(u_target_sensor_chunks)} truth displacement fields.")

    # Tips-mode TBPTT: per-chunk truth soft tip x. One scalar per chunk.
    tips_target_chunks = None
    if args.tbptt_chunk_size > 0 and args.obs_mode == 'tips':
        with torch.no_grad():
            tips_target_chunks = [
                soft_tip_x(d_chunk, node_x, p=args.tip_p).detach().clone()
                for d_chunk in d_target_tbptt_chunks
            ]
        tips_str = ", ".join(f"{float(t):.2f}"
                              for t in tips_target_chunks)
        print(f"  [TBPTT tips #301-followup] per-chunk truth soft tip x: "
              f"({tips_str})")

    # Hard-tip on the FINAL damage field even when no snapshots
    # requested -- single number that says where the crack actually
    # ended up.
    node_x_np_final = solver.mesh.nodes[:, 0].cpu().numpy()
    final_hard_tip = hard_tip_x(d_target_full.cpu().numpy(), node_x_np_final)
    print(f"  Truth final hard tip x (rightmost d>0.5): {final_hard_tip:.3f} mm")

    truth_save = {
        'nodes':        solver.mesh.nodes.cpu().numpy(),
        'elements':     solver.mesh.elements.cpu().numpy(),
        'centroids':    centroids.cpu().numpy(),
        'd_target':     d_target_full.cpu().numpy(),
        'E_truth':      E_truth.cpu().numpy(),
        'truth_pts':    np.array(truth_pts),
        'alpha':        ALPHA_TRUTH,
        'sigma':        SIGMA_INC,
        'inclusion_profile': args.inclusion_profile,
        'level_set_radius':  args.level_set_radius,
        'level_set_epsilon': args.level_set_epsilon,
        'E_bulk':       E_BULK,
        'W':            W,
        'H':            H,
        'a':            a,
        'n_steps':      n_steps,
        'delta_U':      delta_U,
        'tau_ramp_us':  args.tau_ramp_us,
        'damping_zeta': args.damping_zeta,
        'n_particles':  args.n_particles,
        'obs_mode':     args.obs_mode,
    }
    if snaps_truth_np is not None:
        truth_save['snapshots'] = snaps_truth_np
        truth_save['snapshot_steps'] = np.array(snap_steps)
        if tips_target is not None:
            truth_save['tips_target'] = tips_target.cpu().numpy()
    if u_snaps_truth is not None:
        truth_save['u_snapshots'] = np.stack([
            u.detach().cpu().numpy() for u in u_snaps_truth
        ])
    if args.obs_step is not None and not resume_active and d_target_obs is not None:
        truth_save['d_target_obs'] = d_target_obs.cpu().numpy()
        truth_save['obs_step'] = int(args.obs_step)
    if loads_target is not None:
        # Persist the load--displacement target so resume reconstructs it
        # without re-running the truth forward.
        truth_save['loads_target'] = loads_target.cpu().numpy()
        truth_save['load_steps'] = np.array(load_steps)
    # Back-compat: existing plotters (plot_stiff_inclusion.py) and the
    # paper-1 regen flow read x_truth/y_truth scalars. Keep them for
    # n_particles == 1 so nothing downstream breaks.
    if args.n_particles == 1:
        truth_save['x_truth'] = truth_pts[0][0]
        truth_save['y_truth'] = truth_pts[0][1]
    if y_target_path is not None:
        # Persist the path observation target so the plot script and
        # any downstream rerun can reuse it without rebuilding from d.
        truth_save['x_bins']           = x_bins.cpu().numpy()
        truth_save['path_sigma_bin']   = path_sigma
        truth_save['y_target_path']    = y_target_path.cpu().numpy()
        truth_save['mass_target_path'] = mass_target_path.cpu().numpy()
        if path_noise_info is not None:
            truth_save['path_noise_requested_sigma_mm'] = (
                path_noise_info['requested_sigma_mm'])
            truth_save['path_noise_realized_active_sigma_mm'] = (
                path_noise_info['realized_active_sigma_mm'])
            truth_save['path_noise_seed'] = path_noise_info['seed']
            truth_save['path_noise_active_bins'] = (
                path_noise_info['active_bins'])
    if not resume_active:
        np.savez(os.path.join(out_dir, 'damage_truth.npz'), **truth_save)
        print(f"  Truth saved -> {out_dir}/damage_truth.npz")

    if args.observability_gate:
        if args.obs_mode != 'sensor_strain_dic':
            raise NotImplementedError(
                "--observability_gate is currently implemented for "
                "--obs_mode sensor_strain_dic. That is the intended D2 "
                "particle-location gate because it uses displacement/strain "
                "patches rather than saturated final damage.")
        print("\n[observability-gate] D2 sensor-strain identifiability ...",
              flush=True)
        fixed_full = torch.tensor([v for pair in init_pts for v in pair],
                                  dtype=dtype, device=device)
        truth_full = torch.tensor([v for pair in truth_pts for v in pair],
                                  dtype=dtype, device=device)
        if free_coord_indices is not None:
            free_idx_gate = list(free_coord_indices)
        else:
            free_idx_gate = []
            for ip in free_particle_indices:
                free_idx_gate.extend([2 * ip, 2 * ip + 1])
        free_idx_gate_t = torch.tensor(free_idx_gate, dtype=torch.long,
                                       device=device)
        target_feat = torch.cat([
            sensor_strain_dic_features(
                ut, node_x, node_y,
                torch.tensor(_parse_float_csv(args.sensor_xs),
                             dtype=dtype, device=device),
                torch.tensor(_parse_float_csv(args.sensor_ys),
                             dtype=dtype, device=device),
                sigma_x=args.sensor_sigma_x,
                sigma_y=args.sensor_sigma_y)
            for ut in u_target_sensor_chunks
        ], dim=0)
        feature_scale = target_feat.detach().abs().amax(dim=0).clamp_min(1e-9)

        sensor_xs_t = torch.tensor(_parse_float_csv(args.sensor_xs),
                                   dtype=dtype, device=device)
        sensor_ys_t = torch.tensor(_parse_float_csv(args.sensor_ys),
                                   dtype=dtype, device=device)

        def _observable_and_loss(full_flat, requires_grad=False):
            p_full = full_flat.detach().clone().requires_grad_(requires_grad)
            E_gate = gaussian_E_field_multi(
                centroids, p_full, E_BULK, ALPHA_TRUTH, SIGMA_INC)
            _, _, _ = run_forward(
                solver, loading, E_gate, n_steps,
                snapshot_steps=snap_steps,
                checkpoint_chunks=args.checkpoint_chunks,
                record_u_snapshots=True)
            pred_feat = torch.cat([
                sensor_strain_dic_features(
                    up, node_x, node_y, sensor_xs_t, sensor_ys_t,
                    sigma_x=args.sensor_sigma_x,
                    sigma_y=args.sensor_sigma_y)
                for up in solver._last_u_snapshots
            ], dim=0)
            residual = ((pred_feat - target_feat) / feature_scale).reshape(-1)
            return residual, residual.square().mean(), p_full

        residual0, loss0, p_for_grad = _observable_and_loss(
            fixed_full, requires_grad=True)
        loss0.backward()
        grad_full = p_for_grad.grad.detach()
        grad_free = grad_full[free_idx_gate_t]
        to_truth = truth_full[free_idx_gate_t] - fixed_full[free_idx_gate_t]
        grad_norm = grad_free.norm()
        dir_norm = to_truth.norm()
        denom = (grad_norm * dir_norm).clamp_min(torch.finfo(dtype).eps)
        cos_descent_truth = torch.dot(-grad_free, to_truth) / denom

        h_fd = float(args.observability_fd_h)
        jac_cols = []
        print(f"  finite-difference J columns: h={h_fd:g} mm, "
              f"{len(free_idx_gate)} free coordinates", flush=True)
        for idx in free_idx_gate:
            plus = fixed_full.detach().clone()
            minus = fixed_full.detach().clone()
            plus[idx] += h_fd
            minus[idx] -= h_fd
            with torch.no_grad():
                r_plus, _, _ = _observable_and_loss(plus, requires_grad=False)
                r_minus, _, _ = _observable_and_loss(minus, requires_grad=False)
            jac_cols.append(((r_plus - r_minus) / (2.0 * h_fd)).detach())
        J = torch.stack(jac_cols, dim=1)
        col_norms = torch.linalg.norm(J, dim=0)
        try:
            singular_values = torch.linalg.svdvals(J)
        except RuntimeError:
            singular_values = torch.full(
                (min(J.shape),), float('nan'), dtype=dtype, device=device)
        sv_max = singular_values[0] if singular_values.numel() else torch.tensor(
            float('nan'), dtype=dtype, device=device)
        sv_min = singular_values[-1] if singular_values.numel() else torch.tensor(
            float('nan'), dtype=dtype, device=device)
        cond = sv_max / sv_min.clamp_min(torch.finfo(dtype).eps)
        rank_tol = sv_max.detach() * 1e-8
        effective_rank = int((singular_values > rank_tol).sum().detach().cpu())

        line_rows = []
        for alpha in [float(s) for s in args.observability_probe_alphas.split(',')
                      if s.strip()]:
            p_line = fixed_full + alpha * (truth_full - fixed_full)
            with torch.no_grad():
                _, loss_line, _ = _observable_and_loss(
                    p_line, requires_grad=False)
            pts_line = p_line.detach().cpu().numpy().reshape(-1, 2)
            truth_np = truth_full.detach().cpu().numpy().reshape(-1, 2)
            errs = np.linalg.norm(pts_line - truth_np, axis=1)
            line_rows.append({
                'alpha': float(alpha),
                'loss': float(loss_line.detach().cpu()),
                'max_err_mm': float(errs.max()),
                'mean_err_mm': float(errs.mean()),
            })
            print("  line alpha={alpha:.3f} loss={loss:.6e} "
                  "max_err={max_err_mm:.3f}".format(**line_rows[-1]),
                  flush=True)

        verdict = (
            bool(torch.isfinite(grad_free).all().item())
            and float(cos_descent_truth.detach().cpu()) > 0.0
            and effective_rank == len(free_idx_gate)
            and line_rows[-1]['loss'] < line_rows[0]['loss']
        )
        report = {
            'verdict_pass': verdict,
            'loss_at_init': float(loss0.detach().cpu()),
            'free_coord_indices': free_idx_gate,
            'gradient_free': grad_free.detach().cpu().numpy().tolist(),
            'gradient_norm': float(grad_norm.detach().cpu()),
            'direction_to_truth': to_truth.detach().cpu().numpy().tolist(),
            'cos_descent_truth': float(cos_descent_truth.detach().cpu()),
            'jacobian_shape': list(J.shape),
            'jacobian_column_norms': col_norms.detach().cpu().numpy().tolist(),
            'singular_values': singular_values.detach().cpu().numpy().tolist(),
            'condition_number': float(cond.detach().cpu()),
            'effective_rank': effective_rank,
            'line_probe': line_rows,
            'obs_mode': args.obs_mode,
            'n_particles': args.n_particles,
            'n_steps': n_steps,
            'snapshot_steps': list(snap_steps),
            'sensor_xs': _parse_float_csv(args.sensor_xs),
            'sensor_ys': _parse_float_csv(args.sensor_ys),
            'sensor_sigma_x': args.sensor_sigma_x,
            'sensor_sigma_y': args.sensor_sigma_y,
            'note': (
                "This gate applies to the differentiable Gaussian/fixed-mesh "
                "surrogate. The conforming Gmsh true-particle forward has "
                "fixed geometry; moving its centres requires shape "
                "derivatives, remeshing, or a differentiable indicator.")
        }
        gate_json = os.path.join(out_dir, 'observability_gate.json')
        with open(gate_json, 'w') as fh:
            json.dump(report, fh, indent=2)
        import csv
        gate_csv = os.path.join(out_dir, 'observability_line_probe.csv')
        with open(gate_csv, 'w', newline='') as fh:
            writer = csv.DictWriter(
                fh, fieldnames=['alpha', 'loss', 'max_err_mm',
                                'mean_err_mm'])
            writer.writeheader()
            writer.writerows(line_rows)
        print(f"  grad_norm={report['gradient_norm']:.4e}, "
              f"cos(-g,truth-p)={report['cos_descent_truth']:.4e}")
        print(f"  J col norms={report['jacobian_column_norms']}")
        print(f"  singular values={report['singular_values']}")
        print(f"  condition_number={report['condition_number']:.4e}, "
              f"rank={effective_rank}/{len(free_idx_gate)}")
        print(f"[observability-gate] verdict_pass={verdict}")
        print(f"[observability-gate] wrote {gate_json}")
        print(f"[observability-gate] wrote {gate_csv}; skipping optimisation.")
        return

    if args.loss_probe_line:
        if args.tbptt_chunk_size <= 0:
            raise ValueError("--loss_probe_line requires --tbptt_chunk_size "
                             "so probe losses match the chunked objective.")
        if args.obs_mode not in ('full', 'path', 'front', 'front_dic', 'tips'):
            raise ValueError(f"--loss_probe_line unsupported for "
                             f"obs_mode={args.obs_mode!r}")
        print("\n[loss-probe] Evaluating observable along init -> truth ...")
        alphas = [float(s) for s in args.probe_alphas.split(',')
                  if s.strip()]
        init_vec = torch.tensor([v for pair in init_pts for v in pair],
                                dtype=dtype, device=device)
        truth_vec = torch.tensor([v for pair in truth_pts for v in pair],
                                 dtype=dtype, device=device)
        rows = []
        for alpha in alphas:
            probe_vec = init_vec + alpha * (truth_vec - init_vec)
            E_probe = gaussian_E_field_multi(
                centroids, probe_vec, E_BULK, ALPHA_TRUTH, SIGMA_INC)
            with torch.no_grad():
                d_probe, d_snaps_probe, _ = run_forward(
                    solver, loading, E_probe, n_steps,
                    snapshot_steps=tbptt_chunk_steps,
                    record_u_snapshots=(args.obs_mode == 'front_dic'))
                if args.obs_mode == 'front_dic':
                    u_probe_chunks = [
                        u.detach().clone() for u in solver._last_u_snapshots
                    ]
                else:
                    u_probe_chunks = None
            if args.obs_mode == 'full':
                chunk_losses_probe = [
                    ((dp - dt) ** 2).mean()
                    for dp, dt in zip(d_snaps_probe, d_target_tbptt_chunks)
                ]
            elif args.obs_mode == 'path':
                chunk_losses_probe = []
                for dp, y_tk, mass_tk in zip(d_snaps_probe,
                                              y_target_path_chunks,
                                              mass_target_path_chunks):
                    y_pred_k, _ = differentiable_crack_path(
                        dp, node_x, node_y, x_bins, path_sigma, p=4)
                    sq_k = (y_pred_k - y_tk) ** 2
                    chunk_losses_probe.append(
                        (mass_tk * sq_k).sum() / (mass_tk.sum() + 1e-12))
            elif args.obs_mode == 'front':
                zero_dp = torch.zeros_like(d_snaps_probe[0])
                prev_probe = [zero_dp] + [d.detach().clone()
                                           for d in d_snaps_probe[:-1]]
                chunk_losses_probe = [
                    front_localised_path_loss(
                        dp, dp_prev, dt, dt_prev,
                        node_x, node_y, x_bins, path_sigma, crack_y, p=2)
                    for dp, dp_prev, dt, dt_prev in zip(
                        d_snaps_probe, prev_probe,
                        d_target_tbptt_chunks,
                        d_target_prev_tbptt_chunks)
                ]
            elif args.obs_mode == 'front_dic':
                chunk_losses_probe = [
                    front_dic_loss(
                        up, ut, dt, dt_prev,
                        node_x, node_y, x_bins, path_sigma, crack_y)
                    for up, ut, dt, dt_prev in zip(
                        u_probe_chunks,
                        u_target_tbptt_chunks,
                        d_target_tbptt_chunks,
                        d_target_prev_tbptt_chunks)
                ]
            elif args.obs_mode == 'tips':
                chunk_losses_probe = [
                    (soft_tip_x(dp, node_x, p=args.tip_p) - tk) ** 2
                    for dp, tk in zip(d_snaps_probe, tips_target_chunks)
                ]
            loss_probe = torch.stack(chunk_losses_probe).mean()
            pts_np = probe_vec.detach().cpu().numpy().reshape(-1, 2)
            truth_np = truth_vec.detach().cpu().numpy().reshape(-1, 2)
            errs = np.linalg.norm(pts_np - truth_np, axis=1)
            row = {
                'alpha': float(alpha),
                'loss': float(loss_probe.detach().cpu()),
                'max_err_mm': float(errs.max()),
                'mean_err_mm': float(errs.mean()),
                'max_damage': float(d_probe.detach().max().cpu()),
            }
            rows.append(row)
            print("  alpha={alpha:.3f} loss={loss:.6e} "
                  "max_err={max_err_mm:.3f} mean_err={mean_err_mm:.3f}"
                  .format(**row), flush=True)
        csv_path = os.path.join(out_dir, 'loss_probe_line.csv')
        import csv
        with open(csv_path, 'w', newline='') as fh:
            writer = csv.DictWriter(
                fh, fieldnames=['alpha', 'loss', 'max_err_mm',
                                'mean_err_mm', 'max_damage'])
            writer.writeheader()
            writer.writerows(rows)
        print(f"[loss-probe] wrote {csv_path}; skipping optimisation.")
        return

    # --- Pre-inversion forward visualisation (truth) ---
    # Pure plotter on already-computed snapshots; does not re-run the
    # forward. Falls back gracefully on resume if the cached truth had
    # no snapshots stored.
    if args.save_forward_viz:
        try:
            from inverse_problems._viz import save_forward_viz
            truth_snaps_for_viz = (snaps_truth
                                    if not resume_active
                                    else (snaps_truth_np
                                          if snaps_truth_np is not None
                                          else None))
            paths = save_forward_viz(
                solver.mesh.nodes, solver.mesh.elements,
                d_target_full, out_dir, label='truth',
                snapshots=truth_snaps_for_viz,
                snap_steps=snap_steps,
                n_steps_total=n_steps,
                particles=truth_pts,
                particle_radius=(
                    args.level_set_radius
                    if args.inclusion_profile == 'level_set'
                    else SIGMA_INC
                ),
                particle_label_prefix='T',
                particle_color='tab:orange',
            )
            print(f"  [forward-viz] truth png -> {paths['png']}")
            if paths['gif']:
                print(f"  [forward-viz] truth gif -> {paths['gif']}")
        except Exception as exc:
            print(f"  [forward-viz] truth viz failed: {exc}")

    # --- Pre-inversion forward visualisation (init guess) ---
    # One extra forward eval (no autograd) so the user can sanity-check
    # the init-parameter response before committing to the L-BFGS loop.
    if args.save_forward_viz and not args.gradcheck:
        print(f"\n[1b] Forward at init guess "
              f"({n_steps} steps, no_grad) for forward-viz ...")
        t0_init = time.time()
        init_t = torch.tensor([list(p) for p in init_pts],
                              dtype=dtype, device=device)
        try:
            with torch.no_grad():
                E_init = gaussian_E_field_multi(
                    centroids, init_t, E_BULK, ALPHA_TRUTH, SIGMA_INC)
                d_init_full, snaps_init, _ = run_forward(
                    solver, loading, E_init, n_steps,
                    snapshot_steps=snap_steps,
                    load_steps=None, top_idx=None)
                d_init_full = d_init_full.detach().clone()
            print(f"  Init forward done in {time.time()-t0_init:.1f} s, "
                  f"max(d)={d_init_full.max().item():.3f}, "
                  f"#d>0.5={(d_init_full>0.5).sum().item()}")
            from inverse_problems._viz import save_forward_viz
            paths = save_forward_viz(
                solver.mesh.nodes, solver.mesh.elements,
                d_init_full, out_dir, label='init',
                snapshots=snaps_init,
                snap_steps=snap_steps,
                n_steps_total=n_steps,
                particles=init_pts,
                particle_radius=(
                    args.level_set_radius
                    if args.inclusion_profile == 'level_set'
                    else SIGMA_INC
                ),
                particle_label_prefix='I',
                particle_color='tab:blue',
            )
            print(f"  [forward-viz] init png -> {paths['png']}")
            if paths['gif']:
                print(f"  [forward-viz] init gif -> {paths['gif']}")
        except Exception as exc:
            print(f"  [forward-viz] init forward/viz failed: {exc}")

    if args.forward_only:
        print("\n--forward_only set; skipping inversion.")
        return

    # Pair A OOM mitigation (job 29517): the no-grad truth + init forwards
    # leave the solver state populated (u, v, a, d, H_elem, H_nodal,
    # _last_strain) and Python locals like ``snaps_init`` / ``d_init_full``
    # holding GPU tensors that the L-BFGS closure does not need. Drop
    # references where safe and force the CUDA caching allocator to
    # release blocks before the first closure builds a 50-step autograd
    # graph on top of them.
    # Drop GPU references the inversion no longer needs. Each name may
    # be undefined depending on the upstream code path (e.g. when
    # --no_save_forward_viz suppresses the init pass), so we wrap each
    # del in its own try/except. ``del`` in a function frame DOES
    # release the local slot — unlike ``del locals()[name]``.
    try: del snaps_init  # noqa: E701
    except NameError: pass  # noqa: E722
    try: del d_init_full  # noqa: E701
    except NameError: pass  # noqa: E722
    try: del init_t  # noqa: E701
    except NameError: pass  # noqa: E722
    try: del E_init  # noqa: E701
    except NameError: pass  # noqa: E722
    try: del truth_snaps_for_viz  # noqa: E701
    except NameError: pass  # noqa: E722
    try: del paths  # noqa: E701
    except NameError: pass  # noqa: E722
    # Reset solver simulator state to small zero tensors so the residue
    # from the init forward is not carried into the closure's reset (the
    # closure overwrites these anyway, but releasing now lets empty_cache
    # actually reclaim the storage).
    n_nodes = solver.mesh.n_nodes
    n_elem = solver.mesh.n_elems
    solver.u = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.v = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.a = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.d = torch.zeros(n_nodes, dtype=dtype, device=device)
    solver.H_elem = torch.zeros(n_elem, dtype=dtype, device=device)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dtype, device=device)
    if hasattr(solver, '_last_strain'):
        solver._last_strain = None
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    _free_cuda("post-init", verbose=args.memlog)

    # --- Gradcheck mode: dL/dp via autograd vs central FD ---
    if args.gradcheck:
        print("\n[gradcheck] Comparing autograd vs central FD at init pts ...")
        init_flat0 = torch.tensor([v for pair in init_pts for v in pair],
                                   dtype=dtype, device=device)

        # Loss function: take a parameter vector, return scalar loss.
        # Default: full-damage MSE.
        # --no_damage (issue #228 Gate A1 elastic-only): switch to mean-
        # squared final displacement, since damage is identically zero
        # in that mode and would yield a trivially zero loss with no
        # gradient. ||u_final||^2 is a non-degenerate quadratic in E
        # that exercises the same chunked Verlet forward.
        def loss_at(p_flat, requires_grad):
            p = p_flat.detach().clone().requires_grad_(requires_grad)
            E_e = gaussian_E_field_multi(centroids, p, E_BULK,
                                          ALPHA_TRUTH, SIGMA_INC)
            d_p, _, _ = run_forward(solver, loading, E_e, n_steps,
                                     checkpoint_chunks=args.checkpoint_chunks,
                                     use_custom_adjoint=args.use_custom_adjoint)
            if args.no_damage:
                return (solver.u ** 2).mean(), p
            return ((d_p - d_target_full) ** 2).mean(), p

        t0 = time.time()
        loss_ref, p_ad = loss_at(init_flat0, requires_grad=True)
        loss_ref.backward()
        g_autograd = p_ad.grad.detach().clone()
        print(f"  autograd: loss={float(loss_ref):.6e}  "
              f"grad={g_autograd.tolist()}  "
              f"({time.time()-t0:.1f}s)")

        rows = [('h', 'idx', 'autograd', 'fd', 'abs_err', 'rel_err')]
        for h in (1e-3, 1e-5, 1e-7):
            print(f"  FD h={h:.0e} ...")
            g_fd = torch.zeros_like(init_flat0)
            for i in range(len(init_flat0)):
                p_plus  = init_flat0.clone(); p_plus[i]  += h
                p_minus = init_flat0.clone(); p_minus[i] -= h
                with torch.no_grad():
                    L_plus,  _ = loss_at(p_plus,  requires_grad=False)
                    L_minus, _ = loss_at(p_minus, requires_grad=False)
                g_fd[i] = (float(L_plus) - float(L_minus)) / (2.0 * h)
            for i, (gad, gfd) in enumerate(zip(g_autograd, g_fd)):
                ae = abs(float(gad) - float(gfd))
                re = ae / (abs(float(gad)) + 1e-30)
                rows.append((f'{h:.0e}', i, float(gad), float(gfd), ae, re))
            print(f"    grad_fd  = {g_fd.tolist()}")

        import csv
        out_csv = os.path.join(out_dir, 'gradcheck.csv')
        with open(out_csv, 'w', newline='') as f:
            csv.writer(f).writerows(rows)
        print(f"  -> {out_csv}")
        print("\n--gradcheck done; skipping inversion.")
        return

    # --- Backprop probe: finite particle-coordinate gradients ---
    if args.backprop_probe:
        print("\n[backprop_probe] Checking particle-coordinate gradients ...")
        init_flat0 = torch.tensor([v for pair in init_pts for v in pair],
                                  dtype=dtype, device=device,
                                  requires_grad=True)
        E_e = gaussian_E_field_multi(centroids, init_flat0, E_BULK,
                                      ALPHA_TRUTH, SIGMA_INC)
        d_p, snaps_p, loads_p = run_forward(
            solver, loading, E_e, n_steps,
            snapshot_steps=snap_steps,
            load_steps=load_steps if args.obs_mode == 'load_disp' else None,
            top_idx=solver.mesh.node_sets.get('top', None)
                    if args.obs_mode == 'load_disp' else None,
            checkpoint_chunks=args.checkpoint_chunks,
            use_custom_adjoint=args.use_custom_adjoint)
        if args.obs_mode == 'path':
            y_pred, m_pred = differentiable_crack_path(
                d_p, solver.mesh.nodes[:, 0], solver.mesh.nodes[:, 1],
                x_bins, path_sigma, p=4)
            loss_probe = (((y_pred - y_target_path) ** 2)
                          * mass_target_path).sum() / (
                              mass_target_path.sum() + 1e-12)
        elif args.obs_mode == 'tips':
            if snaps_p is None:
                raise RuntimeError("--backprop_probe with obs_mode=tips "
                                   "requires snapshot steps.")
            tips_p = torch.stack([
                soft_tip_x(s, node_x, p=args.tip_p) for s in snaps_p
            ])
            loss_probe = ((tips_p - tips_target) ** 2).mean()
        elif args.obs_mode == 'load_disp':
            if loads_p is None or loads_target is None:
                raise RuntimeError("--backprop_probe with obs_mode=load_disp "
                                   "requires load samples.")
            loss_probe = ((torch.stack(loads_p) - loads_target) ** 2).mean()
        else:
            loss_probe = ((d_p - d_target_full) ** 2).mean()
        loss_probe.backward()
        grad = init_flat0.grad.detach()
        finite = bool(torch.isfinite(grad).all().item())
        print(f"  loss={float(loss_probe.detach()):.6e}")
        print(f"  grad={grad.cpu().tolist()}")
        print(f"  finite_grad={finite}")
        with open(os.path.join(out_dir, 'backprop_probe.json'), 'w') as f:
            json.dump({
                'loss': float(loss_probe.detach().cpu()),
                'grad': grad.cpu().tolist(),
                'finite_grad': finite,
                'energy_split': args.energy_split,
                'pf_model': args.pf_model,
                'plane_stress': not args.plane_strain,
                'H_update_method': args.H_update_method,
                'obs_mode': args.obs_mode,
                'n_particles': args.n_particles,
                'n_steps': n_steps,
            }, f, indent=2)
        print("\n--backprop_probe done; skipping inversion.")
        return

    # --- Inversion ---
    fixed_flat = torch.tensor([v for pair in init_pts for v in pair],
                              dtype=dtype, device=device)
    truth_flat = torch.tensor([v for pair in truth_pts for v in pair],
                               dtype=dtype, device=device)

    def _best_truth_assignment(cur_full):
        """Match exchangeable particles by minimum Euclidean distance."""
        if args.n_particles <= 1:
            return truth_flat.detach(), [0]
        cur_pts = cur_full.detach().view(args.n_particles, 2)
        truth_pts_t = truth_flat.detach().view(args.n_particles, 2)
        best_perm = tuple(range(args.n_particles))
        best_cost = None
        for perm in itertools.permutations(range(args.n_particles)):
            perm_t = truth_pts_t[list(perm)]
            cost = torch.linalg.norm(cur_pts - perm_t, dim=1).sum()
            if best_cost is None or float(cost) < float(best_cost):
                best_cost = cost
                best_perm = perm
        matched = truth_pts_t[list(best_perm)].reshape(-1)
        return matched, list(best_perm)

    def _particle_error_report(cur_full):
        matched_truth, perm = _best_truth_assignment(cur_full)
        cur_pts = cur_full.detach().view(args.n_particles, 2)
        truth_pts_matched = matched_truth.view(args.n_particles, 2)
        errs_t = torch.linalg.norm(cur_pts - truth_pts_matched, dim=1)
        errs = [float(v) for v in errs_t.detach().cpu()]
        return errs, max(errs), perm, truth_pts_matched.detach().cpu().numpy()

    if free_coord_indices is not None:
        free_idx = list(free_coord_indices)
    else:
        free_idx = []
        for ip in free_particle_indices:
            free_idx.extend([2 * ip, 2 * ip + 1])
    free_idx_t = torch.tensor(free_idx, dtype=torch.long, device=device)
    init_flat = fixed_flat[free_idx_t].detach().clone().requires_grad_(True)

    def _assemble_particles(free_values=None):
        full = fixed_flat.detach().clone()
        vals = init_flat if free_values is None else free_values
        full[free_idx_t] = vals
        return full

    counter = {'fwd': 0, 'iter': 0}
    history = []
    start_iter = 0

    # Resume L-BFGS state from inv_checkpoint.pt only if it actually
    # exists (independent of whether the truth pass was re-run).
    if inv_resume:
        ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
        if int(ckpt.get('n_particles', args.n_particles)) != args.n_particles:
            raise RuntimeError(
                f"Resume mismatch: checkpoint n_particles="
                f"{ckpt.get('n_particles')} but args=={args.n_particles}.")
        with torch.no_grad():
            if 'fixed_flat' in ckpt:
                fixed_flat.copy_(torch.tensor(ckpt['fixed_flat'],
                                              dtype=dtype, device=device))
            saved_free = ckpt.get('free_flat', ckpt.get('init_flat'))
            init_flat.copy_(torch.tensor(saved_free, dtype=dtype, device=device))
        start_iter = int(ckpt['next_iter'])
        counter['fwd'] = int(ckpt['counter_fwd'])
        history = list(ckpt['history'])
        print(f"  Resumed from {ckpt_path}: starting at iter {start_iter}, "
              f"after {counter['fwd']} forward evals; "
              f"{len(history)} history entries restored.", flush=True)

    last_grad_alignment = {}

    def _gradient_alignment_report():
        if init_flat.grad is None:
            return {}
        grad = init_flat.grad.detach()
        cur_full = _assemble_particles().detach()
        matched_truth, perm = _best_truth_assignment(cur_full)
        to_truth = matched_truth[free_idx_t] - init_flat.detach()
        grad_norm = grad.norm()
        dir_norm = to_truth.norm()
        denom = (grad_norm * dir_norm).clamp_min(
            torch.finfo(grad.dtype).eps)
        grad_dot_to_truth = torch.dot(grad, to_truth)
        descent_dot_to_truth = torch.dot(-grad, to_truth)
        cos_descent_truth = descent_dot_to_truth / denom
        report = {
            'grad_norm': float(grad_norm.detach().cpu()),
            'direction_to_truth_norm_mm': float(dir_norm.detach().cpu()),
            'grad_dot_to_truth': float(grad_dot_to_truth.detach().cpu()),
            'descent_dot_to_truth': float(
                descent_dot_to_truth.detach().cpu()),
            'cos_descent_truth': float(cos_descent_truth.detach().cpu()),
            'grad': grad.detach().cpu().numpy().tolist(),
            'direction_to_truth': to_truth.detach().cpu().numpy().tolist(),
            'free_particle_indices': free_particle_indices,
            'truth_permutation': perm,
        }
        return report

    def closure():
        cc = counter['fwd'] + 1   # 1-based: this call's index
        it_now = counter['iter']
        cur = _assemble_particles().detach()
        cur_pts = cur.cpu().numpy().reshape(-1, 2).tolist()
        cur_str = ", ".join(f"({p[0]:.3f},{p[1]:.3f})" for p in cur_pts)
        print(f"  [iter {it_now} closure call {cc}] starting forward "
              f"(p = {cur_str}) ...", flush=True)
        t_fwd = time.time()
        opt.zero_grad()
        # Pair A OOM mitigation: release any cached blocks left over from
        # the previous closure's autograd graph BEFORE we start growing
        # this call's graph. Without this, expandable_segments=True still
        # fragments enough to OOM at chunk 1 of 400 (job 29517).
        _free_cuda(f"closure-{cc}-pre", verbose=args.memlog)
        E_e = gaussian_E_field_multi(centroids, _assemble_particles(),
                                      E_BULK, ALPHA_TRUTH, SIGMA_INC)

        # --- TBPTT branch (#288) ---
        if args.tbptt_chunk_size > 0:
            # Eager-backward mode (Pair A OOM fix): build a per-chunk
            # loss_fn that captures the relevant truth targets for
            # this obs_mode, hand it to the TBPTT helper, and the
            # helper backwards each chunk before freeing its tape.
            # Memory is bounded at one chunk's graph instead of
            # O(n_chunks). Gradient is mathematically identical to
            # the lazy `mean(stack(chunks)).backward()` path because
            # sum_k (c_k / N).backward()` accumulates into the same
            # leaf grad as `mean_k(c_k).backward()`.
            n_chunks_total = len(tbptt_chunk_steps)
            eager_scale = 1.0 / n_chunks_total
            if args.tbptt_eager_backward and args.obs_mode == 'full':
                def _eager_loss(idx, dp):
                    return ((dp - d_target_tbptt_chunks[idx]) ** 2).mean()
            elif args.tbptt_eager_backward and args.obs_mode == 'path':
                def _eager_loss(idx, dp):
                    y_pred_k, _ = differentiable_crack_path(
                        dp, node_x, node_y, x_bins, path_sigma, p=4)
                    sq_k = (y_pred_k - y_target_path_chunks[idx]) ** 2
                    mass_tk = mass_target_path_chunks[idx]
                    return (mass_tk * sq_k).sum() / (
                        mass_tk.sum() + 1e-12)
            elif args.tbptt_eager_backward and args.obs_mode == 'front':
                raise NotImplementedError(
                    "--obs_mode front currently requires the lazy TBPTT "
                    "path because the active-front loss compares adjacent "
                    "chunk endpoints. Re-run with --no_tbptt_eager_backward.")
            elif args.tbptt_eager_backward and args.obs_mode == 'front_dic':
                raise NotImplementedError(
                    "--obs_mode front_dic currently requires the lazy TBPTT "
                    "path because the DIC loss compares adjacent chunk "
                    "endpoints. Re-run with --no_tbptt_eager_backward.")
            elif args.tbptt_eager_backward and args.obs_mode == 'tips':
                def _eager_loss(idx, dp):
                    return (soft_tip_x(dp, node_x, p=args.tip_p)
                            - tips_target_chunks[idx]) ** 2
            else:
                _eager_loss = None  # legacy lazy-backward path
            # In eager mode, pass a zero-arg E factory so the helper
            # rebuilds a fresh non-leaf E_e per chunk (each with its
            # own grad_fn). Without this, chunk K+1's backward would
            # try to traverse chunk K's already-freed gaussian saved
            # tensors. In lazy mode the legacy single-tensor path is
            # fine -- one mean-backward at the end consumes the chain
            # exactly once.
            if _eager_loss is not None:
                _E_arg = (lambda: gaussian_E_field_multi(
                    centroids, _assemble_particles(),
                    E_BULK, ALPHA_TRUTH, SIGMA_INC))
            else:
                _E_arg = E_e
            d_pred, chunk_snaps_pred, chunk_steps_pred, _ = run_forward_tbptt(
                solver, loading, _E_arg, n_steps,
                tbptt_chunk_size=args.tbptt_chunk_size,
                eager_loss_fn=_eager_loss,
                eager_backward_scale=eager_scale,
                record_u_chunks=(args.obs_mode == 'front_dic'),
            )
            if args.obs_mode == 'front_dic':
                u_chunk_snaps_pred = solver._tbptt_last_u_chunk_snaps
            else:
                u_chunk_snaps_pred = None
            # Defensive: chunk-end step indices must agree with the
            # truth-side cache built in main().
            assert chunk_steps_pred == tbptt_chunk_steps, (
                f"TBPTT chunk-step mismatch: pred={chunk_steps_pred}, "
                f"truth={tbptt_chunk_steps}")
            # Loss = mean over chunks of per-chunk observation loss.
            # Each per-chunk term has its own local tape (the helper
            # detaches the simulator state at chunk boundaries by
            # construction), so backward triggers one local backward per
            # chunk and gradients sum -- the canonical TBPTT estimator
            # (biased; documented in --tbptt_chunk_size help and in
            # #288). The per-chunk observation function depends on
            # obs_mode (#301-followup):
            #   full -> per-chunk damage MSE (existing behaviour)
            #   path -> per-chunk mass-weighted MSE on the soft crack
            #           centerline y(x), against per-chunk truth (y, mass)
            #   tips -> per-chunk MSE on the soft tip x against per-chunk
            #           truth tip
            if _eager_loss is not None:
                # Eager-backward path: per-chunk losses + per-chunk
                # backwards already happened inside the helper.
                # init_flat.grad is fully populated.
                if args.time_weight_lambda != 0.0:
                    raise NotImplementedError(
                        "--time_weight_lambda is not yet supported in "
                        "the TBPTT eager-backward path; weights would "
                        "need to flow into the per-chunk backward "
                        "scale inside _tbptt.py. Use the lazy TBPTT "
                        "path (--no_tbptt_eager_backward) or non-TBPTT "
                        "mode for time-weighted losses (issue #475).")
                chunk_losses = solver._tbptt_last_chunk_losses
                loss = torch.stack(chunk_losses).mean()  # detached scalar
                fwd_s = time.time() - t_fwd
                bwd_s = 0.0  # backward time was inside the forward loop
            else:
                if args.obs_mode == 'full':
                    chunk_losses = [
                        ((dp - dt) ** 2).mean()
                        for dp, dt in zip(chunk_snaps_pred,
                                           d_target_tbptt_chunks)
                    ]
                elif args.obs_mode == 'path':
                    chunk_losses = []
                    for dp, y_tk, mass_tk in zip(chunk_snaps_pred,
                                                  y_target_path_chunks,
                                                  mass_target_path_chunks):
                        y_pred_k, _ = differentiable_crack_path(
                            dp, node_x, node_y, x_bins, path_sigma, p=4)
                        sq_k = (y_pred_k - y_tk) ** 2
                        chunk_losses.append(
                            (mass_tk * sq_k).sum()
                            / (mass_tk.sum() + 1e-12)
                        )
                elif args.obs_mode == 'front':
                    zero_dp = torch.zeros_like(chunk_snaps_pred[0])
                    prev_pred_chunks = [zero_dp] + [
                        d.detach() for d in chunk_snaps_pred[:-1]
                    ]
                    chunk_losses = [
                        front_localised_path_loss(
                            dp, dp_prev, dt, dt_prev,
                            node_x, node_y, x_bins, path_sigma, crack_y, p=2)
                        for dp, dp_prev, dt, dt_prev in zip(
                            chunk_snaps_pred, prev_pred_chunks,
                            d_target_tbptt_chunks,
                            d_target_prev_tbptt_chunks)
                    ]
                elif args.obs_mode == 'front_dic':
                    chunk_losses = []
                    for up, ut, dt, dt_prev in zip(
                            u_chunk_snaps_pred,
                            u_target_tbptt_chunks,
                            d_target_tbptt_chunks,
                            d_target_prev_tbptt_chunks):
                        c_loss = front_dic_loss(
                            up, ut, dt, dt_prev,
                            node_x, node_y, x_bins, path_sigma, crack_y)
                        if args.front_dic_elastic_weight != 0.0:
                            c_loss = c_loss + args.front_dic_elastic_weight * (
                                dic_band_loss(up, ut, node_x, node_y, crack_y,
                                              notch_x=a))
                        chunk_losses.append(c_loss)
                elif args.obs_mode == 'tips':
                    chunk_losses = [
                        (soft_tip_x(dp, node_x, p=args.tip_p) - tk) ** 2
                        for dp, tk in zip(chunk_snaps_pred,
                                           tips_target_chunks)
                    ]
                else:
                    # Should never reach here; the gate at the top of main()
                    # rejects load_disp + TBPTT before any forward runs.
                    raise NotImplementedError(
                        f"Internal error: unsupported obs_mode "
                        f"{args.obs_mode!r} in TBPTT branch")
                if args.time_weight_lambda != 0.0:
                    from phast.inverse_problems._loss_weights import (
                        time_weights, weighted_mean)
                    _w = time_weights(tbptt_chunk_steps,
                                       args.time_weight_lambda,
                                       dtype=chunk_losses[0].dtype,
                                       device=chunk_losses[0].device)
                    loss = weighted_mean(chunk_losses, _w)
                else:
                    loss = torch.stack(chunk_losses).mean()
                if not loss.requires_grad:
                    # Degenerate early/no-crack probes can yield a true
                    # zero observable. Keep the smoke path executable while
                    # preserving a mathematically zero gradient.
                    loss = loss + init_flat.sum() * 0.0
                fwd_s = time.time() - t_fwd
                t_bwd = time.time()
                loss.backward()
                bwd_s = time.time() - t_bwd
            gnorm = (float(init_flat.grad.norm())
                     if init_flat.grad is not None else float('nan'))
            align = _gradient_alignment_report()
            if align:
                last_grad_alignment.clear()
                last_grad_alignment.update(align)
                print(f"  [grad-dir] -g·(truth-p)="
                      f"{align['descent_dot_to_truth']:.4e}  "
                      f"cos(-g,truth-p)="
                      f"{align['cos_descent_truth']:.4e}",
                      flush=True)
            if args.grad_clip_norm is not None and init_flat.grad is not None:
                torch.nn.utils.clip_grad_norm_([init_flat],
                                               args.grad_clip_norm)
                gnorm_clip = float(init_flat.grad.norm())
            else:
                gnorm_clip = None
            per_chunk_str = ", ".join(f"{float(c.detach()):.2e}"
                                       for c in chunk_losses)
            clip_str = (f"  |g|clip={gnorm_clip:.4e}"
                        if gnorm_clip is not None else "")
            print(f"  [iter {it_now} closure call {cc}] "
                  f"loss={float(loss.detach()):.4e}  "
                  f"|g|={gnorm:.4e}{clip_str}  "
                  f"fwd={fwd_s:.1f}s  bwd={bwd_s:.1f}s  "
                  f"[TBPTT #288 chunks=({per_chunk_str})]",
                  flush=True)
            counter['fwd'] += 1
            if args.memlog:
                _free_cuda(f"closure-{cc}-post", verbose=True)
            return loss

        if args.obs_mode in ('tips', 'front_dic', 'sensor_strain_dic'):
            closure_snap_steps = snap_steps
        elif args.obs_step is not None:
            closure_snap_steps = [int(args.obs_step)]
        else:
            closure_snap_steps = None
        closure_load_steps = load_steps if args.obs_mode == 'load_disp' else None
        d_pred, snaps_pred, loads_pred = run_forward(
            solver, loading, E_e, n_steps,
            snapshot_steps=closure_snap_steps,
            load_steps=closure_load_steps, top_idx=top_idx,
            checkpoint_chunks=args.checkpoint_chunks,
            record_u_snapshots=(args.obs_mode in (
                'front_dic', 'sensor_strain_dic')))
        if args.obs_step is not None and args.obs_mode == 'full':
            # Loss against the pre-saturation damage field (W3C #269).
            obs_idx = closure_snap_steps.index(int(args.obs_step))
            d_pred_obs = snaps_pred[obs_idx]
            loss = ((d_pred_obs - d_target_obs) ** 2).mean()
        elif args.obs_mode == 'tips':
            tips_pred = torch.stack(
                [soft_tip_x(s, node_x, p=args.tip_p) for s in snaps_pred])
            if args.time_weight_lambda != 0.0:
                from phast.inverse_problems._loss_weights import (
                    time_weights, weighted_mean)
                _w = time_weights(closure_snap_steps,
                                   args.time_weight_lambda,
                                   dtype=tips_pred.dtype,
                                   device=tips_pred.device)
                loss = weighted_mean((tips_pred - tips_target) ** 2, _w)
            else:
                loss = ((tips_pred - tips_target) ** 2).mean()
        elif args.obs_mode == 'path':
            d_for_path = d_pred
            if args.obs_step is not None:
                obs_idx = closure_snap_steps.index(int(args.obs_step))
                d_for_path = snaps_pred[obs_idx]
            y_pred_path, _ = differentiable_crack_path(
                d_for_path, node_x, node_y, x_bins, path_sigma, p=4)
            sq = (y_pred_path - y_target_path) ** 2
            loss = (mass_target_path * sq).sum() / (
                mass_target_path.sum() + 1e-12)
        elif args.obs_mode == 'front':
            raise NotImplementedError(
                "--obs_mode front is implemented for TBPTT only; use "
                "--tbptt_chunk_size > 0 --no_tbptt_eager_backward.")
        elif args.obs_mode == 'front_dic':
            if snaps_pred is None:
                raise RuntimeError(
                    "--obs_mode front_dic requires snapshot steps; this "
                    "should be auto-enabled by the parser setup.")
            u_front_pred = solver._last_u_snapshots
            zero_dp = torch.zeros_like(snaps_pred[0])
            prev_pred_chunks = [zero_dp] + [
                d.detach() for d in snaps_pred[:-1]
            ]
            chunk_losses = []
            for up, ut, dt, dt_prev in zip(
                    u_front_pred,
                    u_target_front_chunks,
                    d_target_front_chunks,
                    d_target_prev_front_chunks):
                c_loss = front_dic_loss(
                    up, ut, dt, dt_prev,
                    node_x, node_y, x_bins, path_sigma, crack_y)
                if args.front_dic_elastic_weight != 0.0:
                    c_loss = c_loss + args.front_dic_elastic_weight * (
                        dic_band_loss(up, ut, node_x, node_y, crack_y,
                                      notch_x=a))
                chunk_losses.append(c_loss)
            pred_regularizer = torch.stack([
                0.0 * dp.sum() for dp in prev_pred_chunks
            ]).sum()
            loss = torch.stack(chunk_losses).mean() + pred_regularizer
        elif args.obs_mode == 'sensor_strain_dic':
            u_sensor_pred = solver._last_u_snapshots
            sensor_xs = torch.tensor(
                _parse_float_csv(args.sensor_xs), dtype=dtype, device=device)
            sensor_ys = torch.tensor(
                _parse_float_csv(args.sensor_ys), dtype=dtype, device=device)
            chunk_losses = [
                sensor_strain_dic_loss(
                    up, ut, node_x, node_y, sensor_xs, sensor_ys,
                    sigma_x=args.sensor_sigma_x,
                    sigma_y=args.sensor_sigma_y)
                for up, ut in zip(u_sensor_pred, u_target_sensor_chunks)
            ]
            loss = torch.stack(chunk_losses).mean()
            if args.sensor_extent_weight != 0.0 and snaps_pred is not None:
                extent_terms = []
                zero_dp = torch.zeros_like(snaps_pred[0])
                prev_pred_chunks = [zero_dp] + [
                    d.detach() for d in snaps_pred[:-1]
                ]
                zero_dt = torch.zeros_like(d_target_front_chunks[0])
                target_prev = [zero_dt] + [
                    d.detach() for d in d_target_front_chunks[:-1]
                ]
                for dp, dp_prev, dt, dt_prev in zip(
                        snaps_pred, prev_pred_chunks,
                        d_target_front_chunks, target_prev):
                    extent_terms.append(front_localised_path_loss(
                        dp, dp_prev, dt, dt_prev,
                        node_x, node_y, x_bins, path_sigma, crack_y))
                loss = loss + args.sensor_extent_weight * torch.stack(
                    extent_terms).mean()
        elif args.obs_mode == 'load_disp':
            loads_pred_t = torch.stack(loads_pred)
            scale = loads_target.abs().max() + 1e-12
            loss = (((loads_pred_t - loads_target) / scale) ** 2).mean()
        else:
            loss = ((d_pred - d_target_full) ** 2).mean()
        if not loss.requires_grad:
            loss = loss + init_flat.sum() * 0.0
        fwd_s = time.time() - t_fwd
        t_bwd = time.time()
        loss.backward()
        bwd_s = time.time() - t_bwd
        # Gradient diagnostic: param-space norm.
        gnorm = float(init_flat.grad.norm()) if init_flat.grad is not None else float('nan')
        align = _gradient_alignment_report()
        if align:
            last_grad_alignment.clear()
            last_grad_alignment.update(align)
            print(f"  [grad-dir] -g·(truth-p)="
                  f"{align['descent_dot_to_truth']:.4e}  "
                  f"cos(-g,truth-p)="
                  f"{align['cos_descent_truth']:.4e}",
                  flush=True)
        if args.grad_clip_norm is not None and init_flat.grad is not None:
            torch.nn.utils.clip_grad_norm_([init_flat], args.grad_clip_norm)
            gnorm_clip = float(init_flat.grad.norm())
        else:
            gnorm_clip = None
        clip_str = (f"  |g|clip={gnorm_clip:.4e}"
                    if gnorm_clip is not None else "")
        print(f"  [iter {it_now} closure call {cc}] "
              f"loss={float(loss.detach()):.4e}  "
              f"|g|={gnorm:.4e}{clip_str}  "
              f"fwd={fwd_s:.1f}s  bwd={bwd_s:.1f}s",
              flush=True)
        counter['fwd'] += 1
        return loss

    def eval_front_dic_loss_no_grad():
        if args.tbptt_chunk_size > 0 or args.obs_mode != 'front_dic':
            raise NotImplementedError(
                "--tbptt_optimizer sgd_backtrack is currently implemented "
                "only for full-BPTT --obs_mode front_dic.")
        with torch.no_grad():
            E_eval = gaussian_E_field_multi(
                centroids, _assemble_particles(init_flat.detach()),
                E_BULK, ALPHA_TRUTH, SIGMA_INC)
            _, snaps_eval, _ = run_forward(
                solver, loading, E_eval, n_steps,
                snapshot_steps=snap_steps,
                record_u_snapshots=True)
            u_eval = solver._last_u_snapshots
            chunk_losses = []
            for up, ut, dt, dt_prev in zip(
                    u_eval,
                    u_target_front_chunks,
                    d_target_front_chunks,
                    d_target_prev_front_chunks):
                c_loss = front_dic_loss(
                    up, ut, dt, dt_prev,
                    node_x, node_y, x_bins, path_sigma, crack_y)
                if args.front_dic_elastic_weight != 0.0:
                    c_loss = c_loss + args.front_dic_elastic_weight * (
                        dic_band_loss(up, ut, node_x, node_y, crack_y,
                                      notch_x=a))
                chunk_losses.append(c_loss)
            loss_eval = torch.stack(chunk_losses).mean()
        counter['fwd'] += 1
        return float(loss_eval.detach().cpu())

    # TBPTT (#288): default to Adam because TBPTT gradients are biased
    # estimators of full-BPTT gradients; L-BFGS strong-Wolfe line search
    # can stall when the descent direction it trusts disagrees with the
    # biased gradient. Override with --tbptt_optimizer=lbfgs at your own
    # risk for a TBPTT-vs-LBFGS sanity check.
    if args.tbptt_optimizer == 'adam':
        opt = torch.optim.Adam([init_flat], lr=args.tbptt_lr)
    elif args.tbptt_optimizer in ('sgd', 'sgd_backtrack'):
        opt = torch.optim.SGD([init_flat], lr=args.tbptt_lr)
    else:
        opt = torch.optim.LBFGS(
            [init_flat], lr=1.0, max_iter=1,
            tolerance_grad=1e-12, tolerance_change=1e-12,
            history_size=10, line_search_fn='strong_wolfe',
        )

    # Restore L-BFGS history vectors from the checkpoint after the
    # optimizer is constructed (state_dict references the parameter
    # group keyed by id, so optimizer must exist first).
    if inv_resume and 'optimizer_state' in ckpt:
        opt.load_state_dict(ckpt['optimizer_state'])
        print(f"  L-BFGS state restored: "
              f"{len(opt.state.get(opt.param_groups[0]['params'][0], {}).get('old_dirs', []))} "
              f"history vectors.", flush=True)

    if args.grad_projection_probe:
        print("\n[grad-probe] Evaluating initial gradient direction ...",
              flush=True)
        counter['iter'] = 0
        loss_v = float(closure().detach())
        report = dict(last_grad_alignment)
        report.update({
            'loss': loss_v,
            'particles': _assemble_particles().detach().cpu().numpy()
                         .reshape(-1, 2).tolist(),
            'truth_particles': [list(p) for p in truth_pts],
            'free_particle_indices': free_particle_indices,
            'obs_mode': args.obs_mode,
            'tbptt_chunk_size': args.tbptt_chunk_size,
            'n_steps': n_steps,
        })
        out_path = os.path.join(out_dir, 'grad_projection_probe.json')
        with open(out_path, 'w') as fh:
            json.dump(report, fh, indent=2)
        print(f"[grad-probe] wrote {out_path}; skipping optimisation.")
        return

    print(f"\n[2/3] {args.tbptt_optimizer.upper()} on "
          f"{len(free_idx)}-vector free subset {free_particle_indices}, "
          f"{args.n_iters} outer iterations "
          f"(starting at iter {start_iter}) ...", flush=True)
    t_inv = time.time()
    for it in range(start_iter, args.n_iters):
        counter['iter'] = it
        t_outer = time.time()
        print(f"\n=== outer iteration {it}/{args.n_iters - 1} "
              f"({counter['fwd']} closure calls so far) ===", flush=True)
        # Adam.step doesn't run a line search so we invoke the closure
        # directly to compute loss + .grad, then call opt.step() (no
        # closure). L-BFGS keeps the closure-based API.
        if args.tbptt_optimizer in ('adam', 'sgd'):
            loss_v = float(closure().detach())
            opt.step()
        elif args.tbptt_optimizer == 'sgd_backtrack':
            loss_v = float(closure().detach())
            if init_flat.grad is None:
                raise RuntimeError("sgd_backtrack requires a gradient.")
            old_flat = init_flat.detach().clone()
            direction = -init_flat.grad.detach().clone()
            best_loss = loss_v
            best_flat = old_flat
            best_step = 0.0
            for trial in range(max(1, int(args.line_search_trials))):
                step_len = args.tbptt_lr / (2 ** trial)
                with torch.no_grad():
                    init_flat.copy_(old_flat + step_len * direction)
                trial_loss = eval_front_dic_loss_no_grad()
                print(f"    [line-search] trial {trial}: "
                      f"step={step_len:.4e} loss={trial_loss:.4e}",
                      flush=True)
                if trial_loss < best_loss:
                    best_loss = trial_loss
                    best_flat = init_flat.detach().clone()
                    best_step = step_len
            with torch.no_grad():
                init_flat.copy_(best_flat)
            if best_step == 0.0:
                print("    [line-search] rejected all candidate steps; "
                      "kept previous parameters.", flush=True)
            else:
                print(f"    [line-search] accepted step={best_step:.4e} "
                      f"loss={best_loss:.4e}", flush=True)
            loss_v = best_loss
        else:
            loss_v = float(opt.step(closure))
        cur = _assemble_particles().detach()
        err_per_particle, max_err, truth_perm, _ = _particle_error_report(cur)
        h_entry = {
            'iter': it,
            'particles': cur.cpu().numpy().reshape(-1, 2).tolist(),
            'loss': loss_v,
            'pos_err_per_particle_mm': err_per_particle,
            'pos_err_max_mm': max_err,
            'truth_permutation': truth_perm,
            'forward_evals': counter['fwd'],
            'free_particle_indices': free_particle_indices,
        }
        # Back-compat: plot_stiff_inclusion.py reads h["x_h"], h["y_h"].
        if args.n_particles == 1:
            h_entry['x_h'] = float(cur[0])
            h_entry['y_h'] = float(cur[1])
            h_entry['pos_err_mm'] = err_per_particle[0]
        history.append(h_entry)
        cur_str = ", ".join(f"({float(cur[2*i]):.2f},{float(cur[2*i+1]):.2f})"
                              for i in range(args.n_particles))
        print(f"  iter {it:2d}: {cur_str}  max_err={max_err:.3f} mm  "
              f"loss={loss_v:.3e}  fwd={counter['fwd']}")

        # Atomic checkpoint write: save to .tmp, then rename. This way an
        # interrupted write never corrupts inv_checkpoint.pt.
        ckpt_tmp = ckpt_path + '.tmp'
        torch.save({
            'next_iter':      it + 1,
            'free_flat':      init_flat.detach().cpu().numpy(),
            'fixed_flat':     fixed_flat.detach().cpu().numpy(),
            'init_flat':      cur.cpu().numpy(),
            'optimizer_state': opt.state_dict(),
            'counter_fwd':    counter['fwd'],
            'history':        history,
            'n_particles':    args.n_particles,
            'obs_mode':       args.obs_mode,
            'n_steps':        n_steps,
            'argv':           vars(args),
        }, ckpt_tmp)
        os.replace(ckpt_tmp, ckpt_path)
        print(f"  ckpt -> {ckpt_path} (iter {it+1} ready to resume)",
              flush=True)

        if max_err < max(0.05, h_crack):
            print(f"  Converged: max pos err < max(0.05, h_crack) at iter {it}")
            break

    wall = time.time() - t_inv
    cur = _assemble_particles().detach()
    err_per_particle, max_err, truth_perm, matched_truth_np = _particle_error_report(cur)
    print(f"\n[3/3] Result: {counter['fwd']} forward sims, {wall:.1f} s")
    for i in range(args.n_particles):
        print(f"  particle {i}: recovered=({float(cur[2*i]):.3f},"
              f"{float(cur[2*i+1]):.3f})  matched_truth="
              f"({matched_truth_np[i,0]:.3f},{matched_truth_np[i,1]:.3f})  "
              f"err={err_per_particle[i]:.3f} mm")

    with torch.no_grad():
        E_rec = gaussian_E_field_multi(centroids, cur,
                                        E_BULK, ALPHA_TRUTH, SIGMA_INC)
        d_rec, _, _ = run_forward(solver, loading, E_rec, n_steps)
        d_rec = d_rec.detach().clone()
    rec_save = {
        'd_recovered': d_rec.cpu().numpy(),
        'E_recovered': E_rec.cpu().numpy(),
        'recovered_particles': cur.cpu().numpy().reshape(-1, 2),
    }
    # Back-compat for plot_stiff_inclusion.py (paper-1 regen).
    if args.n_particles == 1:
        rec_save['x_recovered'] = float(cur[0])
        rec_save['y_recovered'] = float(cur[1])
    np.savez(os.path.join(out_dir, 'damage_recovered.npz'), **rec_save)

    json_out = {
        'truth_particles':     [list(p) for p in truth_pts],
        'truth_permutation':   truth_perm,
        'init_particles':      [list(p) for p in init_pts],
        'recovered_particles': cur.cpu().numpy().reshape(-1, 2).tolist(),
        'free_particle_indices': free_particle_indices,
        'pos_err_per_particle_mm': err_per_particle,
        'pos_err_max_mm':      max_err,
        'forward_sims':        counter['fwd'],
        'wall_time_s':         wall,
        'n_steps':             n_steps,
        'h_crack_mm':          h_crack,
        'mesh_nodes':          solver.mesh.n_nodes,
        'mesh_elements':       solver.mesh.n_elems,
        'delta_U_mm':          delta_U,
        'alpha':               ALPHA_TRUTH,
        'sigma_mm':            SIGMA_INC,
        'inclusion_profile':   args.inclusion_profile,
        'level_set_radius_mm': args.level_set_radius,
        'level_set_epsilon_mm': args.level_set_epsilon,
        'tau_ramp_us':         args.tau_ramp_us,
        'damping_zeta':        args.damping_zeta,
        'n_particles':         args.n_particles,
        'obs_mode':            args.obs_mode,
        'n_tips':              args.n_tips if args.obs_mode == 'tips' else None,
        'n_path_bins':         args.n_path_bins if args.obs_mode == 'path' else None,
        'path_noise_std_mm':   args.path_noise_std if args.obs_mode == 'path' else 0.0,
        'path_noise_seed':     args.path_noise_seed if args.obs_mode == 'path' else None,
        'n_load_samples':      args.n_load_samples if args.obs_mode == 'load_disp' else None,
        'checkpoint_chunks':   args.checkpoint_chunks,
        'history':             history,
    }
    if path_noise_info is not None:
        json_out['path_noise_realized_active_sigma_mm'] = (
            path_noise_info['realized_active_sigma_mm'])
        json_out['path_noise_active_bins'] = path_noise_info['active_bins']
    if args.n_particles == 1:
        # Back-compat for plot_stiff_inclusion.py and paper-1 regen flow.
        json_out['truth']     = {'x_h': truth_pts[0][0], 'y_h': truth_pts[0][1]}
        json_out['init']      = {'x_h': init_pts[0][0],  'y_h': init_pts[0][1]}
        json_out['recovered'] = {'x_h': float(cur[0]),    'y_h': float(cur[1])}
        json_out['pos_err_mm'] = err_per_particle[0]
    with open(os.path.join(out_dir, 'demo_inverse_stiff_inclusion.json'),
              'w') as fh:
        json.dump(json_out, fh, indent=2)
    print(f"  Saved: {out_dir}/")


if __name__ == '__main__':
    main()
