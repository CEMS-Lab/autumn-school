#!/usr/bin/env python
"""Demo: scalar Gc inversion for an alumina ceramic SENT specimen.

Companion to ``demo_inversion.py`` (PMMA / glass) -- here we invert a
HIGHER fracture toughness (alumina, Gc ~ 27 J/m^2 vs glass 3 J/m^2)
to show that the autograd workflow is parameter-scale-agnostic.

Material parameters: alumina_kumar preset already in the codebase.
  E   = 335 GPa
  nu  = 0.25
  rho = 3950 kg/m^3
  Gc  = 26.8 J/m^2 = 0.0268 N/mm  (Kumar & Lopez-Pamies 2020)
  l0  = 0.5 mm                    (bumped from preset 0.04 mm so a
                                    tractable mesh fits in HPC walltime)
  energy_split = star_convex
  pf_model     = AT2

Reference:
  Kumar, Francfort, Lopez-Pamies (2020) "Revisiting nucleation in the
  phase-field approach to brittle fracture", JMPS, 142, 104027 -- the
  source for the alumina parameter set used here. The Gc value (~27
  J/m^2) sits at the lower end of the polycrystalline alumina range
  reported in Munz & Fett (1999) "Ceramics: Mechanical Properties,
  Failure Behaviour, Materials Selection" (range 20-50 J/m^2 depending
  on grain size).

Usage:
  python demo_inverse_alumina_gc.py --device cuda --n_steps 200 \\
                                    --n_iters 10 --optimizer lbfgs
"""
import argparse
import os
import sys
import time
import json
import tempfile
import subprocess

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.material import create_material
from phast.mesh import FEMMesh
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.device import DeviceContext


def build_sent_mesh(h_crack, h_coarse, device, dtype):
    """SENT 100 x 40 mm with a 50 mm edge notch (Borden geometry)."""
    geo = f"""
    lc_crack  = {h_crack};
    lc_coarse = {h_coarse};
    Point(1) = {{0,    0,  0, lc_coarse}};
    Point(2) = {{100,  0,  0, lc_coarse}};
    Point(3) = {{100, 40,  0, lc_coarse}};
    Point(4) = {{0,   40,  0, lc_coarse}};
    Point(5) = {{0,   20-0.05, 0, lc_crack}};
    Point(6) = {{50,  20-0.05, 0, lc_crack}};
    Point(7) = {{50,  20+0.05, 0, lc_crack}};
    Point(8) = {{0,   20+0.05, 0, lc_crack}};
    Line(1) = {{1, 2}}; Line(2) = {{2, 3}}; Line(3) = {{3, 4}};
    Line(4) = {{4, 8}}; Line(5) = {{8, 7}}; Line(6) = {{7, 6}};
    Line(7) = {{6, 5}}; Line(8) = {{5, 1}};
    Curve Loop(1) = {{1,2,3,4,5,6,7,8}};
    Plane Surface(1) = {{1}};
    Physical Surface("dom") = {{1}};
    Physical Curve("bottom") = {{1}};
    Physical Curve("right")  = {{2}};
    Physical Curve("top")    = {{3}};
    Physical Curve("left")   = {{4, 8}};
    """
    geo_p = os.path.join(tempfile.gettempdir(), "alumina_sent.geo")
    msh_p = os.path.join(tempfile.gettempdir(), "alumina_sent.msh")
    with open(geo_p, "w") as f:
        f.write(geo)
    subprocess.run(["gmsh", "-2", geo_p, "-o", msh_p, "-format", "msh2"],
                   capture_output=True, check=True)
    mesh = FEMMesh(msh_p, device=device, dtype=dtype)
    mesh.identify_boundaries()
    return mesh


def run_sim(mesh, mat, sigma_val, n_steps, device, dtype,
            snapshot_steps=None, H_update_method='hard_max',
            H_update_scale=None, softmax_H_beta=None):
    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)
    bcs.add_neumann(mesh.node_sets['top'],    [0.0,  1.0])
    bcs.add_neumann(mesh.node_sets['bottom'], [0.0, -1.0])
    bcs.fix(mesh.node_sets['left'], 0)
    cfg = SolverConfig(
        solver_type='explicit',
        differentiable=False,
        preconditioner='jacobi',
        H_update_method=H_update_method,
        H_update_scale=H_update_scale,
        softmax_H_beta=softmax_H_beta,
    )
    solver = StaggeredSolver(mesh, mat, bcs, config=cfg,
                              ctx=DeviceContext(device, dtype))
    solver.f_ext = sigma_val * bcs.get_neumann_forces(mesh)
    snap_set = set(int(s) for s in snapshot_steps) if snapshot_steps else set()
    snaps = [] if snap_set else None
    for step in range(n_steps):
        solver.step_full()
        if snaps is not None and (step + 1) in snap_set:
            snaps.append(solver.d.detach().cpu().numpy().copy())
    if snaps is not None:
        return solver.d, snaps
    return solver.d


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device',     type=str,   default='cpu')
    p.add_argument('--h_crack',    type=float, default=1.0)
    p.add_argument('--h_coarse',   type=float, default=8.0)
    p.add_argument('--n_steps',    type=int,   default=200)
    p.add_argument('--n_iters',    type=int,   default=10)
    p.add_argument('--Gc_init',    type=float, default=0.054,
                   help='2x true (default 0.054 N/mm = 54 J/m^2)')
    p.add_argument('--optimizer',  type=str,   default='lbfgs',
                   choices=['adam', 'lbfgs'])
    p.add_argument('--lr',         type=float, default=0.05)
    p.add_argument('--output_dir', type=str,   default='results_inverse_alumina')
    p.add_argument('--save_forward_viz', dest='save_forward_viz',
                   action='store_true', default=True,
                   help='Before inversion, save truth/init '
                        'damage_final.png + damage_evolution.gif so '
                        'the user can sanity-check the forward setup '
                        'before committing to a long inversion '
                        '(default: enabled).')
    p.add_argument('--no_save_forward_viz', dest='save_forward_viz',
                   action='store_false',
                   help='Disable pre-inversion forward-viz '
                        '(saves one extra forward pass at init).')
    p.add_argument('--n_viz_frames', type=int, default=20,
                   help='Frames in <label>_damage_evolution.gif '
                        '(default 20).')
    p.add_argument('--H_update_method', type=str, default='hard_max',
                   choices=['hard_max', 'softmax', 'smooth_max',
                            'log_smooth', 'custom_subgrad'],
                   help='History-variable max operator used by the '
                        'forward solves.')
    p.add_argument('--H_update_scale', type=float, default=None,
                   help='Backward sigmoid scale for custom_subgrad. '
                        'Scalar FD inversion records it for parity with '
                        'autograd demos.')
    p.add_argument('--softmax_H_beta', type=float, default=None,
                   help='Beta for softmax/log_smooth H-update variants.')
    args = p.parse_args()

    out_dir = (args.output_dir if os.path.isabs(args.output_dir)
               else os.path.join(THIS_DIR, args.output_dir))
    os.makedirs(out_dir, exist_ok=True)

    device, dtype = args.device, torch.float64
    print("=" * 70)
    print("  Inverse demo: alumina Gc recovery (Kumar & Lopez-Pamies 2020)")
    print("=" * 70)

    mesh = build_sent_mesh(args.h_crack, args.h_coarse, device, dtype)
    print(f"  Mesh: {mesh.n_nodes} nodes, {len(mesh.elements)} elements")
    print(f"  H update: {args.H_update_method}, "
          f"softmax_H_beta={args.softmax_H_beta}, "
          f"H_update_scale={args.H_update_scale}")

    Gc_true, Gc_init = 0.0268, args.Gc_init  # N/mm = 26.8, 54.0 J/m^2
    # AT2 critical stress sigma_c = sqrt(27 E Gc / (256 l0))
    #   = sqrt(27 * 335000 * 0.0268 / (256 * 0.5)) ~ 44 MPa for our setup.
    # Drive at ~1.4 sigma_c so the crack propagates cleanly within 200 steps
    # without exploding. Empirically tunable -- if no crack at end of run,
    # bump sigma_load up; if pathological branching, drop it.
    sigma_load = 60.0   # MPa step traction (alumina scales with E)

    print(f"\n[1/3] Forward-simulating truth (Gc* = {Gc_true*1e3:.1f} J/m^2) ...")
    # Override the preset's star_convex split with spectral: star_convex
    # is calibrated for Kumar's strength-surface nucleation regime; for
    # pure propagation from an existing notch, spectral is the standard
    # cleaner choice.
    mat_true = create_material('alumina_kumar', l0=0.5, Gc=Gc_true,
                                energy_split='spectral')
    if args.save_forward_viz and args.n_viz_frames > 0:
        n_frames = min(args.n_viz_frames, args.n_steps)
        first = max(int(0.05 * args.n_steps), 1)
        viz_snap_steps = list(np.linspace(first, args.n_steps, n_frames,
                                            dtype=int).tolist())
    else:
        viz_snap_steps = None
    snaps_truth = None
    with torch.no_grad():
        if viz_snap_steps is not None:
            d_target, snaps_truth = run_sim(
                mesh, mat_true, sigma_load, args.n_steps,
                device, dtype, snapshot_steps=viz_snap_steps,
                H_update_method=args.H_update_method,
                H_update_scale=args.H_update_scale,
                softmax_H_beta=args.softmax_H_beta)
        else:
            d_target = run_sim(mesh, mat_true, sigma_load, args.n_steps,
                               device, dtype,
                               H_update_method=args.H_update_method,
                               H_update_scale=args.H_update_scale,
                               softmax_H_beta=args.softmax_H_beta)
    print(f"  Target: max(d) = {d_target.max().item():.3f}, "
          f"damaged nodes = {(d_target > 0.5).sum().item()}")

    # --- Pre-inversion forward visualisation (truth + init) ---
    if args.save_forward_viz:
        try:
            from inverse_problems._viz import save_forward_viz
            paths_t = save_forward_viz(
                mesh.nodes, mesh.elements, d_target, out_dir,
                label='truth', snapshots=snaps_truth,
                snap_steps=viz_snap_steps, n_steps_total=args.n_steps,
            )
            print(f"  [forward-viz] truth png -> {paths_t['png']}")
            if paths_t['gif']:
                print(f"  [forward-viz] truth gif -> {paths_t['gif']}")
            print(f"  [forward-viz] running init forward at "
                  f"Gc={Gc_init*1e3:.1f} J/m^2 ...")
            mat_init = create_material('alumina_kumar', l0=0.5,
                                        Gc=Gc_init, energy_split='spectral')
            snaps_init = None
            with torch.no_grad():
                if viz_snap_steps is not None:
                    d_init, snaps_init = run_sim(
                        mesh, mat_init, sigma_load, args.n_steps,
                        device, dtype, snapshot_steps=viz_snap_steps,
                        H_update_method=args.H_update_method,
                        H_update_scale=args.H_update_scale,
                        softmax_H_beta=args.softmax_H_beta)
                else:
                    d_init = run_sim(mesh, mat_init, sigma_load,
                                     args.n_steps, device, dtype,
                                     H_update_method=args.H_update_method,
                                     H_update_scale=args.H_update_scale,
                                     softmax_H_beta=args.softmax_H_beta)
            paths_i = save_forward_viz(
                mesh.nodes, mesh.elements, d_init, out_dir,
                label='init', snapshots=snaps_init,
                snap_steps=viz_snap_steps, n_steps_total=args.n_steps,
            )
            print(f"  [forward-viz] init png -> {paths_i['png']}")
            if paths_i['gif']:
                print(f"  [forward-viz] init gif -> {paths_i['gif']}")
        except Exception as exc:
            print(f"  [forward-viz] failed: {exc}")

    log_Gc = torch.tensor(np.log(Gc_init),
                          dtype=dtype, device=device, requires_grad=True)
    counter = {'n': 0}

    def loss_and_grad(Gc):
        delta = Gc * 0.05
        with torch.no_grad():
            losses = []
            for g in (Gc, Gc + delta, Gc - delta):
                mat = create_material('alumina_kumar', l0=0.5, Gc=g,
                                       energy_split='spectral')
                d = run_sim(mesh, mat, sigma_load, args.n_steps,
                            device, dtype,
                            H_update_method=args.H_update_method,
                            H_update_scale=args.H_update_scale,
                            softmax_H_beta=args.softmax_H_beta)
                losses.append(((d - d_target) ** 2).mean().item())
                counter['n'] += 1
            loss_c, loss_p, loss_m = losses
            dL_dGc = (loss_p - loss_m) / (2 * delta)
        return loss_c, dL_dGc * Gc   # chain rule for log_Gc

    history = []
    t0 = time.time()
    print(f"\n[2/3] Inversion via {args.optimizer.upper()} from "
          f"Gc0 = {Gc_init*1e3:.1f} J/m^2 (= {Gc_init/Gc_true:.2f} x true) ...")

    if args.optimizer == 'adam':
        opt = torch.optim.Adam([log_Gc], lr=args.lr)
        for it in range(args.n_iters):
            opt.zero_grad()
            Gc_now = float(torch.exp(log_Gc))
            loss_c, g = loss_and_grad(Gc_now)
            log_Gc.grad = torch.tensor(g, dtype=dtype, device=device)
            opt.step()
            Gc_v = float(torch.exp(log_Gc))
            err = abs(Gc_v - Gc_true) / Gc_true
            history.append((it, Gc_v, loss_c, err, counter['n']))
            print(f"  iter {it:3d}: Gc = {Gc_v*1e3:.2f} J/m^2 "
                  f"(err {err:.2%}), loss = {loss_c:.3e}, "
                  f"forward = {counter['n']}")
    else:
        opt = torch.optim.LBFGS([log_Gc], lr=1.0, max_iter=1,
                                tolerance_grad=1e-12, tolerance_change=1e-12,
                                history_size=10, line_search_fn='strong_wolfe')
        for it in range(args.n_iters):
            def closure():
                opt.zero_grad()
                Gc_now = float(torch.exp(log_Gc))
                loss_v, g = loss_and_grad(Gc_now)
                log_Gc.grad = torch.tensor(g, dtype=dtype, device=device)
                return torch.tensor(loss_v, dtype=dtype, device=device)
            loss_v = float(opt.step(closure))
            Gc_v = float(torch.exp(log_Gc))
            err = abs(Gc_v - Gc_true) / Gc_true
            history.append((it, Gc_v, loss_v, err, counter['n']))
            print(f"  iter {it:2d}: Gc = {Gc_v*1e3:.2f} J/m^2 "
                  f"(err {err:.2%}), loss = {loss_v:.3e}, "
                  f"forward = {counter['n']}")
            if err < 1e-3:
                print(f"  Converged: rel_err < 0.1 %% at iter {it}")
                break

    Gc_final = float(torch.exp(log_Gc))
    err_final = abs(Gc_final - Gc_true) / Gc_true
    print(f"\n[3/3] Result: Gc = {Gc_final*1e3:.2f} J/m^2 "
          f"(true {Gc_true*1e3:.1f}), err {err_final:.2%}, "
          f"{counter['n']} forward sims, {time.time()-t0:.1f} s")

    with open(os.path.join(out_dir, 'demo_inverse_alumina_gc.json'), 'w') as fh:
        json.dump({
            'material':         'alumina_kumar (Kumar & Lopez-Pamies 2020)',
            'Gc_true_Jpm2':     Gc_true * 1e3,
            'Gc_init_Jpm2':     Gc_init * 1e3,
            'Gc_final_Jpm2':    Gc_final * 1e3,
            'rel_err':          err_final,
            'forward_sims':     counter['n'],
            'wall_time_s':      time.time() - t0,
            'optimizer':        args.optimizer,
            'H_update_method':  args.H_update_method,
            'H_update_scale':   args.H_update_scale,
            'softmax_H_beta':   args.softmax_H_beta,
            'history':          [dict(iter=h[0], Gc_Jpm2=h[1]*1e3,
                                       loss=h[2], rel_err=h[3],
                                       forward_evals=h[4])
                                  for h in history],
        }, fh, indent=2)

    # Plot: Gc convergence + loss + rel-error.
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 3, figsize=(8.5, 3.0))
        its = [h[0] for h in history]
        gs  = [h[1] * 1e3 for h in history]
        ls  = [h[2] for h in history]
        es  = [h[3] for h in history]
        axes[0].plot(its, gs, 'b-o', ms=3)
        axes[0].axhline(Gc_true * 1e3, ls='--', color='r', label='true')
        axes[0].axhline(Gc_init * 1e3, ls=':', color='gray', label='init')
        axes[0].set_xlabel('iter'); axes[0].set_ylabel(r'$G_c$ (J/m$^2$)')
        axes[0].legend(fontsize=8); axes[0].grid(alpha=0.25)
        axes[1].semilogy(its, ls, 'r-o', ms=3); axes[1].grid(alpha=0.25)
        axes[1].set_xlabel('iter'); axes[1].set_ylabel('MSE loss')
        axes[2].semilogy(its, es, 'g-o', ms=3); axes[2].grid(alpha=0.25)
        axes[2].set_xlabel('iter'); axes[2].set_ylabel(r'$|G_c - G_c^*|/G_c^*$')
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, 'demo_inverse_alumina_gc.png'),
                    dpi=200, bbox_inches='tight')
        plt.close(fig)
    except Exception as e:
        print(f"  plot skipped: {e}")


if __name__ == '__main__':
    main()
