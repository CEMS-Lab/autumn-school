"""Signal-to-Noise-Ratio (SNR) preconditioner.

Reference
---------
Litman, R. & Guo, Y. (2026). *A Theory of Generalization in Deep
Learning*. arXiv:2605.01172. Section 6 / Corollary 6.3 and the
"SNR gate" of section F.4.

Math
----
For each parameter coordinate ``k`` Adam already maintains running
estimates of the gradient mean ``m`` and second moment ``v``.  Litman &
Guo argue that, under the empirical-NTK partition, the *signal* in
``m`` is rapidly damped relative to the *noise* in ``v``, and that one
should attenuate updates whose squared mean does not exceed the
variance:

.. math::

    \\hat{\\sigma}^2_k = \\hat{v}_k - \\hat{m}_k^2,
    \\qquad
    \\mathrm{SNR}_k = \\frac{\\hat{m}_k^2}{\\hat{m}_k^2 + \\hat{\\sigma}^2_k}
                    = \\frac{\\hat{m}_k^2}{\\hat{v}_k}.

Hatted quantities use Adam's standard bias correction.  The gate is
clipped to ``[snr_eps, 1]`` so a noise-free coordinate (``v == m**2``)
recovers vanilla Adam and a pure-noise coordinate (``m**2 / v -> 0``) is
attenuated to ``snr_eps``.

Faithfulness note
-----------------
Litman & Guo describe an additional EMA ``s`` of squared deviations
from the prior mean, used to construct an off-diagonal rate matrix
``A_b = g_bar g_bar^T - Sigma_b/(b-1)``.  For a per-parameter Adam
preconditioner the diagonal of that rate matrix is exactly
``m^2 - (v - m^2)/(b-1)``, which under ``b -> infinity`` (or a single
mini-batch viewed as a noisy gradient sample) collapses to the
coordinate-wise SNR ``m^2 / v`` used here.  This is the "SNR gate"
form of the preconditioner; the small-batch correction
``1/(b-1)`` is exposed via :attr:`batch_size` for callers who want it.

API
---
Two interfaces:

1. :class:`SNRPreconditioner` -- a stateless functor that, given a
   sequence of ``(grad, exp_avg, exp_avg_sq, step)`` tuples, returns
   per-parameter SNR multipliers.  Suitable as a hook on top of an
   existing optimizer.
2. :class:`SNRAdam` -- a thin subclass of :class:`torch.optim.Adam`
   that scales each parameter's gradient by the SNR gate before
   delegating to ``Adam.step``.  Adam's two existing moment buffers
   already provide ``m`` and ``v``; the "one extra state vector"
   claim of the paper applies if a separate slow EMA is used, so we
   document the choice to *reuse* Adam's buffers and not allocate
   extra state.
"""
from __future__ import annotations

from typing import Optional

import torch
from torch.optim import Adam


def _bias_correct(m: torch.Tensor, v: torch.Tensor, beta1: float, beta2: float, step: int):
    """Adam bias-corrected first and second moments.

    ``step`` is 1-indexed (matches torch.optim.Adam's `state['step']`).
    """
    bc1 = 1.0 - beta1 ** step
    bc2 = 1.0 - beta2 ** step
    return m / bc1, v / bc2


def snr_gate(
    m_hat: torch.Tensor,
    v_hat: torch.Tensor,
    *,
    eps: float = 1e-3,
    floor: float = 1e-3,
    batch_size: Optional[int] = None,
) -> torch.Tensor:
    """Per-parameter SNR multiplier in ``[floor, 1]``.

    Parameters
    ----------
    m_hat, v_hat : Tensor
        Bias-corrected first and second moment EMAs (same shape).
    eps : float
        Numerical floor added to denominator.
    floor : float
        Lower clip applied after the SNR ratio.
    batch_size : int, optional
        If provided and >1, applies Litman-Guo's small-batch
        correction:  ``snr = (m^2 - (v - m^2)/(b-1)) / v`` (clamped
        non-negative before the floor).
    """
    m_sq = m_hat * m_hat
    if batch_size is not None and batch_size > 1:
        var = (v_hat - m_sq).clamp_min(0.0)
        signal = (m_sq - var / (batch_size - 1)).clamp_min(0.0)
        ratio = signal / (v_hat + eps)
    else:
        ratio = m_sq / (v_hat + eps)
    return ratio.clamp(min=floor, max=1.0)


class SNRPreconditioner:
    """Stateless SNR-gate functor.

    Maintains *no* internal state -- the caller passes Adam's running
    moments in.  This makes it composable with any optimizer that
    already estimates ``m`` and ``v``.

    Example
    -------
    >>> precond = SNRPreconditioner(beta1=0.9, beta2=0.999)
    >>> gate = precond(m, v, step=10)        # uses bias-corrected moments
    >>> grad_scaled = grad * gate
    """

    def __init__(
        self,
        beta1: float = 0.9,
        beta2: float = 0.999,
        eps: float = 1e-3,
        floor: float = 1e-3,
        batch_size: Optional[int] = None,
    ) -> None:
        self.beta1 = beta1
        self.beta2 = beta2
        self.eps = eps
        self.floor = floor
        self.batch_size = batch_size

    def __call__(
        self,
        m: torch.Tensor,
        v: torch.Tensor,
        step: int,
    ) -> torch.Tensor:
        m_hat, v_hat = _bias_correct(m, v, self.beta1, self.beta2, max(step, 1))
        return snr_gate(
            m_hat,
            v_hat,
            eps=self.eps,
            floor=self.floor,
            batch_size=self.batch_size,
        )

    def extra_repr(self) -> str:
        return (
            f"beta1={self.beta1}, beta2={self.beta2}, eps={self.eps}, "
            f"floor={self.floor}, batch_size={self.batch_size}"
        )

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self.extra_repr()})"


class SNRAdam(Adam):
    """Adam with per-parameter SNR gating (Litman & Guo 2026).

    Drop-in replacement for :class:`torch.optim.Adam`.  After Adam's
    moment EMAs are updated, each parameter's gradient is multiplied
    by ``snr_gate(m_hat, v_hat)`` before the standard Adam step.

    Notes
    -----
    * Reuses Adam's existing ``exp_avg`` (= ``m``) and ``exp_avg_sq``
      (= ``v``) buffers; no extra state is allocated.
    * Differentiability is unaffected: the gate is applied to ``.grad``
      after the backward pass, so it never enters the autograd graph.
    """

    def __init__(
        self,
        params,
        lr: float = 1e-3,
        betas=(0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.0,
        amsgrad: bool = False,
        *,
        snr_eps: float = 1e-3,
        snr_floor: float = 1e-3,
        snr_batch_size: Optional[int] = None,
    ) -> None:
        super().__init__(
            params,
            lr=lr,
            betas=betas,
            eps=eps,
            weight_decay=weight_decay,
            amsgrad=amsgrad,
        )
        self.snr_eps = float(snr_eps)
        self.snr_floor = float(snr_floor)
        self.snr_batch_size = snr_batch_size

    @torch.no_grad()
    def step(self, closure=None):  # type: ignore[override]
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        # First, materialise Adam state on a no-op pre-pass so we can
        # read m/v before the actual update.  We do this by calling the
        # parent step with a temporary saved gradient set to zero --
        # but that would advance Adam's bookkeeping.  Instead, run the
        # SNR scaling using the *prior* state (state from the last
        # step), which is what the paper's "one extra state vector"
        # framing assumes (the gate uses the running estimate).
        for group in self.param_groups:
            beta1, beta2 = group["betas"]
            for p in group["params"]:
                if p.grad is None:
                    continue
                state = self.state[p]
                # state['step'] is created lazily inside Adam.step
                step_t = state.get("step", None)
                if step_t is None:
                    # First call: no prior moments exist; gate = 1 (no-op).
                    continue
                m = state["exp_avg"]
                v = state["exp_avg_sq"]
                step_int = int(step_t.item()) if torch.is_tensor(step_t) else int(step_t)
                if step_int < 1:
                    continue
                m_hat, v_hat = _bias_correct(m, v, beta1, beta2, step_int)
                gate = snr_gate(
                    m_hat,
                    v_hat,
                    eps=self.snr_eps,
                    floor=self.snr_floor,
                    batch_size=self.snr_batch_size,
                )
                p.grad.mul_(gate)

        # Now run the standard Adam step (which will update m, v, step).
        super().step(closure=None)
        return loss
