#!/usr/bin/env python
"""Demo: discrete adjoint with Griewank checkpointing for material
parameter recovery, paired against full-tape autograd on the same SENT
problem as ``demo_autograd_inversion.py``.

This is the headline demo for Paper 3 P3-C1: gradient-equivalence is
preserved while peak backward memory drops from O(N) to O(sqrt(N)) in
the unroll length.

Honest framing: the discrete adjoint does NOT cure chaotic-dynamics
gradient blow-up -- the adjoint recurrence shares the forward Lyapunov
spectrum (sign-flipped). The benefit is purely memory.

Outputs (under --output_dir):
  - history.json with iter loss/Gc/l0 trajectory + wall + peak-mem.
  - demo_discrete_adjoint_summary.png.
  - results.json: side-by-side autograd vs discrete-adjoint comparison.

Usage:
    python demo_inverse_discrete_adjoint.py
    python demo_inverse_discrete_adjoint.py --n_steps 50 --n_iters 10
"""
from __future__ import annotations

import argparse
import gc
import json
import math
import os
import sys
import tempfile
import threading
import time
from typing import Any, Callable, Dict, List, Tuple

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(THIS_DIR, "..", ".."))
PARENT = os.path.abspath(os.path.join(ROOT, ".."))
# Need both: PARENT for ``import phast`` (package),
# ROOT for ``import inverse_problems.adjoint`` (sibling subpackage).
if PARENT not in sys.path:
    sys.path.insert(0, PARENT)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from phast.material import Material  # noqa: E402
from phast.mesh import FEMMesh  # noqa: E402
from phast.boundary_conditions import BoundaryConditions  # noqa: E402
from phast.staggered_solver import StaggeredSolver, SolverConfig  # noqa: E402
from phast.mesh_generator import rectangular_sent  # noqa: E402
from phast.device import DeviceContext  # noqa: E402

from inverse_problems.adjoint import DiscreteAdjoint  # noqa: E402


def build_mesh(device, dtype, h_crack=1.5, h_coarse=3.0):
    mesh_path = os.path.join(tempfile.gettempdir(),
                              "demo_discrete_adjoint_mesh.msh")
    rectangular_sent(mesh_path, W=20.0, H=20.0, a=10.0, l0=0.5,
                     h_crack=h_crack, h_coarse=h_coarse)
    mesh = FEMMesh(mesh_path, device=device, dtype=dtype)
    mesh.identify_boundaries()
    return mesh


def build_solver(mesh, sigma=500.0, device="cpu"):
    mat = Material(E=210000.0, nu=0.30, Gc=2.7, l0=0.5, rho=7.8e-9,
                   energy_split="spectral", pf_model="AT2",
                   eta_residual=1e-7)
    ctx = DeviceContext(device=device, profile=False, compile_solvers=False)
    bcs = BoundaryConditions(mesh.n_nodes, device=ctx.device, dtype=ctx.dtype)
    bcs.add_neumann(mesh.node_sets["top"], [0.0, 1.0])
    bcs.add_neumann(mesh.node_sets["bottom"], [0.0, -1.0])
    bcs.fix(mesh.node_sets["left"], 0)
    cfg = SolverConfig(solver_type="explicit", dt_safety=0.5,
                       differentiable=True)
    solver = StaggeredSolver(mesh, mat, bcs, config=cfg, ctx=ctx)
    solver.f_ext = sigma * bcs.get_neumann_forces(mesh)
    return solver


# ---------------------------------------------------------------------------
# Stepper adapters around the in-place StaggeredSolver.step_full().
# ---------------------------------------------------------------------------

# State tuple convention: (u, v, a, d, H_elem, H_nodal)
STATE_ATTRS = ("u", "v", "a", "d", "H_elem", "H_nodal")


def _zero_state(solver):
    n_nodes = solver.mesh.n_nodes
    n_elems = len(solver.mesh.elements)
    dt = solver.u.dtype
    dv = solver.u.device
    return (
        torch.zeros(n_nodes, 2, dtype=dt, device=dv),
        torch.zeros(n_nodes, 2, dtype=dt, device=dv),
        torch.zeros(n_nodes, 2, dtype=dt, device=dv),
        torch.zeros(n_nodes, dtype=dt, device=dv),
        torch.zeros(n_elems, dtype=dt, device=dv),
        torch.zeros(n_nodes, dtype=dt, device=dv),
    )


def make_stepper(solver) -> Callable:
    def stepper(state, params):
        u, v, a, d, He, Hn = state
        Gc, l0 = params
        solver.u = u
        solver.v = v
        solver.a = a
        solver.d = d
        solver.H_elem = He
        solver.H_nodal = Hn
        solver.diff_Gc = Gc
        solver.diff_l0 = l0
        # Force fresh _step_count so explicit step honours dt schedule.
        solver._step_count = 0
        if hasattr(solver, "_explicit_step_count"):
            solver._explicit_step_count = 0
        solver.step_full()
        return (solver.u, solver.v, solver.a, solver.d,
                solver.H_elem, solver.H_nodal)

    return stepper


def run_full_autograd(solver, Gc_t, l0_t, n_steps):
    """Equivalent of demo_autograd_inversion.run_forward but returns
    final damage with full autograd graph."""
    state = _zero_state(solver)
    stepper = make_stepper(solver)
    params = (Gc_t, l0_t)
    for _ in range(n_steps):
        state = stepper(state, params)
    return state[3]  # damage


def run_discrete_adjoint(solver, Gc_t, l0_t, n_steps, n_checkpoints=None):
    state0 = _zero_state(solver)
    stepper = make_stepper(solver)
    if n_checkpoints is None:
        n_checkpoints = max(1, int(math.ceil(math.sqrt(n_steps))))
    adj = DiscreteAdjoint(stepper, n_steps=n_steps, n_checkpoints=n_checkpoints)
    final = adj(state0, (Gc_t, l0_t))
    return final[3]  # damage


# ---------------------------------------------------------------------------
# Memory sampler (live tensor bytes via gc).
# ---------------------------------------------------------------------------


def _live_tensor_bytes() -> int:
    total = 0
    seen = set()
    for obj in gc.get_objects():
        try:
            if isinstance(obj, torch.Tensor):
                try:
                    sp = obj.untyped_storage().data_ptr()
                    sz = obj.untyped_storage().nbytes()
                except Exception:
                    sp = obj.data_ptr()
                    sz = obj.element_size() * obj.nelement()
                if sp == 0 or sp in seen:
                    continue
                seen.add(sp)
                total += sz
        except Exception:
            continue
    return total


class PeakSampler:
    def __init__(self, interval_s=0.02):
        self.interval = interval_s
        self.peak = 0
        self._stop = threading.Event()
        self._th = None
        self._base = 0

    def __enter__(self):
        gc.collect()
        self._base = _live_tensor_bytes()
        self.peak = self._base
        self._stop.clear()
        self._th = threading.Thread(target=self._run, daemon=True)
        self._th.start()
        return self

    def _run(self):
        while not self._stop.is_set():
            try:
                cur = _live_tensor_bytes()
                if cur > self.peak:
                    self.peak = cur
            except Exception:
                pass
            time.sleep(self.interval)

    def __exit__(self, *exc):
        self._stop.set()
        if self._th is not None:
            self._th.join(timeout=1.0)
        cur = _live_tensor_bytes()
        if cur > self.peak:
            self.peak = cur

    @property
    def peak_mb(self) -> float:
        return (self.peak - self._base) / (1024 * 1024)


# ---------------------------------------------------------------------------
# Optimisation drivers.
# ---------------------------------------------------------------------------


def optimise(label: str, run_forward_fn, solver, n_steps, d_target,
             Gc_init, l0_init, Gc_true, l0_true, n_iters, lr, dtype, device):
    log_Gc = torch.tensor(float(np.log(Gc_init)), dtype=dtype,
                           device=device, requires_grad=True)
    log_l0 = torch.tensor(float(np.log(l0_init)), dtype=dtype,
                           device=device, requires_grad=True)
    optimizer = torch.optim.Adam([log_Gc, log_l0], lr=lr)
    history: Dict[str, List[Any]] = {
        "iter": [], "loss": [], "Gc": [], "l0": [], "wall": [], "peak_mb": [],
    }
    t0 = time.time()
    print(f"\n--- Optimising via {label} ---")
    for it in range(n_iters):
        ti = time.time()
        with PeakSampler() as ps:
            optimizer.zero_grad()
            Gc_t = torch.exp(log_Gc)
            l0_t = torch.exp(log_l0)
            d_pred = run_forward_fn(solver, Gc_t, l0_t, n_steps)
            loss = ((d_pred - d_target) ** 2).mean()
            loss.backward()
            optimizer.step()
        peak = ps.peak_mb
        history["iter"].append(it)
        history["loss"].append(float(loss.item()))
        history["Gc"].append(float(torch.exp(log_Gc).item()))
        history["l0"].append(float(torch.exp(log_l0).item()))
        history["wall"].append(time.time() - ti)
        history["peak_mb"].append(peak)
        if it % max(1, n_iters // 8) == 0 or it == n_iters - 1:
            print(f"  [{label}] it {it:3d} | loss={loss.item():.3e} "
                  f"| Gc={history['Gc'][-1]:.4f} l0={history['l0'][-1]:.4f} "
                  f"| wall={history['wall'][-1]:.1f}s peak={peak:.1f} MB",
                  flush=True)
    total = time.time() - t0
    history["total_wall_s"] = total
    history["final_Gc"] = history["Gc"][-1]
    history["final_l0"] = history["l0"][-1]
    history["mean_peak_mb"] = float(np.mean(history["peak_mb"]))
    return history


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--n_steps", type=int, default=40)
    p.add_argument("--n_iters", type=int, default=8)
    p.add_argument("--lr", type=float, default=0.4)
    p.add_argument("--device", type=str, default="cpu")
    p.add_argument("--h_crack", type=float, default=1.5)
    p.add_argument("--output_dir", type=str,
                   default="results_discrete_adjoint_demo")
    p.add_argument("--n_checkpoints", type=int, default=0,
                   help="0 = sqrt(N_steps) (default).")
    args = p.parse_args()

    out_dir = os.path.join(THIS_DIR, args.output_dir)
    os.makedirs(out_dir, exist_ok=True)
    print("=" * 70)
    print("  DEMO: Discrete adjoint (Griewank checkpointing) vs autograd")
    print("=" * 70)

    Gc_true, l0_true = 2.7, 0.5
    Gc_init, l0_init = 4.0, 0.75

    device = args.device
    dtype = torch.float64
    print(f"  Device: {device}, dtype: float64")
    print(f"  N_steps={args.n_steps}  N_iters={args.n_iters}")

    mesh = build_mesh(device, dtype, h_crack=args.h_crack)
    print(f"  Mesh: {int(mesh.n_nodes)} nodes, "
          f"{int(len(mesh.elements))} elements")
    solver = build_solver(mesh, sigma=500.0, device=device)

    # ---- target ----
    print("\n[1/3] Generating target damage at (Gc*, l0*) ...")
    with torch.no_grad():
        Gc_star = torch.tensor(Gc_true, dtype=dtype, device=device)
        l0_star = torch.tensor(l0_true, dtype=dtype, device=device)
        d_target = run_full_autograd(solver, Gc_star, l0_star,
                                      args.n_steps).detach().clone()
    print(f"  max(d_target)={d_target.max().item():.3f}, "
          f"damaged>0.1: {(d_target>0.1).sum().item()}")

    nck = args.n_checkpoints if args.n_checkpoints > 0 else \
          max(1, int(math.ceil(math.sqrt(args.n_steps))))
    print(f"  n_checkpoints (sqrt(N)): {nck}")

    # ---- optimise via autograd ----
    print("\n[2/3] Autograd baseline ...")
    hist_a = optimise("autograd", run_full_autograd, solver, args.n_steps,
                      d_target, Gc_init, l0_init, Gc_true, l0_true,
                      args.n_iters, args.lr, dtype, device)

    # ---- optimise via discrete adjoint ----
    print("\n[3/3] Discrete adjoint (Griewank) ...")
    def run_da(solver, Gc, l0, n):
        return run_discrete_adjoint(solver, Gc, l0, n, n_checkpoints=nck)
    hist_d = optimise("discrete-adjoint", run_da, solver, args.n_steps,
                      d_target, Gc_init, l0_init, Gc_true, l0_true,
                      args.n_iters, args.lr, dtype, device)

    # ---- summary ----
    summary = {
        "config": {
            "n_steps": args.n_steps, "n_iters": args.n_iters,
            "lr": args.lr, "n_checkpoints": nck,
            "device": args.device, "dtype": "float64",
            "h_crack": args.h_crack,
        },
        "truth": {"Gc": Gc_true, "l0": l0_true},
        "init": {"Gc": Gc_init, "l0": l0_init},
        "autograd": {
            "final_Gc": hist_a["final_Gc"],
            "final_l0": hist_a["final_l0"],
            "final_loss": hist_a["loss"][-1],
            "total_wall_s": hist_a["total_wall_s"],
            "mean_peak_mb": hist_a["mean_peak_mb"],
            "loss_history": hist_a["loss"],
        },
        "discrete_adjoint": {
            "final_Gc": hist_d["final_Gc"],
            "final_l0": hist_d["final_l0"],
            "final_loss": hist_d["loss"][-1],
            "total_wall_s": hist_d["total_wall_s"],
            "mean_peak_mb": hist_d["mean_peak_mb"],
            "loss_history": hist_d["loss"],
        },
        "comparison": {
            "wall_ratio_da_over_autograd":
                hist_d["total_wall_s"] / max(hist_a["total_wall_s"], 1e-9),
            "peak_mb_ratio_da_over_autograd":
                hist_d["mean_peak_mb"] / max(hist_a["mean_peak_mb"], 1e-9),
            "max_abs_loss_diff":
                float(np.max(np.abs(np.array(hist_a["loss"]) -
                                     np.array(hist_d["loss"])))),
        },
    }
    with open(os.path.join(out_dir, "results.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print("\n--- SUMMARY ---")
    print(f"  autograd:  Gc={hist_a['final_Gc']:.4f}  l0={hist_a['final_l0']:.4f}"
          f"  loss={hist_a['loss'][-1]:.3e}  wall={hist_a['total_wall_s']:.1f}s"
          f"  peak={hist_a['mean_peak_mb']:.1f} MB")
    print(f"  discrete:  Gc={hist_d['final_Gc']:.4f}  l0={hist_d['final_l0']:.4f}"
          f"  loss={hist_d['loss'][-1]:.3e}  wall={hist_d['total_wall_s']:.1f}s"
          f"  peak={hist_d['mean_peak_mb']:.1f} MB")
    print(f"  max abs loss-trajectory diff: "
          f"{summary['comparison']['max_abs_loss_diff']:.3e}")
    print(f"  -> {os.path.join(out_dir, 'results.json')}")

    # ---- figure ----
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.rcParams.update({
            "font.family": "serif", "font.serif": ["STIXGeneral"],
            "mathtext.fontset": "stix",
        })
        fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.4))
        ax = axes[0]
        ax.semilogy(hist_a["iter"], hist_a["loss"], "o-", color="C3",
                    ms=4, label="autograd")
        ax.semilogy(hist_d["iter"], hist_d["loss"], "s--", color="C0",
                    ms=4, label="discrete adjoint")
        ax.set_xlabel("iteration")
        ax.set_ylabel("MSE loss")
        ax.set_title("(a) loss convergence")
        ax.grid(True, alpha=0.3)
        ax.legend()
        ax = axes[1]
        ax.bar([0, 1],
               [hist_a["mean_peak_mb"], hist_d["mean_peak_mb"]],
               color=["C3", "C0"])
        ax.set_xticks([0, 1])
        ax.set_xticklabels(["autograd", "discrete\nadjoint"])
        ax.set_ylabel("mean peak memory [MB]")
        ax.set_title("(b) peak backward memory")
        ax.grid(True, axis="y", alpha=0.3)
        fig.tight_layout()
        out_png = os.path.join(out_dir, "demo_discrete_adjoint_summary.png")
        fig.savefig(out_png, dpi=160, bbox_inches="tight")
        plt.close(fig)
        print(f"  figure -> {out_png} "
              f"({os.path.getsize(out_png)/1024:.1f} kB)")
    except Exception as e:
        print(f"  figure skipped: {e}")


if __name__ == "__main__":
    main()
