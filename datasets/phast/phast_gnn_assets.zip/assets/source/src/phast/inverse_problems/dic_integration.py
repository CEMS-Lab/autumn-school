"""Differentiable DIC (Digital Image Correlation) integration for FEM fields.

Bridges unstructured FEM displacement fields and regular camera-pixel DIC
observations via a two-stage pipeline:

  1. Scatter FEM nodal values onto a regular intermediate grid using
     precomputed inverse-distance-weighted (IDW) coefficients.
  2. Interpolate that regular grid to camera pixel coordinates using
     a second IDW pass (also precomputed).

Both weight matrices are constant (depend only on mesh geometry, not on the
parameters being recovered), so the only autograd operation in the forward
pass is a single dense matrix multiply:
    ``u_cam = W_full @ fem_disp``

This is fully differentiable, float64-safe, and requires no ``grid_sample``.

Typical use
-----------
::

    from phast.inverse_problems.dic_integration import (
        FEMtoDICInterpolator, huber_dic_loss, make_synthetic_dic,
        regular_camera_grid,
    )

    cam_coords = regular_camera_grid(W, H, nx=64, ny=32).reshape(-1, 2)
    interp = FEMtoDICInterpolator(mesh.nodes, cam_coords,
                                  device='cuda', dtype=torch.float64)
    u_cam  = interp(fem_disp)               # (n_cam, 2)
    loss   = huber_dic_loss(u_cam, obs_dic) # scalar

Integration test
----------------
::

    python -m phast.inverse_problems.dic_integration
"""
from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
import torch
import torch.nn.functional as F
from torch import Tensor


# ---------------------------------------------------------------------------
# Camera grid helpers
# ---------------------------------------------------------------------------

def regular_camera_grid(
    W: float,
    H: float,
    nx: int = 64,
    ny: int = 32,
    margin_frac: float = 0.05,
    device: str = "cpu",
    dtype: torch.dtype = torch.float64,
) -> Tensor:
    """Return a (ny × nx × 2) grid of (x, y) coordinates in mm.

    The grid covers the specimen interior; ``margin_frac`` is excluded at each
    edge to avoid extrapolation artefacts near the boundary.
    """
    x = torch.linspace(W * margin_frac, W * (1 - margin_frac), nx,
                       device=device, dtype=dtype)
    y = torch.linspace(H * margin_frac, H * (1 - margin_frac), ny,
                       device=device, dtype=dtype)
    yy, xx = torch.meshgrid(y, x, indexing="ij")
    return torch.stack([xx, yy], dim=-1)  # (ny, nx, 2)


# ---------------------------------------------------------------------------
# IDW weight matrix builder
# ---------------------------------------------------------------------------

def _build_idw_matrix(
    source_pts: np.ndarray,
    target_pts: np.ndarray,
    n_neighbors: int = 4,
    power: float = 2.0,
    eps: float = 1e-10,
) -> np.ndarray:
    """Build (n_target, n_source) IDW weight matrix with rows summing to 1.

    Handles exact-coincidence (zero-distance) hits by assigning weight 1 to
    the coincident source point so no division-by-zero NaN propagates.
    """
    from scipy.spatial import cKDTree

    tree = cKDTree(source_pts)
    k = min(n_neighbors, len(source_pts))
    dists, idxs = tree.query(target_pts, k=k)  # (n_target, k)

    W = np.zeros((target_pts.shape[0], source_pts.shape[0]), dtype=np.float64)
    for i, (d, idx) in enumerate(zip(dists, idxs)):
        if d[0] == 0.0:
            W[i, idx[0]] = 1.0
        else:
            d_safe = np.maximum(d, eps)
            w = 1.0 / d_safe ** power
            w /= w.sum()
            W[i, idx] = w
    return W


# ---------------------------------------------------------------------------
# Core interpolator
# ---------------------------------------------------------------------------

class FEMtoDICInterpolator:
    """Differentiable FEM-node-to-DIC-pixel interpolator (fully precomputed).

    Precomputes a single (n_cam, n_fem) weight matrix combining:
    - IDW scatter from FEM nodes to a regular G×G intermediate grid
    - IDW interpolation from that grid to camera pixel coordinates

    Forward pass: ``u_cam = W_full @ fem_disp``  — one matrix multiply,
    fully differentiable with respect to ``fem_disp``.

    Parameters
    ----------
    fem_nodes     : (n_fem, 2) node coordinates in mm
    cam_coords    : (n_cam, 2) camera pixel coordinates in mm
    domain_bounds : optional ``[(x_min, x_max), (y_min, y_max)]``
                    (default: bounding box of ``fem_nodes``)
    grid_res      : resolution of intermediate regular grid (G × G)
    n_neighbors   : k-nearest neighbours for IDW (both stages)
    idw_power     : IDW exponent (2 = standard inverse-square distance)
    device, dtype : torch device/dtype for the weight matrix
    """

    def __init__(
        self,
        fem_nodes: np.ndarray | Tensor,
        cam_coords: np.ndarray | Tensor,
        domain_bounds: Optional[Tuple] = None,
        grid_res: int = 128,
        n_neighbors: int = 4,
        idw_power: float = 2.0,
        device: str = "cpu",
        dtype: torch.dtype = torch.float64,
    ) -> None:
        self.device = device
        self.dtype = dtype

        fem_np = (fem_nodes.cpu().numpy()
                  if isinstance(fem_nodes, Tensor)
                  else np.asarray(fem_nodes, dtype=np.float64))
        cam_np = (cam_coords.cpu().numpy()
                  if isinstance(cam_coords, Tensor)
                  else np.asarray(cam_coords, dtype=np.float64))

        if domain_bounds is None:
            x_min, x_max = float(fem_np[:, 0].min()), float(fem_np[:, 0].max())
            y_min, y_max = float(fem_np[:, 1].min()), float(fem_np[:, 1].max())
        else:
            (x_min, x_max), (y_min, y_max) = domain_bounds

        self.n_fem = fem_np.shape[0]
        self.n_cam = cam_np.shape[0]

        # Intermediate regular G×G grid
        gx = np.linspace(x_min, x_max, grid_res)
        gy = np.linspace(y_min, y_max, grid_res)
        GX, GY = np.meshgrid(gx, gy, indexing="ij")
        grid_pts = np.stack([GX.ravel(), GY.ravel()], axis=1)  # (G², 2)

        # Stage 1: FEM nodes → G×G grid   shape (G², n_fem)
        W_scatter = _build_idw_matrix(
            fem_np, grid_pts, n_neighbors=n_neighbors, power=idw_power
        )

        # Stage 2: G×G grid → camera pixels   shape (n_cam, G²)
        W_cam = _build_idw_matrix(
            grid_pts, cam_np, n_neighbors=n_neighbors, power=idw_power
        )

        # Compose: (n_cam, n_fem)
        # errstate: suppress NaN/overflow warnings from near-zero IDW weights
        # multiplied with large intermediate values; nan_to_num cleans up below.
        with np.errstate(divide="ignore", over="ignore", invalid="ignore"):
            W_full = W_cam @ W_scatter
        # Sanitize any NaN/Inf from degenerate near-boundary grid cells
        W_full = np.nan_to_num(W_full, nan=0.0, posinf=0.0, neginf=0.0)
        # Re-normalise rows that lost weight due to sanitization
        row_sums = W_full.sum(axis=1, keepdims=True)
        row_sums = np.where(row_sums > 0, row_sums, 1.0)
        W_full /= row_sums

        self._W_full = torch.tensor(W_full, dtype=torch.float64, device=device)

    def __call__(self, fem_disp: Tensor) -> Tensor:
        """Interpolate FEM nodal displacements to camera pixel coordinates.

        Parameters
        ----------
        fem_disp : (n_fem, n_comp) or (n_fem,)

        Returns
        -------
        (n_cam, n_comp) or (n_cam,) on the same device, cast to ``self.dtype``
        """
        squeeze = fem_disp.dim() == 1
        if squeeze:
            fem_disp = fem_disp.unsqueeze(-1)

        u = fem_disp.to(dtype=torch.float64, device=self.device)
        u_cam = self._W_full @ u          # (n_cam, n_comp), float64
        u_cam = u_cam.to(dtype=self.dtype)

        if squeeze:
            u_cam = u_cam.squeeze(-1)
        return u_cam


# ---------------------------------------------------------------------------
# Convenience wrapper
# ---------------------------------------------------------------------------

def register_fem_to_dic(
    fem_nodes: np.ndarray | Tensor,
    fem_disp: Tensor,
    camera_grid: np.ndarray | Tensor,
    *,
    domain_bounds: Optional[Tuple] = None,
    grid_res: int = 128,
    n_neighbors: int = 4,
    idw_power: float = 2.0,
) -> Tensor:
    """One-shot differentiable FEM→DIC interpolation.

    For repeated calls on the same mesh, construct ``FEMtoDICInterpolator``
    once and reuse it — this function rebuilds the weight matrix each time.

    Parameters
    ----------
    fem_nodes   : (n_fem, 2) mesh node coordinates in mm
    fem_disp    : (n_fem, n_comp) or (n_fem,) nodal displacements
    camera_grid : (n_cam, 2) camera pixel coordinates in mm

    Returns
    -------
    (n_cam, n_comp) or (n_cam,) interpolated displacements
    """
    device = str(fem_disp.device) if isinstance(fem_disp, Tensor) else "cpu"
    dtype = fem_disp.dtype if isinstance(fem_disp, Tensor) else torch.float64
    interp = FEMtoDICInterpolator(
        fem_nodes, camera_grid,
        domain_bounds=domain_bounds,
        grid_res=grid_res,
        n_neighbors=n_neighbors,
        idw_power=idw_power,
        device=device,
        dtype=dtype,
    )
    return interp(fem_disp)


# ---------------------------------------------------------------------------
# Loss functions
# ---------------------------------------------------------------------------

def huber_dic_loss(
    pred: Tensor,
    obs: Tensor,
    delta: float = 0.01,
    mask: Optional[Tensor] = None,
) -> Tensor:
    """Huber loss between predicted and observed DIC displacement fields.

    Robust to DIC outliers (speckle-correlation failures, crack-face occlusion).
    For |error| < delta: quadratic (L2).  For |error| ≥ delta: linear (L1).

    Parameters
    ----------
    pred  : (n_cam, n_comp) or (n_cam,) predicted displacements in mm
    obs   : same shape — observed DIC displacements
    delta : Huber threshold in mm (0.01 mm ≈ 10 μm, typical DIC noise floor)
    mask  : optional bool (n_cam,) — True = valid pixel; False = occluded

    Returns
    -------
    Scalar loss (mean Huber over valid pixels and components)
    """
    r = pred - obs
    loss = F.huber_loss(r, torch.zeros_like(r), delta=delta, reduction="none")
    if mask is not None:
        m = mask.to(dtype=loss.dtype)
        if loss.dim() > 1:
            m = m.unsqueeze(-1)
        loss = loss * m
        n_valid = mask.float().sum().clamp(min=1)
        n_comp = pred.shape[-1] if pred.dim() > 1 else 1
        return loss.sum() / (n_valid * n_comp)
    return loss.mean()


def mse_dic_loss(pred: Tensor, obs: Tensor, mask: Optional[Tensor] = None) -> Tensor:
    """MSE loss for DIC (less robust than Huber near crack faces)."""
    r = (pred - obs) ** 2
    if mask is not None:
        m = mask.to(dtype=r.dtype)
        if r.dim() > 1:
            m = m.unsqueeze(-1)
        r = r * m
        n_valid = mask.float().sum().clamp(min=1)
        n_comp = pred.shape[-1] if pred.dim() > 1 else 1
        return r.sum() / (n_valid * n_comp)
    return r.mean()


# ---------------------------------------------------------------------------
# Synthetic DIC for testing and benchmarking
# ---------------------------------------------------------------------------

def make_synthetic_dic(
    fem_nodes: np.ndarray | Tensor,
    fem_disp_truth: Tensor,
    cam_coords: np.ndarray | Tensor,
    noise_std: float = 0.0,
    *,
    seed: int = 0,
    grid_res: int = 128,
    n_neighbors: int = 4,
) -> Tensor:
    """Generate synthetic DIC observations from a truth FEM displacement field.

    Parameters
    ----------
    fem_nodes      : (n_fem, 2) mesh node coords in mm
    fem_disp_truth : (n_fem, n_comp) truth nodal displacements
    cam_coords     : (n_cam, 2) camera pixel coords in mm
    noise_std      : Gaussian noise std in mm (0 = noise-free)

    Returns
    -------
    (n_cam, n_comp) synthetic DIC displacement observations
    """
    device = fem_disp_truth.device
    dtype = fem_disp_truth.dtype
    interp = FEMtoDICInterpolator(
        fem_nodes, cam_coords,
        grid_res=grid_res,
        n_neighbors=n_neighbors,
        device=str(device),
        dtype=dtype,
    )
    with torch.no_grad():
        u_cam = interp(fem_disp_truth)
    if noise_std > 0.0:
        torch.manual_seed(seed)
        u_cam = u_cam + torch.randn(u_cam.shape, dtype=dtype, device=device) * noise_std
    return u_cam


# ---------------------------------------------------------------------------
# Integration test
# ---------------------------------------------------------------------------

def _run_integration_test() -> None:
    print("dic_integration integration test")
    print("=" * 48)

    dtype = torch.float64
    device = "cpu"

    # Synthetic FEM mesh: 500 random nodes on [0, 20] × [0, 10] mm
    np.random.seed(7)
    n_fem = 500
    fem_nodes = np.random.rand(n_fem, 2) * np.array([20.0, 10.0])

    # Truth displacement: linear shear
    u_truth_np = np.stack([
        0.1 * fem_nodes[:, 0] / 20.0,
        0.05 * fem_nodes[:, 1] / 10.0,
    ], axis=1)
    u_truth_t = torch.tensor(u_truth_np, dtype=dtype, device=device)

    # Camera grid: 16×8 pixels
    cam_grid = regular_camera_grid(20.0, 10.0, nx=16, ny=8, device=device, dtype=dtype)
    cam_coords = cam_grid.reshape(-1, 2)  # (128, 2)
    print(f"  FEM nodes: {n_fem}, camera pixels: {cam_coords.shape[0]}")

    interp = FEMtoDICInterpolator(fem_nodes, cam_coords,
                                   grid_res=64, device=device, dtype=dtype)
    print(f"  W_full shape: {interp._W_full.shape}")
    assert interp._W_full.shape == (cam_coords.shape[0], n_fem)

    # Interpolation sanity: output should approximate linear truth
    obs = interp(u_truth_t)
    print(f"  obs u_x range: [{obs[:,0].min():.4f}, {obs[:,0].max():.4f}] mm")
    print(f"  obs u_y range: [{obs[:,1].min():.4f}, {obs[:,1].max():.4f}] mm")
    assert not obs.isnan().any(), "NaN in obs output"
    assert obs.shape == (cam_coords.shape[0], 2)

    # Synthetic noisy observations
    obs_noisy = make_synthetic_dic(fem_nodes, u_truth_t, cam_coords,
                                    noise_std=1e-4, grid_res=64)
    noise_level = float((obs_noisy - obs).std())
    print(f"  noisy obs noise level: {noise_level:.2e} mm  (target ~1e-4)")
    assert 0.5e-4 < noise_level < 2e-4, f"noise level unexpected: {noise_level}"

    # Gradient test: perturb, check loss + gradient
    u_perturbed = torch.tensor(u_truth_np + 0.01, dtype=dtype,
                                requires_grad=True)
    pred = interp(u_perturbed)
    loss = huber_dic_loss(pred, obs.detach(), delta=0.01)
    loss.backward()
    print(f"  loss (perturbed +0.01mm): {loss.item():.4e}")
    assert loss.item() > 0
    grad_norm = float(u_perturbed.grad.norm())
    print(f"  ||grad u_fem||: {grad_norm:.4e}")
    assert grad_norm > 0, "gradient should be non-zero"

    # Zero-loss test
    u_exact = torch.tensor(u_truth_np, dtype=dtype, requires_grad=True)
    loss_exact = huber_dic_loss(interp(u_exact), obs.detach(), delta=0.01)
    print(f"  loss (exact u_fem): {loss_exact.item():.2e}  (expect ~0)")
    assert loss_exact.item() < 1e-20, f"exact loss too large: {loss_exact.item()}"

    # Mask test
    mask = torch.ones(cam_coords.shape[0], dtype=torch.bool)
    mask[:10] = False
    loss_masked = huber_dic_loss(pred.detach(), obs.detach(), delta=0.01, mask=mask)
    print(f"  masked loss (10 pixels excluded): {loss_masked.item():.4e}")
    assert not torch.isnan(loss_masked)

    # MSE loss test
    loss_mse = mse_dic_loss(pred.detach(), obs.detach())
    print(f"  MSE loss (perturbed): {loss_mse.item():.4e}")
    assert loss_mse.item() > 0

    print("\nPASS — all assertions passed")


if __name__ == "__main__":
    _run_integration_test()
