#!/usr/bin/env python
"""ES (Evolutionary Strategies) baseline for the stiff-inclusion
inverse problem (issues #289, #312, #313).

This is the gradient-free counterpart to ``demo_inverse_stiff_inclusion.py``.
We import the helpers from that demo (geometry constants, ``build_solver``,
``gaussian_E_field_multi``, ``run_forward``, ``differentiable_crack_path``,
``soft_tip_x``, ``hard_tip_x``) so the *forward* model and the path
observable are bit-identical to the autograd demo. Only the optimizer
changes.

Why ES
------
For Paper 3 we need a head-to-head comparison of three optimizer
families on the same forward problem:

1. Vanilla autograd (LBFGS + full unroll) -- the demo above.
2. Continuous adjoint (other agent, ``inverse_problems/adjoint/``).
3. Evolutionary Strategies (this file).

Salimans 2017 / Suh 2022 §5 motivate ES as the natural baseline when
the dynamics make autograd unreliable. The estimator is bounded by
``O(|L|/sigma)`` regardless of any chaotic eigenvalue blow-up in the
unrolled forward, so it is the floor below which any "differentiable
simulator" claim must show a real win.

Observation modes (#312)
------------------------
- ``--obs_mode full`` (default): final-time damage MSE. Saturation-
  degenerate at production-scale ``--n_steps`` (entire crack saturates
  to ``d=1`` outside the inclusion lobe so the loss surface collapses).
- ``--obs_mode path``: damage-weighted crack centerline ``y(x)`` on a
  fixed x-grid. Mass-weighted MSE so bins with no truth crack carry
  zero weight. Uses the *same* differentiable_crack_path soft-bin
  formula as the L-BFGS demo so the two are directly comparable. The
  smoothing is irrelevant for ES (we read out a scalar per forward,
  not a gradient) but keeping the same observable makes the gradient-
  vs-gradient-free head-to-head apples-to-apples.
- ``--obs_mode tips``: hard-argmax crack-tip x-positions at ``n_tips``
  evenly-spaced timesteps. ES does not need a differentiable extractor
  so we use ``hard_tip_x`` (rightmost ``d > 0.5`` x). Note: hard-argmax
  is plateau-flat between element boundaries -- safe at the smoke mesh
  (h_crack 0.4 mm) where the ES sigma 0.5 mm crosses element widths,
  but at the production mesh (h_crack 0.05 mm) sigma should be tuned
  >= h_crack to avoid stalling.
- ``--obs_mode load_disp`` / ``load_displacement``: normalised MSE on
  sampled top-boundary reaction force. This is experimentally realistic
  but weaker than path observations because many crack paths can share
  a similar global force-displacement curve.

Multi-particle (#313)
---------------------
- ``--n_particles {1,3,5,10}``. Defaults follow the L-BFGS demo for
  ``n in {1, 3}``: ``truth=[(16, 9.5)]`` for 1p,
  ``truth=[(13, 9.5), (25, 9.5), (19, 6.5)]`` for 3p. For ``n in {5, 10}``
  particles are sampled pseudo-randomly with a fixed seed, all inside
  the 6-sigma observability band ``|y - crack_y| <= 6*SIGMA_INC``,
  and inside the propagation strip ``a + 1 <= x <= W - 1``.
- ``--truth_particles "x1,y1,x2,y2,..."`` and ``--init_particles ...``
  override the defaults (CSV format, mirrors the L-BFGS demo).
- The parameter vector grows to ``2 * n_particles`` -- ES sigma/lr
  defaults stay constant; bump ``--n_samples`` ~ proportional to
  ``n_particles`` on HPC if convergence is slow.

This demo runs ES at the smoke configuration so it fits inside a
~10 min CPU budget. The ``--full`` flag enables the production-
resolution forward but is not the default.

Usage
-----
    # Default (single particle, full damage MSE)
    python demo_inverse_stiff_inclusion_es.py --device cpu --smoke

    # Path-mode loss (matches L-BFGS path observable; #312)
    python demo_inverse_stiff_inclusion_es.py --device cpu --smoke \
        --obs_mode path --n_path_bins 40

    # 3-particle inversion with path-mode (#313 + #312 combined)
    python demo_inverse_stiff_inclusion_es.py --device cpu --smoke \
        --obs_mode path --n_particles 3 --n_iter 10 --n_samples 4

The output is a loss curve ``es_loss_curve.png`` and a JSON record
``es_run.json`` in the run directory.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(THIS_DIR, '..', '..'))
sys.path.insert(0, os.path.dirname(REPO_ROOT))
sys.path.insert(0, REPO_ROOT)

# The autograd demo does ``from phast.mesh_generator import ...``
# This works in the canonical checkout because the repo's parent
# (``neural_operator/``) holds a ``phast/`` directory. In a
# git-worktree the worktree path is the repo, but its parent
# (``worktrees/``) has no such package. Register the repo itself under
# the alias ``phast`` in ``sys.modules`` so the autograd demo
# import resolves whichever path we are run from.
if 'phast' not in sys.modules:
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        'phast', os.path.join(REPO_ROOT, '__init__.py'),
        submodule_search_locations=[REPO_ROOT])
    if spec is not None and spec.loader is not None:
        mod = importlib.util.module_from_spec(spec)
        sys.modules['phast'] = mod
        try:
            spec.loader.exec_module(mod)
        except Exception:
            # Best-effort: if root __init__ has bugs we still let
            # later imports try -- the autograd demo only needs a few
            # submodules that may import individually.
            pass

# Import helpers from the autograd demo (do NOT modify it).
from inverse_problems.demos.demo_inverse_stiff_inclusion import (  # noqa: E402
    E_BULK, ALPHA_TRUTH, SIGMA_INC,
    build_solver, gaussian_E_field_multi, run_forward,
    differentiable_crack_path, soft_tip_x, hard_tip_x,
    _parse_particles, _check_six_sigma,
)
from inverse_problems.optimizers import ESOptimizer  # noqa: E402


import matplotlib  # noqa: E402
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402


# Stable serif rcParams (memory: feedback_paper_font.md)
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['STIX', 'Times New Roman', 'DejaVu Serif'],
    'mathtext.fontset': 'stix',
    'pdf.fonttype': 42,
})


# ----------------------------------------------------------------------
# Default truth/init particle layouts (#313)
# ----------------------------------------------------------------------

def _default_particles(n_particles, W, H, a, crack_y, seed=0):
    """Return ``(truth_pts, init_pts)`` as lists of (x, y) tuples.

    For ``n in {1, 3}`` the defaults mirror the L-BFGS demo verbatim
    so the two demos compare apples-to-apples. For ``n in {5, 10}``
    particles are sampled pseudo-randomly with fixed seeds. All
    particles satisfy:

      - ``|y - crack_y| <= 6 * SIGMA_INC``  (6-sigma observability)
      - ``a + 1 <= x <= W - 1``             (inside the propagation strip)

    Init points are offset from truth by a fixed (dx, dy) per particle
    that keeps them inside the same band; the ES optimiser then has a
    finite, non-degenerate distance to recover.
    """
    if n_particles == 1:
        truth = [(16.0, 9.5)]
        init  = [(13.0, 11.5)]
        return truth, init
    if n_particles == 3:
        # Match L-BFGS default: two stiff bumps above the crack
        # (y = 9.5) at x = 13 and x = 25, third bump below
        # (y = 6.5) at x = 19. All 1.5 mm off the crack axis.
        truth = [(13.0, 9.5), (25.0, 9.5), (19.0, 6.5)]
        init  = [(11.0, 11.0), (27.0, 11.0), (21.0, 4.5)]
        return truth, init

    # n in {5, 10}: pseudo-random with fixed seed.
    rng = np.random.default_rng(seed)
    band = 6.0 * SIGMA_INC
    x_lo, x_hi = a + 1.0, W - 1.0
    # Clamp y-band to inside the plate so the Gaussian bumps are not
    # half-truncated by the top/bottom boundary. _check_six_sigma only
    # enforces the observability band (|y - crack_y| <= 6 sigma), not
    # plate bounds; for the canonical 32x16 SENT, 6 sigma = 9.6 mm and
    # crack_y = 8 mm so the raw band [-1.6, 17.6] mm exceeds H = 16.
    y_lo = max(0.5, crack_y - band)
    y_hi = min(H - 0.5, crack_y + band)
    truth = []
    while len(truth) < n_particles:
        x = float(rng.uniform(x_lo, x_hi))
        y = float(rng.uniform(y_lo, y_hi))
        # No two truth particles within 2 * SIGMA_INC so each contributes
        # an independent bump rather than one merged blob.
        if all(math.hypot(x - xt, y - yt) > 2.0 * SIGMA_INC
               for (xt, yt) in truth):
            truth.append((x, y))
    # Init: rotate each truth point by a fixed (1.5, 1.5) mm offset,
    # clip back to the (x, y) bands so we never violate _check_six_sigma.
    init = []
    for (x, y) in truth:
        ix = float(np.clip(x - 2.0, x_lo, x_hi))
        iy = float(np.clip(y + 1.5 if y < crack_y else y - 1.5,
                           y_lo, y_hi))
        init.append((ix, iy))
    return truth, init


# ----------------------------------------------------------------------
# Loss closures (#312)
# ----------------------------------------------------------------------

def _make_loss_fn(solver, loading, centroids, n_steps, *,
                   obs_mode, d_target_full,
                   node_x=None, node_y=None,
                   x_bins=None, path_sigma=None,
                   y_target_path=None, mass_target_path=None,
                   snap_steps=None, tips_target=None,
                   load_steps=None, top_idx=None, loads_target=None):
    """Build a closure ``loss_fn(theta) -> float`` for the requested obs mode.

    Everything runs under ``torch.no_grad`` -- ES does not need
    autograd, and skipping tape construction halves the per-forward
    cost relative to the L-BFGS demo.

    Loss formulas
    -------------
    - ``full``: ``loss = mean((d_pred - d_target)**2)`` over all nodes.
      Saturation-degenerate at large n_steps.
    - ``path``: same as L-BFGS ``crack_path_loss`` --
      ``loss = sum(mass_target * (y_pred - y_target)**2) / sum(mass_target)``
      where ``y_pred, _ = differentiable_crack_path(d_pred, ...)``.
      Mass-weighted so bins with no truth crack carry zero weight.
    - ``tips``: ``loss = mean((tip_pred - tip_target)**2)`` where
      ``tip(d) = max(node_x[d > 0.5])`` (hard-argmax, non-differentiable).
      Computed at each step in ``snap_steps``. Plateau-flat between
      element widths -- safe for smoke mesh (h_crack 0.4) but tune
      sigma at production scale.
    - ``load_disp``: normalised MSE on sampled top-boundary reaction force.
      This is weaker than path observations but matches an experimentally
      realistic load-displacement signal.
    """
    dtype = centroids.dtype
    device = centroids.device

    if obs_mode == 'path':
        assert x_bins is not None and y_target_path is not None
    elif obs_mode == 'tips':
        assert snap_steps is not None and tips_target is not None
    elif obs_mode == 'load_disp':
        assert load_steps is not None and top_idx is not None
        assert loads_target is not None
    elif obs_mode != 'full':
        raise ValueError(f"unknown obs_mode {obs_mode!r}")

    node_x_np = node_x.detach().cpu().numpy() if node_x is not None else None

    def loss_fn(theta):
        with torch.no_grad():
            E_e = gaussian_E_field_multi(
                centroids, theta.to(dtype=dtype, device=device),
                E_BULK, ALPHA_TRUTH, SIGMA_INC)
            d_pred, snaps_pred, loads_pred = run_forward(
                solver, loading, E_e, n_steps,
                snapshot_steps=snap_steps if obs_mode == 'tips' else None,
                load_steps=load_steps if obs_mode == 'load_disp' else None,
                top_idx=top_idx if obs_mode == 'load_disp' else None)
            if obs_mode == 'full':
                loss = ((d_pred - d_target_full) ** 2).mean()
            elif obs_mode == 'path':
                y_pred, _ = differentiable_crack_path(
                    d_pred, node_x, node_y, x_bins, path_sigma, p=4)
                sq = (y_pred - y_target_path) ** 2
                loss = (mass_target_path * sq).sum() / (
                    mass_target_path.sum() + 1e-12)
            elif obs_mode == 'load_disp':
                loads_pred_t = torch.stack(loads_pred)
                scale = loads_target.abs().max() + 1e-12
                loss = (((loads_pred_t - loads_target) / scale) ** 2).mean()
            else:  # tips
                # Hard-argmax tip extractor -- read out per-snapshot
                # rightmost x with d > 0.5. Non-differentiable; ES OK.
                tips_pred_np = np.array([
                    hard_tip_x(s.detach().cpu().numpy(), node_x_np)
                    for s in snaps_pred
                ], dtype=np.float64)
                # If the predicted crack hasn't propagated yet
                # (hard_tip_x returns -inf), substitute the notch tip
                # so the loss is well-defined.
                tips_pred_np = np.where(np.isfinite(tips_pred_np),
                                         tips_pred_np, 0.0)
                tips_pred = torch.tensor(tips_pred_np, dtype=dtype,
                                          device=device)
                loss = ((tips_pred - tips_target) ** 2).mean()
        return float(loss.item())

    return loss_fn


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--device', type=str, default='cpu')
    p.add_argument('--smoke', action='store_true', default=True,
                   help='Smoke-tier mesh and timesteps (CPU-friendly).')
    p.add_argument('--full', action='store_true',
                   help='Production resolution. Hours on CPU; HPC only.')
    p.add_argument('--n_steps', type=int, default=None,
                   help='Override timestep count.')
    p.add_argument('--n_iter', type=int, default=12,
                   help='ES outer iterations. Default keeps the demo '
                        'inside the ~10 min CPU budget; 200 iters '
                        'requires --device cuda or HPC.')
    p.add_argument('--n_samples', type=int, default=4,
                   help='ES samples per step (forward count = 2 * n_samples '
                        'with antithetic). Default 4 is the smallest '
                        'count where the rank-shaped estimator is '
                        'meaningful; bump to 16-32 on HPC. With '
                        '--n_particles > 1 the parameter vector size '
                        'grows to 2 * n_particles; consider scaling '
                        'n_samples in proportion if convergence stalls.')
    p.add_argument('--sigma', type=float, default=0.5,
                   help='ES perturbation scale (mm). Inclusion sigma is '
                        '1.6 mm; perturbation 0.5 mm exercises the loss '
                        'landscape without leaving the 6-sigma observability '
                        'band. With --obs_mode tips on a fine mesh '
                        '(h_crack 0.05 mm), bump sigma above h_crack to '
                        'avoid plateau-flat hard-argmax responses.')
    p.add_argument('--lr', type=float, default=0.5,
                   help='ES learning rate (mm per step gradient unit).')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--out_dir', type=str, default=None)

    # ---- #312: observation mode ---------------------------------------
    p.add_argument('--obs_mode', type=str, default='full',
                   choices=['full', 'path', 'tips',
                            'load_disp', 'load_displacement'],
                   help='full = MSE on final damage field (saturation-'
                        'degenerate at large n_steps); '
                        'path = mass-weighted MSE on damage-weighted '
                        'crack centerline y(x) on n_path_bins (matches '
                        'L-BFGS path observable, #312); '
                        'tips = MSE on hard-argmax crack-tip x at n_tips '
                        'snapshots. ES does not need a differentiable '
                        'extractor so the tip is plain rightmost d>0.5 '
                        'x rather than the L-BFGS softargmax; '
                        'load_disp/load_displacement = normalised MSE on '
                        'sampled top-boundary reaction force.')
    p.add_argument('--n_load_samples', type=int, default=20,
                   help='Number of reaction-force samples for '
                        '--obs_mode load_disp/load_displacement.')
    p.add_argument('--n_path_bins', type=int, default=40,
                   help='Number of x-bins for --obs_mode path.')
    p.add_argument('--path_sigma_factor', type=float, default=0.6,
                   help='Bin width as a fraction of inter-bin spacing '
                        '(--obs_mode path). Default 0.6 matches the '
                        'L-BFGS demo so the truth/predicted paths are '
                        'binned identically.')
    p.add_argument('--n_tips', type=int, default=10,
                   help='Number of tip snapshots when --obs_mode tips.')

    # ---- #313: multi-particle ----------------------------------------
    p.add_argument('--n_particles', type=int, default=1,
                   choices=[1, 3, 5, 10],
                   help='Number of stiff inclusions to recover. 1, 3 '
                        'mirror the L-BFGS demo defaults; 5 and 10 are '
                        'pseudo-random layouts seeded by --seed for '
                        'this demo (the L-BFGS demo only supports '
                        '{1, 3} as of this PR).')
    p.add_argument('--truth_particles', type=str, default=None,
                   help='Override truth centres as CSV "x1,y1,x2,y2,...". '
                        'Length must equal 2 * --n_particles.')
    p.add_argument('--init_particles', type=str, default=None,
                   help='Override initial guesses as CSV. Length must '
                        'equal 2 * --n_particles.')

    args = p.parse_args()
    if args.obs_mode == 'load_displacement':
        args.obs_mode = 'load_disp'

    if args.full:
        args.smoke = False

    device = torch.device(args.device)
    dtype = torch.float64

    W, H, a = 32.0, 16.0, 4.0
    crack_y = H / 2.0  # 8 mm
    if args.smoke:
        h_crack, h_coarse = 0.4, 2.0
        # 800 steps lands deep in saturation (max(d) hits 1.0 by
        # step ~750 at the smoke mesh) -- enough signal for the loss
        # surface, fast enough for CPU. The autograd demo uses 2500
        # because L-BFGS needs a longer settling tail; ES doesn't.
        n_steps = args.n_steps if args.n_steps is not None else 800
        delta_U = 5e-2
    else:
        h_crack, h_coarse = 0.05, 0.5
        n_steps = args.n_steps if args.n_steps is not None else 9000
        delta_U = 5e-2
    tau_ramp = 30e-6
    damping_zeta = 0.05

    # ---- #313: resolve particle layout --------------------------------
    default_truth, default_init = _default_particles(
        args.n_particles, W, H, a, crack_y, seed=args.seed)
    truth_pts = _parse_particles(args.truth_particles, default_truth)
    init_pts  = _parse_particles(args.init_particles,  default_init)
    if len(truth_pts) != args.n_particles:
        raise ValueError(f"--n_particles {args.n_particles} but "
                         f"--truth_particles has {len(truth_pts)} centres")
    if len(init_pts) != args.n_particles:
        raise ValueError(f"--n_particles {args.n_particles} but "
                         f"--init_particles has {len(init_pts)} centres")
    _check_six_sigma(truth_pts, SIGMA_INC, crack_y, 'truth')
    _check_six_sigma(init_pts,  SIGMA_INC, crack_y, 'init')

    out_dir = args.out_dir or os.path.join(
        REPO_ROOT,
        'examples',
        'inverse_problems',
        'demo1_one_particle_stiff_inclusion',
        'local_es_baseline',
        'results',
    )
    os.makedirs(out_dir, exist_ok=True)

    print("=" * 70)
    print("  Stiff-inclusion ES inversion (Salimans 2017 / Suh 2022 sec 5)")
    print("=" * 70)
    print(f"  Plate: {W} x {H} mm, notch {a} mm")
    print(f"  N particles: {args.n_particles}; obs mode: {args.obs_mode}")
    for i, (xt, yt) in enumerate(truth_pts):
        xi, yi = init_pts[i]
        print(f"    particle {i}: truth=({xt:.2f},{yt:.2f})  "
              f"init=({xi:.2f},{yi:.2f})  "
              f"offset={math.hypot(xi-xt, yi-yt):.2f} mm")
    print(f"  n_steps = {n_steps}; mesh = (h_crack {h_crack}, h_coarse {h_coarse})")
    print(f"  ES: n_iter={args.n_iter}, n_samples={args.n_samples}, "
          f"sigma={args.sigma}, lr={args.lr}, seed={args.seed}")
    print(f"  out_dir = {out_dir}")

    solver, centroids, loading = build_solver(
        W, H, a, h_crack, h_coarse, delta_U, tau_ramp,
        damping_zeta, device, dtype,
        enable_damage=True,
        softmax_H_beta=10.0,  # paper-3 production setting (CLAIMS_LOG C8)
        H_cap=None,
    )
    print(f"  Mesh: {solver.mesh.n_nodes} nodes, {solver.mesh.n_elems} elements")

    node_x = solver.mesh.nodes[:, 0]
    node_y = solver.mesh.nodes[:, 1]

    # Path-mode bin grid (#312): x_bins span the crack-propagation strip
    # from the notch tip (x = a) to the right edge (x = W). Same grid
    # for truth and all closure forwards so the loss surface is well-
    # defined.
    if args.obs_mode == 'path':
        x_bins = torch.linspace(a, W, args.n_path_bins,
                                  dtype=dtype, device=device)
        bin_dx = float(x_bins[1] - x_bins[0])
        path_sigma = args.path_sigma_factor * bin_dx
        print(f"  Path bins: {args.n_path_bins} from x={a} to x={W}, "
              f"sigma_bin = {path_sigma:.3f} mm")
    else:
        x_bins = None
        path_sigma = None

    # Tips-mode snapshot steps (#312): n_tips evenly-spaced timesteps
    # past the loading ramp. Same convention as L-BFGS demo.
    if args.obs_mode == 'tips':
        first = max(int(0.05 * n_steps), 1)
        snap_steps = list(np.linspace(first, n_steps, args.n_tips,
                                        dtype=int).tolist())
        print(f"  Tip snapshots at {args.n_tips} steps: "
              f"{snap_steps[0]}..{snap_steps[-1]}")
    else:
        snap_steps = None

    # Load-displacement mode samples the global reaction curve. The
    # displacement abscissa is fixed by the smooth ramp and sample step,
    # so the observable is the sampled top reaction force.
    if args.obs_mode == 'load_disp':
        first = max(int(0.05 * n_steps), 1)
        load_steps = list(np.linspace(first, n_steps, args.n_load_samples,
                                      dtype=int).tolist())
        top_idx = solver.mesh.node_sets['top']
        print(f"  Load samples at {args.n_load_samples} steps: "
              f"{load_steps[0]}..{load_steps[-1]}; "
              f"|top_idx|={len(top_idx)}")
    else:
        load_steps = None
        top_idx = None

    print("\n[1/3] Truth forward (no-grad) ...")
    t0 = time.time()
    truth_t = torch.tensor([list(pt) for pt in truth_pts],
                            dtype=dtype, device=device)
    with torch.no_grad():
        E_truth = gaussian_E_field_multi(
            centroids, truth_t, E_BULK, ALPHA_TRUTH, SIGMA_INC)
        d_target_full, snaps_truth, loads_truth = run_forward(
            solver, loading, E_truth, n_steps,
            snapshot_steps=snap_steps if args.obs_mode == 'tips' else None,
            load_steps=load_steps if args.obs_mode == 'load_disp' else None,
            top_idx=top_idx if args.obs_mode == 'load_disp' else None)
        d_target_full = d_target_full.detach().clone()
    truth_wall = time.time() - t0
    print(f"  truth wall: {truth_wall:.1f}s; max(d) = {float(d_target_full.max()):.3f}; "
          f"#d>0.5 = {int((d_target_full > 0.5).sum())}")

    # Cache obs-mode-specific truth observables (#312).
    y_target_path = None
    mass_target_path = None
    tips_target = None
    loads_target = None
    if args.obs_mode == 'path':
        with torch.no_grad():
            y_target_path, mass_target_path = differentiable_crack_path(
                d_target_full, node_x, node_y, x_bins, path_sigma, p=4)
        signal_bins = (mass_target_path > mass_target_path.max() * 0.05)
        if signal_bins.any():
            print(f"  Truth path y(x) range over signal bins: "
                  f"y_min={y_target_path[signal_bins].min().item():.3f}, "
                  f"y_max={y_target_path[signal_bins].max().item():.3f} mm "
                  f"(total mass = {float(mass_target_path.sum()):.3e})")
    elif args.obs_mode == 'tips':
        node_x_np = node_x.detach().cpu().numpy()
        tips_np = np.array([
            hard_tip_x(s.detach().cpu().numpy(), node_x_np)
            for s in snaps_truth
        ], dtype=np.float64)
        tips_np = np.where(np.isfinite(tips_np), tips_np, 0.0)
        tips_target = torch.tensor(tips_np, dtype=dtype, device=device)
        print(f"  Truth hard tip x at {args.n_tips} snapshots: "
              + ", ".join(f"{t:.2f}" for t in tips_np))
    elif args.obs_mode == 'load_disp':
        loads_target = torch.stack(loads_truth).detach().clone()
        scale = float(loads_target.abs().max())
        print(f"  Truth load-displacement reaction samples: "
              f"min={float(loads_target.min()):.3e}, "
              f"max={float(loads_target.max()):.3e}, scale={scale:.3e}")

    loss_fn = _make_loss_fn(
        solver, loading, centroids, n_steps,
        obs_mode=args.obs_mode,
        d_target_full=d_target_full,
        node_x=node_x, node_y=node_y,
        x_bins=x_bins, path_sigma=path_sigma,
        y_target_path=y_target_path,
        mass_target_path=mass_target_path,
        snap_steps=snap_steps, tips_target=tips_target,
        load_steps=load_steps, top_idx=top_idx,
        loads_target=loads_target,
    )

    init_flat = torch.tensor(
        [v for pair in init_pts for v in pair], dtype=dtype, device=device)
    print("\n[2/3] Init forward sanity ...")
    t0 = time.time()
    init_loss = loss_fn(init_flat)
    init_wall = time.time() - t0
    print(f"  init loss = {init_loss:.6e}  ({init_wall:.1f}s/eval)")

    print(f"\n[3/3] ES inversion ({args.n_iter} iters, "
          f"{2*args.n_samples} forwards/iter; param dim = "
          f"{2*args.n_particles}) ...")
    opt = ESOptimizer(
        params=init_flat,
        lr=args.lr,
        sigma=args.sigma,
        n_samples=args.n_samples,
        antithetic=True,
        fitness_shaping=True,
        seed=args.seed,
        dtype=dtype,
        device=device,
    )

    truth_flat = torch.tensor(
        [v for pair in truth_pts for v in pair], dtype=dtype, device=device)

    history = []
    t_start = time.time()
    for it in range(args.n_iter):
        t_it = time.time()
        loss_here = opt.step(loss_fn)
        wall = time.time() - t_it
        cur_pts = opt.theta.detach().cpu().numpy().reshape(-1, 2).tolist()
        # Per-particle err and the overall max -- multi-particle (#313)
        # makes the single-particle scalar misleading.
        err_per_particle = [
            float(np.hypot(cur_pts[i][0] - truth_pts[i][0],
                            cur_pts[i][1] - truth_pts[i][1]))
            for i in range(args.n_particles)
        ]
        max_err = max(err_per_particle)
        history.append({
            'iter': it,
            'loss': loss_here,
            'theta': cur_pts,
            'grad_norm': opt.last_grad_norm,
            'err_per_particle_mm': err_per_particle,
            'err_max_mm': max_err,
            'wall_s': wall,
        })
        if it < 5 or (it + 1) % max(1, args.n_iter // 20) == 0:
            print(f"  it {it:4d}  loss={loss_here:.4e}  "
                  f"max_err={max_err:.3f} mm  |g|={opt.last_grad_norm:.3e}  "
                  f"wall={wall:.1f}s  cum={time.time()-t_start:.1f}s",
                  flush=True)

    final_loss = float(loss_fn(opt.theta))
    total_wall = time.time() - t_start
    final_pts = opt.theta.detach().cpu().numpy().reshape(-1, 2).tolist()
    final_err_per_particle = [
        float(np.hypot(final_pts[i][0] - truth_pts[i][0],
                        final_pts[i][1] - truth_pts[i][1]))
        for i in range(args.n_particles)
    ]
    final_max_err = max(final_err_per_particle)

    print(f"\n  ES finished: {args.n_iter} iters in {total_wall:.1f}s")
    print(f"  loss: {init_loss:.4e} -> {final_loss:.4e} "
          f"({init_loss/max(final_loss,1e-30):.2f}x reduction)")
    for i in range(args.n_particles):
        print(f"  particle {i}: init={init_pts[i]} -> final="
              f"({final_pts[i][0]:.3f},{final_pts[i][1]:.3f})  "
              f"truth={truth_pts[i]}  err={final_err_per_particle[i]:.3f} mm")

    record = {
        'init_pts': [list(pt) for pt in init_pts],
        'truth_pts': [list(pt) for pt in truth_pts],
        'final_pts': final_pts,
        'init_loss': init_loss,
        'final_loss': final_loss,
        'final_err_per_particle_mm': final_err_per_particle,
        'final_max_err_mm': final_max_err,
        'n_particles': args.n_particles,
        'obs_mode': args.obs_mode,
        'n_path_bins': args.n_path_bins if args.obs_mode == 'path' else None,
        'n_tips': args.n_tips if args.obs_mode == 'tips' else None,
        'n_load_samples': (args.n_load_samples
                           if args.obs_mode == 'load_disp' else None),
        'n_iter': args.n_iter,
        'n_samples': args.n_samples,
        'sigma': args.sigma,
        'lr': args.lr,
        'seed': args.seed,
        'n_steps': n_steps,
        'wall_total_s': total_wall,
        'truth_wall_s': truth_wall,
        'mesh': {'h_crack': h_crack, 'h_coarse': h_coarse,
                  'n_nodes': solver.mesh.n_nodes,
                  'n_elems': solver.mesh.n_elems},
        'history': history,
    }
    json_path = os.path.join(out_dir, 'es_run.json')
    with open(json_path, 'w') as f:
        json.dump(record, f, indent=2)
    print(f"  -> {json_path}")

    fig, ax = plt.subplots(1, 1, figsize=(4.5, 3.0), constrained_layout=True)
    iters = np.array([h['iter'] for h in history])
    losses = np.array([h['loss'] for h in history])
    obs_label = {'full': r'Damage MSE',
                  'path': r'Path mass-MSE',
                  'tips': r'Tip-x MSE',
                  'load_disp': r'Load-displacement MSE'}[args.obs_mode]
    ax.semilogy(iters, losses, '-', color='C2', lw=1.4,
                 label=f'ES (rank-shaped, obs={args.obs_mode})')
    ax.set_xlabel('ES iteration')
    ax.set_ylabel(obs_label)
    ax.set_title(f'ES inverse: stiff-inclusion centre  '
                  f'(n_particles={args.n_particles}, '
                  f'n_samples={args.n_samples}, sigma={args.sigma})')
    ax.grid(True, which='both', ls=':', lw=0.5, alpha=0.6)
    ax.legend(loc='best', frameon=False)
    png_path = os.path.join(out_dir, 'es_loss_curve.png')
    fig.savefig(png_path, dpi=200)
    plt.close(fig)
    sz_kb = os.path.getsize(png_path) / 1024
    print(f"  -> {png_path}  ({sz_kb:.0f} kB)")


if __name__ == '__main__':
    main()
