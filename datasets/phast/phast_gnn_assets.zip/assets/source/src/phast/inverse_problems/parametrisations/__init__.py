"""Low-dimensional parametrisations for spatially varying inverse-problem
fields (Gc(x), E(x), ...).

Currently provided
------------------
- ``FourierFeatures`` -- random Fourier feature lifting (Tancik 2020).
- ``FieldINR``        -- implicit neural representation: a small MLP that
  evaluates a scalar field at queried coordinates.
- ``evaluate_at_nodes`` -- thin convenience wrapper to evaluate an INR on a
  ``(n_nodes, n_dims)`` coordinate tensor.
- ``smooth_stiffness_field`` / ``smooth_toughness_field`` -- bounded Gaussian
  implicit fields for low-dimensional smooth material-zone recovery.

These are intended as smoothness-biased parametrisations for inverse-problem
demos (see issue #205): instead of optimising one DOF per element/node, the
inverse problem optimises the (small) parameter set ``theta`` of the network.
"""

from .fourier_features import FourierFeatures
from .inr import FieldINR, evaluate_at_nodes
from .smooth_graded import (
    SmoothBumpSpec,
    bounded_amplitude,
    element_centroids,
    gaussian_bump,
    positive_sigma,
    smooth_graded_field,
    smooth_stiffness_field,
    smooth_toughness_field,
)

__all__ = [
    "FourierFeatures",
    "FieldINR",
    "SmoothBumpSpec",
    "bounded_amplitude",
    "element_centroids",
    "evaluate_at_nodes",
    "gaussian_bump",
    "positive_sigma",
    "smooth_graded_field",
    "smooth_stiffness_field",
    "smooth_toughness_field",
]
