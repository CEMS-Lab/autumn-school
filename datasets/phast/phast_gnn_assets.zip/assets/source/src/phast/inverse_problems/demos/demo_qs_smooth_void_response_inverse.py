#!/usr/bin/env python
"""QS PF response inverse for a smooth fixed-mesh void.

This is the response-based counterpart to the holed-plate circle-fit lane.
Instead of differentiably remeshing a true circular hole, the hole is
represented by a smooth void surrogate on a fixed background mesh:

    void(x; c, r) = sigmoid((r - ||x - c||) / epsilon)

The surrogate reduces the element stiffness and toughness near the unknown
centre ``c``.  A quasistatic phase-field forward solve predicts reaction and
sparse displacement observations, and L-BFGS recovers the centre by autograd.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch

from phast.boundary_conditions import BoundaryConditions
from phast.device import DeviceContext
from phast.inverse_problems.parametrisations import element_centroids
from phast.material import create_material
from phast.mesh import FEMMesh
from phast.mesh_generator import square_plate
from phast.staggered_solver import SolverConfig, StaggeredSolver


DEFAULT_OUT = Path("examples/inverse_problems/qs_smooth_void_response/run1/results")


@dataclass(frozen=True)
class SmoothVoidResponseConfig:
    """Small but real QS PF/autograd response-inverse setup."""

    L: float = 1.0
    h: float = 0.16
    E_bulk: float = 210000.0
    Gc_bulk: float = 2.7
    nu: float = 0.30
    l0: float = 0.08
    true_center: tuple[float, float] = (0.63, 0.54)
    # This represents a realistic geometry/contour initializer.  The response
    # inverse refines this estimate; it is not expected to discover a distant
    # hole from a flat global search in the smoke-scale benchmark.
    init_center: tuple[float, float] = (0.55, 0.60)
    radius: float = 0.16
    epsilon: float = 0.035
    stiffness_floor: float = 0.08
    toughness_floor: float = 0.30
    displacements: tuple[float, ...] = (0.0015, 0.0030, 0.0045, 0.0060)
    energy_split: str = "isotropic"
    pf_model: str = "AT2"
    backend: str = "scipy"
    stagger_tol: float = 1.0e-6
    max_stagger: int = 120
    damage_tol: float = 1.0e-8
    static_tol: float = 1.0e-9
    dic_stride: int = 2
    reaction_weight: float = 1.0
    dic_weight: float = 0.35
    damage_weight: float = 0.03


@dataclass
class VoidResponseRollout:
    reactions: torch.Tensor
    dic: torch.Tensor
    d_final: torch.Tensor
    u_final: torch.Tensor
    max_damage: torch.Tensor
    void_field: torch.Tensor
    E_field: torch.Tensor
    Gc_field: torch.Tensor


def build_mesh(out_dir: Path, cfg: SmoothVoidResponseConfig, *, verbose: bool = False) -> FEMMesh:
    out_dir.mkdir(parents=True, exist_ok=True)
    mesh_path = out_dir / "smooth_void_response.msh"
    square_plate(str(mesh_path), L=cfg.L, h=cfg.h, verbose=verbose)
    mesh = FEMMesh(str(mesh_path), device="cpu", dtype=torch.float64)
    mesh.identify_boundaries()
    return mesh


def make_solver(mesh: FEMMesh, cfg: SmoothVoidResponseConfig) -> StaggeredSolver:
    material = create_material(
        "miehe_tension",
        E=cfg.E_bulk,
        nu=cfg.nu,
        Gc=cfg.Gc_bulk,
        l0=cfg.l0,
        pf_model=cfg.pf_model,
        energy_split=cfg.energy_split,
        gamma_correction=True,
    )
    bcs = BoundaryConditions(mesh.n_nodes, mesh.device, mesh.dtype)
    bcs.fix(mesh.node_sets["bottom"], 0)
    bcs.fix(mesh.node_sets["bottom"], 1)
    bcs.add(mesh.node_sets["top"], 1, 1.0)
    solver_cfg = SolverConfig(
        solver_type="quasi_static",
        differentiable=True,
        damage_tol=cfg.damage_tol,
        static_tol=cfg.static_tol,
        stagger_tol=cfg.stagger_tol,
        max_stagger=cfg.max_stagger,
        preconditioner="jacobi",
        use_multigrid=False,
        backend=cfg.backend,
    )
    return StaggeredSolver(
        mesh,
        material,
        bcs,
        config=solver_cfg,
        ctx=DeviceContext("cpu", torch.float64),
    )


def dic_node_indices(mesh: FEMMesh, stride: int) -> torch.Tensor:
    stride = max(1, int(stride))
    nodes = mesh.nodes
    x = nodes[:, 0]
    y = nodes[:, 1]
    interior = torch.where(
        (x > x.min() + 0.10 * (x.max() - x.min()))
        & (x < x.max() - 0.10 * (x.max() - x.min()))
        & (y > y.min() + 0.10 * (y.max() - y.min()))
        & (y < y.max() - 0.10 * (y.max() - y.min()))
    )[0]
    if interior.numel() == 0:
        interior = torch.arange(mesh.n_nodes, dtype=torch.long)
    return interior[::stride].long()


def smooth_void_indicator(
    coords: torch.Tensor,
    center: torch.Tensor,
    radius: float,
    epsilon: float,
) -> torch.Tensor:
    center_t = center.to(device=coords.device, dtype=coords.dtype)
    distance = torch.linalg.norm(coords - center_t, dim=1)
    return torch.sigmoid((torch.as_tensor(radius, dtype=coords.dtype) - distance) / epsilon)


def make_void_fields(
    mesh: FEMMesh,
    cfg: SmoothVoidResponseConfig,
    center: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    coords = element_centroids(mesh)
    void = smooth_void_indicator(coords, center, cfg.radius, cfg.epsilon)
    stiffness_factor = cfg.stiffness_floor + (1.0 - cfg.stiffness_floor) * (1.0 - void)
    toughness_factor = cfg.toughness_floor + (1.0 - cfg.toughness_floor) * (1.0 - void)
    E_field = torch.as_tensor(cfg.E_bulk, dtype=coords.dtype, device=coords.device) * stiffness_factor
    Gc_field = torch.as_tensor(cfg.Gc_bulk, dtype=coords.dtype, device=coords.device) * toughness_factor
    return void, E_field, Gc_field


def rollout(
    mesh: FEMMesh,
    cfg: SmoothVoidResponseConfig,
    center: torch.Tensor,
) -> VoidResponseRollout:
    solver = make_solver(mesh, cfg)
    void, E_field, Gc_field = make_void_fields(mesh, cfg, center)
    solver.install_diff_E_field(E_field)
    solver.diff_Gc_field = Gc_field
    top = mesh.node_sets["top"]
    dic_idx = dic_node_indices(mesh, cfg.dic_stride)
    reactions = []
    dic_samples = []

    for disp in cfg.displacements:
        solver.bcs.load_factor = float(disp)
        solver.step_full()
        fint = solver.fem.internal_force(solver.u, solver.d)
        reactions.append(fint[top, 1].sum())
        dic_samples.append(solver.u[dic_idx].reshape(-1))

    return VoidResponseRollout(
        reactions=torch.stack(reactions),
        dic=torch.cat(dic_samples),
        d_final=solver.d,
        u_final=solver.u,
        max_damage=solver.d.max(),
        void_field=void,
        E_field=E_field,
        Gc_field=Gc_field,
    )


def inverse_loss(
    pred: VoidResponseRollout,
    target: VoidResponseRollout,
    cfg: SmoothVoidResponseConfig,
) -> torch.Tensor:
    r_scale = target.reactions.detach().abs().max().clamp_min(1.0)
    u_scale = target.dic.detach().abs().max().clamp_min(1.0e-12)
    reaction = ((pred.reactions - target.reactions.detach()) / r_scale).pow(2).mean()
    dic = ((pred.dic - target.dic.detach()) / u_scale).pow(2).mean()
    damage = (pred.d_final - target.d_final.detach()).pow(2).mean()
    return (
        cfg.reaction_weight * reaction
        + cfg.dic_weight * dic
        + cfg.damage_weight * damage
    )


def _center_error(center: torch.Tensor | tuple[float, float], cfg: SmoothVoidResponseConfig) -> float:
    center_t = torch.as_tensor(center, dtype=torch.float64)
    truth = torch.tensor(cfg.true_center, dtype=torch.float64)
    return float(torch.linalg.norm(center_t - truth))


def gradient_check(
    mesh: FEMMesh,
    cfg: SmoothVoidResponseConfig,
    target: VoidResponseRollout,
    *,
    eps: float = 1.0e-4,
) -> dict[str, object]:
    center = torch.tensor(cfg.init_center, dtype=torch.float64, requires_grad=True)
    loss = inverse_loss(rollout(mesh, cfg, center), target, cfg)
    loss.backward()
    autograd = center.grad.detach().clone()
    finite_difference = []
    for idx in range(2):
        vals = []
        for sign in (1.0, -1.0):
            probe = torch.tensor(cfg.init_center, dtype=torch.float64)
            probe[idx] += sign * eps
            vals.append(float(inverse_loss(rollout(mesh, cfg, probe), target, cfg).detach()))
        finite_difference.append((vals[0] - vals[1]) / (2.0 * eps))
    fd = torch.tensor(finite_difference, dtype=torch.float64)
    rel = (autograd - fd).abs() / fd.abs().clamp_min(1.0e-30)
    return {
        "loss_at_init": float(loss.detach()),
        "names": ["center_x", "center_y"],
        "autograd": [float(v) for v in autograd],
        "finite_difference": [float(v) for v in fd],
        "relative_errors": [float(v) for v in rel],
        "max_relative_error": float(rel.max()),
    }


def run_inverse(
    mesh: FEMMesh,
    cfg: SmoothVoidResponseConfig,
    *,
    max_iter: int = 8,
) -> dict[str, object]:
    target_center = torch.tensor(cfg.true_center, dtype=torch.float64, requires_grad=True)
    target = rollout(mesh, cfg, target_center)
    initial_center = torch.tensor(cfg.init_center, dtype=torch.float64, requires_grad=True)
    initial = rollout(mesh, cfg, initial_center)
    center = torch.tensor(cfg.init_center, dtype=torch.float64, requires_grad=True)
    opt = torch.optim.LBFGS([center], lr=0.45, max_iter=max_iter, line_search_fn="strong_wolfe")
    history: list[dict[str, float]] = []

    def closure() -> torch.Tensor:
        opt.zero_grad()
        with torch.no_grad():
            center.clamp_(0.12 * cfg.L, 0.88 * cfg.L)
        pred = rollout(mesh, cfg, center)
        loss = inverse_loss(pred, target, cfg)
        loss.backward()
        history.append(
            {
                "center_x": float(center.detach()[0]),
                "center_y": float(center.detach()[1]),
                "loss": float(loss.detach()),
                "grad_norm": float(center.grad.detach().norm()),
            }
        )
        return loss

    opt.step(closure)
    with torch.no_grad():
        center.clamp_(0.12 * cfg.L, 0.88 * cfg.L)
    recovered = rollout(mesh, cfg, center.detach().clone().requires_grad_(True))
    gradcheck = gradient_check(mesh, cfg, target)
    initial_error = _center_error(cfg.init_center, cfg)
    recovered_error = _center_error(center.detach(), cfg)
    return {
        "problem": "qs_smooth_void_response_center_inverse",
        "target": target,
        "initial": initial,
        "recovered": recovered,
        "history": history,
        "truth_center": {"x": cfg.true_center[0], "y": cfg.true_center[1]},
        "initial_center": {"x": cfg.init_center[0], "y": cfg.init_center[1]},
        "recovered_center": {"x": float(center.detach()[0]), "y": float(center.detach()[1])},
        "initial_center_error": initial_error,
        "recovered_center_error": recovered_error,
        "error_reduction_factor": initial_error / max(recovered_error, 1.0e-30),
        "response_errors": {
            "initial_loss": history[0]["loss"] if history else float("nan"),
            "final_loss": history[-1]["loss"] if history else float("nan"),
            "max_damage_target": float(target.max_damage.detach()),
            "max_damage_initial": float(initial.max_damage.detach()),
            "max_damage_recovered": float(recovered.max_damage.detach()),
        },
        "field_errors": {
            "void_initial_rel_l2": float(
                (initial.void_field.detach() - target.void_field.detach()).norm()
                / target.void_field.detach().norm().clamp_min(1.0e-30)
            ),
            "void_recovered_rel_l2": float(
                (recovered.void_field.detach() - target.void_field.detach()).norm()
                / target.void_field.detach().norm().clamp_min(1.0e-30)
            ),
        },
        "gradcheck": gradcheck,
        "claim_boundary": (
            "Full QS PF/autograd response inverse for a fixed-mesh smooth-void "
            "hole centre from synthetic reaction + sparse-DIC observations. "
            "This is not differentiable remeshing of a sharp COMSOL hole."
        ),
    }


def save_artifacts(mesh: FEMMesh, cfg: SmoothVoidResponseConfig, result: dict[str, object], out_dir: Path) -> dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    summary_path = out_dir / "summary.json"
    history_path = out_dir / "history.csv"
    figure_path = out_dir / "smooth_void_response_inverse.png"
    pdf_path = out_dir / "smooth_void_response_inverse.pdf"
    animation_path = out_dir / "smooth_void_response_inverse.gif"

    summary = {
        "problem": result["problem"],
        "claim_boundary": result["claim_boundary"],
        "config": {
            "L": cfg.L,
            "h": cfg.h,
            "radius": cfg.radius,
            "epsilon": cfg.epsilon,
            "stiffness_floor": cfg.stiffness_floor,
            "toughness_floor": cfg.toughness_floor,
            "displacements": list(cfg.displacements),
        },
        "truth_center": result["truth_center"],
        "initial_center": result["initial_center"],
        "recovered_center": result["recovered_center"],
        "initial_center_error": result["initial_center_error"],
        "recovered_center_error": result["recovered_center_error"],
        "error_reduction_factor": result["error_reduction_factor"],
        "response_errors": result["response_errors"],
        "field_errors": result["field_errors"],
        "gradcheck": result["gradcheck"],
        "figures": {"png": str(figure_path), "pdf": str(pdf_path), "gif": str(animation_path)},
    }
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    if result["history"]:
        with history_path.open("w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(result["history"][0].keys()))
            writer.writeheader()
            writer.writerows(result["history"])
    _save_figure(mesh, cfg, result, figure_path, pdf_path)
    _save_animation(mesh, cfg, result, animation_path)
    return {
        "summary": str(summary_path),
        "history": str(history_path),
        "figure": str(figure_path),
        "pdf": str(pdf_path),
        "animation": str(animation_path),
    }


def _save_figure(mesh: FEMMesh, cfg: SmoothVoidResponseConfig, result: dict[str, object], png: Path, pdf: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.tri as mtri

    nodes = mesh.nodes.detach().cpu().numpy()
    elems = mesh.elements.detach().cpu().numpy()
    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elems)
    target: VoidResponseRollout = result["target"]
    initial: VoidResponseRollout = result["initial"]
    recovered: VoidResponseRollout = result["recovered"]
    disps = np.asarray(cfg.displacements)
    history = result["history"]

    fig, ax = plt.subplots(3, 3, figsize=(12.6, 10.4), constrained_layout=True)
    centres = [
        (cfg.true_center, "truth"),
        (cfg.init_center, "initial"),
        ((result["recovered_center"]["x"], result["recovered_center"]["y"]), "recovered"),
    ]
    panels = [
        ("truth smooth void", target.void_field, "magma", centres[0]),
        ("initial smooth void", initial.void_field, "magma", centres[1]),
        ("recovered smooth void", recovered.void_field, "magma", centres[2]),
        ("truth stiffness", target.E_field / cfg.E_bulk, "viridis", centres[0]),
        ("initial stiffness", initial.E_field / cfg.E_bulk, "viridis", centres[1]),
        ("recovered stiffness", recovered.E_field / cfg.E_bulk, "viridis", centres[2]),
    ]
    for axis, (title, field, cmap, (centre_xy, label)) in zip(ax[:2].reshape(-1), panels):
        artist = axis.tripcolor(tri, facecolors=field.detach().cpu().numpy(), shading="flat", cmap=cmap)
        axis.scatter(
            [centre_xy[0]],
            [centre_xy[1]],
            marker="x",
            s=70,
            linewidths=2.0,
            color="white" if cmap == "magma" else "black",
            label=label,
        )
        axis.set_title(title)
        axis.set_aspect("equal")
        axis.set_xlabel("x")
        axis.set_ylabel("y")
        fig.colorbar(artist, ax=axis, shrink=0.74)
        axis.legend(loc="lower right", fontsize=8, framealpha=0.82)

    ax[2, 0].plot(disps, target.reactions.detach().cpu().numpy(), "o-", label="truth")
    ax[2, 0].plot(disps, initial.reactions.detach().cpu().numpy(), "s--", label="initial")
    ax[2, 0].plot(disps, recovered.reactions.detach().cpu().numpy(), "^-.", label="recovered")
    ax[2, 0].set_title("reaction response")
    ax[2, 0].set_xlabel("imposed displacement")
    ax[2, 0].set_ylabel("top reaction")
    ax[2, 0].grid(alpha=0.3)
    ax[2, 0].legend()

    ax[2, 1].semilogy([row["loss"] for row in history], "o-", color="#b23a48")
    ax[2, 1].set_title("loss convergence")
    ax[2, 1].set_xlabel("closure evaluation")
    ax[2, 1].set_ylabel("loss")
    ax[2, 1].grid(alpha=0.3)

    grad = result["gradcheck"]
    x = np.arange(len(grad["names"]))
    width = 0.38
    ax[2, 2].bar(x - width / 2, grad["autograd"], width, label="autograd")
    ax[2, 2].bar(x + width / 2, grad["finite_difference"], width, label="finite diff")
    ax[2, 2].set_xticks(x, grad["names"])
    ax[2, 2].set_title(f"gradient check, max rel {grad['max_relative_error']:.2e}")
    ax[2, 2].grid(alpha=0.3)
    ax[2, 2].legend()

    fig.suptitle("QS PF smooth-void response inverse: recover hole centre", fontsize=14)
    fig.savefig(png, dpi=190)
    fig.savefig(pdf)
    plt.close(fig)


def _save_animation(mesh: FEMMesh, cfg: SmoothVoidResponseConfig, result: dict[str, object], gif: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.animation as animation
    import matplotlib.pyplot as plt
    import matplotlib.tri as mtri

    nodes = mesh.nodes.detach().cpu().numpy()
    elems = mesh.elements.detach().cpu().numpy()
    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elems)
    target: VoidResponseRollout = result["target"]
    history = result["history"]
    if not history:
        return

    losses = np.asarray([row["loss"] for row in history], dtype=float)
    xs = np.asarray([row["center_x"] for row in history], dtype=float)
    ys = np.asarray([row["center_y"] for row in history], dtype=float)
    truth = np.asarray(cfg.true_center, dtype=float)
    init = np.asarray(cfg.init_center, dtype=float)

    fig, (ax0, ax1) = plt.subplots(1, 2, figsize=(8.8, 3.8), constrained_layout=True)
    artist = ax0.tripcolor(
        tri,
        facecolors=target.void_field.detach().cpu().numpy(),
        shading="flat",
        cmap="magma",
        vmin=0.0,
        vmax=1.0,
    )
    fig.colorbar(artist, ax=ax0, shrink=0.82)
    ax0.scatter([truth[0]], [truth[1]], marker="*", s=120, color="white", edgecolor="black", label="truth")
    ax0.scatter([init[0]], [init[1]], marker="o", s=48, color="#1f77b4", label="initial")
    path_line, = ax0.plot([], [], "o-", color="#00d1ff", linewidth=2.0, markersize=4, label="optimiser path")
    ax0.set_title("smooth-void centre recovery")
    ax0.set_xlabel("x")
    ax0.set_ylabel("y")
    ax0.set_aspect("equal")
    ax0.legend(loc="lower right", fontsize=8)

    loss_line, = ax1.semilogy([], [], "o-", color="#b23a48", linewidth=2.0, markersize=4)
    ax1.set_xlim(0, max(len(losses) - 1, 1))
    ax1.set_ylim(losses.min() * 0.7, losses.max() * 1.4)
    ax1.set_title("response loss")
    ax1.set_xlabel("closure evaluation")
    ax1.set_ylabel("loss")
    ax1.grid(alpha=0.3)

    def update(frame: int):
        path_line.set_data(xs[: frame + 1], ys[: frame + 1])
        loss_line.set_data(np.arange(frame + 1), losses[: frame + 1])
        fig.suptitle(
            f"centre error {np.linalg.norm([xs[frame] - truth[0], ys[frame] - truth[1]]):.4f}",
            fontsize=12,
        )
        return path_line, loss_line

    anim = animation.FuncAnimation(fig, update, frames=len(history), interval=550, blit=False)
    writer = animation.PillowWriter(fps=2)
    anim.save(gif, writer=writer)
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--max-iter", type=int, default=8)
    parser.add_argument("--h", type=float, default=SmoothVoidResponseConfig.h)
    args = parser.parse_args()
    cfg = SmoothVoidResponseConfig(h=args.h)
    mesh = build_mesh(args.out_dir / "mesh", cfg)
    result = run_inverse(mesh, cfg, max_iter=args.max_iter)
    artifacts = save_artifacts(mesh, cfg, result, args.out_dir)
    payload = {
        "summary": artifacts["summary"],
        "figure": artifacts["figure"],
        "animation": artifacts["animation"],
        "recovered_center": result["recovered_center"],
        "recovered_center_error": result["recovered_center_error"],
        "gradcheck_max_relative_error": result["gradcheck"]["max_relative_error"],
        "claim_boundary": result["claim_boundary"],
    }
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
