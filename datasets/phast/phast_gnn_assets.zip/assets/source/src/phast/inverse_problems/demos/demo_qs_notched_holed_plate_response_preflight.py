#!/usr/bin/env python
"""Preflight for a response-based inverse on the QS notched-holed plate.

This module does not claim a full response inverse.  It prepares the missing
bridge between the passing boundary/circle-fit recovery and the future
load/DIC-based inverse: a differentiable smooth-void parameterisation of the
three holes, evaluated on a fixed background grid, with explicit gates that must
be satisfied before promotion.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import torch  # noqa: E402

from phast.inverse_problems.demos.demo_qs_notched_holed_plate_fixed_mesh import (
    smooth_hole_indicator,
)
from phast.inverse_problems.demos.demo_qs_notched_holed_plate_inverse import (
    DEFAULT_H5,
    HOLE_NODESETS,
    INIT_GUESSES,
    load_boundary_observations,
    recover_holes,
)


DEFAULT_OUT = Path("examples/inverse_problems/qs_comsol_hole_position/run1/response_preflight")


@dataclass(frozen=True)
class ResponsePreflightConfig:
    epsilon: float = 0.35
    stiffness_floor: float = 0.02
    grid_nx: int = 160
    grid_ny: int = 280


def regular_plate_grid(nodes: np.ndarray, cfg: ResponsePreflightConfig) -> tuple[np.ndarray, tuple[int, int]]:
    x = np.linspace(float(nodes[:, 0].min()), float(nodes[:, 0].max()), cfg.grid_nx)
    y = np.linspace(float(nodes[:, 1].min()), float(nodes[:, 1].max()), cfg.grid_ny)
    xx, yy = np.meshgrid(x, y)
    return np.column_stack([xx.ravel(), yy.ravel()]), (cfg.grid_ny, cfg.grid_nx)


def _parameter_arrays(rows: list[dict], source: str) -> tuple[np.ndarray, np.ndarray]:
    centres = []
    radii = []
    for row in rows:
        if source == "truth":
            centres.append([row["truth_x"], row["truth_y"]])
            radii.append(row["truth_radius"])
        elif source == "initial":
            centres.append([row["init_x"], row["init_y"]])
            radii.append(row["truth_radius"])
        elif source == "circle_fit":
            centres.append([row["recovered_x"], row["recovered_y"]])
            radii.append(row["recovered_radius"])
        else:
            raise ValueError(f"unknown source {source!r}")
    return np.asarray(centres, dtype=float), np.asarray(radii, dtype=float)


def smooth_void_fields(
    points: np.ndarray,
    rows: list[dict],
    cfg: ResponsePreflightConfig,
    *,
    source: str,
) -> tuple[np.ndarray, np.ndarray]:
    centres_np, radii_np = _parameter_arrays(rows, source)
    pts = torch.tensor(points, dtype=torch.float64)
    centres = torch.tensor(centres_np, dtype=torch.float64)
    radii = torch.tensor(radii_np, dtype=torch.float64)
    void = smooth_hole_indicator(pts, centres, radii, cfg.epsilon)
    stiffness = cfg.stiffness_floor + (1.0 - cfg.stiffness_floor) * (1.0 - void)
    return void.detach().cpu().numpy(), stiffness.detach().cpu().numpy()


def _relative_l2(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b) / max(np.linalg.norm(b), 1.0e-30))


def _max_centre_error(rows: list[dict], source: str) -> float:
    key_x, key_y = {
        "initial": ("init_x", "init_y"),
        "circle_fit": ("recovered_x", "recovered_y"),
    }[source]
    return max(
        float(np.linalg.norm([row[key_x] - row["truth_x"], row[key_y] - row["truth_y"]]))
        for row in rows
    )


def plot_preflight(
    points: np.ndarray,
    shape: tuple[int, int],
    fields: dict[str, np.ndarray],
    out_dir: Path,
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    x = points[:, 0].reshape(shape)
    y = points[:, 1].reshape(shape)
    fig, axes = plt.subplots(1, 4, figsize=(14.2, 5.2), constrained_layout=True)
    panels = [
        ("truth smooth void", fields["truth_void"], "magma", 0.0, 1.0),
        ("initial smooth void", fields["initial_void"], "magma", 0.0, 1.0),
        ("circle-fit smooth void", fields["circle_fit_void"], "magma", 0.0, 1.0),
        ("|circle-fit - truth|", np.abs(fields["circle_fit_void"] - fields["truth_void"]), "viridis", 0.0, None),
    ]
    for ax, (title, values, cmap, vmin, vmax) in zip(axes, panels):
        im = ax.pcolormesh(x, y, values.reshape(shape), shading="auto", cmap=cmap, vmin=vmin, vmax=vmax)
        ax.set_aspect("equal")
        ax.set_title(title)
        ax.set_xlabel("x (mm)")
        ax.set_ylabel("y (mm)")
        fig.colorbar(im, ax=ax, shrink=0.78)
    fig.suptitle("Holed-plate response-inverse preflight: differentiable smooth-void surrogate")
    fig.savefig(out_dir / "response_inverse_preflight.png", dpi=220)
    fig.savefig(out_dir / "response_inverse_preflight.pdf")
    plt.close(fig)


def run(
    h5: Path = DEFAULT_H5,
    out_dir: Path = DEFAULT_OUT,
    *,
    epsilon: float = ResponsePreflightConfig.epsilon,
    stiffness_floor: float = ResponsePreflightConfig.stiffness_floor,
    grid_nx: int = ResponsePreflightConfig.grid_nx,
    grid_ny: int = ResponsePreflightConfig.grid_ny,
    damage_step: str | int | None = None,
) -> dict:
    cfg = ResponsePreflightConfig(
        epsilon=epsilon,
        stiffness_floor=stiffness_floor,
        grid_nx=grid_nx,
        grid_ny=grid_ny,
    )
    boundaries, h5_fields = load_boundary_observations(h5, damage_step=damage_step)
    rows = recover_holes(boundaries)
    points, shape = regular_plate_grid(h5_fields["nodes"], cfg)
    field_payload: dict[str, np.ndarray] = {}
    summary_fields: dict[str, dict[str, float]] = {}
    for source in ("truth", "initial", "circle_fit"):
        void, stiffness = smooth_void_fields(points, rows, cfg, source=source)
        field_payload[f"{source}_void"] = void
        field_payload[f"{source}_stiffness"] = stiffness
        summary_fields[source] = {
            "void_mean": float(void.mean()),
            "void_max": float(void.max()),
            "stiffness_min_factor": float(stiffness.min()),
            "stiffness_mean_factor": float(stiffness.mean()),
        }

    out_dir.mkdir(parents=True, exist_ok=True)
    plot_preflight(points, shape, field_payload, out_dir)

    payload = {
        "status": "preflight_only_not_response_inverse",
        "claim_boundary": (
            "This validates the differentiable smooth-void parameterisation and "
            "response-inverse contract. It does not run a load/DIC response "
            "optimisation and must not be promoted as a full response inverse."
        ),
        "h5": str(h5),
        "selected_step": h5_fields["selected_step"],
        "config": {
            "epsilon": cfg.epsilon,
            "stiffness_floor": cfg.stiffness_floor,
            "grid_nx": cfg.grid_nx,
            "grid_ny": cfg.grid_ny,
        },
        "holes": rows,
        "smooth_void_metrics": {
            "initial_vs_truth_rel_l2": _relative_l2(field_payload["initial_void"], field_payload["truth_void"]),
            "circle_fit_vs_truth_rel_l2": _relative_l2(field_payload["circle_fit_void"], field_payload["truth_void"]),
            "initial_max_centre_error_mm": _max_centre_error(rows, "initial"),
            "circle_fit_max_centre_error_mm": _max_centre_error(rows, "circle_fit"),
        },
        "field_stats": summary_fields,
        "response_inverse_required_next": [
            "build a non-holed background mesh for the same outer plate outline",
            "install the smooth-void stiffness field in the quasistatic PF solver",
            "extract reaction and sparse displacement observations from the H5 archive",
            "check at least one centre-parameter autograd gradient against finite differences",
            "optimise response loss on training load steps and validate on held-out steps",
        ],
        "figures": {
            "png": str(out_dir / "response_inverse_preflight.png"),
            "pdf": str(out_dir / "response_inverse_preflight.pdf"),
        },
    }
    (out_dir / "response_inverse_preflight.json").write_text(json.dumps(payload, indent=2) + "\n")
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--h5", type=Path, default=DEFAULT_H5)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--epsilon", type=float, default=ResponsePreflightConfig.epsilon)
    parser.add_argument("--stiffness-floor", type=float, default=ResponsePreflightConfig.stiffness_floor)
    parser.add_argument("--grid-nx", type=int, default=ResponsePreflightConfig.grid_nx)
    parser.add_argument("--grid-ny", type=int, default=ResponsePreflightConfig.grid_ny)
    parser.add_argument("--damage-step", type=str, default=None)
    args = parser.parse_args()
    result = run(
        args.h5,
        args.out_dir,
        epsilon=args.epsilon,
        stiffness_floor=args.stiffness_floor,
        grid_nx=args.grid_nx,
        grid_ny=args.grid_ny,
        damage_step=args.damage_step,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
