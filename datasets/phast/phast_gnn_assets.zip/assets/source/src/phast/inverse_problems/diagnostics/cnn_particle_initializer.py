"""CNN coarse initializers for particle inverse problems.

The CNN stage is a measurement preprocessor, not the inverse solve. It maps
an observed damage/DIC-like image to coarse particle centres; the differentiable
solver then uses those centres as the starting point for local autograd
refinement on the fixed-mesh level-set particle parametrisation.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import torch
from torch import nn


@dataclass(frozen=True)
class ParticleCNNConfig:
    """Image-domain and network settings for coarse particle localization."""

    n_particles: int = 1
    image_size: tuple[int, int] = (96, 192)  # (height, width)
    domain: tuple[float, float, float, float] = (0.0, 32.0, 0.0, 16.0)
    in_channels: int = 1
    hidden_channels: int = 24

    def __post_init__(self) -> None:
        if self.n_particles <= 0:
            raise ValueError("n_particles must be positive")
        if len(self.image_size) != 2 or min(self.image_size) <= 1:
            raise ValueError("image_size must be (height, width) with values > 1")
        if len(self.domain) != 4:
            raise ValueError("domain must be (x_min, x_max, y_min, y_max)")
        x0, x1, y0, y1 = self.domain
        if not (x1 > x0 and y1 > y0):
            raise ValueError("domain extents must be increasing")


class TinyParticleInitializerCNN(nn.Module):
    """Small CNN that predicts normalized particle centres from an image.

    Output coordinates are in ``[0, 1]`` as ``(x1, y1, x2, y2, ...)``. Convert
    them to physical coordinates with :func:`normalized_to_physical`.
    """

    def __init__(self, config: ParticleCNNConfig):
        super().__init__()
        self.config = config
        c = int(config.hidden_channels)
        self.features = nn.Sequential(
            nn.Conv2d(config.in_channels, c, kernel_size=5, padding=2),
            nn.GroupNorm(4, c),
            nn.SiLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(c, 2 * c, kernel_size=3, padding=1),
            nn.GroupNorm(4, 2 * c),
            nn.SiLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(2 * c, 4 * c, kernel_size=3, padding=1),
            nn.GroupNorm(4, 4 * c),
            nn.SiLU(),
            nn.AdaptiveAvgPool2d(1),
        )
        self.head = nn.Sequential(
            nn.Flatten(),
            nn.Linear(4 * c, 4 * c),
            nn.SiLU(),
            nn.Linear(4 * c, 2 * config.n_particles),
            nn.Sigmoid(),
        )

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        """Return normalized particle coordinates for ``image``.

        ``image`` may have shape ``(H, W)``, ``(C, H, W)``, or
        ``(N, C, H, W)``. The return shape is ``(N, 2*n_particles)``.
        """
        if image.dim() == 2:
            image = image.unsqueeze(0).unsqueeze(0)
        elif image.dim() == 3:
            image = image.unsqueeze(0)
        elif image.dim() != 4:
            raise ValueError("image must have shape (H,W), (C,H,W), or (N,C,H,W)")
        return self.head(self.features(image))


def normalise_damage_image(image: np.ndarray | torch.Tensor,
                           eps: float = 1e-12) -> torch.Tensor:
    """Scale a damage-like image to ``[0, 1]`` without changing shape."""
    tensor = torch.as_tensor(image, dtype=torch.float32)
    finite = torch.isfinite(tensor)
    if not bool(finite.any()):
        raise ValueError("image contains no finite values")
    clean = torch.where(finite, tensor, torch.zeros_like(tensor))
    lo = torch.min(clean[finite])
    hi = torch.max(clean[finite])
    return torch.clamp((clean - lo) / (hi - lo + float(eps)), 0.0, 1.0)


def rasterize_nodal_field(nodes: np.ndarray,
                          values: np.ndarray,
                          image_size: tuple[int, int],
                          domain: tuple[float, float, float, float] | None = None
                          ) -> np.ndarray:
    """Nearest-bin rasterisation of nodal scalar data onto an image grid."""
    nodes = np.asarray(nodes, dtype=float)
    values = np.asarray(values, dtype=float).reshape(-1)
    if nodes.ndim != 2 or nodes.shape[1] != 2:
        raise ValueError("nodes must have shape (n_nodes, 2)")
    if values.shape[0] != nodes.shape[0]:
        raise ValueError("values length must match nodes")
    h, w = int(image_size[0]), int(image_size[1])
    if h <= 1 or w <= 1:
        raise ValueError("image_size entries must be greater than one")
    if domain is None:
        x_min, x_max = float(nodes[:, 0].min()), float(nodes[:, 0].max())
        y_min, y_max = float(nodes[:, 1].min()), float(nodes[:, 1].max())
    else:
        x_min, x_max, y_min, y_max = map(float, domain)
    if not (x_max > x_min and y_max > y_min):
        raise ValueError("domain extents must be increasing")

    ix = np.rint((nodes[:, 0] - x_min) / (x_max - x_min) * (w - 1)).astype(int)
    iy = np.rint((nodes[:, 1] - y_min) / (y_max - y_min) * (h - 1)).astype(int)
    keep = (ix >= 0) & (ix < w) & (iy >= 0) & (iy < h) & np.isfinite(values)
    image = np.zeros((h, w), dtype=np.float32)
    count = np.zeros((h, w), dtype=np.float32)
    np.add.at(image, (iy[keep], ix[keep]), values[keep].astype(np.float32))
    np.add.at(count, (iy[keep], ix[keep]), 1.0)
    mask = count > 0
    image[mask] /= count[mask]
    return image


def normalized_to_physical(coords: torch.Tensor | np.ndarray,
                           domain: tuple[float, float, float, float]
                           ) -> np.ndarray:
    """Convert normalized ``(x,y)`` coordinates to physical coordinates."""
    arr = np.asarray(torch.as_tensor(coords).detach().cpu(), dtype=float)
    flat = arr.reshape(-1, 2)
    x_min, x_max, y_min, y_max = map(float, domain)
    out = np.empty_like(flat, dtype=float)
    out[:, 0] = x_min + flat[:, 0] * (x_max - x_min)
    out[:, 1] = y_min + flat[:, 1] * (y_max - y_min)
    return out.reshape(arr.shape)


def physical_to_normalized(coords: torch.Tensor | np.ndarray,
                           domain: tuple[float, float, float, float]
                           ) -> np.ndarray:
    """Convert physical ``(x,y)`` coordinates to normalized coordinates."""
    arr = np.asarray(torch.as_tensor(coords).detach().cpu(), dtype=float)
    flat = arr.reshape(-1, 2)
    x_min, x_max, y_min, y_max = map(float, domain)
    out = np.empty_like(flat, dtype=float)
    out[:, 0] = (flat[:, 0] - x_min) / (x_max - x_min)
    out[:, 1] = (flat[:, 1] - y_min) / (y_max - y_min)
    return np.clip(out.reshape(arr.shape), 0.0, 1.0)


def load_damage_image_npz(path: Path,
                          config: ParticleCNNConfig,
                          damage_key: str | None = None) -> torch.Tensor:
    """Load a damage-like observation as a normalized tensor image."""
    z = np.load(path, allow_pickle=True)
    key = damage_key
    if key is None:
        for candidate in ("d_target", "d_final", "damage", "damage_final"):
            if candidate in z.files:
                key = candidate
                break
    if key is None:
        raise ValueError(f"{path} has no supported damage field key")
    field = np.asarray(z[key], dtype=float)
    if field.ndim == 2:
        image = field.astype(np.float32)
    elif "nodes" in z.files:
        image = rasterize_nodal_field(
            np.asarray(z["nodes"], dtype=float),
            field,
            config.image_size,
            config.domain,
        )
    else:
        raise ValueError(
            f"{path}:{key} is one-dimensional but no nodes array is present")
    return normalise_damage_image(image)


def load_checkpoint_model(path: Path,
                          config: ParticleCNNConfig,
                          device: str | torch.device = "cpu") -> TinyParticleInitializerCNN:
    """Load a trained CNN initializer checkpoint."""
    model = TinyParticleInitializerCNN(config).to(device)
    checkpoint = torch.load(path, map_location=device)
    state = checkpoint.get("model_state_dict", checkpoint) if isinstance(checkpoint, dict) else checkpoint
    model.load_state_dict(state)
    model.eval()
    return model


@torch.no_grad()
def predict_particle_initializers(model: TinyParticleInitializerCNN,
                                  image: torch.Tensor,
                                  config: ParticleCNNConfig
                                  ) -> dict:
    """Predict physical particle centres and emit solver initializer JSON."""
    device = next(model.parameters()).device
    pred = model(image.to(device)).detach().cpu().view(config.n_particles, 2)
    particles = normalized_to_physical(pred, config.domain)
    x_min, x_max, _, _ = config.domain
    half_width = max(0.5, 0.08 * (x_max - x_min))
    windows = [
        {
            "x_min": float(max(x_min, xy[0] - half_width)),
            "x_max": float(min(x_max, xy[0] + half_width)),
        }
        for xy in particles
    ]
    return {
        "recovered_particles": [[float(x), float(y)] for x, y in particles],
        "observation_windows": windows,
        "method": "cnn_particle_initializer_v1",
        "diagnostics": {
            "n_particles": int(config.n_particles),
            "image_size": [int(config.image_size[0]), int(config.image_size[1])],
            "domain": [float(v) for v in config.domain],
            "normalized_prediction": pred.numpy().reshape(-1).tolist(),
        },
    }


def _parse_pair(text: str) -> tuple[int, int]:
    parts = [int(v.strip()) for v in text.split(",")]
    if len(parts) != 2:
        raise ValueError("expected H,W")
    return parts[0], parts[1]


def _parse_domain(text: str) -> tuple[float, float, float, float]:
    parts = [float(v.strip()) for v in text.split(",")]
    if len(parts) != 4:
        raise ValueError("expected x_min,x_max,y_min,y_max")
    return parts[0], parts[1], parts[2], parts[3]


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Predict particle initializer JSON from a damage image.")
    parser.add_argument("input", type=Path, help="NPZ with damage image/field.")
    parser.add_argument("--checkpoint", type=Path, required=True,
                        help="Trained TinyParticleInitializerCNN checkpoint.")
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--n_particles", type=int, default=1)
    parser.add_argument("--image_size", default="96,192", help="H,W")
    parser.add_argument("--domain", default="0,32,0,16",
                        help="x_min,x_max,y_min,y_max in mm")
    parser.add_argument("--damage_key", default=None)
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args(list(argv) if argv is not None else None)

    config = ParticleCNNConfig(
        n_particles=args.n_particles,
        image_size=_parse_pair(args.image_size),
        domain=_parse_domain(args.domain),
    )
    image = load_damage_image_npz(args.input, config, args.damage_key)
    model = load_checkpoint_model(args.checkpoint, config, args.device)
    result = predict_particle_initializers(model, image, config)

    out = args.output or args.input.with_name(args.input.stem + "_cnn_initializer.json")
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
