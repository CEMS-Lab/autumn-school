"""Shared truncated-BPTT helper for inverse-problem demos (issue #301).

Promoted from ``demo_inverse_stiff_inclusion.run_forward_tbptt`` (PR #291)
so that every inverse demo can opt into the same chunked-BPTT path. The
per-step body is identical across demos (``solver.step_full()``) -- what
differs is **how the controllable parameter is installed** on the solver.

Demos pass an ``install_fn(solver) -> None`` callback that performs the
demo-specific install (``solver.install_diff_E_field(E_field)``,
``solver.diff_Gc_field = Gc_field``, scalar Gc set on material, etc.).
The helper itself stays demo-agnostic.

The function is a strict generalisation of the original:
* signature is ``(solver, loading, install_fn, n_steps, tbptt_chunk_size,
  ...)`` -- the parameter tensor argument has been replaced by the
  install callback, but no other behaviour changes.
* state reset, step loop, snapshot semantics, chunk-boundary detach, and
  return tuple are unchanged.

The original ``run_forward_tbptt`` symbol in
``demo_inverse_stiff_inclusion`` is preserved as a thin wrapper so
existing imports (``tests/test_tbptt_inversion.py``,
``inverse_problems/precheck_truth_fields.py``) keep working.

This module is private (``_tbptt``) by convention -- callers reach in
explicitly via the absolute import path and we make no stability
guarantees outside the demo set.
"""
from __future__ import annotations

import gc
import os
import time
from typing import Callable, List, Optional, Tuple

import torch


# Pair A OOM mitigation (job 29517): the TBPTT helper allocates one
# chunk's autograd tape per iteration of its outer loop. Without an
# explicit empty_cache between chunks, the CUDA caching allocator can
# hold the prior chunk's released-but-still-cached blocks while the next
# chunk begins to allocate -- which fragmented enough on 80GB A100 at
# n_steps=20000, chunk_size=50 to OOM at chunk 1.
#
# Gated on the TPS_TBPTT_FREE env var so legacy callers (CPU smoke
# tests, existing inverse demos that don't see the OOM) are unaffected.
# The Pair A slurms set TPS_TBPTT_FREE=1.
_TBPTT_FREE = os.environ.get("TPS_TBPTT_FREE", "1") not in ("0", "false", "")

from phast.config import compute_load_factor

# Module-level counter incremented every time the TBPTT helper is
# invoked. Smoke tests check this to assert "the TBPTT path was taken"
# without log scraping. Reset by ``reset_call_count`` in test setup.
_call_count = 0


def reset_call_count() -> None:
    """Reset the TBPTT invocation counter to 0 (test helper)."""
    global _call_count
    _call_count = 0


def get_call_count() -> int:
    """Return the current TBPTT invocation counter (test helper)."""
    return _call_count


def _reaction_force_y(solver, u, d, top_idx):
    """Sum of internal-force y-component at the loaded top boundary.

    Local copy of stiff_inclusion's helper -- pulled in here so this
    module has no upward dependency on the demos. See
    ``demo_inverse_stiff_inclusion.reaction_force_y`` for the canonical
    docstring.
    """
    f_int = solver.fem.internal_force(u, d)
    return f_int[top_idx, 1].sum()


def run_forward_tbptt_generic(
    solver,
    loading,
    install_fn: Callable[[object], None],
    n_steps: int,
    tbptt_chunk_size: int,
    snapshot_steps: Optional[List[int]] = None,
    load_steps: Optional[List[int]] = None,
    top_idx=None,
    eager_loss_fn: Optional[Callable[[int, torch.Tensor], torch.Tensor]] = None,
    eager_backward_scale: float = 1.0,
    reinstall_per_chunk: bool = True,
    record_u_chunks: bool = False,
) -> Tuple[torch.Tensor, List[torch.Tensor], List[int], Optional[list]]:
    """Truncated-BPTT forward (issue #288, generalised in #301).

    Splits the n_steps explicit-dynamics loop into chunks of length
    ``tbptt_chunk_size`` (last chunk may be shorter). Within each chunk
    the autograd tape is intact and gradients of the chunk-end damage
    snapshot flow back to whichever leaf parameter ``install_fn``
    installed on the solver. At each chunk boundary the simulator
    state ``(u, v, a, d, H_elem, H_nodal)`` is detached -- the
    gradient-propagation horizon is bounded by ``tbptt_chunk_size``.

    The resulting gradient is a **biased** estimator of the full-BPTT
    gradient (chunk k's loss has no path through chunks 1..k-1's state
    evolution). Bound on chaotic amplification is the deliberate
    trade-off (Suh et al. 2022 ICML S5.4; #287, #288).

    Parameters
    ----------
    solver : StaggeredSolver
        Will be reset (state zeroed, ``_step_count = 0``) before the
        loop. The caller's parameter tensor is installed by
        ``install_fn`` after the reset.
    loading : LoadingConfig
        Used by ``compute_load_factor`` each step.
    install_fn : callable
        ``install_fn(solver) -> None``. Called once after state reset.
        Must install the demo's controllable parameter (E field, Gc
        field, scalar Gc, etc.) such that ``solver.step_full()`` picks
        it up. The parameter tensor must already be a leaf with
        ``requires_grad=True`` if backward is desired.
    n_steps : int
    tbptt_chunk_size : int
        Must be ``> 0``. ``0`` is the "TBPTT disabled" sentinel and is
        the caller's responsibility to dispatch around.
    snapshot_steps, load_steps, top_idx
        Same semantics as ``run_forward``: optional per-step damage /
        reaction-force samples that attach to whichever chunk's local
        tape they fall inside.
    eager_loss_fn : callable, optional
        ``eager_loss_fn(chunk_idx, chunk_d) -> scalar tensor``. When
        supplied, the per-chunk loss is computed and **backward is
        called immediately** (with ``retain_graph=False``) so the
        chunk's autograd graph can be freed before the next chunk
        starts. This bounds peak memory at one chunk's tape (vs
        ``O(n_chunks)`` when the closure-side stacks ``chunk_snaps``
        and backwards a single mean at the end). The mathematical
        gradient is identical to the lazy path -- ``.backward()`` on
        ``mean(c1, c2, ..., cN)`` is equivalent to a sum of
        ``(ck/N).backward()`` calls into the same leaf, in any order.
        ``chunk_snaps`` in the return contains **detached** tensors in
        this mode (the caller must not call backward on them again).
    eager_backward_scale : float, default 1.0
        Multiplier applied to each chunk loss before the eager backward
        call. Pass ``1.0/n_chunks`` to recover the canonical
        mean-of-chunks gradient. Pass ``1.0`` for sum-of-chunks. Has
        no effect when ``eager_loss_fn`` is None.
    record_u_chunks : bool, default False
        When True, store chunk-end displacement tensors in
        ``solver._tbptt_last_u_chunk_snaps``. This is a diagnostic
        back-channel for DIC-style observables and preserves the
        historical 4-tuple return contract.
    reinstall_per_chunk : bool, default True
        When True (and eager mode is on), call ``install_fn(solver)``
        at every chunk boundary. This is required when the parameter
        installed on the solver is a NON-leaf tensor (e.g. a
        ``gaussian_E_field_multi(init_flat, ...)`` derivation): chunk
        K's backward consumes the saved tensors of the derivation's
        grad_fn, so chunk K+1's backward into the same derived tensor
        would fail with "backward through the graph a second time".
        Reinstall causes the install_fn to call its derivation
        callback again, producing a fresh non-leaf tensor with a
        fresh grad_fn each chunk. The accumulation into the original
        leaf parameter is unchanged. Set False only when
        ``install_fn`` performs an irreversible side-effect (mesh
        rebuild, mechanics rebuild) that cannot be re-run cheaply per
        chunk -- the per-element Lame cache is invalidated regardless.

    Returns
    -------
    (d_final, chunk_snaps, chunk_end_steps, loads)
        See module docstring; identical shape to PR #291's original.
        When ``eager_loss_fn`` is supplied, ``chunk_snaps`` entries are
        ``detach()``ed after the per-chunk backward; the caller can use
        them for diagnostics but cannot run a second backward through
        them. The eager per-chunk loss values (detached scalars) are
        accessible via ``solver._tbptt_last_chunk_losses`` after the
        call (a small back-channel kept here to avoid breaking the
        public 4-tuple return contract).
    """
    if tbptt_chunk_size <= 0:
        raise ValueError("tbptt_chunk_size must be > 0 for TBPTT mode")
    global _call_count
    _call_count += 1

    n_nodes = solver.mesh.n_nodes
    n_elem = solver.mesh.n_elems
    dt = solver.dtype
    dev = solver.device
    solver.u = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.v = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.a = torch.zeros(n_nodes, 2, dtype=dt, device=dev)
    solver.d = torch.zeros(n_nodes, dtype=dt, device=dev)
    solver.H_elem = torch.zeros(n_elem, dtype=dt, device=dev)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dt, device=dev)
    solver._step_count = 0
    install_fn(solver)
    solver_dt = solver.dt

    snap_set = set(snapshot_steps) if snapshot_steps else set()
    load_set = set(load_steps) if load_steps else set()
    chunk_snaps: List[torch.Tensor] = []
    u_chunk_snaps: List[torch.Tensor] = []
    chunk_end_steps: List[int] = []
    loads: Optional[list] = [] if load_steps else None
    snaps: Optional[list] = [] if snapshot_steps else None

    n_chunks = (n_steps + tbptt_chunk_size - 1) // tbptt_chunk_size
    progress_every = max(1, n_chunks // 20)
    _t_loop_start = time.time()

    base = 0
    chunk_idx = 0
    eager_chunk_losses: List[torch.Tensor] = []
    eager_mode = eager_loss_fn is not None
    print(f"    [TBPTT #301] {n_chunks} chunks of size "
          f"{tbptt_chunk_size} over {n_steps} steps"
          + ("  [eager-backward, peak=1-chunk graph]" if eager_mode else ""),
          flush=True)
    while base < n_steps:
        k = min(tbptt_chunk_size, n_steps - base)
        for j in range(k):
            step = base + j
            solver.bcs.load_factor = compute_load_factor(
                step, solver_dt, loading)
            solver.step_full()
            if (step + 1) in snap_set and snaps is not None:
                snaps.append(solver.d)
            if (step + 1) in load_set and loads is not None:
                loads.append(_reaction_force_y(
                    solver, solver.u, solver.d, top_idx))
        # Snapshot chunk-end damage on the *current* in-chunk tape
        # before detaching state.
        if eager_mode:
            # Compute the per-chunk loss using the caller-supplied
            # functional (it can capture targets, obs_mode, etc. via
            # closure) and backward immediately. retain_graph=False
            # frees the chunk's tape; the next chunk starts from a
            # detached state and builds a fresh tape.
            chunk_loss = eager_loss_fn(chunk_idx, solver.d)
            (chunk_loss * eager_backward_scale).backward()
            eager_chunk_losses.append(chunk_loss.detach())
            # chunk_snaps in eager mode is detached -- the tape is gone.
            chunk_snaps.append(solver.d.detach())
        else:
            chunk_snaps.append(solver.d)
        if record_u_chunks:
            u_chunk_snaps.append(solver.u.detach() if eager_mode else solver.u)
        chunk_end_steps.append(base + k)
        base += k
        chunk_idx += 1
        # Cut the time-recursion graph at the boundary; keep installed
        # parameter intact so each chunk's loss still flows back to its
        # leaf.
        solver.u = solver.u.detach()
        solver.v = solver.v.detach()
        solver.a = solver.a.detach()
        solver.d = solver.d.detach()
        solver.H_elem = solver.H_elem.detach()
        solver.H_nodal = solver.H_nodal.detach()
        # Drop any solver scratch that referenced the just-detached
        # in-chunk graph (e.g. _last_strain). Without this the previous
        # chunk's strain-tape stays alive across the boundary and the
        # CUDA caching allocator can't reclaim it. Forward semantics
        # unchanged (the next chunk's step_full overwrites _last_strain).
        if hasattr(solver, '_last_strain'):
            solver._last_strain = None
        # Invalidate the per-element Lame cache in fem_operators
        # (``_resolve_lame`` keys (lam_e, mu_e, kappa_e) by
        # ``id(diff_E_field)`` and reuses them across step_full calls).
        # When eager backward fires on a chunk, autograd frees the
        # saved intermediates of the lam/mu nodes; the next chunk's
        # graph would then try to backward through those freed nodes
        # ("Trying to backward through the graph a second time").
        # Clearing the cache forces _resolve_lame to rebuild fresh
        # lam/mu tensors per chunk, giving each chunk its own
        # self-contained subgraph. Numerics unchanged -- the
        # recomputed lam/mu are bit-identical functions of E.
        fem = getattr(solver, 'fem', None)
        if fem is not None and hasattr(fem, '_E_field_cache_id'):
            fem._E_field_cache_id = None
            fem._E_field_lam = None
            fem._E_field_mu = None
            fem._E_field_kappa = None
        # Eager-mode + non-leaf parameter: re-run install_fn so the
        # solver receives a fresh derived parameter tensor (e.g. a
        # fresh gaussian(init_flat) call) with a fresh grad_fn. Without
        # this, chunk K+1's backward into the SAME derived tensor would
        # try to traverse the gaussian's grad_fn whose saved tensors
        # were freed by chunk K's backward.
        if eager_mode and reinstall_per_chunk and base < n_steps:
            install_fn(solver)
        # Pair A OOM mitigation (job 29517): release cached-but-unused
        # CUDA blocks between chunks so the next chunk's graph does not
        # have to grow into a fragmented allocator. empty_cache is a
        # no-op for tensors still in use; safe to call inside the loop.
        if _TBPTT_FREE and torch.cuda.is_available():
            torch.cuda.empty_cache()
        if (chunk_idx % progress_every == 0
                or chunk_idx == n_chunks):
            print(f"    [TBPTT] chunk {chunk_idx}/{n_chunks} "
                  f"(step {base}/{n_steps}, "
                  f"max(d)={float(solver.d.max()):.3f}, "
                  f"{time.time() - _t_loop_start:.1f}s elapsed)",
                  flush=True)

    d_final = solver.d
    if eager_mode:
        # Back-channel: caller (closure) may want the per-chunk losses
        # for the diagnostics print. Avoids breaking the public 4-tuple
        # return contract.
        solver._tbptt_last_chunk_losses = eager_chunk_losses
    if record_u_chunks:
        solver._tbptt_last_u_chunk_snaps = u_chunk_snaps
    return d_final, chunk_snaps, chunk_end_steps, loads


# Convenience install-fn factories for the common parameter-install
# patterns observed across the 8 demos.
def make_install_E_field(E_field) -> Callable:
    """Install via ``solver.install_diff_E_field``.

    Accepts either a tensor (legacy: same E_field captured for every
    install call) or a zero-arg callable factory (eager-backward
    friendly: each install call re-derives a fresh non-leaf E tensor
    so chunk K+1's backward does not collide with chunk K's freed
    saved tensors). The factory pattern is what the production
    closure uses under ``--tbptt_eager_backward``.

    Used by: stiff_inclusion, E_horizontal.
    """
    if callable(E_field) and not isinstance(E_field, torch.Tensor):
        def _install_from_factory(solver):
            solver.install_diff_E_field(E_field())
        return _install_from_factory

    def _install(solver):
        solver.install_diff_E_field(E_field)
    return _install


def make_install_Gc_field(Gc_field: torch.Tensor) -> Callable:
    """Install via ``solver.diff_Gc_field`` attribute.

    Used by: gc_horizontal, microstructure, hole_topology,
    spatial_gc_recovery.
    """
    def _install(solver):
        solver.diff_Gc_field = Gc_field
    return _install


def make_install_diff_Gc(Gc_t: torch.Tensor,
                          l0_t: Optional[torch.Tensor] = None) -> Callable:
    """Install a scalar (autograd-tape) Gc (and optionally l0) via the
    ``solver.diff_Gc`` / ``solver.diff_l0`` attributes.

    Used by: ``demo_autograd_inversion`` (Gc + l0) and
    ``demo_spatial_gc_recovery`` (when used with a scalar Gc).

    Note: ``demo_inverse_alumina_gc`` is **not** an autograd demo --
    it uses finite differences (#301 audit) so TBPTT does not apply.
    """
    def _install(solver):
        solver.diff_Gc = Gc_t
        if l0_t is not None:
            solver.diff_l0 = l0_t
    return _install


def make_install_kalthoff_params(params: dict) -> Callable:
    """Install the Kalthoff parameter dict on the solver.

    autograd_kalthoff installs a mixture of material attributes
    (``solver.material.E``, ``solver.material.nu``) and solver-level
    diff overrides (``solver.diff_Gc``, ``solver.diff_l0``). Encapsulated
    here so the demo's TBPTT branch stays a one-liner.
    """
    def _install(solver):
        if 'E' in params:
            solver.material.E = params['E']
        if 'nu' in params:
            solver.material.nu = params['nu']
        if 'Gc' in params:
            solver.diff_Gc = params['Gc']
        if 'l0' in params:
            solver.diff_l0 = params['l0']
    return _install
