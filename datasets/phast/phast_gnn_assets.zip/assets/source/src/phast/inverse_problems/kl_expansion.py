"""Karhunen-Loève expansion for random Gc(x) fields.

Models Gc(x) as a Gaussian random field with exponential covariance:

    C(x, x') = sigma_kl^2 * exp(-|x - x'| / L_corr)

The KL expansion truncates to K terms:

    Gc(x; xi) = Gc_mean + sum_{k=1}^{K} sqrt(lambda_k) * phi_k(x) * xi_k

where (lambda_k, phi_k) are the K leading eigenpairs of the covariance
operator, and xi ~ N(0, 1) are independent standard normal random variables.

Differentiable use (for gradient-based variance estimation)
-----------------------------------------------------------
The KL realisation is a linear function of xi. When the forward solver
accepts Gc(x; xi) and produces a scalar QoI, autograd backpropagates
through the linear map to give dQoI/d(xi), enabling:

  - Pathwise gradient estimator for E[QoI] and Var[QoI]
  - Score-function estimator for P(crack reaches x = x_target)
  - Importance-weighted Monte Carlo with gradient-based IS weights

Typical use
-----------
::

    from phast.inverse_problems.kl_expansion import (
        KLExpansion, kl_realisation, kl_variance_gradient
    )

    # 1. Build expansion from element centroid x-coordinates
    kl = KLExpansion(coords_x, K=20, L_corr=5.0, sigma_kl=0.1, Gc_mean=0.3)

    # 2. Draw a realisation at new xi
    xi = torch.randn(20)           # 20 KL modes
    Gc = kl(xi)                    # (n_elem,) Gc field, differentiable in xi

    # 3. Use in forward solver and backpropagate
    d_final = solver_forward(Gc)   # depends on Gc via forward
    qoi = (d_final > 0.5).float().sum()  # non-differentiable
    # Use pathwise gradient through the differentiable pre-crack region instead.

Integration test
----------------
::

    python -m phast.inverse_problems.kl_expansion
"""
from __future__ import annotations

from typing import Optional, Tuple

import numpy as np
import torch
from torch import Tensor


# ---------------------------------------------------------------------------
# KL expansion (1D covariance, suitable for horizontal crack band)
# ---------------------------------------------------------------------------

class KLExpansion:
    """Karhunen-Loève expansion of a 1-D Gaussian random field over x-coords.

    Covariance: ``C(x, x') = sigma^2 * exp(-|x - x'| / L_corr)``

    Parameters
    ----------
    coords_x   : (n_pts,) x-coordinates (element centroids or nodes) in mm
    K          : number of KL modes to retain
    L_corr     : correlation length in mm
    sigma_kl   : standard deviation of the field
    Gc_mean    : mean Gc (baseline). Realisations will deviate from this.
    device, dtype : torch device/dtype
    """

    def __init__(
        self,
        coords_x: np.ndarray | Tensor,
        K: int = 20,
        L_corr: float = 5.0,
        sigma_kl: float = 0.05,
        Gc_mean: float = 0.3,
        device: str = "cpu",
        dtype: torch.dtype = torch.float64,
    ) -> None:
        self.K = K
        self.L_corr = L_corr
        self.sigma_kl = sigma_kl
        self.Gc_mean = Gc_mean
        self.device = device
        self.dtype = dtype

        if isinstance(coords_x, Tensor):
            x_np = coords_x.detach().cpu().numpy().astype(np.float64)
        else:
            x_np = np.asarray(coords_x, dtype=np.float64)

        self.n_pts = x_np.shape[0]
        lambdas, phis = self._compute_eigenpairs(x_np, K, L_corr, sigma_kl)

        # Store as buffers
        self._sqrt_lambdas = torch.tensor(
            lambdas, dtype=torch.float64, device=device
        )  # (K,)
        self._phis = torch.tensor(
            phis, dtype=torch.float64, device=device
        )  # (n_pts, K)
        self._Gc_mean_t = torch.tensor(Gc_mean, dtype=torch.float64, device=device)

    @staticmethod
    def _compute_eigenpairs(
        x: np.ndarray,
        K: int,
        L_corr: float,
        sigma: float,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Compute (sqrt_lambdas, phis) by dense eigendecomposition.

        Returns
        -------
        sqrt_lambdas : (K,) — sqrt of K largest eigenvalues
        phis         : (n, K) — corresponding eigenvectors (columns)
        """
        n = x.shape[0]
        # Exponential covariance matrix
        dx = x[:, None] - x[None, :]   # (n, n)
        C = sigma ** 2 * np.exp(-np.abs(dx) / L_corr)

        # Regularise for numerical stability
        C += 1e-10 * np.eye(n)

        # Dense eigendecomposition (sorted descending)
        eigvals, eigvecs = np.linalg.eigh(C)
        # eigh returns ascending order; flip
        eigvals = eigvals[::-1]
        eigvecs = eigvecs[:, ::-1]

        K = min(K, n)
        eigvals_K = np.maximum(eigvals[:K], 0.0)
        phis_K = eigvecs[:, :K]  # (n, K)

        return np.sqrt(eigvals_K), phis_K.copy()

    def __call__(self, xi: Tensor) -> Tensor:
        """Draw a Gc(x) realisation for given KL coefficients xi.

        Parameters
        ----------
        xi : (K,) standard normal random variables

        Returns
        -------
        (n_pts,) Gc field, differentiable w.r.t. xi
        """
        xi = xi.to(dtype=torch.float64, device=self.device)
        if xi.shape[0] > self.K:
            xi = xi[:self.K]
        # Gc(x) = Gc_mean + Phi @ (sqrt_lambda * xi)
        weights = self._sqrt_lambdas[:xi.shape[0]] * xi  # (K,)
        delta = self._phis[:, :xi.shape[0]] @ weights    # (n_pts,)
        return (self._Gc_mean_t + delta).to(dtype=self.dtype)

    def sample_xi(self, n_samples: int = 1, seed: Optional[int] = None) -> Tensor:
        """Sample n_samples × K independent N(0,1) coefficients."""
        if seed is not None:
            torch.manual_seed(seed)
        return torch.randn(n_samples, self.K, dtype=torch.float64, device=self.device)

    def variance_field(self) -> Tensor:
        """Exact pointwise variance: sum_k lambda_k * phi_k(x)^2."""
        return (self._sqrt_lambdas ** 2 * self._phis ** 2).sum(dim=1).to(dtype=self.dtype)

    def energy_fraction(self) -> float:
        """Fraction of total variance explained by the K retained modes."""
        total = float((self._sqrt_lambdas ** 2).sum())
        return total / (self.sigma_kl ** 2 * self.n_pts + 1e-30)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

def kl_realisation(
    kl: KLExpansion,
    xi: Tensor,
) -> Tensor:
    """Convenience wrapper: ``kl(xi)`` returning (n_pts,) Gc field."""
    return kl(xi)


def kl_variance_gradient(
    qoi_fn,
    kl: KLExpansion,
    n_mc: int = 50,
    seed: int = 0,
) -> dict:
    """Estimate E[QoI] and Var[QoI] with pathwise gradients.

    Pathwise estimator:
        d/d(Gc_mean) E[f(Gc(xi))] = E[df/dGc · dGc/dGc_mean] = E[df/dGc · 1]
        d/d(sigma_kl) E[f(Gc(xi))] requires implicit differentiation through
        the eigenvalue problem; here approximated by FD on sigma_kl.

    This function returns:
        - ``E_qoi``       : Monte Carlo estimate of E[f]
        - ``Var_qoi``     : Monte Carlo estimate of Var[f]
        - ``grad_xi_mean``: mean of df/dxi over MC samples  (shape K)
        - ``P_exceed``    : fraction of realisations where QoI > qoi_threshold

    Parameters
    ----------
    qoi_fn   : callable(Gc: Tensor) → scalar Tensor, differentiable
    kl       : KLExpansion
    n_mc     : number of Monte Carlo samples
    seed     : random seed for reproducibility

    Returns
    -------
    dict with E_qoi, Var_qoi, grad_xi_mean, grad_xi_std
    """
    torch.manual_seed(seed)
    qois = []
    grads_xi = []

    for _ in range(n_mc):
        xi = torch.randn(kl.K, dtype=torch.float64,
                         device=kl.device, requires_grad=True)
        Gc = kl(xi)
        q = qoi_fn(Gc)
        q.backward()
        qois.append(q.detach())
        grads_xi.append(xi.grad.detach())
        xi = xi.detach()  # release for GC

    qois_t = torch.stack(qois)        # (n_mc,)
    grads_t = torch.stack(grads_xi)   # (n_mc, K)

    return {
        "E_qoi": float(qois_t.mean()),
        "Var_qoi": float(qois_t.var()),
        "std_qoi": float(qois_t.std()),
        "grad_xi_mean": grads_t.mean(0).numpy().tolist(),
        "grad_xi_std": grads_t.std(0).numpy().tolist(),
        "n_mc": n_mc,
    }


# ---------------------------------------------------------------------------
# Integration test
# ---------------------------------------------------------------------------

def _run_integration_test() -> None:
    print("kl_expansion integration test")
    print("=" * 48)

    dtype = torch.float64
    device = "cpu"

    # Synthetic 1D domain: 200 points on [0, 20] mm
    x = np.linspace(0.0, 20.0, 200)

    # --- KL construction ---
    kl = KLExpansion(x, K=20, L_corr=5.0, sigma_kl=0.05, Gc_mean=0.3,
                     device=device, dtype=dtype)
    print(f"  n_pts={kl.n_pts}, K={kl.K}")
    print(f"  sqrt(lambdas[:5]): {kl._sqrt_lambdas[:5].tolist()}")
    ef = kl.energy_fraction()
    print(f"  energy fraction (K=20): {ef:.3f}")
    assert ef > 0.5, f"Expected >50% variance captured: {ef:.3f}"

    # --- Realisation: differentiable w.r.t. xi ---
    xi = kl.sample_xi(n_samples=1, seed=42).squeeze(0)  # (K,)
    xi_leaf = xi.clone().requires_grad_(True)
    Gc_real = kl(xi_leaf)
    print(f"  Gc realisation range: [{float(Gc_real.min()):.4f}, {float(Gc_real.max()):.4f}]")
    assert Gc_real.shape == (kl.n_pts,)
    assert not Gc_real.isnan().any()

    # Backprop through KL realisation
    loss = Gc_real.sum()
    loss.backward()
    print(f"  dGc/dxi[:3]: {xi_leaf.grad[:3].tolist()}")
    assert xi_leaf.grad is not None
    assert not xi_leaf.grad.isnan().any()

    # Variance field
    var_field = kl.variance_field()
    print(f"  Variance field range: [{float(var_field.min()):.4e}, {float(var_field.max()):.4e}]")
    assert var_field.shape == (kl.n_pts,)
    assert (var_field >= 0).all()

    # --- Multiple samples ---
    xis = kl.sample_xi(n_samples=100, seed=0)
    Gc_samples = torch.stack([kl(xis[i]) for i in range(100)])  # (100, n_pts)
    empirical_var = Gc_samples.var(0)
    theoretical_var = var_field
    rel_err = ((empirical_var - theoretical_var) / (theoretical_var + 1e-10)).abs().mean()
    print(f"  Empirical vs theoretical variance rel error (100 samples): {rel_err:.3f}")
    assert rel_err < 0.5, f"Variance mismatch: {rel_err:.3f}"

    # --- kl_variance_gradient smoke ---
    def qoi_fn(Gc: Tensor) -> Tensor:
        return (Gc - 0.3).abs().mean()  # deviation from mean Gc

    stats = kl_variance_gradient(qoi_fn, kl, n_mc=20, seed=1)
    print(f"  E[|Gc - Gc_mean|] = {stats['E_qoi']:.4e}")
    print(f"  Var[|Gc - Gc_mean|] = {stats['Var_qoi']:.4e}")
    assert stats['E_qoi'] > 0
    assert stats['Var_qoi'] >= 0

    print("\nPASS — all assertions passed")


if __name__ == "__main__":
    _run_integration_test()
