"""Implicit smooth parametrisations for graded material fields.

The inverse demos often need a small set of unknowns to describe a spatially
varying stiffness or toughness field.  This module provides that contract:
evaluate a smooth coordinate function at element centroids and pass the
resulting per-element tensor into the differentiable solver.

For a single graded zone the field is

    q(x; theta) = q0 * (1 + a * exp(-||x - c||^2 / (2 sigma^2))).

``q`` can be Young's modulus ``E`` or fracture toughness ``G_c``.  The
amplitude ``a`` is bounded with a sigmoid transform, so the field remains
positive even when optimisation steps are aggressive.  Negative amplitudes
represent soft/weak graded zones; positive amplitudes represent stiff/tough
graded zones.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class SmoothBumpSpec:
    """Physical bounds for an implicit Gaussian material zone.

    Parameters
    ----------
    base_value
        Bulk material value, e.g. Young's modulus or fracture toughness.
    amplitude_min, amplitude_max
        Bounds for the multiplicative contrast ``a`` in
        ``base_value * (1 + a * bump)``.  ``amplitude_min`` must be greater
        than ``-1`` to keep the field strictly positive.
    sigma_min
        Lower bound for the Gaussian width.  This avoids nearly singular,
        mesh-scale spikes during inverse optimisation.
    """

    base_value: float
    amplitude_min: float = -0.95
    amplitude_max: float = 4.0
    sigma_min: float = 1.0e-6

    def __post_init__(self) -> None:
        if self.base_value <= 0.0:
            raise ValueError("base_value must be positive")
        if self.amplitude_min <= -1.0:
            raise ValueError("amplitude_min must be greater than -1")
        if self.amplitude_max <= self.amplitude_min:
            raise ValueError("amplitude_max must exceed amplitude_min")
        if self.sigma_min <= 0.0:
            raise ValueError("sigma_min must be positive")


def element_centroids(mesh, elements: torch.Tensor | None = None) -> torch.Tensor:
    """Return element centroids as a differentiable-friendly coordinate tensor."""

    elems = mesh.elements if elements is None else elements
    return mesh.nodes[elems].mean(dim=1)


def bounded_amplitude(
    raw_amplitude: torch.Tensor | float,
    *,
    amplitude_min: float,
    amplitude_max: float,
) -> torch.Tensor:
    """Map an unconstrained scalar to a bounded multiplicative contrast."""

    raw = torch.as_tensor(raw_amplitude)
    return amplitude_min + (amplitude_max - amplitude_min) * torch.sigmoid(raw)


def positive_sigma(
    raw_log_sigma: torch.Tensor | float,
    *,
    sigma_min: float = 1.0e-6,
) -> torch.Tensor:
    """Map an unconstrained log-width to a strictly positive Gaussian width."""

    raw = torch.as_tensor(raw_log_sigma)
    return torch.exp(raw) + torch.as_tensor(sigma_min, device=raw.device, dtype=raw.dtype)


def gaussian_bump(
    coords: torch.Tensor,
    center: torch.Tensor,
    sigma: torch.Tensor | float,
) -> torch.Tensor:
    """Evaluate a smooth radial Gaussian bump at coordinates.

    ``coords`` is ``(n, 2)`` and ``center`` is ``(2,)``.  The return value is a
    1-D tensor in ``[0, 1]`` whose graph remains connected to ``center`` and
    ``sigma`` when they require gradients.
    """

    if coords.dim() != 2:
        raise ValueError(f"coords must be 2-D; got {tuple(coords.shape)}")
    if coords.shape[1] != 2:
        raise ValueError(f"coords must have two columns; got {coords.shape[1]}")
    center_t = torch.as_tensor(center, device=coords.device, dtype=coords.dtype)
    if center_t.shape != (2,):
        raise ValueError(f"center must have shape (2,); got {tuple(center_t.shape)}")
    sigma_t = torch.as_tensor(sigma, device=coords.device, dtype=coords.dtype)
    if torch.any(sigma_t <= 0):
        raise ValueError("sigma must be positive")
    r2 = ((coords - center_t) ** 2).sum(dim=1)
    return torch.exp(-r2 / (2.0 * sigma_t * sigma_t))


def smooth_graded_field(
    coords: torch.Tensor,
    *,
    center: torch.Tensor,
    raw_log_sigma: torch.Tensor,
    raw_amplitude: torch.Tensor,
    spec: SmoothBumpSpec,
) -> torch.Tensor:
    """Evaluate a positive smooth graded material field.

    This is the common helper for implicit stiffness and toughness fields.
    The caller chooses the physical meaning through ``spec.base_value``:
    use ``E_bulk`` for stiffness or ``Gc_bulk`` for toughness.
    """

    sigma = positive_sigma(raw_log_sigma, sigma_min=spec.sigma_min).to(
        device=coords.device,
        dtype=coords.dtype,
    )
    amp = bounded_amplitude(
        raw_amplitude,
        amplitude_min=spec.amplitude_min,
        amplitude_max=spec.amplitude_max,
    ).to(device=coords.device, dtype=coords.dtype)
    bump = gaussian_bump(coords, center, sigma)
    base = torch.as_tensor(spec.base_value, device=coords.device, dtype=coords.dtype)
    return base * (1.0 + amp * bump)


def smooth_stiffness_field(
    coords: torch.Tensor,
    *,
    center: torch.Tensor,
    raw_log_sigma: torch.Tensor,
    raw_amplitude: torch.Tensor,
    E_bulk: float,
    amplitude_min: float = -0.90,
    amplitude_max: float = 5.0,
    sigma_min: float = 1.0e-6,
) -> torch.Tensor:
    """Evaluate an implicit smoothly graded Young's-modulus field."""

    return smooth_graded_field(
        coords,
        center=center,
        raw_log_sigma=raw_log_sigma,
        raw_amplitude=raw_amplitude,
        spec=SmoothBumpSpec(
            base_value=E_bulk,
            amplitude_min=amplitude_min,
            amplitude_max=amplitude_max,
            sigma_min=sigma_min,
        ),
    )


def smooth_toughness_field(
    coords: torch.Tensor,
    *,
    center: torch.Tensor,
    raw_log_sigma: torch.Tensor,
    raw_amplitude: torch.Tensor,
    Gc_bulk: float,
    amplitude_min: float = -0.95,
    amplitude_max: float = 3.0,
    sigma_min: float = 1.0e-6,
) -> torch.Tensor:
    """Evaluate an implicit smoothly graded fracture-toughness field."""

    return smooth_graded_field(
        coords,
        center=center,
        raw_log_sigma=raw_log_sigma,
        raw_amplitude=raw_amplitude,
        spec=SmoothBumpSpec(
            base_value=Gc_bulk,
            amplitude_min=amplitude_min,
            amplitude_max=amplitude_max,
            sigma_min=sigma_min,
        ),
    )


__all__ = [
    "SmoothBumpSpec",
    "bounded_amplitude",
    "element_centroids",
    "gaussian_bump",
    "positive_sigma",
    "smooth_graded_field",
    "smooth_stiffness_field",
    "smooth_toughness_field",
]
