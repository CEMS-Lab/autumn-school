#!/usr/bin/env python3
"""Full 2D Gc(x,y) recovery via Implicit Neural Representation (INR).

Parametrises the fracture-toughness field as a small MLP
  Gc(x,y; theta) = Gc_baseline * Softplus(MLP(x_norm, y_norm; theta) / s)
and recovers theta by gradient descent through the differentiable solver.

Truth: D3 horizontal Gaussian band (x0=16mm, sigma=2mm, wf=0.5)
  Gc(x) = Gc_baseline * (1 - 0.5 * exp(-(x-16)^2/(2*2^2)))

This is the "fracture toughness map from crack observations" capability --
full 2D recovery via >100 INR parameters vs 2-3 parameters in the
low-rank Gaussian demo.

ADiMU (ferreira2025adimu) connection: additive corrector Gc = Gc_baseline + INR(x,y)
is the direct analogue of their Gc = M_physics + M_GRU corrector.

Acceptance gate:
  - Loss decreases over n_iters
  - NRMSE(Gc_recovered, Gc_truth) < 0.10 at best iter

Usage (Mac CPU debug)::

    python -m phast.inverse_problems.demos.demo_inverse_gc_inr \\
        --device cpu --dtype float64 \\
        --n_steps 400 --checkpoint_chunks 8 \\
        --n_iters 10 --lr 5e-4 \\
        --output_dir /tmp/inr_debug

Usage (HPC GPU)::

    python -m phast.inverse_problems.demos.demo_inverse_gc_inr \\
        --device cuda --dtype float64 \\
        --n_steps 2000 --checkpoint_chunks 40 \\
        --n_iters 30 --lr 1e-3 \\
        --output_dir $OUT/D3_Gc_inr
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.inverse_problems.demos.demo_inverse_gc_horizontal import (
    horizontal_band_field, build_sent_mesh, build_solver, run_forward,
    GC, DEFAULT_X0, DEFAULT_SIGMA, DEFAULT_WEAK_FRACTION,
)
from phast.inverse_problems.parametrisations import (
    FieldINR, evaluate_at_nodes,
)
from phast.config import LoadingConfig


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--device",   default="cpu")
    p.add_argument("--dtype",    default="float64")
    p.add_argument("--h_crack",  type=float, default=0.4)
    p.add_argument("--h_coarse", type=float, default=2.0)
    p.add_argument("--n_steps",  type=int,   default=2000)
    p.add_argument("--checkpoint_chunks", type=int, default=40)
    # Truth
    p.add_argument("--x0_truth",    type=float, default=16.0)
    p.add_argument("--sigma_truth", type=float, default=2.0)
    p.add_argument("--weak_fraction", type=float, default=0.5)
    # INR architecture
    p.add_argument("--n_fourier",   type=int,   default=32,
                   help="Random Fourier features")
    p.add_argument("--fourier_sigma", type=float, default=2.0,
                   help="Fourier feature bandwidth (1/mm)")
    p.add_argument("--hidden_width", type=int,  default=32)
    p.add_argument("--n_hidden",     type=int,  default=2)
    # Optimiser
    p.add_argument("--n_iters",      type=int,   default=30)
    p.add_argument("--lr",           type=float, default=1e-3)
    p.add_argument("--grad_clip",    type=float, default=0.5)
    p.add_argument("--tv_weight",    type=float, default=1e-4,
                   help="TV regularization weight on Gc field")
    # Output
    p.add_argument("--damping_zeta", type=float, default=0.05)
    p.add_argument("--delta_U",      type=float, default=0.05)
    p.add_argument("--H_update_method", default="custom_subgrad")
    p.add_argument("--H_update_scale",  type=float, default=1.0)
    p.add_argument("--save_snapshots",  type=int,   default=5)
    p.add_argument("--output_dir",  default="/tmp/inr_d3")
    return p.parse_args()


# ---------------------------------------------------------------------------
# INR → Gc field
# ---------------------------------------------------------------------------

def build_inr_gc_field(
    inr: torch.nn.Module,
    centroids_norm: torch.Tensor,
    gc_baseline: float,
    softplus_scale: float = 2.0,
    dtype=torch.float64,
) -> torch.Tensor:
    """Gc(x,y; theta) = gc_baseline * sigmoid(MLP(x_n, y_n) / scale).

    The Softplus / sigmoid ensures Gc ∈ (0, gc_baseline). We use sigmoid
    so the INR starts near gc_baseline * 0.5 (a reasonable prior).
    """
    raw = evaluate_at_nodes(inr, centroids_norm).squeeze(-1)
    # Sigmoid maps (-inf, +inf) → (0,1); scale Gc to (0, gc_baseline)
    return gc_baseline * torch.sigmoid(raw / softplus_scale).to(dtype)


def tv_regularizer(Gc: torch.Tensor, centroids: torch.Tensor) -> torch.Tensor:
    """Approximate total variation on an unstructured element field.

    Uses the mean of |dGc/dx| estimated from adjacent-centroid differences.
    Since elements are unordered, approximate TV as std(Gc) (penalises
    high-frequency variation).
    """
    return Gc.std()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    args = _parse()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    dtype = torch.float64 if args.dtype == "float64" else torch.float32
    device = torch.device(args.device)

    print("=" * 60)
    print("  D3 INR Gc(x,y) field recovery")
    print("=" * 60)
    print(f"  truth: x0={args.x0_truth}, sigma={args.sigma_truth}")
    print(f"  INR: {args.n_fourier} Fourier, {args.hidden_width}x{args.n_hidden}")
    print(f"  n_iters={args.n_iters}, lr={args.lr}, tv_weight={args.tv_weight}")
    print()

    # Mesh + solver
    mesh, _ = build_sent_mesh(args.h_crack, args.h_coarse, device, dtype)
    centroids = mesh.nodes[mesh.elements].mean(dim=1)
    n_elem = mesh.n_elems

    tau_ramp = 1e-6
    dU = args.delta_U / 2.0
    loading = LoadingConfig(ramp_type="smooth", t_ramp=tau_ramp)
    wf = torch.tensor(args.weak_fraction, dtype=dtype, device=device)

    solver = build_solver(
        mesh, dU, tau_ramp,
        damping_zeta=args.damping_zeta,
        device=device, dtype=dtype,
        H_update_method=args.H_update_method,
        H_update_scale=args.H_update_scale,
    )

    # Normalise centroids to [-1, 1]^2 for the INR
    x_min, x_max = float(centroids[:, 0].min()), float(centroids[:, 0].max())
    y_min, y_max = float(centroids[:, 1].min()), float(centroids[:, 1].max())
    centroids_norm = torch.zeros_like(centroids)
    centroids_norm[:, 0] = 2.0 * (centroids[:, 0] - x_min) / (x_max - x_min) - 1.0
    centroids_norm[:, 1] = 2.0 * (centroids[:, 1] - y_min) / (y_max - y_min) - 1.0

    # Truth Gc field
    p0_truth = torch.tensor(args.x0_truth, dtype=dtype, device=device)
    p1_truth = torch.tensor(float(np.log(args.sigma_truth)), dtype=dtype, device=device)
    with torch.no_grad():
        Gc_truth = horizontal_band_field(centroids, p0_truth, torch.exp(p1_truth), wf)

    # Truth forward
    print("Running truth forward ...", flush=True)
    t0 = time.time()
    with torch.no_grad():
        target, _, _ = run_forward(
            solver, loading, Gc_truth, args.n_steps, checkpoint_chunks=0)
    target = target.detach()
    print(f"  done in {time.time()-t0:.1f}s, max(d)={float(target.max()):.3f}", flush=True)

    # Build INR
    torch.manual_seed(0)
    inr = FieldINR(
        n_input_dims=2,
        n_fourier_features=args.n_fourier,
        fourier_sigma=args.fourier_sigma,
        hidden_width=args.hidden_width,
        n_hidden_layers=args.n_hidden,
        activation=torch.nn.GELU,
        output_activation=None,
        seed=42,
    ).to(device=device, dtype=dtype)
    n_params = inr.n_trainable_parameters()
    print(f"  INR: {n_elem} elements, {n_params} trainable params, "
          f"compression {n_elem/n_params:.1f}×", flush=True)

    softplus_scale = 2.0
    opt = torch.optim.Adam(inr.parameters(), lr=args.lr)

    # Initial Gc field (before training)
    with torch.no_grad():
        Gc_init = build_inr_gc_field(inr, centroids_norm, GC, softplus_scale, dtype)
    print(f"  Gc init: min={float(Gc_init.min()):.4f} max={float(Gc_init.max()):.4f} "
          f"mean={float(Gc_init.mean()):.4f} (truth min={float(Gc_truth.min()):.4f})",
          flush=True)

    # Inversion loop
    history = {
        "iter": [], "loss_data": [], "loss_tv": [], "loss_total": [],
        "nrmse_gc": [], "wall_s": [],
    }
    best_nrmse = float("inf")
    best_iter = 0
    t_start = time.time()

    for it in range(args.n_iters):
        t_iter = time.time()
        opt.zero_grad()

        Gc = build_inr_gc_field(inr, centroids_norm, GC, softplus_scale, dtype)
        d_pred, _, _ = run_forward(
            solver, loading, Gc, args.n_steps,
            checkpoint_chunks=args.checkpoint_chunks)
        loss_data = ((d_pred - target) ** 2).mean()
        loss_tv = tv_regularizer(Gc, centroids)
        loss = loss_data + args.tv_weight * loss_tv
        loss.backward()

        torch.nn.utils.clip_grad_norm_(inr.parameters(), args.grad_clip)
        opt.step()

        with torch.no_grad():
            Gc_eval = build_inr_gc_field(inr, centroids_norm, GC, softplus_scale, dtype)
            nrmse = float(
                ((Gc_eval - Gc_truth) ** 2).mean().sqrt()
                / (Gc_truth.abs().mean() + 1e-12)
            )

        iter_s = time.time() - t_iter
        history["iter"].append(it)
        history["loss_data"].append(float(loss_data))
        history["loss_tv"].append(float(loss_tv))
        history["loss_total"].append(float(loss))
        history["nrmse_gc"].append(nrmse)
        history["wall_s"].append(iter_s)

        if nrmse < best_nrmse:
            best_nrmse = nrmse
            best_iter = it
            torch.save(inr.state_dict(), out_dir / "best_inr.pt")

        print(
            f"  it {it:3d} | loss={float(loss):.4e} "
            f"(data={float(loss_data):.4e} tv={float(loss_tv):.4e}) "
            f"| NRMSE={nrmse:.4f} | {iter_s:.1f}s",
            flush=True,
        )

    total_s = time.time() - t_start

    # Acceptance gate
    gate_pass = (
        best_nrmse < 0.10
        and history["loss_total"][-1] < history["loss_total"][0]
    )

    print(f"\n  Best NRMSE={best_nrmse:.4f} at iter {best_iter}")
    print(f"  Loss: iter0={history['loss_total'][0]:.4e}  last={history['loss_total'][-1]:.4e}")
    print(f"  Total wall: {total_s/60:.1f} min")
    print(f"  GATE: {'PASS' if gate_pass else 'FAIL'}")

    # Save summary
    summary = {
        "history": history,
        "best_iter": best_iter,
        "best_nrmse_gc": best_nrmse,
        "gate_pass": gate_pass,
        "n_params": n_params,
        "n_elem": n_elem,
        "wall_s": total_s,
    }
    (out_dir / "inr_summary.json").write_text(json.dumps(summary, indent=2))

    # Produce figures
    _plot_results(
        Gc_truth, centroids, args, best_nrmse, best_iter,
        history, inr, centroids_norm, softplus_scale, dtype, out_dir
    )
    print(f"Done -> {out_dir}", flush=True)


def _plot_results(
    Gc_truth, centroids, args, best_nrmse, best_iter,
    history, inr, centroids_norm, softplus_scale, dtype, out_dir
):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return

    RCPARAMS = {
        "font.family": "serif",
        "font.serif": ["STIXGeneral", "Times New Roman", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 9, "axes.labelsize": 9,
        "legend.fontsize": 8, "xtick.labelsize": 8, "ytick.labelsize": 8,
    }
    plt.rcParams.update(RCPARAMS)

    with torch.no_grad():
        Gc_rec = build_inr_gc_field(inr, centroids_norm, GC, softplus_scale, dtype)

    x = centroids[:, 0].cpu().numpy()
    y = centroids[:, 1].cpu().numpy()
    gc_t = Gc_truth.detach().cpu().numpy()
    gc_r = Gc_rec.detach().cpu().numpy()
    err = gc_r - gc_t

    fig, axes = plt.subplots(1, 3, figsize=(9.0, 2.4), constrained_layout=True)
    s = 3
    vmin, vmax = float(gc_t.min()), float(gc_t.max())

    for ax, data, title in zip(axes, [gc_t, gc_r, err],
                                [r"$G_c$ truth", r"$G_c$ recovered",
                                 r"Error $G_c^{\mathrm{rec}} - G_c^{\ast}$"]):
        vl = min(data.min(), -1e-6) if "Error" in title else vmin
        vh = max(data.max(), 1e-6) if "Error" in title else vmax
        cmap = "RdBu_r" if "Error" in title else "viridis"
        sc = ax.scatter(x, y, c=data, s=s, cmap=cmap, vmin=vl, vmax=vh,
                        rasterized=True)
        plt.colorbar(sc, ax=ax, shrink=0.8)
        ax.set_title(title)
        ax.set_aspect("equal")
        ax.set_xlabel("$x$ (mm)")

    axes[0].set_ylabel("$y$ (mm)")
    fig.suptitle(f"INR Gc recovery: NRMSE={best_nrmse:.4f} (iter {best_iter})")

    for ext in ("pdf", "png"):
        kw = {"dpi": 200} if ext == "png" else {}
        fig.savefig(out_dir / f"inr_gc_recovery.{ext}", **kw)
        print(f"  saved: {out_dir / f'inr_gc_recovery.{ext}'}")
    plt.close(fig)

    # Loss curve
    fig2, ax2 = plt.subplots(figsize=(3.5, 2.4), constrained_layout=True)
    ax2.semilogy(history["iter"], history["loss_total"], "o-",
                 ms=3, lw=1, color="#2166ac", label="total")
    ax2.semilogy(history["iter"], history["loss_data"], "--",
                 lw=0.8, color="#d6604d", label="data")
    ax2.set_xlabel("iteration")
    ax2.set_ylabel(r"$\mathcal{L}$")
    ax2.set_title("INR Gc recovery: loss")
    ax2.legend()
    ax2.grid(ls=":", lw=0.5, alpha=0.5)
    for ext in ("pdf", "png"):
        kw = {"dpi": 200} if ext == "png" else {}
        fig2.savefig(out_dir / f"inr_loss_curve.{ext}", **kw)
    plt.close(fig2)


if __name__ == "__main__":
    main()
