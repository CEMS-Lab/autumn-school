"""Discrete adjoint with Griewank-style checkpointing.

Public API
----------
- ``CheckpointedForward``: low-level forward sweep that stores
  sqrt(N)-strided state checkpoints.
- ``DiscreteAdjoint``: user-facing wrapper exposing ``__call__`` that
  routes backward through a custom ``torch.autograd.Function``,
  recomputing each chunk from the prior checkpoint to bound peak memory.
- ``StatefulStepper``: adapter that turns an in-place
  ``solver.step_full()`` into the pure ``(state, params) -> state``
  contract that ``DiscreteAdjoint`` expects.

See ``discrete_adjoint`` module docstring for the honest framing
(memory benefit only; chaotic-dynamics gradient stability is unchanged
relative to autograd).
"""
from .discrete_adjoint import (
    CheckpointedForward,
    DiscreteAdjoint,
    StatefulStepper,
)

__all__ = ["CheckpointedForward", "DiscreteAdjoint", "StatefulStepper"]
