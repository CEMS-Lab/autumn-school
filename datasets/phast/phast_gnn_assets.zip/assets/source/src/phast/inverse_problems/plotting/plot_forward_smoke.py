#!/usr/bin/env python
"""Plot forward-only smoke output: truth material field + final damage.

Auto-detects input schema:
  - inclusion demo: damage_truth.npz with E_truth + d_target
  - gc-horizontal demo: truth.npz with Gc_true + d_target

Usage:
    python plot_forward_smoke.py <results_dir>
    python plot_forward_smoke.py <results_dir> --out custom.png
"""
from __future__ import annotations
import argparse
import os
import sys

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.tri import Triangulation


def main():
    p = argparse.ArgumentParser()
    p.add_argument('input_dir')
    p.add_argument('--out', default=None)
    args = p.parse_args()

    cands = ['damage_truth.npz', 'truth.npz']
    src = None
    for c in cands:
        path = os.path.join(args.input_dir, c)
        if os.path.exists(path):
            src = path
            break
    if src is None:
        sys.exit(f"No {cands} in {args.input_dir}")

    z = np.load(src, allow_pickle=True)
    nodes    = z['nodes']
    elements = z['elements']
    d        = z['d_target']
    if 'E_truth' in z.files:
        field = z['E_truth']
        field_label = 'E [MPa]'
        field_cmap = 'inferno'
        kind = 'inclusion'
        truth_pts = z['truth_pts'] if 'truth_pts' in z.files else None
    else:
        field = z['Gc_true']
        field_label = 'Gc [N/mm]'
        field_cmap = 'viridis_r'
        kind = 'gc'
        truth_pts = None

    tri = Triangulation(nodes[:, 0], nodes[:, 1], elements)

    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))

    ax = axes[0]
    im = ax.tripcolor(tri, facecolors=field, cmap=field_cmap, shading='flat')
    plt.colorbar(im, ax=ax, label=field_label, shrink=0.8)
    if truth_pts is not None:
        for i, pt in enumerate(truth_pts):
            ax.plot([pt[0]], [pt[1]], 'wo', ms=8, mec='k', mew=0.6)
            ax.annotate(f'{i+1}', xy=pt, xytext=(pt[0]+0.4, pt[1]+0.4),
                          color='w', fontsize=9, fontweight='bold')
    ax.set_aspect('equal')
    ax.set_title(f'Truth {field_label.split()[0]} field')
    ax.set_xlabel('x [mm]')
    ax.set_ylabel('y [mm]')

    ax = axes[1]
    # Damage is a nodal field — use plot_trisurf-equivalent (tripcolor with
    # node values draws shaded triangles).
    im = ax.tripcolor(tri, d, cmap='inferno', shading='gouraud', vmin=0, vmax=1)
    plt.colorbar(im, ax=ax, label='damage d', shrink=0.8)
    if truth_pts is not None:
        for i, pt in enumerate(truth_pts):
            ax.plot([pt[0]], [pt[1]], 'co', ms=8, mec='k', mew=0.6, alpha=0.7)
    ax.set_aspect('equal')
    n_dmg = int((d > 0.5).sum())
    ax.set_title(f'Final damage  (max={d.max():.3f}, '
                  f'#d>0.5: {n_dmg})')
    ax.set_xlabel('x [mm]')
    ax.set_ylabel('y [mm]')

    fig.suptitle(f'{kind} forward smoke: {os.path.basename(args.input_dir)}',
                  fontsize=12)
    fig.tight_layout()

    out = args.out or os.path.join(args.input_dir, 'forward_smoke.png')
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f"Saved: {out}")


if __name__ == '__main__':
    main()
