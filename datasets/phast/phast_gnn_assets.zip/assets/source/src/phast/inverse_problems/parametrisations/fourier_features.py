"""Random Fourier feature lifting (Tancik et al., 2020).

Given input coordinates ``x in R^d`` and a fixed random projection matrix
``B in R^{n_features x d}`` with entries drawn iid from N(0, sigma^2),
returns the feature vector

    gamma(x) = [ cos(2 pi B x), sin(2 pi B x) ] in R^{2 * n_features}.

The projection ``B`` is registered as a buffer (not a learnable parameter)
following the original formulation: only the downstream MLP weights are
optimised.

Reference
---------
Tancik et al., "Fourier Features Let Networks Learn High Frequency Functions
in Low Dimensional Domains", NeurIPS 2020.
"""

from __future__ import annotations

import math

import torch
from torch import nn


class FourierFeatures(nn.Module):
    """Lift coordinates ``x`` to random Fourier features.

    Parameters
    ----------
    n_features : int
        Number of random projections. Output dimension is ``2 * n_features``
        (cos and sin pair). If ``n_features == 0`` the layer becomes a
        no-op pass-through (returns ``x`` unchanged); callers wrap with
        higher-level logic to skip the lift entirely.
    sigma : float
        Standard deviation of the Gaussian used to draw ``B``. Higher
        sigma -> higher frequencies; typical values for unit-scale
        coordinates are 1-10.
    n_input_dims : int, default 2
        Spatial dimension of the input coordinates.
    seed : int or None, default None
        If given, draws ``B`` from a seeded generator for reproducibility.
    """

    def __init__(
        self,
        n_features: int,
        sigma: float = 1.0,
        n_input_dims: int = 2,
        seed: int | None = None,
    ) -> None:
        super().__init__()
        if n_features < 0:
            raise ValueError(f"n_features must be >= 0, got {n_features}")
        if sigma <= 0:
            raise ValueError(f"sigma must be > 0, got {sigma}")

        self.n_features = int(n_features)
        self.sigma = float(sigma)
        self.n_input_dims = int(n_input_dims)

        if self.n_features == 0:
            # No-op; register an empty buffer so .to(device) still works.
            self.register_buffer(
                "B", torch.zeros(0, self.n_input_dims), persistent=True
            )
        else:
            if seed is not None:
                gen = torch.Generator().manual_seed(int(seed))
                B = (
                    torch.randn(
                        self.n_features, self.n_input_dims, generator=gen
                    )
                    * self.sigma
                )
            else:
                B = torch.randn(self.n_features, self.n_input_dims) * self.sigma
            # Tancik: B is FROZEN -- buffer, not Parameter.
            self.register_buffer("B", B, persistent=True)

    @property
    def out_features(self) -> int:
        """Dimension of the lifted feature vector."""
        return 2 * self.n_features if self.n_features > 0 else self.n_input_dims

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Lift coordinates.

        Parameters
        ----------
        x : Tensor, shape (..., n_input_dims)

        Returns
        -------
        Tensor, shape (..., 2 * n_features) if n_features > 0,
        else passes ``x`` through unchanged.
        """
        if x.shape[-1] != self.n_input_dims:
            raise ValueError(
                f"FourierFeatures expects last dim = {self.n_input_dims}, "
                f"got tensor of shape {tuple(x.shape)}"
            )
        if self.n_features == 0:
            return x

        # x @ B.T -> (..., n_features)
        proj = 2.0 * math.pi * x @ self.B.t()
        return torch.cat([torch.cos(proj), torch.sin(proj)], dim=-1)

    def extra_repr(self) -> str:
        return (
            f"n_features={self.n_features}, sigma={self.sigma}, "
            f"n_input_dims={self.n_input_dims}, out_features={self.out_features}"
        )
