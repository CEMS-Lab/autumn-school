"""Log-domain smoothing of the phase-field history-field ``max()``.

The phase-field driving field is enforced to be monotone in time via

    H(x, t) = max_{s <= t} psi^+(x, s)

which in the explicit time loop is realised by the pointwise update

    H_new = max(H_prev, psi^+) .                                (1)

The pointwise ``max`` has piecewise-constant subgradient: ``dH_new/dpsi``
is exactly ``0`` whenever the prior history is binding and exactly ``1``
when ``psi^+`` is binding, with a measure-zero ill-defined seam at the
crossing.  When ``psi^+`` exactly equals ``H_prev`` (an "active set"
point that is geometrically stable across many time steps in a
stationary front), reverse-mode autograd through (1) returns a
sub-gradient that is sensitive to floating-point ties and effectively
zero across most of the active set.  This is the source of the
"vanishing-gradient on the crack tip" pathology that the existing
``softmax_H_beta`` knob in ``staggered_solver.SolverConfig`` palliates
by additive smoothing in the *primal* domain:

    H_new = H_prev + softplus(beta * (psi - H_prev)) / beta .   (2)

Form (2) is smooth but has an *additive* bias of ``log(2) / beta`` at
the crossing, which scales with the magnitude of ``H``: a domain whose
``H`` spans many orders of magnitude experiences locally varying
relative drift.

This module implements an alternative log-domain smoothing of the
history-field ``max()`` at large sharpness ``beta``.  Introduce a
latent ``q = log H``; replace the pointwise ``max`` in (1) by the
softplus-smoothed-relu in log-space:

    q_new = q + softplus(beta * (log psi^+ - q)) / beta ,
    H_new = exp(q_new) .                                        (3)

In the limit ``beta -> infty`` the softplus collapses to ``relu`` and
(3) recovers ``max(H_prev, psi^+)`` exactly.  At finite ``beta`` the
bias at the crossing is *multiplicative*, ``2^(1/beta)``, i.e. it is
dimensionless and scale-invariant in ``H``.  Compared with (2) — which
has an additive bias proportional to ``log(2)/beta`` independent of
``H`` — (3) is preferable when ``H`` spans many orders of magnitude,
because the relative error of (3) is uniform.

**Honest framing.** This is *log-domain smoothing of* ``max()``, not a
proximal Galerkin method.  Keith & Surowiec (2024, FoCM,
DOI 10.1007/s10208-024-09681-8) describe a structure-preserving FEM
that enforces pointwise bound constraints via a latent-variable
Bregman regularisation with a true KKT active-set treatment; that is
*not* what this module implements.  The closed-form softplus update
above is simply a smooth max in log-space.  At ``beta = 1e6`` the
multiplicative bias is ``2^(1e-6) - 1`` ~ ``6.93e-7``, i.e. it equals
``H_prev * log(2) / beta`` to leading order — small but not zero.
See the tracking follow-up issue for the true K-S formulation.

Boundary handling
-----------------
The phase-field starts with ``H_prev = 0`` and (typically)
``psi^+ = 0`` everywhere, so a literal ``log H_prev`` or ``log psi^+``
is ``-inf``.  We handle the three boundary branches explicitly rather
than by clamping:

1. ``psi^+ <= 0``:  no driving, return ``H_prev``.
2. ``H_prev <= 0`` and ``psi^+ > 0``:  the latent ``q`` is
   ``-inf`` and the smoothed step degenerates to ``H_new = psi^+``.
3. both ``> 0``:  apply (3).

The branches are stitched with ``torch.where``; the resulting tensor
flows gradients through branch 3 and through the identity in
branches 1-2.
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


# Default sharpness.  beta = 1e6 gives multiplicative bias 2^(1e-6) - 1
# ~ 6.9e-7 at the crossing, well below the 1e-6 forward-equivalence
# tolerance the test suite asks for, and float64 has ample headroom.
_DEFAULT_BETA: float = 1.0e6


def log_smoothed_history_update(
    H_prev: torch.Tensor,
    psi_plus: torch.Tensor,
    beta: float = _DEFAULT_BETA,
) -> torch.Tensor:
    """Log-domain smoothing of ``max(H_prev, psi_plus)`` at large beta.

    Implements the closed-form log-space softplus update:

        q       = log H_prev
        q_new   = q + softplus(beta * (log psi_plus - q)) / beta
        H_new   = exp(q_new)

    with explicit handling of the ``H_prev = 0`` and ``psi_plus = 0``
    boundary branches.

    Parameters
    ----------
    H_prev : torch.Tensor
        Previous-step history field (>= 0).
    psi_plus : torch.Tensor
        Current driving energy density (>= 0); same shape as ``H_prev``.
    beta : float
        Sharpness; ``beta -> inf`` recovers ``torch.maximum``.  Default
        ``1e6`` gives forward-equivalence to within ~7e-7 in float64
        (multiplicative bias ``H_prev * log(2) / beta``).

    Returns
    -------
    H_new : torch.Tensor
        Smooth monotone update.  Differentiable in both arguments
        everywhere (including at the active-set crossing).
    """
    if H_prev.shape != psi_plus.shape:
        raise ValueError(
            f"H_prev shape {tuple(H_prev.shape)} != "
            f"psi_plus shape {tuple(psi_plus.shape)}"
        )

    # Strict-positive masks: branch 3 is the smoothing interior.
    eps = torch.finfo(H_prev.dtype).tiny
    pos_H = H_prev > eps
    pos_psi = psi_plus > eps
    interior = pos_H & pos_psi

    # Branch 1: psi <= 0 -> H_new = H_prev (already monotone).
    # Branch 2: H_prev <= 0 and psi > 0 -> H_new = psi.
    # Branch 3: both > 0 -> log-domain smoothed update.

    # Compute branch 3 only on the interior to avoid log(0).  We use
    # safe_log via torch.where so the autograd graph is clean.
    safe_one = torch.ones_like(H_prev)
    H_safe = torch.where(interior, H_prev, safe_one)
    psi_safe = torch.where(interior, psi_plus, safe_one)

    log_H = torch.log(H_safe)
    log_psi = torch.log(psi_safe)
    # softplus(beta * x) / beta is the standard smooth-relu of slope 1.
    delta = log_psi - log_H
    smooth_relu = F.softplus(beta * delta) / beta
    q_new = log_H + smooth_relu
    H_interior = torch.exp(q_new)

    # Stitch branches.
    H_new = torch.where(interior, H_interior, H_prev)
    H_new = torch.where(pos_psi & ~pos_H, psi_plus, H_new)
    return H_new


class LogSmoothedHistory(nn.Module):
    """nn.Module wrapper for :func:`log_smoothed_history_update`.

    Drop-in replacement for the ``torch.maximum(H_prev, psi)`` call site
    in :class:`StaggeredSolver._H_update`.  The production dispatcher
    uses this module when ``H_update_method='log_smooth'``.

    Example
    -------
    >>> ls = LogSmoothedHistory(beta=1e6)
    >>> H_new = ls(H_prev, psi_plus)
    """

    def __init__(self, beta: float = _DEFAULT_BETA) -> None:
        super().__init__()
        if beta <= 0 or not math.isfinite(beta):
            raise ValueError(f"beta must be positive and finite, got {beta}")
        self.beta = float(beta)

    def forward(
        self, H_prev: torch.Tensor, psi_plus: torch.Tensor
    ) -> torch.Tensor:
        return log_smoothed_history_update(H_prev, psi_plus, beta=self.beta)

    def extra_repr(self) -> str:
        return f"beta={self.beta:.3e}"
