"""Sanity tests for :class:`ESOptimizer`.

Two analytic test functions:

* Quadratic ``L(x) = ||x - x*||^2``: well-conditioned, ES should
  converge in ~150 iters at sensible (sigma, lr).
* Rosenbrock ``L(x, y) = (a - x)^2 + b*(y - x^2)^2`` with the standard
  ``a=1, b=100``: ill-conditioned banana, used as a stress test for the
  rank-shaped estimator. Convergence target is loose (loss < initial).

Run as::

    # Direct script:
    python inverse_problems/optimizers/test_es.py

    # Pytest (the legacy repo-root ``__init__.py`` confuses pytest's
    # auto-walk; force the rootdir + importlib mode to bypass):
    python -m pytest inverse_problems/optimizers/test_es.py \
        --rootdir=inverse_problems/optimizers --import-mode=importlib
"""
from __future__ import annotations

import math
import os
import sys

import pytest
import torch

# Make the test runnable both as ``pytest path/to/test_es.py`` from the
# repo root and as ``python test_es.py`` from this directory. We add
# the repo root (two parents up) to sys.path so the ``inverse_problems``
# package resolves.
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_THIS_DIR, '..', '..'))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

# Avoid hitting the phast heavy package import that
# ``inverse_problems/__init__.py`` may trigger -- the ES optimizer is
# self-contained.
sys.path.insert(0, os.path.join(_REPO_ROOT, 'inverse_problems', 'optimizers'))
from es_optimizer import ESOptimizer  # noqa: E402


# -- analytic problems ----------------------------------------------------

def _quadratic_loss(target):
    target = torch.as_tensor(target, dtype=torch.float64)
    def L(theta):
        return float(((theta - target) ** 2).sum())
    return L


def _rosenbrock_loss(a=1.0, b=100.0):
    def L(theta):
        x, y = theta[0], theta[1]
        return float((a - x) ** 2 + b * (y - x ** 2) ** 2)
    return L


# -- pytest cases ---------------------------------------------------------

def test_es_quadratic_2d():
    """5D quadratic -- ES with rank shaping should reach loss < 1e-2."""
    target = torch.tensor([0.5, -1.0, 2.0, 0.0, -0.3], dtype=torch.float64)
    L = _quadratic_loss(target)

    init = torch.zeros(5, dtype=torch.float64)
    opt = ESOptimizer(
        params=init,
        lr=0.3,
        sigma=0.3,
        n_samples=32,
        antithetic=True,
        fitness_shaping=True,
        seed=42,
    )

    losses = []
    for _ in range(200):
        losses.append(opt.step(L))

    final_loss = float(L(opt.theta))
    assert final_loss < 1e-2, (
        f"ES did not converge on 5D quadratic: final loss {final_loss:.3e}, "
        f"first {losses[0]:.3e} -> last {losses[-1]:.3e}")
    assert losses[-1] < losses[0], "loss did not decrease"


def test_es_quadratic_no_shaping():
    """Same quadratic with raw losses (no rank shaping). Still converges,
    but used here just to confirm the non-shaped branch runs end-to-end."""
    target = torch.tensor([1.0, 1.0], dtype=torch.float64)
    L = _quadratic_loss(target)

    opt = ESOptimizer(
        params=torch.zeros(2, dtype=torch.float64),
        lr=0.05,
        sigma=0.2,
        n_samples=16,
        antithetic=True,
        fitness_shaping=False,
        seed=7,
    )
    for _ in range(300):
        opt.step(L)
    assert float(L(opt.theta)) < 0.1


def test_es_no_antithetic():
    """Non-antithetic estimator path with rank shaping."""
    target = torch.tensor([2.0, -1.5], dtype=torch.float64)
    L = _quadratic_loss(target)

    opt = ESOptimizer(
        params=torch.zeros(2, dtype=torch.float64),
        lr=0.5,
        sigma=0.4,
        n_samples=64,
        antithetic=False,
        fitness_shaping=True,
        seed=11,
    )
    for _ in range(300):
        opt.step(L)
    assert float(L(opt.theta)) < 0.1


def test_es_rosenbrock():
    """Rosenbrock is a stress test. Loose tolerance: just demand the
    ES iterate did not blow up and the loss improved over the initial
    point. The banana is famously bad for any isotropic random-direction
    estimator; we are not claiming SOTA here, only that the
    implementation moves in a sensible direction."""
    L = _rosenbrock_loss()
    init = torch.tensor([-1.0, 1.0], dtype=torch.float64)
    init_loss = L(init)

    opt = ESOptimizer(
        params=init,
        lr=1e-3,
        sigma=0.05,
        n_samples=64,
        antithetic=True,
        fitness_shaping=True,
        seed=3,
    )
    losses = []
    for _ in range(500):
        losses.append(opt.step(L))

    final_loss = float(L(opt.theta))
    assert math.isfinite(final_loss)
    assert final_loss < init_loss, (
        f"ES did not improve on Rosenbrock: init {init_loss:.3e} -> "
        f"final {final_loss:.3e}")


def test_es_grad_norm_finite_under_chaos():
    """The point of the chaos-amplification figure: ES estimator is
    bounded by O(|L|/sigma), so even on a wildly non-smooth loss it
    stays finite. Mock-test using a discontinuous step function loss."""
    def L(theta):
        # Discontinuous, with a wide flat region. Autograd of this is
        # zero almost everywhere; ES will still produce a finite,
        # informative descent direction.
        return float(1.0 if theta.sum() > 0 else 0.0)

    opt = ESOptimizer(
        params=torch.tensor([0.5, 0.5], dtype=torch.float64),
        lr=0.1, sigma=0.2, n_samples=32, antithetic=True,
        fitness_shaping=True, seed=1)
    g = opt.estimate_grad(L)
    assert torch.isfinite(g).all()
    assert math.isfinite(opt.last_grad_norm)


def test_es_state_dict_repr():
    opt = ESOptimizer(
        params=torch.zeros(3, dtype=torch.float64),
        lr=0.1, sigma=0.1, n_samples=4, seed=0)
    s = opt.state_dict()
    assert s["iter"] == 0
    assert "theta" in s
    assert "ESOptimizer" in repr(opt)


def test_es_n_workers_not_implemented():
    with pytest.raises(NotImplementedError):
        ESOptimizer(params=torch.zeros(2), lr=0.1, sigma=0.1,
                    n_samples=4, n_workers=4)


if __name__ == "__main__":
    target = torch.tensor([0.5, -1.0, 2.0], dtype=torch.float64)
    L = _quadratic_loss(target)
    opt = ESOptimizer(
        params=torch.zeros(3, dtype=torch.float64),
        lr=0.3, sigma=0.3, n_samples=32,
        antithetic=True, fitness_shaping=True, seed=42)
    for it in range(0, 200, 20):
        for _ in range(20):
            opt.step(L)
        print(f"iter {it+20:4d}  loss = {L(opt.theta):.3e}  "
              f"theta = {opt.theta.tolist()}  |g| = {opt.last_grad_norm:.3e}")
    print("OK")
