"""Maier-2006-inspired TPBT inverse benchmark.

This module is intentionally lightweight. It captures the inverse-analysis
structure of Maier et al.'s three-point-bending test with load-displacement and
ESPI/DIC-like surface displacement observations, but uses a differentiable
reduced quasistatic forward map instead of a full phase-field solve.

The full PF replacement point is :func:`tpbt_forward`: keep its input/output
contract and swap the reduced response model for a quasistatic torch PF rollout.
"""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path

import torch


@dataclass(frozen=True)
class TPBTConfig:
    """Configuration for the reduced TPBT inverse problem."""

    true_gc: float = 2.7
    init_gc: float = 4.2
    stiffness: float = 110.0
    peak_disp: float = 0.42
    softening_width: float = 0.09
    dic_gain: float = 0.035
    reaction_weight: float = 1.0
    dic_weight: float = 0.25
    regularization_weight: float = 1.0e-4


@dataclass
class TPBTObservation:
    """Synthetic TPBT observables."""

    displacements: torch.Tensor
    reaction: torch.Tensor
    dic: torch.Tensor
    points: torch.Tensor
    damage: torch.Tensor
    crack_opening: torch.Tensor


def default_displacements(dtype: torch.dtype = torch.float64) -> torch.Tensor:
    """Return displacement-control points for the TPBT history."""

    return torch.linspace(0.04, 0.82, 18, dtype=dtype)


def surface_points(dtype: torch.dtype = torch.float64) -> torch.Tensor:
    """Return normalized ESPI/DIC point coordinates on the beam side face."""

    x = torch.linspace(-0.75, 0.75, 5, dtype=dtype)
    y = torch.tensor([0.25, 0.55], dtype=dtype)
    xx, yy = torch.meshgrid(x, y, indexing="ij")
    return torch.stack((xx.reshape(-1), yy.reshape(-1)), dim=1)


def _damage_progress(displacements: torch.Tensor, gc: torch.Tensor, cfg: TPBTConfig) -> torch.Tensor:
    """Smooth crack-growth surrogate controlled by toughness."""

    threshold = cfg.peak_disp * torch.sqrt(gc / cfg.true_gc)
    return torch.sigmoid((displacements - threshold) / cfg.softening_width)


def tpbt_forward(
    log_gc: torch.Tensor,
    cfg: TPBTConfig | None = None,
    displacements: torch.Tensor | None = None,
    points: torch.Tensor | None = None,
) -> TPBTObservation:
    """Run the reduced differentiable TPBT forward model.

    Parameters
    ----------
    log_gc:
        Log fracture toughness. Optimizing in log-space keeps ``Gc`` positive.
    cfg:
        Benchmark constants.
    displacements:
        Imposed vertical displacement history.
    points:
        Normalized side-face DIC/ESPI points.
    """

    cfg = cfg or TPBTConfig()
    dtype = log_gc.dtype
    device = log_gc.device
    u = (displacements if displacements is not None else default_displacements(dtype)).to(
        device=device, dtype=dtype
    )
    pts = (points if points is not None else surface_points(dtype)).to(device=device, dtype=dtype)
    gc = torch.exp(log_gc)

    damage = _damage_progress(u, gc, cfg)
    elastic = cfg.stiffness * u
    softening = 1.0 - 0.70 * damage
    bridging = 0.08 * gc * torch.log1p(4.0 * u)
    reaction = elastic * softening + bridging

    x = pts[:, 0]
    y = pts[:, 1]
    opening_shape = (1.0 - x.abs()).clamp_min(0.0) * (0.25 + y)
    bending_shape = x * (1.0 - y)
    crack_opening = cfg.dic_gain * damage * (0.45 + 0.55 * u / u.max())
    vertical = (
        u[:, None] * (0.04 + 0.02 * y)[None, :]
        - crack_opening[:, None] * opening_shape[None, :]
    )
    horizontal = (
        0.015 * u[:, None] * bending_shape[None, :]
        + 0.5 * crack_opening[:, None] * x[None, :]
    )
    dic = torch.stack((horizontal, vertical), dim=-1)
    return TPBTObservation(
        displacements=u,
        reaction=reaction,
        dic=dic,
        points=pts,
        damage=damage,
        crack_opening=crack_opening,
    )


def tpbt_loss(
    pred: TPBTObservation,
    target: TPBTObservation,
    log_gc: torch.Tensor,
    cfg: TPBTConfig | None = None,
) -> torch.Tensor:
    """Weighted reaction + DIC discrepancy for TPBT calibration."""

    cfg = cfg or TPBTConfig()
    reaction_scale = target.reaction.detach().abs().max().clamp_min(1.0)
    dic_scale = target.dic.detach().abs().max().clamp_min(1.0e-8)
    reaction_loss = ((pred.reaction - target.reaction.detach()) / reaction_scale).pow(2).mean()
    dic_loss = ((pred.dic - target.dic.detach()) / dic_scale).pow(2).mean()
    reg = cfg.regularization_weight * (torch.exp(log_gc) / cfg.true_gc - 1.0).pow(2)
    return cfg.reaction_weight * reaction_loss + cfg.dic_weight * dic_loss + reg


def make_synthetic_target(cfg: TPBTConfig | None = None) -> TPBTObservation:
    """Generate noise-free synthetic TPBT target data."""

    cfg = cfg or TPBTConfig()
    log_gc = torch.tensor(cfg.true_gc, dtype=torch.float64).log()
    return tpbt_forward(log_gc, cfg)


def finite_difference_log_gc_gradient(
    cfg: TPBTConfig | None = None,
    *,
    gc: float | None = None,
    eps: float = 1.0e-5,
) -> tuple[float, float]:
    """Compare autograd and central FD gradients with respect to ``log(Gc)``."""

    cfg = cfg or TPBTConfig()
    target = make_synthetic_target(cfg)
    gc_value = cfg.init_gc if gc is None else gc
    log_gc = torch.tensor(gc_value, dtype=torch.float64).log().requires_grad_(True)
    pred = tpbt_forward(log_gc, cfg, target.displacements, target.points)
    loss = tpbt_loss(pred, target, log_gc, cfg)
    loss.backward()
    grad_ad = float(log_gc.grad.detach())

    losses = []
    for sign in (1.0, -1.0):
        trial = torch.tensor(gc_value, dtype=torch.float64).log() + sign * eps
        trial_pred = tpbt_forward(trial, cfg, target.displacements, target.points)
        losses.append(tpbt_loss(trial_pred, target, trial, cfg))
    grad_fd = float(((losses[0] - losses[1]) / (2.0 * eps)).detach())
    return grad_ad, grad_fd


def recover_gc(cfg: TPBTConfig | None = None, max_iter: int = 80) -> dict[str, object]:
    """Recover scalar ``Gc`` from the synthetic TPBT observables."""

    cfg = cfg or TPBTConfig()
    target = make_synthetic_target(cfg)
    log_gc = torch.tensor(cfg.init_gc, dtype=torch.float64).log().requires_grad_(True)
    opt = torch.optim.Adam([log_gc], lr=0.08)
    history: list[dict[str, float]] = []
    for _ in range(max_iter):
        opt.zero_grad()
        pred = tpbt_forward(log_gc, cfg, target.displacements)
        loss = tpbt_loss(pred, target, log_gc, cfg)
        loss.backward()
        opt.step()
        history.append(
            {
                "Gc": float(torch.exp(log_gc).detach()),
                "loss": float(loss.detach()),
                "grad_log_Gc": float(log_gc.grad.detach()),
            }
        )
    recovered = float(torch.exp(log_gc.detach()))
    return {
        "problem": "maier2006_tpbt_reduced_quasistatic",
        "true_Gc": cfg.true_gc,
        "init_Gc": cfg.init_gc,
        "recovered_Gc": recovered,
        "relative_error": abs(recovered - cfg.true_gc) / cfg.true_gc,
        "history": history,
        "target": target,
        "prediction": tpbt_forward(log_gc.detach(), cfg, target.displacements),
        "claim_boundary": "Reduced differentiable quasistatic surrogate; replace tpbt_forward with PF solver for full validation.",
    }


def save_artifacts(result: dict[str, object], out_dir: Path | str) -> dict[str, str]:
    """Write summary, convergence, observations, and a compact PNG figure."""

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    summary_path = out / "summary.json"
    history_path = out / "convergence.csv"
    obs_path = out / "observations.csv"
    figure_path = out / "tpbt_inverse_surrogate.png"

    summary = {
        "problem": result["problem"],
        "true_Gc": result["true_Gc"],
        "init_Gc": result["init_Gc"],
        "recovered_Gc": result["recovered_Gc"],
        "relative_error": result["relative_error"],
        "claim_boundary": result["claim_boundary"],
        "observables": {
            "reaction_history": True,
            "dic_surface_point_displacements": True,
            "n_load_steps": int(result["target"].reaction.numel()),
            "n_dic_points": int(result["target"].points.shape[0]),
        },
    }
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")

    with history_path.open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["iteration", "Gc", "loss", "grad_log_Gc"])
        writer.writeheader()
        for iteration, row in enumerate(result["history"]):
            writer.writerow({"iteration": iteration, **row})

    with obs_path.open("w", newline="") as fh:
        writer = csv.DictWriter(
            fh,
            fieldnames=[
                "series",
                "kind",
                "step",
                "displacement",
                "reaction",
                "point",
                "x",
                "y",
                "ux",
                "uy",
            ],
        )
        writer.writeheader()
        for series, obs in (
            ("target", result["target"]),
            ("recovered", result["prediction"]),
        ):
            _write_observation_rows(writer, series, obs)

    _save_plot(result, figure_path)
    return {
        "summary": str(summary_path),
        "convergence": str(history_path),
        "observations": str(obs_path),
        "figure": str(figure_path),
    }


def _write_observation_rows(
    writer: csv.DictWriter,
    series: str,
    obs: TPBTObservation,
) -> None:
    displacements = obs.displacements.detach().cpu()
    reaction = obs.reaction.detach().cpu()
    points = obs.points.detach().cpu()
    dic = obs.dic.detach().cpu()
    for step, disp in enumerate(displacements):
        writer.writerow(
            {
                "series": series,
                "kind": "reaction",
                "step": step,
                "displacement": float(disp),
                "reaction": float(reaction[step]),
                "point": "",
                "x": "",
                "y": "",
                "ux": "",
                "uy": "",
            }
        )
        for point_id, point in enumerate(points):
            writer.writerow(
                {
                    "series": series,
                    "kind": "dic",
                    "step": step,
                    "displacement": float(disp),
                    "reaction": "",
                    "point": point_id,
                    "x": float(point[0]),
                    "y": float(point[1]),
                    "ux": float(dic[step, point_id, 0]),
                    "uy": float(dic[step, point_id, 1]),
                }
            )


def _save_plot(result: dict[str, object], path: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    target = result["target"]
    prediction = result["prediction"]
    history = result["history"]

    fig, axes = plt.subplots(2, 2, figsize=(10.5, 7.2), constrained_layout=True)
    axes[0, 0].plot(target.displacements.detach(), target.reaction.detach(), "o-", label="target")
    axes[0, 0].plot(
        prediction.displacements.detach(),
        prediction.reaction.detach(),
        "s--",
        label="recovered",
    )
    axes[0, 0].set_xlabel("midspan displacement")
    axes[0, 0].set_ylabel("reaction")
    axes[0, 0].set_title("load-displacement")
    axes[0, 0].grid(alpha=0.3)
    axes[0, 0].legend()

    axes[0, 1].plot(target.displacements.detach(), target.damage.detach(), "o-", label="target")
    axes[0, 1].plot(
        prediction.displacements.detach(),
        prediction.damage.detach(),
        "s--",
        label="recovered",
    )
    axes[0, 1].set_xlabel("midspan displacement")
    axes[0, 1].set_ylabel("surrogate damage")
    axes[0, 1].set_title("softening state")
    axes[0, 1].grid(alpha=0.3)
    axes[0, 1].legend()

    axes[1, 0].plot(
        target.displacements.detach(),
        target.crack_opening.detach(),
        "o-",
        label="target",
    )
    axes[1, 0].plot(
        prediction.displacements.detach(),
        prediction.crack_opening.detach(),
        "s--",
        label="recovered",
    )
    axes[1, 0].set_xlabel("midspan displacement")
    axes[1, 0].set_ylabel("opening proxy")
    axes[1, 0].set_title("DIC-sensitive crack opening")
    axes[1, 0].grid(alpha=0.3)
    axes[1, 0].legend()

    axes[1, 1].semilogy([row["loss"] for row in history], "o-")
    axes[1, 1].set_xlabel("optimizer iteration")
    axes[1, 1].set_ylabel("loss")
    axes[1, 1].set_title(f"recovered Gc={result['recovered_Gc']:.4g}")
    axes[1, 1].grid(alpha=0.3)

    fig.suptitle("Maier-2006-inspired TPBT inverse surrogate")
    fig.savefig(path, dpi=180)
    plt.close(fig)
