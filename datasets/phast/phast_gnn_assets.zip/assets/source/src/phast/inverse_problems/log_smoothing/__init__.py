"""Log-domain smoothing of the phase-field history-field ``max()``.

Public API:

    LogSmoothedHistory(beta=1e6)
        nn.Module surrogate for ``H_new = max(H_prev, psi_plus)`` that
        applies a softplus-smoothed-relu in log-space.  As
        ``beta -> infty`` the surrogate recovers ``torch.maximum``
        exactly; at ``beta = 1e6`` the multiplicative bias is
        ``~ H_prev * log(2) / beta`` (~ 7e-7 * H_prev).

    log_smoothed_history_update(H_prev, psi_plus, beta=1e6)
        Functional form of the same update.

    log_smooth(a, b, beta=1e6)
        Dispatcher-facing wrapper with the canonical ``(a, b)``
        signature consumed by the H-update dispatcher in
        ``staggered_solver`` (issue #360).  Thin adapter over
        ``log_smoothed_history_update``.

See ``log_smoothing_history.py`` for the derivation, the boundary
branches, and the contrast with the additive primal ``softmax_H_beta``
relaxation.

Note: this is *not* a proximal Galerkin method.  Keith & Surowiec
(2024, FoCM) describe a structure-preserving FEM with latent-variable
Bregman regularisation and a true KKT active-set; that formulation is
tracked as a follow-up and is *not* implemented here.
"""
from __future__ import annotations

import torch

from .log_smoothing_history import (
    LogSmoothedHistory,
    log_smoothed_history_update,
)


def log_smooth(
    a: torch.Tensor,
    b: torch.Tensor,
    beta: float = 1.0e6,
) -> torch.Tensor:
    """Dispatcher-facing wrapper for the log-domain smooth ``max(a, b)``.

    Thin adapter over :func:`log_smoothed_history_update` matching the
    H-update dispatcher contract used by the staggered solver
    (issue #360):

        H_new = log_smooth(H_old, psi_plus, beta=1e6)

    Semantically this is a smooth, autograd-friendly surrogate for
    ``torch.maximum(a, b)`` with a multiplicative bias of order
    ``2 ** (1 / beta) - 1`` at the crossing.  Both inputs must be
    non-negative; the underlying implementation handles ``a == 0`` and
    ``b == 0`` boundary branches explicitly via ``torch.where`` so the
    autograd graph stays clean.

    The latent ``q = log(a)`` is carried by the *first* argument, so
    the update is not exactly symmetric in ``(a, b)`` at finite
    ``beta``; in the ``beta -> infty`` limit it recovers
    ``torch.maximum`` and is symmetric.  At ``beta = 1e6`` the
    asymmetry is below the multiplicative bias above.

    The inversion-unblocking property — non-zero ``d(out) / db`` even
    when ``b < a`` — holds because the softplus inside is
    non-saturating in float64 at ``beta = 1e6``: ``sigmoid(beta * x)``
    is finite and strictly positive for all finite ``x``.

    Parameters
    ----------
    a : torch.Tensor
        First argument; conventionally ``H_old`` in the dispatcher
        contract.  Must be ``>= 0``.
    b : torch.Tensor
        Second argument; conventionally ``psi_plus``.  Must be ``>= 0``
        and the same shape as ``a``.
    beta : float, optional
        Sharpness; defaults to ``1e6`` (multiplicative bias
        ``~ a * log(2) / beta`` ~ ``7e-7 * a``).

    Returns
    -------
    torch.Tensor
        Smooth ``max(a, b)`` with the same shape and dtype as ``a``.
    """
    return log_smoothed_history_update(a, b, beta=beta)


__all__ = [
    "LogSmoothedHistory",
    "log_smooth",
    "log_smoothed_history_update",
]
