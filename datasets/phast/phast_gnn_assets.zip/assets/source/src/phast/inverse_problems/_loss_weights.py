"""Time-weighted snapshot loss helper (issue #475).

When inverting against a sequence of N snapshots, the per-snapshot
residual r_i can be reweighted by an exponential decay

    w_i = exp(-lambda * (t_i / T))

so that earlier snapshots (low-damage pre-localization regime)
contribute more to the loss than late snapshots that may sit on the
"dynamic attractor" highlighted in the external review
(papers/paper3/notes/external_review_responses_2026-05-09.md, Q1).

Time normalisation:
    t_i = snapshot_steps[i]   (per-step integer index, or any
                                monotone non-negative scalar)
    T   = max(snapshot_steps)  (so first snap weight = 1, last snap
                                weight = exp(-lambda); when N=1 or
                                T=0, all weights collapse to 1)

Default lambda = 0.0 -> all weights equal 1 -> byte-identical
legacy behaviour (this module's caller should branch on
`lambda == 0.0` to skip the weighted code path entirely).

API
---
time_weights(snapshot_steps, lam) -> torch.Tensor of shape (N,)
weighted_mean(per_snap_losses, weights) -> torch.Tensor scalar

Both helpers operate on a flat sequence of per-snapshot scalar
losses; the demos collect those into ``chunk_losses`` lists already
(via TBPTT) or as a stacked tensor (DIC). The weighted mean is

    L = sum_i (w_i * r_i) / sum_i w_i

so the loss magnitude is preserved for lambda == 0 (where
sum w_i = N and L = mean(r_i)).
"""
from __future__ import annotations

from typing import Iterable, Sequence

import torch


def time_weights(
    snapshot_steps: Sequence[float] | torch.Tensor,
    lam: float,
    *,
    dtype: torch.dtype | None = None,
    device: torch.device | str | None = None,
) -> torch.Tensor:
    """Return the exponential-decay weight vector w_i = exp(-lam * t_i/T).

    Parameters
    ----------
    snapshot_steps : sequence or 1-D tensor of N non-negative scalars.
        Times (or step indices) at which the per-snapshot residuals are
        evaluated. Need not start at 0; T is taken as ``max(.)``.
    lam : float
        Decay rate. ``0.0`` returns a vector of ones (legacy behaviour).
        Positive values down-weight late snapshots.
    dtype, device : optional torch overrides for the returned tensor.

    Returns
    -------
    weights : torch.Tensor, shape (N,)

    Notes
    -----
    * If N == 1 or max(snapshot_steps) == 0, all weights collapse to 1.
    * Negative lam is allowed but pathological (up-weights late
      snapshots); we don't guard against it.
    """
    if isinstance(snapshot_steps, torch.Tensor):
        steps = snapshot_steps.to(dtype=dtype or torch.float64,
                                   device=device or 'cpu')
    else:
        steps = torch.as_tensor(list(snapshot_steps),
                                 dtype=dtype or torch.float64,
                                 device=device or 'cpu')
    n = steps.numel()
    if n == 0:
        return steps  # empty
    T = float(steps.max().item())
    if T <= 0.0 or lam == 0.0:
        return torch.ones(n, dtype=steps.dtype, device=steps.device)
    return torch.exp(-float(lam) * (steps / T))


def weighted_mean(
    per_snap_losses: Iterable[torch.Tensor] | torch.Tensor,
    weights: torch.Tensor,
) -> torch.Tensor:
    """Compute sum(w_i * r_i) / sum(w_i) over the snapshot axis.

    ``per_snap_losses`` may be a list of 0-D tensors (typical for the
    TBPTT chunk-loss path) or a 1-D tensor of shape (N,). ``weights``
    must be a 1-D tensor matching the snapshot count.

    For lambda == 0 (uniform weights), this returns the same numerical
    value as ``torch.stack(per_snap_losses).mean()`` up to a different
    reduction order; callers wanting *byte-identical* legacy behaviour
    should branch on ``lambda == 0.0`` and call ``mean()`` directly.
    """
    if isinstance(per_snap_losses, torch.Tensor):
        losses = per_snap_losses
    else:
        losses = torch.stack(list(per_snap_losses))
    if losses.shape[0] != weights.shape[0]:
        raise ValueError(
            f"snapshot count mismatch: losses={losses.shape[0]} "
            f"weights={weights.shape[0]}"
        )
    w = weights.to(dtype=losses.dtype, device=losses.device)
    return (w * losses).sum() / (w.sum() + 1e-30)


__all__ = ['time_weights', 'weighted_mean']
