#!/usr/bin/env python
"""Spatial Gc(x) recovery via native autograd through the dynamic loop.

This is the "mic drop" autograd demonstration: recover a per-element
fracture-toughness field Gc(x) from an observed damage pattern, where
the number of unknowns k = n_elem is large enough that finite
differences are infeasible (k+1 forwards per gradient).

Problem setup:
  - Simple SENT mesh, AT2 + spectral + plane strain
  - Truth: Gc(x) has a horizontal weak band (reduced Gc) along which
    the crack should preferentially propagate
  - Observations: final damage field at t = T_total
  - Unknowns: Gc_e for each element (k = n_elem ~ 10^3-10^4)
  - Optimiser: L-BFGS on log(Gc_e) for positivity + scale invariance
  - Cost per gradient: 2 CG solves per damage solve, INDEPENDENT of k
    (vs k+1 forwards for FD — infeasible at k=10^4)

Usage
-----
    # Small smoke test (quick, ~500 elements)
    python demo_spatial_gc_recovery.py --h_crack 0.5 --n_steps 50 --n_iters 5

    # Production (few thousand elements)
    python demo_spatial_gc_recovery.py --h_crack 0.25 --n_steps 200 --n_iters 30

This demo is the positive counterpart to the scalar-Gc Kalthoff demo
(demo_autograd_kalthoff.py): there, k=4 and FD is fine. Here, k >> 4
and FD is the wrong tool.
"""
import os
import sys
import time
import json
import argparse
import tempfile
import subprocess
import math

import numpy as np
import torch

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(THIS_DIR, '..', '..'))

from phast.material import Material
from phast.mesh import FEMMesh
from phast.boundary_conditions import BoundaryConditions
from phast.staggered_solver import StaggeredSolver, SolverConfig
from phast.device import DeviceContext
from phast.config import LoadingConfig
from phast.inverse_problems._tbptt import (
    run_forward_tbptt_generic,
    make_install_Gc_field,
)
from phast.inverse_problems.regularisers import (
    h1_seminorm, tv_seminorm,
)
from phast.inverse_problems.parametrisations.inr import (
    FieldINR, evaluate_at_nodes,
)


# ---------------------------------------------------------------------------
# Geometry: simple SENT with edge notch
# ---------------------------------------------------------------------------
def build_sent_mesh(h_crack, h_coarse, device, dtype):
    """Build a small SENT mesh (4×2 mm, 1 mm notch from left)."""
    W, H, a = 4.0, 2.0, 1.0
    geo_txt = f"""
    lc_crack = {h_crack};
    lc_coarse = {h_coarse};
    W = {W}; H = {H}; a = {a};
    Point(1) = {{0, 0, 0, lc_coarse}};
    Point(2) = {{W, 0, 0, lc_coarse}};
    Point(3) = {{W, H, 0, lc_coarse}};
    Point(4) = {{0, H, 0, lc_coarse}};
    Point(5) = {{0, H/2-0.01, 0, lc_crack}};
    Point(6) = {{a, H/2-0.01, 0, lc_crack}};
    Point(7) = {{a, H/2+0.01, 0, lc_crack}};
    Point(8) = {{0, H/2+0.01, 0, lc_crack}};
    Line(1) = {{1, 2}}; Line(2) = {{2, 3}}; Line(3) = {{3, 4}};
    Line(4) = {{4, 8}}; Line(5) = {{8, 7}}; Line(6) = {{7, 6}};
    Line(7) = {{6, 5}}; Line(8) = {{5, 1}};
    Curve Loop(1) = {{1, 2, 3, 4, 5, 6, 7, 8}};
    Plane Surface(1) = {{1}};
    Physical Surface("domain") = {{1}};
    Physical Curve("bottom") = {{1}};
    Physical Curve("right") = {{2}};
    Physical Curve("top") = {{3}};
    Physical Curve("left") = {{4, 8}};
    """
    geo_p = os.path.join(tempfile.gettempdir(), "spatial_gc_demo.geo")
    msh_p = os.path.join(tempfile.gettempdir(), "spatial_gc_demo.msh")
    with open(geo_p, 'w') as f:
        f.write(geo_txt)
    subprocess.run(["gmsh", "-2", geo_p, "-o", msh_p, "-format", "msh2"],
                   capture_output=True, check=True)
    mesh = FEMMesh(msh_p, device=device, dtype=dtype)
    mesh.identify_boundaries()
    return mesh


def build_solver(mesh, device, dtype, damage_every=1, softmax_H_beta=None,
                 dU=0.01, H_update_method='hard_max',
                 H_update_scale=None):
    """Build solver with gamma_correction=True to activate per-element Gc."""
    mat = Material(
        E=32000.0, nu=0.2, Gc=0.003, l0=0.1, rho=2.45e-9,
        energy_split='spectral', pf_model='AT2',
        gamma_correction=True,  # required for Gc_field path
    )
    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)
    bcs.add(mesh.node_sets['top'], component=1, value=+dU)
    bcs.add(mesh.node_sets['bottom'], component=1, value=-dU)
    bcs.fix(mesh.node_sets['left'], component=0)
    cfg = SolverConfig(
        solver_type='explicit',
        differentiable=True,
        damage_every=damage_every,
        softmax_H_beta=softmax_H_beta,
        H_update_method=H_update_method,
        H_update_scale=H_update_scale,
    )
    solver = StaggeredSolver(mesh, mat, bcs, config=cfg,
                              ctx=DeviceContext(device, dtype))
    return solver


def run_dynamic(solver, Gc_field, n_steps, snapshot_steps=None):
    """Run n_steps dynamic steps with the given per-element Gc field."""
    n_nodes = solver.mesh.n_nodes
    n_elem = solver.damage_solver._cg_elements.shape[0]
    device, dtype = solver.u.device, solver.u.dtype

    solver.u = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.v = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.a = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    solver.d = torch.zeros(n_nodes, dtype=dtype, device=device)
    solver.H_elem = torch.zeros(n_elem, dtype=dtype, device=device)
    solver.H_nodal = torch.zeros(n_nodes, dtype=dtype, device=device)
    solver._step_count = 0

    snap_set = set(int(s) for s in (snapshot_steps or []))
    snapshots = []
    solver.diff_Gc_field = Gc_field
    for step in range(n_steps):
        solver.step_full()
        if (step + 1) in snap_set:
            snapshots.append((step + 1, solver.d.detach().cpu().numpy()))
    if hasattr(solver, 'diff_Gc_field'):
        del solver.diff_Gc_field
    if snapshot_steps is not None:
        return solver.d, snapshots
    return solver.d


def make_truth_field(solver, weak_fraction=0.4, Gc_nominal=0.003):
    """Make a truth Gc field with a horizontal weak band at mid-height.

    Gc_e = Gc_nominal * (1 - weak_fraction * exp(-(y-H/2)^2 / sigma^2))
    """
    elements = solver.damage_solver._cg_elements
    centroids = solver.mesh.nodes[elements].mean(dim=1)  # (E, 2)
    y_c = centroids[:, 1]
    H = float(solver.mesh.nodes[:, 1].max() - solver.mesh.nodes[:, 1].min())
    sigma = 0.15 * H  # band width
    weak = torch.exp(-((y_c - H / 2) ** 2) / (2 * sigma ** 2))
    Gc_true = Gc_nominal * (1.0 - weak_fraction * weak)
    return Gc_true.to(torch.float64)


def make_inr_style_truth_field(solver, weak_fraction=0.4,
                               Gc_nominal=0.003):
    """Smooth fixed-Fourier Gc truth for the D8 INR forward gate."""
    elements = solver.damage_solver._cg_elements
    centroids = solver.mesh.nodes[elements].mean(dim=1)
    x = centroids[:, 0]
    y = centroids[:, 1]
    xn = 2.0 * (x - x.min()) / (x.max() - x.min()).clamp_min(1e-12) - 1.0
    yn = 2.0 * (y - y.min()) / (y.max() - y.min()).clamp_min(1e-12) - 1.0
    raw = (
        0.8 * torch.sin(2.0 * math.pi * xn)
        - 0.6 * torch.cos(3.0 * math.pi * yn)
        + 0.5 * torch.sin(math.pi * (xn + yn))
    )
    weak = torch.sigmoid(2.0 * raw)
    return (Gc_nominal * (1.0 - weak_fraction * weak)).to(torch.float64)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--h_crack', type=float, default=0.5)
    p.add_argument('--h_coarse', type=float, default=1.0)
    p.add_argument('--n_steps', type=int, default=50)
    p.add_argument('--n_iters', type=int, default=10)
    p.add_argument('--device', type=str, default='cpu')
    p.add_argument('--damage_every', type=int, default=1)
    p.add_argument('--softmax_H_beta', type=float, default=None)
    p.add_argument('--H_update_method', type=str, default='hard_max',
                   choices=['hard_max', 'softmax', 'smooth_max',
                            'log_smooth', 'custom_subgrad'],
                   help='History-variable max operator.')
    p.add_argument('--H_update_scale', type=float, default=None,
                   help='Backward sigmoid scale for custom_subgrad.')
    p.add_argument('--dU', type=float, default=0.005,
                   help='BC displacement [mm] (default 0.005 for medium loading)')
    p.add_argument('--weak_fraction', type=float, default=0.4,
                   help='Truth field: Gc reduction in weak band (default 0.4)')
    p.add_argument('--truth_source', type=str, default='band',
                   choices=['band', 'inr'],
                   help='Truth Gc source. "inr" uses fixed Fourier features '
                        'for the D8 forward gate.')
    p.add_argument('--output_dir', type=str, default='results_spatial_gc')
    # Issue #236: regularisation + alternative parametrisation -------------
    p.add_argument('--regulariser', type=str, default='none',
                   choices=['none', 'h1', 'tv', 'both'],
                   help='Spatial regulariser on Gc(x) field (issue #236).')
    p.add_argument('--alpha_h1', type=float, default=1.0e-4,
                   help='Weight for H^1 (Dirichlet) seminorm penalty.')
    p.add_argument('--alpha_tv', type=float, default=1.0e-5,
                   help='Weight for total-variation penalty.')
    p.add_argument('--tv_eps', type=float, default=1.0e-8,
                   help='Smoothing for differentiable |.| in TV term.')
    p.add_argument('--parametrisation', type=str, default='per_element',
                   choices=['per_element', 'inr'],
                   help='Field parametrisation: per-element log(Gc_e) '
                        '(default) or implicit neural rep (FieldINR).')
    p.add_argument('--inr_hidden_width', type=int, default=64)
    p.add_argument('--inr_hidden_layers', type=int, default=3)
    p.add_argument('--inr_n_fourier', type=int, default=64)
    p.add_argument('--inr_fourier_sigma', type=float, default=3.0)
    p.add_argument('--inr_seed', type=int, default=0)
    p.add_argument('--time_weight_lambda', type=float, default=0.0,
                   help='Exponential snapshot down-weighting (issue '
                        '#475). Per-chunk residual is multiplied by '
                        'exp(-lambda * t/T) where T=max(snapshot_steps); '
                        'only active when --tbptt_chunk_size > 0 (the '
                        'non-TBPTT path observes a single final field). '
                        'Default 0.0 = uniform = byte-identical legacy.')
    p.add_argument('--tbptt_chunk_size', type=int, default=0,
                   help='Truncated-BPTT chunk length (issue #288 / #301). '
                        '0 disables (default; full autograd graph). '
                        'When > 0, the n_steps explicit-dynamics loop is '
                        'split into chunks of this length; per-chunk damage '
                        'MSE-against-truth is the loss, biased gradient.')
    p.add_argument('--forward_only', action='store_true',
                   help='Generate truth forward bundle and exit before '
                        'optimisation.')
    p.add_argument('--save_forward_viz', dest='save_forward_viz',
                   action='store_true', default=True,
                   help='Save truth damage PNG/GIF.')
    p.add_argument('--no_save_forward_viz', dest='save_forward_viz',
                   action='store_false',
                   help='Disable truth damage PNG/GIF.')
    p.add_argument('--save_snapshots', type=int, default=0,
                   help='Number of damage snapshots to store in truth.npz.')
    p.add_argument('--n_viz_frames', type=int, default=20,
                   help='Frames in truth_damage_evolution.gif.')
    args = p.parse_args()

    out_dir = os.path.join(THIS_DIR, args.output_dir) \
        if not os.path.isabs(args.output_dir) else args.output_dir
    os.makedirs(out_dir, exist_ok=True)

    device = args.device
    dtype = torch.float64

    print("=" * 70)
    print("  Spatial Gc(x) recovery demo — autograd through dynamic loop")
    print("=" * 70)
    print(f"  Mesh:     h_crack={args.h_crack}, h_coarse={args.h_coarse}")
    print(f"  Dynamics: {args.n_steps} steps, damage_every={args.damage_every}, "
          f"softmax_H_beta={args.softmax_H_beta}, "
          f"H_update_method={args.H_update_method}, "
          f"H_update_scale={args.H_update_scale}")
    print(f"  Optimiser: L-BFGS, {args.n_iters} iters")
    print(f"  Output:   {out_dir}")
    snap_count = max(args.save_snapshots,
                     args.n_viz_frames if args.save_forward_viz else 0)
    if snap_count > 0:
        snapshot_steps = sorted(set(
            int(s) for s in np.linspace(1, args.n_steps, snap_count)))
    else:
        snapshot_steps = None

    # Build mesh + solver
    mesh = build_sent_mesh(args.h_crack, args.h_coarse, device, dtype)
    solver = build_solver(mesh, device, dtype,
                           damage_every=args.damage_every,
                           softmax_H_beta=args.softmax_H_beta,
                           H_update_method=args.H_update_method,
                           H_update_scale=args.H_update_scale,
                           dU=args.dU)
    # Tighten CG a bit for inversion accuracy
    solver.damage_solver.tol = 1e-9
    n_nodes = mesh.n_nodes
    n_elem = solver.damage_solver._cg_elements.shape[0]
    print(f"  k (unknowns) = n_elem = {n_elem}  [FD would need {n_elem+1} "
          f"forwards per gradient, autograd needs 2]")

    # ---- TBPTT setup (issue #301) ----
    # When --tbptt_chunk_size > 0 we route the forward through the shared
    # run_forward_tbptt_generic helper (chunked-BPTT, biased gradient).
    # The helper requires a LoadingConfig; this demo uses Dirichlet BCs
    # with constant amplitude (no ramp), so a constant LoadingConfig is
    # the no-op equivalent of the demo's plain step-loop forward.
    tbptt_chunk_steps = None
    d_target_tbptt_chunks = None
    loading = LoadingConfig(ramp_type='constant')
    if args.tbptt_chunk_size > 0:
        cs = int(args.tbptt_chunk_size)
        tbptt_chunk_steps = list(range(cs, args.n_steps, cs))
        if not tbptt_chunk_steps or tbptt_chunk_steps[-1] != args.n_steps:
            tbptt_chunk_steps.append(args.n_steps)
        print(f"\n[TBPTT #301] enabled: chunk_size={cs}, "
              f"{len(tbptt_chunk_steps)} chunks")

    # ---- Truth ----
    print("\n[1/3] Generating target damage from truth Gc(x) field ...")
    t0 = time.time()
    if args.truth_source == 'inr':
        Gc_true = make_inr_style_truth_field(
            solver, weak_fraction=args.weak_fraction)
    else:
        Gc_true = make_truth_field(solver, weak_fraction=args.weak_fraction)
    with torch.no_grad():
        if args.tbptt_chunk_size > 0:
            _, truth_chunk_snaps, truth_chunk_steps_chk, _ = (
                run_forward_tbptt_generic(
                    solver, loading,
                    install_fn=make_install_Gc_field(Gc_true),
                    n_steps=args.n_steps,
                    tbptt_chunk_size=args.tbptt_chunk_size))
            d_target_tbptt_chunks = [s.detach().clone()
                                      for s in truth_chunk_snaps]
            target = d_target_tbptt_chunks[-1]
            assert truth_chunk_steps_chk == tbptt_chunk_steps
            snaps_truth = []
            # Cleanup: TBPTT helper installs Gc_field as a side effect.
            if hasattr(solver, 'diff_Gc_field'):
                del solver.diff_Gc_field
        else:
            target_out = run_dynamic(
                solver, Gc_true, args.n_steps,
                snapshot_steps=snapshot_steps)
            if snapshot_steps is not None:
                target, snaps_truth = target_out
            else:
                target = target_out
                snaps_truth = []
            target = target.detach().clone()
    print(f"  Truth Gc range: [{Gc_true.min():.4e}, {Gc_true.max():.4e}]")
    print(f"  Target damage: max={target.max():.4f}, "
          f"mean={target.mean():.4f}, "
          f"#d>0.5: {(target > 0.5).sum().item()}")
    print(f"  Forward time: {time.time()-t0:.2f}s")
    np.save(os.path.join(out_dir, 'Gc_true.npy'), Gc_true.cpu().numpy())
    np.save(os.path.join(out_dir, 'target_damage.npy'), target.cpu().numpy())
    truth_save = {
        'nodes': mesh.nodes.cpu().numpy(),
        'elements': mesh.elements.cpu().numpy(),
        'd_target': target.cpu().numpy(),
        'Gc_true': Gc_true.cpu().numpy(),
        'n_steps': int(args.n_steps),
        'dt': float(solver.dt),
        'dU': float(args.dU),
        'weak_fraction': float(args.weak_fraction),
        'truth_source': args.truth_source,
        'parametrisation': args.parametrisation,
        'max_damage': float(target.max().item()),
        'n_damage_gt_0p5': int((target > 0.5).sum().item()),
        'crack_present': bool((target > 0.5).any().item()),
    }
    truth_save['bundle_status'] = (
        'ok' if truth_save['crack_present'] else 'no_crack')
    if snapshot_steps is not None and snaps_truth:
        truth_save['snapshot_steps'] = np.array([s for s, _ in snaps_truth])
        truth_save['snapshots'] = np.stack([d for _, d in snaps_truth])
        truth_save['snapshot_t_us'] = (
            truth_save['snapshot_steps'] * float(solver.dt) * 1e6)
    np.savez_compressed(os.path.join(out_dir, 'truth.npz'), **truth_save)
    with open(os.path.join(out_dir, 'forward_bundle.json'), 'w') as fh:
        json.dump({
            'status': truth_save['bundle_status'],
            'max_damage': truth_save['max_damage'],
            'n_damage_gt_0p5': truth_save['n_damage_gt_0p5'],
            'n_steps': int(args.n_steps),
            'parametrisation': args.parametrisation,
            'truth_source': args.truth_source,
            'bundle': 'truth.npz',
        }, fh, indent=2)
    if args.save_forward_viz:
        try:
            from inverse_problems._viz import save_forward_viz
            snap_arrays = [d for _, d in snaps_truth] if snaps_truth else None
            snap_step_idx = [s for s, _ in snaps_truth] if snaps_truth else None
            paths = save_forward_viz(
                mesh.nodes, mesh.elements, target, out_dir,
                label='truth', snapshots=snap_arrays,
                snap_steps=snap_step_idx, n_steps_total=args.n_steps)
            print(f"  [forward-viz] truth png -> {paths['png']}")
            if paths['gif']:
                print(f"  [forward-viz] truth gif -> {paths['gif']}")
        except Exception as exc:
            print(f"  [forward-viz] truth viz failed: {exc}")
    # Persist mesh geometry alongside results so downstream plotting
    # doesn't depend on /tmp state (multiple demos overwrite the same
    # /tmp path and the last one wins).
    np.save(os.path.join(out_dir, 'mesh_nodes.npy'),
            mesh.nodes.cpu().numpy())
    np.save(os.path.join(out_dir, 'mesh_elements.npy'),
            mesh.elements.cpu().numpy())
    import shutil as _sh
    _src_msh = os.path.join(tempfile.gettempdir(), "spatial_gc_demo.msh")
    if os.path.exists(_src_msh):
        _sh.copyfile(_src_msh, os.path.join(out_dir, 'mesh.msh'))

    if args.forward_only:
        print("\n--forward_only set; skipping inversion.")
        print(f"Results: {out_dir}/")
        return

    # ---- Parametrisation ----------------------------------------------
    # ``decode_field()`` returns the per-element Gc tensor (positive,
    # differentiable in the optimisation parameters).
    Gc_nominal = 0.003
    if args.parametrisation == 'per_element':
        Gc_init = torch.full((n_elem,), Gc_nominal, dtype=dtype, device=device)
        log_Gc = torch.log(Gc_init).clone().requires_grad_(True)
        opt_params = [log_Gc]

        def decode_field():
            return torch.exp(log_Gc)
        n_unknowns = log_Gc.numel()
    elif args.parametrisation == 'inr':
        torch.manual_seed(args.inr_seed)
        # Element centroids are evaluation coordinates; normalise to
        # roughly [-1, 1]^2 so the Fourier-feature scale is meaningful.
        elements = solver.damage_solver._cg_elements
        centroids = solver.mesh.nodes[elements].mean(dim=1).to(dtype)
        cmin = centroids.min(dim=0).values
        cmax = centroids.max(dim=0).values
        cscale = 0.5 * (cmax - cmin).clamp_min(1e-12)
        ccenter = 0.5 * (cmax + cmin)
        coords = ((centroids - ccenter) / cscale).to(dtype)
        log_nom = float(np.log(Gc_nominal))
        inr = FieldINR(
            n_input_dims=2,
            n_fourier_features=args.inr_n_fourier,
            fourier_sigma=args.inr_fourier_sigma,
            hidden_width=args.inr_hidden_width,
            n_hidden_layers=args.inr_hidden_layers,
            seed=args.inr_seed,
        ).to(device=device, dtype=dtype)
        opt_params = list(inr.parameters())

        def decode_field():
            # log_Gc(x) = log_nom + small MLP correction
            return torch.exp(log_nom + inr(coords))
        n_unknowns = sum(p.numel() for p in opt_params)
        print(f"  INR parametrisation: {n_unknowns} weights "
              f"(vs {n_elem} per-element unknowns)")
    else:  # pragma: no cover (argparse guards)
        raise ValueError(args.parametrisation)

    optimizer = torch.optim.LBFGS(
        opt_params, lr=0.5, max_iter=3, history_size=10,
        line_search_fn='strong_wolfe',
    )

    use_h1 = args.regulariser in ('h1', 'both')
    use_tv = args.regulariser in ('tv', 'both')
    print(f"  Regulariser: {args.regulariser} "
          f"(alpha_h1={args.alpha_h1 if use_h1 else 0.0}, "
          f"alpha_tv={args.alpha_tv if use_tv else 0.0})")

    history = {'iter': [], 'loss': [], 'loss_data': [],
               'loss_h1': [], 'loss_tv': [],
               'err_L2_rel': [], 'wall_s': []}

    def closure():
        optimizer.zero_grad()
        Gc_e = decode_field()
        if args.tbptt_chunk_size > 0:
            _, chunk_snaps_pred, chunk_steps_pred, _ = (
                run_forward_tbptt_generic(
                    solver, loading,
                    install_fn=make_install_Gc_field(Gc_e),
                    n_steps=args.n_steps,
                    tbptt_chunk_size=args.tbptt_chunk_size))
            assert chunk_steps_pred == tbptt_chunk_steps
            chunk_losses = [
                ((dp - dt) ** 2).mean()
                for dp, dt in zip(chunk_snaps_pred,
                                   d_target_tbptt_chunks)]
            if args.time_weight_lambda != 0.0:
                from phast.inverse_problems._loss_weights import (
                    time_weights, weighted_mean)
                _w = time_weights(tbptt_chunk_steps,
                                   args.time_weight_lambda,
                                   dtype=chunk_losses[0].dtype,
                                   device=chunk_losses[0].device)
                loss = weighted_mean(chunk_losses, _w)
            else:
                loss = torch.stack(chunk_losses).mean()
            if hasattr(solver, 'diff_Gc_field'):
                del solver.diff_Gc_field
        else:
            d_pred = run_dynamic(solver, Gc_e, args.n_steps)
            loss = ((d_pred - target) ** 2).mean()
        loss_data_val = float(loss.detach().item())
        loss_h1_val = 0.0
        loss_tv_val = 0.0
        if use_h1:
            r_h1 = h1_seminorm(Gc_e, solver.mesh)
            loss = loss + args.alpha_h1 * r_h1
            loss_h1_val = float((args.alpha_h1 * r_h1).detach().item())
        if use_tv:
            r_tv = tv_seminorm(Gc_e, solver.mesh, eps=args.tv_eps)
            loss = loss + args.alpha_tv * r_tv
            loss_tv_val = float((args.alpha_tv * r_tv).detach().item())
        # Stash on closure for outer-loop bookkeeping.
        closure._last_data = loss_data_val
        closure._last_h1 = loss_h1_val
        closure._last_tv = loss_tv_val
        loss.backward()
        return loss

    # ---- Inversion ----
    print(f"\n[2/3] Running L-BFGS on {n_unknowns}-dimensional unknowns "
          f"(parametrisation={args.parametrisation}) ...")
    t_loop = time.time()
    for it in range(args.n_iters):
        t_iter = time.time()
        loss = optimizer.step(closure)
        with torch.no_grad():
            Gc_cur = decode_field().detach()
            err_L2 = (Gc_cur - Gc_true).norm().item() / Gc_true.norm().item()
        history['iter'].append(it)
        history['loss'].append(float(loss.item()))
        history['loss_data'].append(getattr(closure, '_last_data', float('nan')))
        history['loss_h1'].append(getattr(closure, '_last_h1', 0.0))
        history['loss_tv'].append(getattr(closure, '_last_tv', 0.0))
        history['err_L2_rel'].append(float(err_L2))
        history['wall_s'].append(time.time() - t_iter)
        print(f"  it {it:3d} | loss={loss.item():.4e} "
              f"(data={getattr(closure, '_last_data', 0.0):.3e}, "
              f"h1={getattr(closure, '_last_h1', 0.0):.3e}, "
              f"tv={getattr(closure, '_last_tv', 0.0):.3e}) | "
              f"||Gc-Gc*||/||Gc*|| = {err_L2:.4e} | "
              f"{time.time()-t_iter:.1f}s")

    elapsed = time.time() - t_loop
    per_iter = elapsed / args.n_iters if args.n_iters > 0 else float('nan')
    print(f"\n[3/3] Done. Total wall: {elapsed:.1f}s "
          f"({per_iter:.1f}s/iter)")

    # ---- Save ----
    with torch.no_grad():
        Gc_rec = decode_field().detach().cpu().numpy()
    np.save(os.path.join(out_dir, 'Gc_recovered.npy'), Gc_rec)
    with open(os.path.join(out_dir, 'history.json'), 'w') as f:
        json.dump(history, f, indent=2)
    with open(os.path.join(out_dir, 'run_metadata.json'), 'w') as f:
        json.dump({
            'H_update_method': args.H_update_method,
            'H_update_scale': args.H_update_scale,
            'softmax_H_beta': args.softmax_H_beta,
            'h_crack': args.h_crack,
            'h_coarse': args.h_coarse,
            'n_steps': args.n_steps,
            'n_iters': args.n_iters,
            'damage_every': args.damage_every,
            'dU': args.dU,
            'weak_fraction': args.weak_fraction,
            'truth_source': args.truth_source,
            'parametrisation': args.parametrisation,
            'regulariser': args.regulariser,
            'alpha_h1': args.alpha_h1,
            'alpha_tv': args.alpha_tv,
        }, f, indent=2)

    print(f"\nResults: {out_dir}/")
    print(f"  Gc_true.npy        — target field ({n_elem},)")
    print(f"  Gc_recovered.npy   — recovered field ({n_elem},)")
    print(f"  target_damage.npy  — target damage at t=T")
    print(f"  history.json       — loss + error per iter")
    print(f"  run_metadata.json  — H-update and run settings")


if __name__ == '__main__':
    main()
