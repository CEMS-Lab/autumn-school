"""Pre-inversion forward-pass visualisation helpers (issue: forward-viz).

Inverse demos in :mod:`inverse_problems.demos` typically run a *truth*
forward to manufacture observations, an *initial-guess* forward as a
sanity probe, and then an L-BFGS recovery loop that runs many forwards.
Before committing to a (potentially-hours-long) inversion, the user
wants to inspect the truth and init forwards visually -- if either
looks wrong, the inversion is doomed regardless of gradient quality.

This module provides a single pure-plotter helper :func:`save_forward_viz`
that takes already-computed forward artefacts (mesh + final damage +
optional snapshot list) and writes:

* ``<label>_damage_final.png`` -- final-time damage tricontour
* ``<label>_damage_evolution.gif`` -- one frame per snapshot

The helper deliberately does NOT run the forward itself: the demos all
have slightly different ``run_forward`` signatures (``E_field`` vs
``Gc_field`` vs ``Gc_field + u_prestrain``) and unifying them is out of
scope. The contract is "demo runs the forward, hands tensors here."

Outputs target the forward-viz size budget noted in
``feedback_figure_sizes`` (~100-800 kB png, ~1-5 MB gif).
"""

from __future__ import annotations

import os
from typing import Iterable, Optional, Sequence

import numpy as np

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
import matplotlib.tri as mtri


def _to_numpy(t):
    if hasattr(t, 'detach'):
        return t.detach().cpu().numpy()
    return np.asarray(t)


def save_forward_viz(
    nodes,
    elements,
    d_final,
    out_dir: str,
    label: str = 'truth',
    snapshots: Optional[Sequence] = None,
    snap_steps: Optional[Iterable[int]] = None,
    n_steps_total: Optional[int] = None,
    title_prefix: Optional[str] = None,
    particles: Optional[Sequence[tuple[float, float]]] = None,
    particle_radius: Optional[float] = None,
    particle_label_prefix: str = 'p',
    particle_color: str = 'tab:cyan',
    dpi: int = 150,
    gif_fps: int = 6,
) -> dict:
    """Save ``<label>_damage_final.png`` and ``<label>_damage_evolution.gif``.

    Parameters
    ----------
    nodes : (n_nodes, 2) array-like
    elements : (n_elems, 3) array-like (triangle connectivity)
    d_final : (n_nodes,) array-like -- final damage field
    out_dir : str -- directory to write into (created if missing)
    label : str -- filename prefix, e.g. ``'truth'`` or ``'init'``
    snapshots : optional list of (n_nodes,) damage tensors/arrays. If
        present, a gif is written. If absent or empty, only the png.
    snap_steps : optional list of int step indices matching ``snapshots``;
        used for per-frame titles only.
    n_steps_total : optional total step count for the gif title.
    title_prefix : optional title text (defaults to ``label.title()``).
    dpi, gif_fps : matplotlib + PIL writer knobs.

    Returns
    -------
    dict with ``png`` (path) and ``gif`` (path or ``None``).
    """
    os.makedirs(out_dir, exist_ok=True)
    nodes_np = _to_numpy(nodes)
    elems_np = _to_numpy(elements)
    d_np = _to_numpy(d_final)
    d_np = np.nan_to_num(d_np, nan=0.0, posinf=1.0, neginf=0.0)

    tri = mtri.Triangulation(nodes_np[:, 0], nodes_np[:, 1], elems_np)
    title_root = title_prefix if title_prefix is not None else label.title()

    def _draw_particles(ax) -> None:
        if particles is None:
            return
        radius = float(particle_radius) if particle_radius is not None else 0.0
        for i, (x_mm, y_mm) in enumerate(particles, start=1):
            if radius > 0.0:
                ax.add_patch(Circle(
                    (x_mm, y_mm), radius,
                    facecolor='none',
                    edgecolor=particle_color,
                    linewidth=1.8,
                    alpha=0.95,
                    zorder=8,
                ))
            ax.plot(
                [x_mm], [y_mm],
                marker='o',
                markersize=4.5,
                markerfacecolor=particle_color,
                markeredgecolor='black',
                markeredgewidth=0.7,
                linestyle='None',
                zorder=9,
            )
            ax.text(
                x_mm + 0.18, y_mm + 0.18,
                f'{particle_label_prefix}{i}',
                color=particle_color,
                fontsize=7,
                weight='bold',
                zorder=10,
            )

    # --- final-state PNG ---
    png_path = os.path.join(out_dir, f'{label}_damage_final.png')
    fig, ax = plt.subplots(1, 1, figsize=(6, 4.5))
    tcf = ax.tricontourf(tri, d_np, levels=64, cmap='inferno',
                         vmin=0.0, vmax=1.0)
    plt.colorbar(tcf, ax=ax, shrink=0.8, label='damage d')
    ax.set_aspect('equal')
    ax.set_title(f'{title_root}: final damage '
                 f'(max={d_np.max():.3f}, #d>0.5={(d_np > 0.5).sum()})',
                 fontsize=10)
    ax.set_xlabel('x (mm)', fontsize=9)
    ax.set_ylabel('y (mm)', fontsize=9)
    _draw_particles(ax)
    fig.tight_layout()
    fig.savefig(png_path, dpi=dpi)
    plt.close(fig)

    # --- evolution GIF (only if snapshots provided) ---
    gif_path = None
    if snapshots is not None and len(snapshots) > 0:
        gif_path = os.path.join(out_dir, f'{label}_damage_evolution.gif')
        try:
            from PIL import Image
        except ImportError:
            print(f'[forward-viz] PIL not available; skipping {gif_path}')
            return {'png': png_path, 'gif': None}

        snap_list = list(snapshots)
        if snap_steps is not None:
            steps_list = list(snap_steps)
        else:
            steps_list = [None] * len(snap_list)

        frames = []
        for i, snap in enumerate(snap_list):
            arr = _to_numpy(snap)
            arr = np.nan_to_num(arr, nan=0.0, posinf=1.0, neginf=0.0)
            fig, ax = plt.subplots(1, 1, figsize=(6, 4.5))
            tcf = ax.tricontourf(tri, arr, levels=64, cmap='inferno',
                                 vmin=0.0, vmax=1.0)
            plt.colorbar(tcf, ax=ax, shrink=0.8, label='damage d')
            ax.set_aspect('equal')
            step_txt = ''
            if steps_list[i] is not None:
                if n_steps_total:
                    step_txt = f' (step {steps_list[i]}/{n_steps_total})'
                else:
                    step_txt = f' (step {steps_list[i]})'
            ax.set_title(f'{title_root}: damage{step_txt} '
                         f'max={arr.max():.3f}', fontsize=10)
            ax.set_xlabel('x (mm)', fontsize=9)
            ax.set_ylabel('y (mm)', fontsize=9)
            _draw_particles(ax)
            fig.tight_layout()

            # Render into a PIL Image without writing intermediate
            # files. matplotlib 3.10 removed ``tostring_rgb``; the
            # portable replacement is ``buffer_rgba`` -> drop alpha.
            fig.canvas.draw()
            w, h = fig.canvas.get_width_height()
            buf_rgba = np.asarray(fig.canvas.buffer_rgba())
            frames.append(Image.fromarray(buf_rgba[..., :3].copy()))
            plt.close(fig)

        if frames:
            duration_ms = max(1, int(1000 / max(1, gif_fps)))
            frames[0].save(
                gif_path, save_all=True, append_images=frames[1:],
                duration=duration_ms, loop=0, optimize=True,
            )

    return {'png': png_path, 'gif': gif_path}


def viz_from_truth_npz(
    truth_npz_path: str,
    out_dir: Optional[str] = None,
    label: str = 'truth',
    n_steps_total: Optional[int] = None,
) -> dict:
    """Convenience: build forward-viz from a ``damage_truth.npz`` file.

    Used by demos that resume from a cached truth pass instead of
    re-running it. Reads ``nodes``, ``elements``, ``d_target`` and
    optionally ``snapshots`` + ``snapshot_steps`` from the npz.
    """
    z = np.load(truth_npz_path, allow_pickle=True)
    nodes = z['nodes']
    elems = z['elements']
    d_final = z['d_target']
    snaps = z['snapshots'] if 'snapshots' in z.files else None
    snap_steps = (z['snapshot_steps']
                  if 'snapshot_steps' in z.files else None)
    if out_dir is None:
        out_dir = os.path.dirname(truth_npz_path)
    return save_forward_viz(
        nodes, elems, d_final, out_dir, label=label,
        snapshots=snaps, snap_steps=snap_steps,
        n_steps_total=n_steps_total,
    )
