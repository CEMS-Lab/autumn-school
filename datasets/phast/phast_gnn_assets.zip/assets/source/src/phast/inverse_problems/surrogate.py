"""Surrogate-accelerated inversion: cheap model + exact-gradient refinement.

Two-phase strategy for expensive differentiable PDE inverse problems:

  Phase 1 (coarse): Train a cheap surrogate L_s(theta) on a small set
    of forward-solver evaluations. Minimise the surrogate (fast, ~ms)
    to find theta_approx near the true minimum.

  Phase 2 (refine): Starting from theta_approx, run the exact
    differentiable solver for n_refine iterations to exploit
    autograd-quality gradients and reach high accuracy.

This avoids spending expensive gradient evaluations far from the minimum.

Surrogate models provided
-------------------------
- ``MLPSurrogate``   — small feed-forward MLP (parameter → scalar loss)
- ``GPSurrogate``    — RBF kernel Gaussian process (scipy-based)

The interface is intentionally minimal: any object with a ``.predict(theta)``
method returning a scalar (tensor or float) can be used as the surrogate.

Typical use (D3 Gc(x) demo)
-----------------------------
::

    from phast.inverse_problems.surrogate import (
        MLPSurrogate, GPSurrogate, surrogate_minimize, hybrid_inversion
    )

    # 1. Collect N forward evaluations (can reuse landscape scan results)
    thetas = torch.tensor([[12.0], [13.0], ..., [19.0]], dtype=torch.float64)
    losses = torch.tensor([L(x0) for x0 in thetas[:, 0]], dtype=torch.float64)

    # 2. Fit surrogate
    sur = MLPSurrogate(n_in=1, hidden=[32, 32])
    sur.fit(thetas, losses, n_epochs=500)

    # 3. Find surrogate minimum
    theta_approx = surrogate_minimize(sur, bounds=[(12.0, 20.0)])

    # 4. Refine with exact solver
    result = hybrid_inversion(exact_loss_fn, theta_approx, n_refine=8)

Integration test
----------------
::

    python -m phast.inverse_problems.surrogate
"""
from __future__ import annotations

from typing import Callable, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch import Tensor


# ---------------------------------------------------------------------------
# MLP surrogate
# ---------------------------------------------------------------------------

class MLPSurrogate(nn.Module):
    """Feed-forward MLP mapping parameter vector theta → scalar loss.

    Trained on (theta, loss) pairs from the exact forward solver.  Lightweight
    enough to evaluate thousands of times per second for surrogate minimisation.

    Parameters
    ----------
    n_in    : number of optimisation parameters
    hidden  : list of hidden-layer widths
    act     : activation class (default: GELU for smooth loss approximation)
    """

    def __init__(
        self,
        n_in: int = 1,
        hidden: List[int] = (64, 64),
        act: type = nn.GELU,
    ) -> None:
        super().__init__()
        layers: List[nn.Module] = []
        dim = n_in
        for h in hidden:
            layers += [nn.Linear(dim, h), act()]
            dim = h
        layers.append(nn.Linear(dim, 1))
        self.net = nn.Sequential(*layers)
        self.register_buffer("theta_mean", torch.zeros(n_in, dtype=torch.float64))
        self.register_buffer("theta_std", torch.ones(n_in, dtype=torch.float64))
        self.register_buffer("loss_mean", torch.zeros(1, dtype=torch.float64))
        self.register_buffer("loss_std", torch.ones(1, dtype=torch.float64))

    def _normalise_theta(self, theta: Tensor) -> Tensor:
        return (theta - self.theta_mean) / (self.theta_std + 1e-8)

    def forward(self, theta: Tensor) -> Tensor:
        """Return predicted log-loss (scalar) for theta (1-D)."""
        x = self._normalise_theta(theta.to(self.theta_mean))
        return self.net(x.float()).squeeze(-1).double()

    def predict(self, theta: Tensor) -> Tensor:
        """Alias for forward. Returns un-normalised predicted loss."""
        log_pred = self(theta)
        return torch.exp(log_pred * self.loss_std + self.loss_mean)

    def fit(
        self,
        thetas: Tensor,
        losses: Tensor,
        n_epochs: int = 1000,
        lr: float = 1e-3,
        verbose: bool = False,
    ) -> "MLPSurrogate":
        """Fit MLP to (theta, loss) training pairs in-place.

        Trains to predict log(loss) to handle the wide dynamic range typical
        of phase-field inverse loss landscapes.

        Parameters
        ----------
        thetas  : (N, n_in) parameter samples
        losses  : (N,) corresponding loss values
        n_epochs: number of gradient steps
        lr      : Adam learning rate
        """
        thetas = thetas.to(torch.float64)
        losses = losses.to(torch.float64)

        # Store normalisation statistics
        self.theta_mean = thetas.mean(0).to(self.theta_mean)
        self.theta_std = thetas.std(0).clamp(min=1e-8).to(self.theta_std)

        log_losses = torch.log(losses.clamp(min=1e-40))
        self.loss_mean = log_losses.mean().unsqueeze(0).to(self.loss_mean)
        self.loss_std = log_losses.std().clamp(min=1e-8).unsqueeze(0).to(self.loss_std)

        y_target = (log_losses - self.loss_mean) / self.loss_std  # normalised targets

        opt = torch.optim.Adam(self.parameters(), lr=lr)
        self.train()
        for ep in range(n_epochs):
            opt.zero_grad()
            y_pred = self(thetas)
            loss = ((y_pred - y_target) ** 2).mean()
            loss.backward()
            opt.step()
            if verbose and (ep + 1) % 200 == 0:
                print(f"  surrogate epoch {ep+1}/{n_epochs}: MSE={loss.item():.4e}")
        self.eval()
        return self


# ---------------------------------------------------------------------------
# GP surrogate (scipy RBF, CPU only, n_in ≤ 4)
# ---------------------------------------------------------------------------

class GPSurrogate:
    """Radial-basis-function interpolant (exact, not statistical).

    Fast to fit (~ms) for N ≤ 100 training points.  Returns a scipy
    ``RBFInterpolant`` that can be queried as a Python callable.

    Parameters
    ----------
    kernel : RBF kernel string passed to scipy.interpolate.RBFInterpolator
    eps    : shape parameter for the kernel
    """

    def __init__(self, kernel: str = "multiquadric", eps: float = 1.0) -> None:
        self.kernel = kernel
        self.eps = eps
        self._rbf = None

    def fit(self, thetas: np.ndarray, losses: np.ndarray) -> "GPSurrogate":
        """Fit RBF interpolant to (thetas, losses)."""
        from scipy.interpolate import RBFInterpolator
        log_losses = np.log(np.clip(losses, 1e-40, None))
        self._rbf = RBFInterpolator(
            thetas, log_losses, kernel=self.kernel, epsilon=self.eps
        )
        return self

    def predict(self, theta: np.ndarray) -> float:
        """Return interpolated loss at theta (shape (n_in,) numpy array)."""
        if self._rbf is None:
            raise RuntimeError("Call fit() first.")
        log_pred = self._rbf(theta.reshape(1, -1))[0]
        return float(np.exp(log_pred))

    def predict_batch(self, thetas: np.ndarray) -> np.ndarray:
        """Return (N,) array of predicted losses."""
        if self._rbf is None:
            raise RuntimeError("Call fit() first.")
        log_pred = self._rbf(thetas)
        return np.exp(log_pred)


# ---------------------------------------------------------------------------
# Surrogate minimisation (gradient-free on the surrogate)
# ---------------------------------------------------------------------------

def surrogate_minimize(
    surrogate,
    bounds: List[Tuple[float, float]],
    n_restarts: int = 20,
    seed: int = 0,
) -> np.ndarray:
    """Find the approximate minimum of the surrogate loss by multi-start L-BFGS-B.

    For an MLPSurrogate, differentiates through the MLP.
    For a GPSurrogate, uses scipy's gradient-free optimizer (Nelder-Mead).

    Parameters
    ----------
    surrogate  : MLPSurrogate or GPSurrogate
    bounds     : list of (lo, hi) per parameter dimension
    n_restarts : number of random starting points

    Returns
    -------
    theta_opt : (n_in,) numpy array — surrogate minimum
    """
    from scipy.optimize import minimize as scipy_minimize

    rng = np.random.default_rng(seed)
    lo = np.array([b[0] for b in bounds], dtype=np.float64)
    hi = np.array([b[1] for b in bounds], dtype=np.float64)

    best_x, best_f = None, np.inf

    if isinstance(surrogate, MLPSurrogate):
        surrogate.eval()
        def obj_and_grad(x):
            t = torch.tensor(x, dtype=torch.float64, requires_grad=True)
            val = surrogate.predict(t.unsqueeze(0)).squeeze()
            val.backward()
            return float(val.detach()), t.grad.detach().numpy()

        for _ in range(n_restarts):
            x0 = rng.uniform(lo, hi)
            res = scipy_minimize(obj_and_grad, x0, method="L-BFGS-B",
                                 bounds=bounds, jac=True,
                                 options={"maxiter": 200, "ftol": 1e-14})
            if res.fun < best_f:
                best_f, best_x = res.fun, res.x

    else:
        # GPSurrogate or any callable with .predict(np array)
        def obj(x):
            return surrogate.predict(x)

        for _ in range(n_restarts):
            x0 = rng.uniform(lo, hi)
            res = scipy_minimize(obj, x0, method="Nelder-Mead",
                                 bounds=bounds,
                                 options={"maxiter": 1000, "xatol": 1e-5})
            if res.fun < best_f:
                best_f, best_x = res.fun, res.x

    return best_x


# ---------------------------------------------------------------------------
# Hybrid inversion: surrogate warmup + exact refinement
# ---------------------------------------------------------------------------

def hybrid_inversion(
    exact_loss_fn: Callable[[Tensor], Tensor],
    theta_init: np.ndarray | Tensor,
    n_refine: int = 10,
    lr: float = 0.05,
    grad_clip: float = 1.0,
    verbose: bool = True,
) -> dict:
    """Gradient-based refinement starting from a surrogate-found initial point.

    This is Phase 2 of the surrogate-accelerated strategy: the exact differentiable
    solver provides autograd-quality gradients from a warm start near the minimum.

    Parameters
    ----------
    exact_loss_fn : callable(theta: Tensor) → scalar loss (with autograd)
    theta_init    : starting parameter vector (from surrogate_minimize or hand-set)
    n_refine      : number of exact gradient steps
    lr            : Adam learning rate
    grad_clip     : gradient clip norm

    Returns
    -------
    dict with keys: 'theta_history', 'loss_history', 'theta_best', 'loss_best'
    """
    if isinstance(theta_init, np.ndarray):
        theta = torch.tensor(theta_init, dtype=torch.float64, requires_grad=True)
    else:
        theta = theta_init.clone().detach().requires_grad_(True)

    opt = torch.optim.Adam([theta], lr=lr)

    history_theta: List[float] = []
    history_loss: List[float] = []
    best_loss = np.inf
    best_theta = theta.detach().clone()

    for i in range(n_refine):
        opt.zero_grad()
        loss = exact_loss_fn(theta)
        loss.backward()
        nn.utils.clip_grad_norm_([theta], grad_clip)
        opt.step()

        loss_val = float(loss.detach())
        theta_val = theta.detach().clone()
        history_loss.append(loss_val)
        history_theta.append(theta_val.tolist())

        if loss_val < best_loss:
            best_loss = loss_val
            best_theta = theta_val

        if verbose:
            print(f"  [refine iter {i:2d}] loss={loss_val:.4e}  theta={theta_val.tolist()}")

    return {
        "theta_history": history_theta,
        "loss_history": history_loss,
        "theta_best": best_theta.numpy().tolist(),
        "loss_best": best_loss,
    }


# ---------------------------------------------------------------------------
# Integration test
# ---------------------------------------------------------------------------

def _run_integration_test() -> None:
    """Smoke test: MLP + GP surrogate on D3 x0 landscape data."""
    print("surrogate integration test")
    print("=" * 48)

    # D3 landscape scan results (jobs 34060+34069, 2026-05-17)
    x0_vals = np.array([12.0, 13.0, 14.0, 14.5, 15.0, 15.5,
                        16.0, 16.5, 17.0, 17.5, 18.0, 19.0])
    loss_vals = np.array([3.90e-2, 3.91e-2, 3.76e-2, 3.57e-2, 6.25e-3, 7.73e-4,
                          1.53e-28, 7.73e-4, 2.68e-3, 2.85e-3, 3.50e-3, 5.16e-3])
    truth_x0 = 16.0
    bounds = [(12.0, 20.0)]

    thetas = torch.tensor(x0_vals[:, None], dtype=torch.float64)
    losses = torch.tensor(loss_vals, dtype=torch.float64)

    # --- MLP surrogate ---
    print("\n[MLP surrogate]")
    sur_mlp = MLPSurrogate(n_in=1, hidden=[32, 32])
    sur_mlp.fit(thetas, losses, n_epochs=2000, verbose=False)

    # Check: predict at training points
    with torch.no_grad():
        pred_losses = [float(sur_mlp.predict(
            torch.tensor([[x]], dtype=torch.float64)).item())
            for x in x0_vals]
    max_rel_err = max(abs(p - t) / (t + 1e-40)
                      for p, t in zip(pred_losses, loss_vals))
    print(f"  max relative training error: {max_rel_err:.3f}")

    theta_mlp = surrogate_minimize(sur_mlp, bounds, n_restarts=10)
    x0_mlp = float(theta_mlp[0])
    print(f"  MLP surrogate minimum: x0={x0_mlp:.4f} mm  (truth={truth_x0})")
    err_mlp = abs(x0_mlp - truth_x0)
    print(f"  Error: {err_mlp:.4f} mm")
    assert err_mlp < 1.0, f"MLP surrogate minimum too far from truth: {err_mlp:.4f}"

    # --- GP surrogate ---
    print("\n[GP surrogate]")
    sur_gp = GPSurrogate(kernel="thin_plate_spline", eps=1.0)
    sur_gp.fit(x0_vals[:, None], loss_vals)

    # Check predictions at training points
    gp_preds = sur_gp.predict_batch(x0_vals[:, None])
    max_rel_gp = max(abs(p - t) / (t + 1e-40) for p, t in zip(gp_preds, loss_vals))
    print(f"  max relative training error: {max_rel_gp:.3f}")

    theta_gp = surrogate_minimize(sur_gp, bounds, n_restarts=10)
    x0_gp = float(theta_gp[0])
    print(f"  GP surrogate minimum: x0={x0_gp:.4f} mm  (truth={truth_x0})")
    err_gp = abs(x0_gp - truth_x0)
    print(f"  Error: {err_gp:.4f} mm")
    assert err_gp < 1.0, f"GP surrogate minimum too far from truth: {err_gp:.4f}"

    # --- hybrid_inversion smoke test (synthetic quadratic exact loss) ---
    # Starts from a 1.0mm offset (realistic surrogate init error) and refines
    # with Adam lr=0.05 (PDE-calibrated). Adam's sign-normalisation gives ~0.05mm
    # steps, so 20 iters from 1.0mm error should reach <0.1mm.
    print("\n[hybrid_inversion smoke]")
    truth_t = torch.tensor([truth_x0], dtype=torch.float64)

    def synthetic_exact_loss(theta: Tensor) -> Tensor:
        return ((theta - truth_t) ** 2).sum()

    init_offset = np.array([truth_x0 + 1.0])  # 1mm from truth (realistic surrogate init)
    result = hybrid_inversion(
        synthetic_exact_loss,
        theta_init=init_offset,
        n_refine=20,
        lr=0.05,
        verbose=False,
    )
    x0_refined = float(result["theta_best"][0])
    print(f"  Start: x0={float(init_offset[0]):.4f}mm → Refined: x0={x0_refined:.4f}mm  (truth={truth_x0})")
    err_ref = abs(x0_refined - truth_x0)
    print(f"  Error after refinement: {err_ref:.4f} mm  (started at 1.0mm)")
    assert err_ref < 0.5, f"Refinement didn't improve: err={err_ref:.4f}"
    assert err_ref < 1.0, f"Refinement diverged: err={err_ref:.4f}"
    assert result["loss_best"] < synthetic_exact_loss(
        torch.tensor(init_offset, dtype=torch.float64)).item(), \
        "Refinement should decrease loss"

    print("\nPASS — all assertions passed")


if __name__ == "__main__":
    _run_integration_test()
