#!/usr/bin/env python
"""
Plot convergence for inverse Kalthoff runs.

Usage:
    python plot_convergence.py <results_root_dir>

Walks subfolders containing history.json and produces:
    - convergence_loss.png       (per-iteration loss)
    - convergence_params.png     (per-parameter relative error)
    - summary_table.txt          (final values vs Stanić)
"""
import os
import sys
import json
import math

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


STANIC_RESULT = {
    'forwards_total': 15173,
    'errors_pct': {'K': 0.6, 'G': -0.1, 'sigma_un': 0.2, 'G_fn': -0.2,
                   'sigma_us': -0.8, 'G_fs': -1.6},
    'reference': 'Stanić et al. 2026 IJNME doi:10.1002/nme.70282',
}


def find_history_files(root):
    out = []
    for dirpath, _, files in os.walk(root):
        if 'history.json' in files:
            out.append(os.path.join(dirpath, 'history.json'))
    return sorted(out)


def load(path):
    with open(path) as f:
        return json.load(f)


def plot_run(history_path, fig_dir):
    data = load(history_path)
    h = data['history']
    if not h['iter']:
        print(f"  empty history: {history_path}")
        return None
    name = os.path.basename(os.path.dirname(history_path))

    iters = np.array(h['iter'])
    losses = np.array(h['loss'])
    fwds = np.array(h['forward_count'])
    param_names = data['param_names']
    theta_true = data['theta_true']

    # Param trajectories
    theta_arr = np.array(h['theta'])  # (n_iter, n_param)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))

    # (a) Loss vs forward count
    ax = axes[0]
    ax.semilogy(fwds, losses, 'o-', ms=4)
    ax.axvline(STANIC_RESULT['forwards_total'], color='r', ls='--',
               label=f"Stanić: {STANIC_RESULT['forwards_total']} fwds")
    ax.set_xlabel('Forward simulation count')
    ax.set_ylabel('MSE loss')
    ax.set_title(f'(a) Loss convergence — {name}')
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=9)

    # (b) Parameter relative error vs iteration
    ax = axes[1]
    for i, k in enumerate(param_names):
        rel = np.abs(theta_arr[:, i] - theta_true[k]) / theta_true[k]
        ax.semilogy(iters, rel, 'o-', ms=3, label=k)
    ax.set_xlabel('Iteration')
    ax.set_ylabel(r'$|\theta - \theta^*| / \theta^*$')
    ax.set_title('(b) Parameter relative error')
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=9)

    fig.suptitle(f'Inverse Kalthoff: {name}', fontsize=12)
    fig.tight_layout()
    out_path = os.path.join(fig_dir, f'convergence_{name}.png')
    fig.savefig(out_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    print(f"  saved: {out_path}")

    # Final summary
    final_theta = theta_arr[-1]
    final_err = {k: float(abs(final_theta[i] - theta_true[k]) / theta_true[k])
                 for i, k in enumerate(param_names)}
    return {
        'name': name,
        'final_theta': {k: float(final_theta[i]) for i, k in enumerate(param_names)},
        'final_err': final_err,
        'final_loss': float(losses[-1]),
        'total_forwards': int(data['total_forward_simulations']),
    }


def write_summary(summaries, out_path):
    with open(out_path, 'w') as f:
        f.write('Inverse Kalthoff identification — head-to-head with Stanić et al. (2026)\n')
        f.write('=' * 80 + '\n\n')
        f.write(f"Reference (Stanić): {STANIC_RESULT['reference']}\n")
        f.write(f"  Forward simulations needed: {STANIC_RESULT['forwards_total']}\n")
        f.write('  Posterior-mean errors:\n')
        for k, v in STANIC_RESULT['errors_pct'].items():
            f.write(f'    {k:10s}: {v:+.1f}%\n')
        f.write('\n')

        for s in summaries:
            if s is None:
                continue
            f.write(f"\n--- Run: {s['name']} ---\n")
            f.write(f"  Forward simulations: {s['total_forwards']}\n")
            f.write(f"  Speedup vs Stanić:   {STANIC_RESULT['forwards_total'] / s['total_forwards']:.1f}x\n")
            f.write(f"  Final loss:          {s['final_loss']:.4e}\n")
            f.write('  Final parameters:\n')
            for k, v in s['final_theta'].items():
                err = s['final_err'][k] * 100
                f.write(f'    {k:6s} = {v:.4g}  (err {err:+.2f}%)\n')


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    root = sys.argv[1]
    fig_dir = os.path.join(root, 'figures')
    os.makedirs(fig_dir, exist_ok=True)

    histories = find_history_files(root)
    print(f"Found {len(histories)} history files in {root}")
    summaries = [plot_run(h, fig_dir) for h in histories]

    summary_path = os.path.join(root, 'summary_table.txt')
    write_summary([s for s in summaries if s is not None], summary_path)
    print(f"\nSummary: {summary_path}")
    with open(summary_path) as f:
        print(f.read())


if __name__ == '__main__':
    main()
