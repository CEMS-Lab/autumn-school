#!/usr/bin/env python
"""Sanity-check the truth E-field (1- and 3-particle) and Gc-field
(horizontal band) BEFORE spending CPU time on dynamic forward smokes.

Builds the same meshes the inversion demos use, evaluates the truth
material fields on element centroids, and produces a 3-panel PNG
showing each field on its mesh.

Run from repo root:

    python -m phast.inverse_problems.precheck_truth_fields
"""
from __future__ import annotations
import os
import sys
import torch
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.tri import Triangulation

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(THIS_DIR, '..'))
sys.path.insert(0, os.path.dirname(REPO_ROOT))

from phast.inverse_problems.demos.demo_inverse_stiff_inclusion import (
    gaussian_E_field_multi, build_solver as _build_inc_solver,
    SIGMA_INC, ALPHA_TRUTH, E_BULK,
)
from phast.inverse_problems.demos.demo_inverse_gc_horizontal import (
    horizontal_band_field, build_sent_mesh as _build_gc_mesh,
    build_solver as _build_gc_solver,
    DEFAULT_X0, DEFAULT_SIGMA, DEFAULT_WEAK_FRACTION,
)


def main():
    dtype = torch.float64
    device = 'cpu'

    # --- inclusion mesh (smoke params: h_crack=0.4, h_coarse=2.0) ---
    print("[1/3] Building inclusion mesh (smoke params)...")
    sol_inc, centroids_inc, _ = _build_inc_solver(
        W=32.0, H=16.0, a=4.0,
        h_crack=0.4, h_coarse=2.0,
        dU=0.05, tau_ramp=30e-6, damping_zeta=0.05,
        device=device, dtype=dtype,
    )
    print(f"  Mesh: {sol_inc.mesh.n_nodes} nodes, "
          f"{sol_inc.mesh.n_elems} elements")
    nodes_inc = sol_inc.mesh.nodes.cpu().numpy()
    tris_inc  = sol_inc.mesh.elements.cpu().numpy()

    truth_1p = torch.tensor([[16.0, 9.5]], dtype=dtype, device=device)
    truth_3p = torch.tensor([[13.0, 9.5], [25.0, 9.5], [19.0, 6.5]],
                              dtype=dtype, device=device)

    E_1p = gaussian_E_field_multi(centroids_inc, truth_1p,
                                    E_BULK, ALPHA_TRUTH, SIGMA_INC)
    E_3p = gaussian_E_field_multi(centroids_inc, truth_3p,
                                    E_BULK, ALPHA_TRUTH, SIGMA_INC)
    print(f"  1p: E range [{E_1p.min():.0f}, {E_1p.max():.0f}] MPa")
    print(f"  3p: E range [{E_3p.min():.0f}, {E_3p.max():.0f}] MPa")

    # Centerline crosscut along y = 8 (crack axis): how distinct are
    # the three bumps when projected onto the crack path?
    print("\n  Centerline E (along y = 8, sampled at 200 x):")
    xs = np.linspace(0.5, 31.5, 200)
    pts = torch.tensor([[x, 8.0] for x in xs], dtype=dtype, device=device)
    E_line_3p = gaussian_E_field_multi(pts, truth_3p,
                                         E_BULK, ALPHA_TRUTH, SIGMA_INC)
    peaks = []
    Eln = E_line_3p.cpu().numpy()
    for i in range(1, len(Eln) - 1):
        if Eln[i] > Eln[i - 1] and Eln[i] > Eln[i + 1]:
            peaks.append((xs[i], Eln[i]))
    print(f"    found {len(peaks)} local maxima along centerline: "
          + ", ".join(f"x={p[0]:.1f}|E={p[1]:.0f}" for p in peaks))

    # --- Gc horizontal mesh (smoke params: h_crack=0.5, h_coarse=1.0) ---
    print("\n[2/3] Building Gc-horizontal mesh (smoke params)...")
    mesh_gc, _ = _build_gc_mesh(0.5, 1.0, device, dtype)
    sol_gc = _build_gc_solver(mesh_gc, device, dtype, dU=0.005)
    elements_gc = sol_gc.damage_solver._cg_elements
    centroids_gc = mesh_gc.nodes[elements_gc].mean(dim=1)
    print(f"  Mesh: {mesh_gc.n_nodes} nodes, {elements_gc.shape[0]} elements")
    Gc_h = horizontal_band_field(
        centroids_gc,
        torch.tensor(DEFAULT_X0, dtype=dtype, device=device),
        torch.tensor(DEFAULT_SIGMA, dtype=dtype, device=device),
        torch.tensor(DEFAULT_WEAK_FRACTION, dtype=dtype, device=device),
    )
    print(f"  Gc range [{Gc_h.min():.4e}, {Gc_h.max():.4e}] N/mm "
          f"(weak band at x = {DEFAULT_X0}, sigma = {DEFAULT_SIGMA})")

    nodes_gc = mesh_gc.nodes.cpu().numpy()
    tris_gc  = elements_gc.cpu().numpy()

    # --- Plot ---
    print("\n[3/3] Plotting truth fields...")
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    tri_inc = Triangulation(nodes_inc[:, 0], nodes_inc[:, 1], tris_inc)
    for ax, E_field, label, truth_pts in zip(
            axes[:2],
            [E_1p, E_3p],
            ['1-particle truth', '3-particle truth (2 above + 1 below)'],
            [truth_1p, truth_3p]):
        im = ax.tripcolor(tri_inc, facecolors=E_field.cpu().numpy(),
                           cmap='inferno', shading='flat')
        # Mark crack axis and 6sigma band
        ax.axhline(8.0, color='cyan', lw=1.2, ls='-', alpha=0.7,
                    label='unperturbed crack axis (y=8)')
        ax.axhline(8.0 + 6 * SIGMA_INC, color='cyan', lw=0.8, ls='--',
                    alpha=0.5, label=f'+/-6 sigma = {6*SIGMA_INC:.1f} mm')
        ax.axhline(8.0 - 6 * SIGMA_INC, color='cyan', lw=0.8, ls='--',
                    alpha=0.5)
        # Mark notch tip and inclusion centres
        ax.plot([4.0], [8.0], 'w*', ms=14, mec='k', mew=0.8,
                  label='notch tip (4, 8)')
        for i, pt in enumerate(truth_pts.cpu().numpy()):
            ax.plot([pt[0]], [pt[1]], 'wo', ms=10, mec='k', mew=0.8)
            ax.annotate(f'{i+1}', xy=pt, xytext=(pt[0]+0.4, pt[1]+0.4),
                          color='white', fontsize=10, fontweight='bold')
        ax.set_xlim(0, 32)
        ax.set_ylim(0, 16)
        ax.set_aspect('equal')
        ax.set_title(label)
        ax.set_xlabel('x [mm]')
        ax.set_ylabel('y [mm]')
        plt.colorbar(im, ax=ax, label='E [MPa]', shrink=0.7)
        if label.startswith('1-'):
            ax.legend(loc='upper right', fontsize=7, framealpha=0.9)

    tri_gc = Triangulation(nodes_gc[:, 0], nodes_gc[:, 1], tris_gc)
    ax = axes[2]
    im = ax.tripcolor(tri_gc, facecolors=Gc_h.cpu().numpy(),
                       cmap='viridis_r', shading='flat')
    ax.axhline(1.0, color='red', lw=1.2, ls='-', alpha=0.7,
                label='unperturbed crack axis (y=1)')
    ax.axvline(DEFAULT_X0, color='red', lw=0.8, ls='--', alpha=0.5,
                label=f'weak band x0={DEFAULT_X0}')
    ax.plot([1.0], [1.0], 'w*', ms=14, mec='k', mew=0.8,
              label='notch tip (1, 1)')
    ax.set_xlim(0, 4)
    ax.set_ylim(0, 2)
    ax.set_aspect('equal')
    ax.set_title('Horizontal Gc(x) truth (vertical weak band)')
    ax.set_xlabel('x [mm]')
    ax.set_ylabel('y [mm]')
    plt.colorbar(im, ax=ax, label='Gc [N/mm]', shrink=0.7)
    ax.legend(loc='upper right', fontsize=7, framealpha=0.9)

    fig.suptitle('Truth material fields (no dynamics yet)', fontsize=14)
    fig.tight_layout()
    out_dir = os.path.join(
        REPO_ROOT, 'examples', 'inverse_problems', 'diagnostics')
    os.makedirs(out_dir, exist_ok=True)
    out_png = os.path.join(out_dir, 'precheck_truth_fields.png')
    fig.savefig(out_png, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f"\nSaved: {out_png}")


if __name__ == '__main__':
    main()
