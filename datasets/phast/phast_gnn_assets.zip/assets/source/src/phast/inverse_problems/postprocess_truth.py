#!/usr/bin/env python
"""Post-process a forward-only truth.npz / damage_truth.npz.

Extracts:
  - Hard tip x = max(node_x | d > threshold)  (honest tip position)
  - Crack path  = damage-weighted centerline y(x) on a uniform x-grid
                  (the candidate observation operator for task #47)
  - If snapshots present, also computes hard-tip and path per snapshot
    so a load-displacement-equivalent timeline can be produced (task #48
    requires reaction forces which are not in the npz; placeholder).

Saves a 4-panel PNG: truth field, final damage with overlaid crack path,
hard-tip-x evolution (if snapshots), and the extracted y(x) path.

Usage:
    python postprocess_truth.py <results_dir> [--threshold 0.5] [--n_bins 80]
"""
from __future__ import annotations
import argparse
import os
import sys

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.tri import Triangulation


def hard_tip_x(d_node, x_node, threshold=0.5):
    """Rightmost x where d > threshold; -inf if no node qualifies."""
    mask = d_node > threshold
    return float(x_node[mask].max()) if mask.any() else float('-inf')


def crack_path(d_node, x_node, y_node, n_bins=80, threshold=0.05, p=4):
    """Damage-weighted centerline y(x_bin) for visualisation / inversion.

    For each x-bin in [x_min, hard_tip_x], compute the d^p-weighted
    average y over nodes with d > threshold falling into the bin.
    Returns (x_bin_centres, y_centerline) with NaN in bins that have
    no damaged node.
    """
    x_lo, x_hi = float(x_node.min()), hard_tip_x(d_node, x_node, threshold)
    if not np.isfinite(x_hi):
        return np.array([]), np.array([])
    edges = np.linspace(x_lo, x_hi, n_bins + 1)
    centres = 0.5 * (edges[:-1] + edges[1:])
    y_path = np.full(n_bins, np.nan)
    bin_idx = np.digitize(x_node, edges) - 1
    for b in range(n_bins):
        sel = (bin_idx == b) & (d_node > threshold)
        if sel.any():
            w = d_node[sel] ** p
            y_path[b] = float((w * y_node[sel]).sum() / w.sum())
    return centres, y_path


def main():
    p = argparse.ArgumentParser()
    p.add_argument('input_dir')
    p.add_argument('--threshold', type=float, default=0.5)
    p.add_argument('--n_bins', type=int, default=80)
    p.add_argument('--out', default=None)
    args = p.parse_args()

    cands = ['damage_truth.npz', 'truth.npz']
    src = None
    for c in cands:
        path = os.path.join(args.input_dir, c)
        if os.path.exists(path):
            src = path
            break
    if src is None:
        sys.exit(f"No {cands} in {args.input_dir}")

    z = np.load(src, allow_pickle=True)
    nodes    = z['nodes']
    elements = z['elements']
    d_final  = z['d_target']
    x_node   = nodes[:, 0]
    y_node   = nodes[:, 1]

    if 'E_truth' in z.files:
        field = z['E_truth']
        field_label = 'E [MPa]'
        field_cmap = 'inferno'
        kind = 'inclusion'
        truth_pts = z['truth_pts'] if 'truth_pts' in z.files else None
    else:
        field = z['Gc_true']
        field_label = 'Gc [N/mm]'
        field_cmap = 'viridis_r'
        kind = 'gc'
        truth_pts = None
        x0_truth   = float(z['x0_truth'])    if 'x0_truth'    in z.files else None
        sigma_t    = float(z['sigma_truth']) if 'sigma_truth' in z.files else None

    # Hard-tip + crack path on the FINAL damage field.
    final_tip = hard_tip_x(d_final, x_node, args.threshold)
    x_bins, y_path = crack_path(d_final, x_node, y_node,
                                  n_bins=args.n_bins,
                                  threshold=max(0.05, args.threshold * 0.1),
                                  p=4)

    # Per-snapshot tip evolution if snapshots are present.
    has_snaps = 'snapshots' in z.files and 'snapshot_steps' in z.files
    if has_snaps:
        snaps = z['snapshots']           # (n_snaps, n_nodes)
        snap_steps = z['snapshot_steps']
        dt_s = float(z['dt']) if 'dt' in z.files else 1.0
        t_us = snap_steps * dt_s * 1e6
        snap_tip_hard = np.array([hard_tip_x(s, x_node, args.threshold)
                                    for s in snaps])
        snap_tip_soft = z['tip_x_truth'] if 'tip_x_truth' in z.files else None
    else:
        snaps = None
        t_us = None
        snap_tip_hard = None
        snap_tip_soft = None

    # ----- Diagnostic print -----
    print("=" * 60)
    print(f"  {os.path.basename(args.input_dir)} — {kind}")
    print("=" * 60)
    print(f"  Final max(d)  = {d_final.max():.3f}")
    print(f"  #d > 0.5      = {(d_final > 0.5).sum()}")
    print(f"  #d > 0.9      = {(d_final > 0.9).sum()}")
    print(f"  Hard tip x    = {final_tip:.3f} mm  (rightmost d>{args.threshold})")
    print(f"  Crack path    = {np.isfinite(y_path).sum()}/{args.n_bins} bins populated")
    if truth_pts is not None:
        for i, pt in enumerate(truth_pts):
            print(f"  Truth particle {i+1}: ({pt[0]:.2f}, {pt[1]:.2f})  "
                  f"-> {'reached' if final_tip > pt[0] else 'NOT reached'}")
    elif kind == 'gc' and x0_truth is not None:
        print(f"  Truth band x0 = {x0_truth:.2f} mm, sigma = {sigma_t:.2f} mm  "
              f"-> {'crack crossed band' if final_tip > x0_truth else 'crack stopped before band'}")
    if has_snaps:
        print(f"  Snapshots     = {len(snaps)} times "
              f"({t_us[0]:.1f} ... {t_us[-1]:.1f} us)")
        print(f"  Hard tip x trajectory:")
        print(f"    " + ", ".join(f"{t:.2f}" for t in snap_tip_hard))

    # ----- Plot -----
    tri = Triangulation(nodes[:, 0], nodes[:, 1], elements)
    fig, axes = plt.subplots(2, 2, figsize=(14, 7))

    # (a) Truth field
    ax = axes[0, 0]
    im = ax.tripcolor(tri, facecolors=field, cmap=field_cmap, shading='flat')
    plt.colorbar(im, ax=ax, label=field_label, shrink=0.8)
    if truth_pts is not None:
        for i, pt in enumerate(truth_pts):
            ax.plot([pt[0]], [pt[1]], 'wo', ms=8, mec='k', mew=0.6)
            ax.annotate(f'{i+1}', xy=pt, xytext=(pt[0]+0.4, pt[1]+0.4),
                          color='w', fontsize=9, fontweight='bold')
    elif kind == 'gc' and x0_truth is not None:
        ax.axvline(x0_truth, color='r', ls='--', lw=0.8, alpha=0.6,
                    label=f'truth x0={x0_truth:.1f}')
        ax.legend(loc='upper right', fontsize=7)
    ax.set_aspect('equal')
    ax.set_title(f'(a) Truth {field_label.split()[0]} field')
    ax.set_xlabel('x [mm]')
    ax.set_ylabel('y [mm]')

    # (b) Final damage with crack path overlay
    ax = axes[0, 1]
    im = ax.tripcolor(tri, d_final, cmap='inferno', shading='gouraud',
                       vmin=0, vmax=1)
    plt.colorbar(im, ax=ax, label='d', shrink=0.8)
    if np.isfinite(y_path).any():
        valid = np.isfinite(y_path)
        ax.plot(x_bins[valid], y_path[valid], 'c-', lw=2, alpha=0.8,
                  label='extracted crack path')
        ax.legend(loc='upper right', fontsize=7)
    ax.axvline(final_tip, color='lime', lw=0.8, ls='--', alpha=0.7,
                label=f'hard tip x={final_tip:.2f}')
    if truth_pts is not None:
        for pt in truth_pts:
            ax.plot([pt[0]], [pt[1]], 'co', ms=7, mec='k', mew=0.6, alpha=0.6)
    ax.set_aspect('equal')
    ax.set_title(f'(b) Final damage  (hard tip x = {final_tip:.2f} mm)')
    ax.set_xlabel('x [mm]')
    ax.set_ylabel('y [mm]')

    # (c) Crack path y(x) zoomed on the crack zone
    ax = axes[1, 0]
    if np.isfinite(y_path).any():
        valid = np.isfinite(y_path)
        ax.plot(x_bins[valid], y_path[valid], 'b-o', ms=3, lw=1.2,
                  label='extracted y(x)')
        # Reference unperturbed crack axis (notch height)
        if 'H' in z.files:
            ax.axhline(float(z['H']) / 2, color='k', ls=':', lw=0.8,
                        alpha=0.5, label=f'unperturbed y = {float(z["H"])/2:.1f}')
        if truth_pts is not None:
            for i, pt in enumerate(truth_pts):
                ax.plot([pt[0]], [pt[1]], 'ro', ms=10, mec='k', mew=0.5,
                          label='inclusion centre' if i == 0 else None)
        ax.legend(loc='best', fontsize=8)
        ax.grid(alpha=0.3)
    ax.set_title('(c) Crack path y(x) — candidate inverse observable')
    ax.set_xlabel('x [mm]')
    ax.set_ylabel('y [mm] of crack centerline')

    # (d) Hard-tip evolution
    ax = axes[1, 1]
    if has_snaps:
        ax.plot(t_us, snap_tip_hard, 'r-o', ms=4, lw=1.2,
                  label='hard tip (rightmost d>0.5)')
        if snap_tip_soft is not None:
            ax.plot(t_us, snap_tip_soft, 'b--s', ms=4, lw=1.0,
                      label='soft tip (d-weighted)')
        if truth_pts is not None:
            for i, pt in enumerate(truth_pts):
                ax.axhline(pt[0], color='gray', ls=':', lw=0.8, alpha=0.6,
                            label=f'particle {i+1} x={pt[0]:.1f}'
                                    if i == 0 else None)
        ax.legend(loc='lower right', fontsize=7)
        ax.grid(alpha=0.3)
        ax.set_xlabel('t [us]')
        ax.set_ylabel('crack tip x [mm]')
        ax.set_title('(d) Tip-x trajectory (hard vs soft)')
    else:
        ax.text(0.5, 0.5, 'No snapshots available\n(only final damage saved)',
                  ha='center', va='center', fontsize=12,
                  transform=ax.transAxes)
        ax.set_title('(d) Tip-x trajectory — N/A')

    fig.suptitle(f'{kind} truth post-processing: '
                  f'{os.path.basename(args.input_dir)}', fontsize=12)
    fig.tight_layout()

    out = args.out or os.path.join(args.input_dir, 'postprocess_truth.png')
    fig.savefig(out, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f"\nSaved: {out}")


if __name__ == '__main__':
    main()
