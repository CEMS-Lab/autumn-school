#!/usr/bin/env python
"""Quasistatic scalar Gc calibration from reaction and sparse DIC data.

This demo is intentionally small and staged. It manufactures a synthetic
Miehe-SENT quasistatic experiment, observes the top reaction force and sparse
interior displacements over the informative crack-initiation window, and
recovers a scalar fracture toughness with L-BFGS. The purpose is to show the
implicit/quasistatic counterpart of the dynamic inverse demos: gradients flow
through the quasistatic equilibrium solve and the implicit damage solve.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.tri as mtri  # noqa: E402

from phast.boundary_conditions import BoundaryConditions
from phast.device import DeviceContext
from phast.material import create_material
from phast.mesh import FEMMesh
from phast.mesh_generator import miehe_tension
from phast.staggered_solver import SolverConfig, StaggeredSolver


@dataclass
class QSGcConfig:
    l0: float = 0.06
    h_crack: float = 0.06
    h_coarse: float = 0.18
    true_Gc: float = 2.7
    init_Gc: float = 3.4
    displacements: tuple[float, ...] = (0.002, 0.004, 0.006, 0.008)
    energy_split: str = "isotropic"
    pf_model: str = "AT2"
    backend: str = "scipy"
    stagger_tol: float = 1.0e-6
    max_stagger: int = 80
    damage_tol: float = 1.0e-8
    static_tol: float = 1.0e-9
    dic_stride: int = 20


@dataclass
class QSRollout:
    reactions: torch.Tensor
    dic: torch.Tensor
    d_final: torch.Tensor
    u_final: torch.Tensor
    max_damage: torch.Tensor
    mean_damage: torch.Tensor


def build_mesh(output_dir: Path, cfg: QSGcConfig, *, verbose: bool = False) -> FEMMesh:
    output_dir.mkdir(parents=True, exist_ok=True)
    mesh_path = output_dir / "mesh.msh"
    miehe_tension(
        str(mesh_path),
        L=1.0,
        a=0.5,
        l0=cfg.l0,
        h_crack=cfg.h_crack,
        h_coarse=cfg.h_coarse,
        verbose=verbose,
    )
    mesh = FEMMesh(str(mesh_path), device="cpu", dtype=torch.float64)
    mesh.identify_boundaries()
    return mesh


def make_solver(mesh: FEMMesh, cfg: QSGcConfig) -> StaggeredSolver:
    material = create_material(
        "miehe_tension",
        l0=cfg.l0,
        pf_model=cfg.pf_model,
        energy_split=cfg.energy_split,
        gamma_correction=True,
    )
    bcs = BoundaryConditions(mesh.n_nodes, mesh.device, mesh.dtype)
    bcs.fix(mesh.node_sets["bottom"], 0)
    bcs.fix(mesh.node_sets["bottom"], 1)
    bcs.add(mesh.node_sets["top"], 1, 1.0)
    solver_cfg = SolverConfig(
        solver_type="quasi_static",
        differentiable=True,
        damage_tol=cfg.damage_tol,
        static_tol=cfg.static_tol,
        stagger_tol=cfg.stagger_tol,
        max_stagger=cfg.max_stagger,
        preconditioner="jacobi",
        use_multigrid=False,
        backend=cfg.backend,
    )
    return StaggeredSolver(
        mesh,
        material,
        bcs,
        config=solver_cfg,
        ctx=DeviceContext("cpu", torch.float64),
    )


def dic_node_indices(mesh: FEMMesh, stride: int) -> torch.Tensor:
    stride = max(1, int(stride))
    nodes = mesh.nodes
    interior = torch.where(
        (nodes[:, 0] > 0.05)
        & (nodes[:, 0] < 0.95)
        & (nodes[:, 1] > 0.05)
        & (nodes[:, 1] < 0.95)
    )[0]
    if interior.numel() == 0:
        interior = torch.arange(mesh.n_nodes, dtype=torch.long)
    return interior[::stride].long()


def rollout(mesh: FEMMesh, cfg: QSGcConfig, Gc: torch.Tensor) -> QSRollout:
    solver = make_solver(mesh, cfg)
    solver.diff_Gc = Gc
    top = mesh.node_sets["top"]
    dic_idx = dic_node_indices(mesh, cfg.dic_stride)
    reactions = []
    dic_samples = []

    for disp in cfg.displacements:
        solver.bcs.load_factor = float(disp)
        solver.step_full()
        fint = solver.fem.internal_force(solver.u, solver.d)
        reactions.append(fint[top, 1].sum())
        dic_samples.append(solver.u[dic_idx].reshape(-1))

    return QSRollout(
        reactions=torch.stack(reactions),
        dic=torch.cat(dic_samples),
        d_final=solver.d,
        u_final=solver.u,
        max_damage=solver.d.max(),
        mean_damage=solver.d.mean(),
    )


def inverse_loss(pred: QSRollout, target: QSRollout) -> torch.Tensor:
    r_scale = target.reactions.detach().abs().max().clamp(min=1.0)
    u_scale = target.dic.detach().abs().max().clamp(min=1.0e-12)
    reaction = ((pred.reactions - target.reactions.detach()) / r_scale).pow(2).mean()
    dic = ((pred.dic - target.dic.detach()) / u_scale).pow(2).mean()
    damage = (pred.d_final - target.d_final.detach()).pow(2).mean()
    return reaction + 0.10 * dic + 0.02 * damage


def autograd_gradient(mesh: FEMMesh, cfg: QSGcConfig, target: QSRollout, gc_value: float) -> tuple[float, float]:
    log_gc = torch.tensor(math.log(gc_value), dtype=torch.float64, requires_grad=True)
    pred = rollout(mesh, cfg, torch.exp(log_gc))
    loss = inverse_loss(pred, target)
    loss.backward()
    return float(loss.detach()), float(log_gc.grad.detach())


def fd_gradient(mesh: FEMMesh, cfg: QSGcConfig, target: QSRollout, gc_value: float, eps: float = 1.0e-4) -> float:
    lp = math.log(gc_value) + eps
    lm = math.log(gc_value) - eps
    # Use the same differentiable scalar-Gc code path as the inverse closure.
    # The forward-only scalar override intentionally bypasses adjoint storage,
    # but gamma-corrected scalar runs are compared most honestly on the exact
    # path the optimizer uses.
    loss_p = inverse_loss(
        rollout(mesh, cfg, torch.tensor(math.exp(lp), dtype=torch.float64, requires_grad=True)),
        target,
    )
    loss_m = inverse_loss(
        rollout(mesh, cfg, torch.tensor(math.exp(lm), dtype=torch.float64, requires_grad=True)),
        target,
    )
    return float(((loss_p - loss_m) / (2.0 * eps)).detach())


def run_inverse(mesh: FEMMesh, cfg: QSGcConfig, *, max_iter: int = 6) -> dict:
    target = rollout(
        mesh, cfg,
        torch.tensor(cfg.true_Gc, dtype=torch.float64, requires_grad=True),
    )
    initial = rollout(
        mesh, cfg,
        torch.tensor(cfg.init_Gc, dtype=torch.float64, requires_grad=True),
    )

    log_gc = torch.tensor(math.log(cfg.init_Gc), dtype=torch.float64, requires_grad=True)
    opt = torch.optim.LBFGS([log_gc], lr=0.7, max_iter=max_iter, line_search_fn="strong_wolfe")
    history: list[dict[str, float]] = []

    def closure() -> torch.Tensor:
        opt.zero_grad()
        pred = rollout(mesh, cfg, torch.exp(log_gc))
        loss = inverse_loss(pred, target)
        loss.backward()
        history.append(
            {
                "Gc": float(torch.exp(log_gc).detach()),
                "loss": float(loss.detach()),
                "grad_log_Gc": float(log_gc.grad.detach()),
            }
        )
        return loss

    opt.step(closure)
    recovered_gc = float(torch.exp(log_gc.detach()))
    recovered = rollout(
        mesh, cfg,
        torch.tensor(recovered_gc, dtype=torch.float64, requires_grad=True),
    )
    grad_loss, grad_ad = autograd_gradient(mesh, cfg, target, cfg.init_Gc)
    grad_fd = fd_gradient(mesh, cfg, target, cfg.init_Gc)
    grad_rel = abs(grad_ad - grad_fd) / max(abs(grad_fd), 1.0e-30)
    return {
        "target": target,
        "initial": initial,
        "recovered": recovered,
        "history": history,
        "true_Gc": cfg.true_Gc,
        "init_Gc": cfg.init_Gc,
        "recovered_Gc": recovered_gc,
        "relative_error": abs(recovered_gc - cfg.true_Gc) / cfg.true_Gc,
        "gradcheck_loss": grad_loss,
        "grad_autograd": grad_ad,
        "grad_fd": grad_fd,
        "grad_rel_error": grad_rel,
    }


def _np(t: torch.Tensor) -> np.ndarray:
    return t.detach().cpu().numpy()


def save_figure(mesh: FEMMesh, cfg: QSGcConfig, result: dict, out_dir: Path) -> dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    nodes = _np(mesh.nodes)
    elems = _np(mesh.elements)
    tri = mtri.Triangulation(nodes[:, 0], nodes[:, 1], elems)

    target: QSRollout = result["target"]
    initial: QSRollout = result["initial"]
    recovered: QSRollout = result["recovered"]
    history = result["history"]
    disps = np.asarray(cfg.displacements)

    fig, ax = plt.subplots(2, 3, figsize=(13.2, 7.6), constrained_layout=True)
    target_damage = _np(target.d_final)
    tcf = ax[0, 0].tricontourf(tri, target_damage, levels=64, cmap="inferno", vmin=0.0, vmax=1.0)
    ax[0, 0].set_title(f"target crack context, max d={target_damage.max():.3f}")
    fig.colorbar(tcf, ax=ax[0, 0], shrink=0.72, label="damage d")

    init_u_err = np.linalg.norm(_np(initial.u_final - target.u_final), axis=1)
    rec_u_err = np.linalg.norm(_np(recovered.u_final - target.u_final), axis=1)
    err_max = max(float(init_u_err.max()), float(rec_u_err.max()), 1.0e-15)
    dic_idx = _np(dic_node_indices(mesh, cfg.dic_stride))
    error_panels = [
        ("initial displacement error", init_u_err),
        ("recovered displacement error", rec_u_err),
    ]
    for axis, (label, values) in zip(ax[0, 1:], error_panels):
        tcf = axis.tricontourf(tri, values, levels=64, cmap="magma", vmin=0.0, vmax=err_max)
        axis.scatter(nodes[dic_idx, 0], nodes[dic_idx, 1], s=4, c="white", alpha=0.5, linewidths=0.0)
        axis.set_title(f"{label}, max={values.max():.2e} mm")
        fig.colorbar(tcf, ax=axis, shrink=0.72, label="|u - target| (mm)")

    for axis in ax[0]:
        axis.set_aspect("equal")
        axis.set_xlabel("x (mm)")
        axis.set_ylabel("y (mm)")

    ax[1, 0].plot(disps, _np(target.reactions), "o-", label="target")
    ax[1, 0].plot(disps, _np(initial.reactions), "s--", label="initial")
    ax[1, 0].plot(disps, _np(recovered.reactions), "^-.", label="recovered")
    ax[1, 0].set_xlabel("applied displacement (mm)")
    ax[1, 0].set_ylabel("top reaction (N)")
    ax[1, 0].set_title("reaction observable")
    ax[1, 0].grid(alpha=0.3)
    ax[1, 0].legend()

    ax[1, 1].semilogy([h["loss"] for h in history], "o-", color="#c43c39")
    ax[1, 1].set_xlabel("closure evaluation")
    ax[1, 1].set_ylabel("loss")
    ax[1, 1].set_title("L-BFGS convergence")
    ax[1, 1].grid(alpha=0.3)

    ax[1, 2].plot([h["Gc"] for h in history], "o-", label="estimate")
    ax[1, 2].axhline(cfg.true_Gc, color="k", linestyle="--", linewidth=1.0, label="truth")
    ax[1, 2].set_xlabel("closure evaluation")
    ax[1, 2].set_ylabel(r"$G_c$ (N/mm)")
    ax[1, 2].set_title(
        f"recovered {result['recovered_Gc']:.4g}, error {100.0 * result['relative_error']:.2f}%"
    )
    ax[1, 2].grid(alpha=0.3)
    ax[1, 2].legend()

    fig.suptitle("Implicit quasistatic scalar Gc calibration from reaction + sparse DIC", fontsize=13)
    png = out_dir / "qs_gc_calibration.png"
    pdf = out_dir / "qs_gc_calibration.pdf"
    fig.savefig(png, dpi=180)
    fig.savefig(pdf)
    plt.close(fig)
    return {"png": str(png), "pdf": str(pdf)}


def save_summary(cfg: QSGcConfig, result: dict, figures: dict[str, str], out_dir: Path) -> Path:
    data = {
        "config": {
            "l0": cfg.l0,
            "h_crack": cfg.h_crack,
            "h_coarse": cfg.h_coarse,
            "displacements": list(cfg.displacements),
            "energy_split": cfg.energy_split,
            "pf_model": cfg.pf_model,
            "backend": cfg.backend,
        },
        "true_Gc": result["true_Gc"],
        "init_Gc": result["init_Gc"],
        "recovered_Gc": result["recovered_Gc"],
        "relative_error": result["relative_error"],
        "gradcheck": {
            "loss_at_init": result["gradcheck_loss"],
            "autograd_dloss_dlogGc": result["grad_autograd"],
            "fd_dloss_dlogGc": result["grad_fd"],
            "relative_error": result["grad_rel_error"],
        },
        "history": result["history"],
        "figures": figures,
    }
    path = out_dir / "summary.json"
    path.write_text(json.dumps(data, indent=2) + "\n")
    return path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=Path("examples/inverse_problems/qs_gc_calibration/run1/results"))
    parser.add_argument("--paper-figure-dir", type=Path, default=None)
    parser.add_argument("--h-crack", type=float, default=QSGcConfig.h_crack)
    parser.add_argument("--h-coarse", type=float, default=QSGcConfig.h_coarse)
    parser.add_argument("--l0", type=float, default=QSGcConfig.l0)
    parser.add_argument("--true-Gc", type=float, default=QSGcConfig.true_Gc)
    parser.add_argument("--init-Gc", type=float, default=QSGcConfig.init_Gc)
    parser.add_argument("--displacements", type=float, nargs="+", default=list(QSGcConfig.displacements))
    parser.add_argument("--max-iter", type=int, default=6)
    parser.add_argument("--max-stagger", type=int, default=QSGcConfig.max_stagger)
    parser.add_argument("--dic-stride", type=int, default=QSGcConfig.dic_stride)
    parser.add_argument("--backend", choices=["auto", "scipy", "mumps", "cg"], default=QSGcConfig.backend)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cfg = QSGcConfig(
        l0=args.l0,
        h_crack=args.h_crack,
        h_coarse=args.h_coarse,
        true_Gc=args.true_Gc,
        init_Gc=args.init_Gc,
        displacements=tuple(float(v) for v in args.displacements),
        backend=args.backend,
        max_stagger=args.max_stagger,
        dic_stride=args.dic_stride,
    )
    args.out_dir.mkdir(parents=True, exist_ok=True)
    mesh_dir = args.out_dir / "mesh"
    mesh = build_mesh(mesh_dir, cfg, verbose=True)
    result = run_inverse(mesh, cfg, max_iter=args.max_iter)
    figures = save_figure(mesh, cfg, result, args.out_dir)
    summary = save_summary(cfg, result, figures, args.out_dir)

    if args.paper_figure_dir is not None:
        args.paper_figure_dir.mkdir(parents=True, exist_ok=True)
        for src_name in ("qs_gc_calibration.png", "qs_gc_calibration.pdf", "summary.json"):
            src = args.out_dir / src_name
            if src.exists():
                (args.paper_figure_dir / src_name).write_bytes(src.read_bytes())

    print(json.dumps({
        "summary": str(summary),
        "recovered_Gc": result["recovered_Gc"],
        "relative_error": result["relative_error"],
        "grad_rel_error": result["grad_rel_error"],
        "figures": figures,
    }, indent=2))


if __name__ == "__main__":
    main()
