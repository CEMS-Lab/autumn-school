"""core subpackage."""
