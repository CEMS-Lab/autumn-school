"""
Adaptive Mesh Refinement (AMR) via Newest Vertex Bisection (NVB).

Provides element-level refinement indicators, conforming mesh bisection,
and field interpolation routines for phase-field fracture simulations.

Algorithm overview
------------------
Newest Vertex Bisection is the standard AMR strategy for triangular meshes.
Each triangle is bisected by inserting a node at the midpoint of its
*refinement edge* (chosen as the longest edge). Conforming closure ensures
that every newly bisected edge is shared by two refined triangles, so
the resulting mesh has no hanging nodes.

Typical usage::

    from phast.adaptive import (
        compute_refinement_indicator, refine_mesh,
        interpolate_field, interpolate_elem_field,
    )

    marked = compute_refinement_indicator(mesh, d)
    if marked.any():
        new_mesh, parent_map, child_map = refine_mesh(mesh, marked)
        d = interpolate_field(old_mesh, new_mesh, d, parent_map)
        H = interpolate_elem_field(old_mesh, new_mesh, H, child_map)
        mesh = new_mesh

References
----------
- Mitchell, W.F. (1989). A comparison of adaptive refinement techniques
  for elliptic problems. *ACM TOMS* 15(4), 326-347.
- Bartels, S. (2015). *Numerical Methods for Nonlinear PDEs*. Springer.
  Chapter 4: Adaptive finite element methods.
"""

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch

try:  # top-level module layout (matches sibling modules)
    from mesh import FEMMesh
except ImportError:  # fallback when imported as part of a package
    from ..core.mesh import FEMMesh


@dataclass(frozen=True)
class RefinementOptions:
    """Controls AMR transaction behavior without changing legacy defaults."""

    max_refine_fraction: Optional[float] = None
    max_new_elements: Optional[int] = None
    min_h: Optional[float] = None
    validate_topology: bool = True
    include_quality_summary: bool = False


@dataclass(frozen=True)
class AMRStepReport:
    """Compact audit record for one refinement transaction."""

    old_nodes: int
    old_elements: int
    new_nodes: int
    new_elements: int
    requested_elements: Tuple[int, ...]
    refined_elements: Tuple[int, ...]
    closure_forced_elements: Tuple[int, ...]
    new_midpoint_nodes: Tuple[int, ...]
    min_h_before: float
    min_h_after: float
    area_before: float
    area_after: float
    topology_validated: bool
    validation_errors: Tuple[str, ...] = ()


@dataclass(frozen=True)
class RefinementResult:
    """Audited AMR result. Use ``as_legacy_tuple`` for old callers."""

    mesh: FEMMesh
    parent_map: Dict[int, Tuple[int, int]]
    child_map: Dict[int, int]
    report: AMRStepReport

    def as_legacy_tuple(self):
        return self.mesh, self.parent_map, self.child_map


# -------------------------------------------------------------------- #
# 1. Composable refinement criteria (Galvis-style)
# -------------------------------------------------------------------- #
#
# These criterion helpers (originally landed in ``mesh_adaptivity.py``,
# #111 scaffold) return *which* elements to refine as element-ID lists.
# They are integrated here to live alongside the newest-vertex-bisection
# pipeline that consumes a boolean mask.
#
# Reference
# ---------
# Galvis et al. 2026 (Eng Fract Mech): FreeFEM++ ``adaptmesh()`` on the
# damage-gradient indicator with relative tol 0.04 and max-vertex cap.

def damage_gradient_criterion(
    d_field: torch.Tensor,
    mesh: 'FEMMesh',
    threshold: float = 0.1,
) -> List[int]:
    """Flag elements where the damage-gradient magnitude exceeds ``threshold``.

    Element-level gradient is the standard P1 reconstruction
    ``grad_d_e = sum_j grad_phi_j * d_j`` over the three vertices.

    Parameters
    ----------
    d_field : torch.Tensor, shape (N,)
        Nodal damage in [0, 1].
    mesh : FEMMesh
        Must expose ``elements`` (E, 3) and ``grad_phi`` (E, 3, 2).
    threshold : float
        Gradient-magnitude threshold (units: 1/length).

    Returns
    -------
    list of int
        Element indices satisfying ``||grad d|| > threshold``.
    """
    elems = mesh.elements
    d_elem = d_field[elems]
    if getattr(mesh, 'element_type', 'T3') == 'Q4':
        gx_q = torch.einsum('eqa,ea->eq', mesh.quad_grad_phi[..., 0], d_elem)
        gy_q = torch.einsum('eqa,ea->eq', mesh.quad_grad_phi[..., 1], d_elem)
        grad_mag = torch.sqrt(gx_q * gx_q + gy_q * gy_q).max(dim=1).values
    else:
        gx = (mesh.grad_phi[:, :, 0] * d_elem).sum(dim=1)      # (E,)
        gy = (mesh.grad_phi[:, :, 1] * d_elem).sum(dim=1)      # (E,)
        grad_mag = torch.sqrt(gx * gx + gy * gy)
    flagged = torch.where(grad_mag > threshold)[0]
    return flagged.cpu().tolist()


def crack_tip_neighborhood_criterion(
    d_field: torch.Tensor,
    mesh: 'FEMMesh',
    radius: float = 3.0,
    d_tip_threshold: float = 0.5,
) -> List[int]:
    """Flag elements within ``radius * h_min`` of any cracked element.

    A "cracked" element is one whose maximum nodal damage exceeds
    ``d_tip_threshold``. Every element whose centroid lies within
    ``radius * mesh.h_min`` of any cracked-element centroid is flagged
    (cracked elements themselves included).

    Parameters
    ----------
    d_field : torch.Tensor, shape (N,)
        Nodal damage in [0, 1].
    mesh : FEMMesh
        Must expose ``nodes``, ``elements``, ``h_min``.
    radius : float
        Neighbourhood radius in units of ``h_min``.
    d_tip_threshold : float
        Damage value above which an element is treated as cracked.

    Returns
    -------
    list of int
        Element indices within the crack-tip neighbourhood.
    """
    elems = mesh.elements
    nodes = mesh.nodes
    centroids = nodes[elems].mean(dim=1)                   # (E, 2)

    d_elem = d_field[elems]                                # (E, 3)
    is_cracked = d_elem.max(dim=1).values > d_tip_threshold
    if not bool(is_cracked.any()):
        return []

    tip_centroids = centroids[is_cracked]                  # (T, 2)

    # Pairwise distances (E, T); fine for scaffold-scale tests, the
    # production driver should use a kd-tree or chunked computation.
    diff = centroids.unsqueeze(1) - tip_centroids.unsqueeze(0)
    dist = torch.linalg.norm(diff, dim=2)                  # (E, T)
    min_dist = dist.min(dim=1).values                      # (E,)

    cutoff = radius * float(mesh.h_min)
    flagged = torch.where(min_dist <= cutoff)[0]
    return flagged.cpu().tolist()


def union_refine_set(criteria_results: Iterable[Sequence[int]]) -> List[int]:
    """Union of element-ID lists from multiple criteria.

    Parameters
    ----------
    criteria_results : iterable of int sequences
        Output of one or more criterion functions.

    Returns
    -------
    list of int
        Sorted unique element IDs.
    """
    merged: set = set()
    for r in criteria_results:
        merged.update(int(i) for i in r)
    return sorted(merged)


def mark_top_fraction(
    scores: torch.Tensor,
    *,
    fraction: float,
    min_score: float = 0.0,
) -> torch.Tensor:
    """Mark the highest-scoring elements above ``min_score``."""
    if scores.ndim != 1:
        raise ValueError(f"scores must be 1D, got shape {tuple(scores.shape)}")
    if not (0.0 < float(fraction) <= 1.0):
        raise ValueError("fraction must satisfy 0 < fraction <= 1")

    eligible = scores > float(min_score)
    n_eligible = int(eligible.sum().item())
    out = torch.zeros_like(eligible)
    if n_eligible == 0:
        return out

    k = max(1, int(np.ceil(float(fraction) * n_eligible)))
    eligible_idx = torch.where(eligible)[0]
    eligible_scores = scores[eligible_idx]
    order = torch.argsort(eligible_scores, descending=True, stable=True)
    out[eligible_idx[order[:k]]] = True
    return out


def apply_refinement_budget(
    marked: torch.Tensor,
    scores: torch.Tensor,
    *,
    max_marked: Optional[int] = None,
    mesh: Optional[FEMMesh] = None,
    min_h: Optional[float] = None,
) -> torch.Tensor:
    """Apply deterministic caps and absolute length-scale guardrails."""
    if marked.shape != scores.shape:
        raise ValueError(
            f"marked shape {tuple(marked.shape)} does not match scores "
            f"{tuple(scores.shape)}")

    out = marked.clone()
    if mesh is not None and min_h is not None:
        h_elem = torch.sqrt(torch.clamp(mesh.areas, min=0.0))
        out = out & (h_elem > float(min_h))

    if max_marked is not None:
        max_marked = int(max_marked)
        if max_marked < 0:
            raise ValueError("max_marked must be non-negative")
        idx = torch.where(out)[0]
        if len(idx) > max_marked:
            idx_scores = scores[idx]
            order = torch.argsort(idx_scores, descending=True, stable=True)
            keep = idx[order[:max_marked]]
            limited = torch.zeros_like(out)
            limited[keep] = True
            out = limited

    return out


def compute_mechanical_refinement_scores(
    mesh: FEMMesh,
    *,
    psi_plus: torch.Tensor,
    Gc: float,
    l0: float,
    activation_fraction: float = 0.8,
) -> torch.Tensor:
    """Return dimensionless pre-damage scores from tensile energy density.

    Scores greater than one indicate ``psi_plus`` exceeds
    ``activation_fraction * Gc / l0``. This is only a marking heuristic.
    It does not alter the phase-field damage law.
    """
    if psi_plus.ndim != 1 or psi_plus.shape[0] != mesh.n_elems:
        raise ValueError(
            f"psi_plus must have shape ({mesh.n_elems},), got "
            f"{tuple(psi_plus.shape)}")
    if Gc <= 0.0:
        raise ValueError("Gc must be positive")
    if l0 <= 0.0:
        raise ValueError("l0 must be positive")
    if activation_fraction <= 0.0:
        raise ValueError("activation_fraction must be positive")
    threshold = float(activation_fraction) * float(Gc) / float(l0)
    return psi_plus / threshold


# -------------------------------------------------------------------- #
# 2. Refinement indicator (boolean mask consumed by refine_mesh)
# -------------------------------------------------------------------- #

def compute_refinement_indicator(
    mesh: FEMMesh,
    d: torch.Tensor,
    grad_d_threshold: float = 0.3,
    d_threshold: float = 0.5,
    *,
    use_damage: bool = True,
    use_gradient: bool = True,
    use_neighborhood: bool = False,
    neighborhood_radius: float = 3.0,
) -> torch.Tensor:
    """Compose refinement criteria into a boolean mask over elements.

    By default an element is marked for refinement if *either*:
      - The maximum nodal damage among its three vertices exceeds
        ``d_threshold`` (element lies within the crack region), or
      - The magnitude of the element-level damage gradient exceeds
        ``grad_d_threshold`` (element lies at the crack front where
        the damage field transitions rapidly).

    The optional ``use_neighborhood`` flag adds a third criterion that
    flags elements within ``neighborhood_radius * mesh.h_min`` of any
    cracked element (see ``crack_tip_neighborhood_criterion``).

    Parameters
    ----------
    mesh : FEMMesh
        Current mesh (must have ``elements``, ``grad_phi``).
    d : torch.Tensor, shape (N,)
        Nodal damage field, values in [0, 1].
    grad_d_threshold : float
        Gradient magnitude threshold for crack-front marking.
    d_threshold : float
        Maximum nodal damage threshold for crack-body marking.
    use_damage, use_gradient, use_neighborhood : bool
        Toggles for each criterion. The defaults reproduce the legacy
        behaviour (damage OR gradient).
    neighborhood_radius : float
        Radius (in units of ``h_min``) for the optional crack-tip
        neighborhood criterion.

    Returns
    -------
    marked : torch.Tensor, shape (E,), dtype=torch.bool
        True for each element that should be refined.
    """
    E = mesh.elements.shape[0]
    elems = mesh.elements
    d_elem = d[elems]

    marked = torch.zeros(E, dtype=torch.bool, device=d.device)

    # Criterion 1: max nodal damage within element exceeds threshold
    if use_damage:
        max_d_elem = d_elem.max(dim=1).values  # (E,)
        marked = marked | (max_d_elem > d_threshold)

    # Criterion 2: gradient magnitude exceeds threshold
    # Element-level gradient: grad_d_e = sum_j grad_phi_j * d_j
    if use_gradient:
        if getattr(mesh, 'element_type', 'T3') == 'Q4':
            grad_d_x_q = torch.einsum(
                'eqa,ea->eq', mesh.quad_grad_phi[..., 0], d_elem)
            grad_d_y_q = torch.einsum(
                'eqa,ea->eq', mesh.quad_grad_phi[..., 1], d_elem)
            grad_d_mag = torch.sqrt(
                grad_d_x_q ** 2 + grad_d_y_q ** 2).max(dim=1).values
        else:
            grad_d_x = (mesh.grad_phi[:, :, 0] * d_elem).sum(dim=1)  # (E,)
            grad_d_y = (mesh.grad_phi[:, :, 1] * d_elem).sum(dim=1)  # (E,)
            grad_d_mag = torch.sqrt(grad_d_x ** 2 + grad_d_y ** 2)   # (E,)
        marked = marked | (grad_d_mag > grad_d_threshold)

    # Criterion 3 (opt-in): crack-tip neighborhood
    if use_neighborhood:
        flagged = crack_tip_neighborhood_criterion(
            d, mesh, radius=neighborhood_radius,
            d_tip_threshold=d_threshold,
        )
        if flagged:
            idx = torch.tensor(flagged, dtype=torch.long, device=d.device)
            marked[idx] = True

    return marked


def q4_structured_element_indices(
    mesh: FEMMesh,
) -> Tuple[torch.Tensor, Tuple[int, int]]:
    """Recover logical ``(ix, iy)`` indices for an axis-aligned Q4 grid.

    The helper intentionally derives indices from element centroids instead
    of requiring ``FEMMesh`` to carry structured-grid metadata. It is meant
    for tensor-friendly block marking on regular Q4 meshes and fails fast on
    non-rectangular or duplicate centroid layouts.
    """
    if getattr(mesh, 'element_type', 'T3') != 'Q4':
        raise ValueError("q4_structured_element_indices requires a Q4 FEMMesh")

    centroids = mesh.nodes[mesh.elements].mean(dim=1).detach().cpu()
    if centroids.ndim != 2 or centroids.shape[1] != 2:
        raise ValueError("mesh centroids must have shape (n_elements, 2)")

    xs = torch.unique(centroids[:, 0]).sort().values
    ys = torch.unique(centroids[:, 1]).sort().values
    nx = int(xs.numel())
    ny = int(ys.numel())
    if nx * ny != int(mesh.n_elems):
        raise ValueError(
            "Q4 mesh is not a complete structured grid: "
            f"{nx} x {ny} centroids for {int(mesh.n_elems)} elements")

    ix = torch.searchsorted(xs, centroids[:, 0].contiguous())
    iy = torch.searchsorted(ys, centroids[:, 1].contiguous())
    if bool((ix >= nx).any().item()) or bool((iy >= ny).any().item()):
        raise ValueError("Q4 element centroid lies outside structured grid")
    if not torch.allclose(xs[ix], centroids[:, 0], rtol=1e-10, atol=1e-12):
        raise ValueError("Q4 x-centroids are not aligned to a structured grid")
    if not torch.allclose(ys[iy], centroids[:, 1], rtol=1e-10, atol=1e-12):
        raise ValueError("Q4 y-centroids are not aligned to a structured grid")

    flat = iy * nx + ix
    if int(torch.unique(flat).numel()) != int(mesh.n_elems):
        raise ValueError("Q4 structured grid has duplicate element centroids")

    ij = torch.stack([ix, iy], dim=1).to(
        dtype=torch.long, device=mesh.elements.device)
    return ij, (nx, ny)


def _element_history_max(mesh: FEMMesh, H: torch.Tensor) -> torch.Tensor:
    """Return per-element history maxima for element or Gauss-point history."""
    if H.shape[0] != mesh.n_elems:
        raise ValueError(
            f"H first dimension must match mesh.n_elems={mesh.n_elems}, "
            f"got {tuple(H.shape)}")
    if H.ndim == 1:
        return H
    return H.reshape(H.shape[0], -1).max(dim=1).values


def compute_q4_block_refinement_indicator(
    mesh: FEMMesh,
    d: torch.Tensor,
    H_q4: Optional[torch.Tensor] = None,
    *,
    block_shape: Tuple[int, int] = (16, 16),
    Gc: Optional[float] = None,
    l0: Optional[float] = None,
    predictive_fraction: float = 0.8,
    grad_d_threshold: float = 0.3,
    d_threshold: float = 0.5,
    use_damage: bool = True,
    use_gradient: bool = True,
    use_neighborhood: bool = False,
    neighborhood_radius: float = 3.0,
    use_predictive: bool = True,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Mark structured Q4 blocks near a crack zone.

    Element seeds come from the usual reactive damage/gradient indicator plus
    an optional predictive history criterion ``max(H) >=
    predictive_fraction * Gc / l0``. Any seed expands to its whole logical
    block, preserving block-level tensor regularity before conforming Q4
    closure is applied by :func:`refine_q4_mesh`.

    Returns
    -------
    marked : torch.Tensor, shape (E,), dtype=bool
        Block-expanded element mask.
    block_ids : torch.Tensor, shape (E,), dtype=long
        Logical block id for each element.
    """
    if getattr(mesh, 'element_type', 'T3') != 'Q4':
        raise ValueError(
            "compute_q4_block_refinement_indicator requires a Q4 FEMMesh")

    bx, by = (int(block_shape[0]), int(block_shape[1]))
    if bx <= 0 or by <= 0:
        raise ValueError("block_shape entries must be positive")

    seeds = compute_refinement_indicator(
        mesh,
        d,
        grad_d_threshold=grad_d_threshold,
        d_threshold=d_threshold,
        use_damage=use_damage,
        use_gradient=use_gradient,
        use_neighborhood=use_neighborhood,
        neighborhood_radius=neighborhood_radius,
    )

    if use_predictive and H_q4 is not None:
        if Gc is None or l0 is None:
            raise ValueError("Gc and l0 are required for predictive Q4 marking")
        if float(Gc) <= 0.0:
            raise ValueError("Gc must be positive")
        if float(l0) <= 0.0:
            raise ValueError("l0 must be positive")
        if float(predictive_fraction) <= 0.0:
            raise ValueError("predictive_fraction must be positive")
        threshold = float(predictive_fraction) * float(Gc) / float(l0)
        H_elem = _element_history_max(mesh, H_q4).to(device=seeds.device)
        seeds = seeds | (H_elem >= threshold)

    ij, (nx, ny) = q4_structured_element_indices(mesh)
    ij = ij.to(device=seeds.device)
    n_block_x = int(np.ceil(nx / bx))
    n_block_y = int(np.ceil(ny / by))
    block_ix = ij[:, 0] // bx
    block_iy = ij[:, 1] // by
    block_ids = block_iy * n_block_x + block_ix

    block_marked = torch.zeros(
        n_block_x * n_block_y,
        dtype=torch.bool,
        device=seeds.device,
    )
    if bool(seeds.any().item()):
        block_marked[block_ids[seeds]] = True
    return block_marked[block_ids], block_ids.to(dtype=torch.long)


# -------------------------------------------------------------------- #
# 2. Edge-to-element adjacency
# -------------------------------------------------------------------- #

def _build_edge_to_elem(elements: torch.Tensor) -> Dict[Tuple[int, int], list]:
    """Build a mapping from sorted edge tuples to element indices.

    Vectorized with NumPy: builds all edges, sorts, and groups by unique edge.

    Parameters
    ----------
    elements : (E, 3) long tensor

    Returns
    -------
    edge_to_elem : dict mapping (ni, nj) -> [elem_idx, ...]
        Edge nodes are sorted so (min, max).
    """
    import numpy as np
    elems_np = elements.cpu().numpy()
    E = elems_np.shape[0]

    # Build all 3E edges: (node_min, node_max, elem_idx)
    e0, e1, e2 = elems_np[:, 0], elems_np[:, 1], elems_np[:, 2]
    edges_a = np.stack([e0, e1], axis=1)  # edge 0-1
    edges_b = np.stack([e1, e2], axis=1)  # edge 1-2
    edges_c = np.stack([e2, e0], axis=1)  # edge 2-0
    all_edges = np.concatenate([edges_a, edges_b, edges_c], axis=0)  # (3E, 2)
    all_edges.sort(axis=1)  # sort each edge so (min, max)

    elem_ids = np.tile(np.arange(E), 3)  # (3E,)

    # Group by unique edge using structured array
    edge_keys = all_edges[:, 0].astype(np.int64) * (elems_np.max() + 1) + all_edges[:, 1]
    sort_idx = np.argsort(edge_keys)
    sorted_keys = edge_keys[sort_idx]
    sorted_edges = all_edges[sort_idx]
    sorted_elems = elem_ids[sort_idx]

    # Find boundaries between unique edges
    breaks = np.concatenate([[0], np.where(np.diff(sorted_keys) != 0)[0] + 1, [len(sorted_keys)]])

    edge_to_elem: Dict[Tuple[int, int], list] = {}
    for i in range(len(breaks) - 1):
        s, e = breaks[i], breaks[i + 1]
        key = (int(sorted_edges[s, 0]), int(sorted_edges[s, 1]))
        edge_to_elem[key] = sorted_elems[s:e].tolist()

    return edge_to_elem


def _longest_edge(nodes: torch.Tensor, tri: torch.Tensor) -> int:
    """Return the local index (0, 1, 2) of the vertex opposite the longest edge.

    The longest edge of triangle (v0, v1, v2) is determined, and the
    local index of the vertex *opposite* that edge is returned. This
    vertex becomes the "newest vertex" in the NVB convention, and the
    longest edge is the refinement (bisection) edge.

    Local edge convention:
      - Edge 0: v1-v2  (opposite v0)
      - Edge 1: v0-v2  (opposite v1)
      - Edge 2: v0-v1  (opposite v2)

    Parameters
    ----------
    nodes : (N, 2) node coordinates
    tri : (3,) long tensor of node indices

    Returns
    -------
    int : local vertex index opposite the longest edge (0, 1, or 2)
    """
    p = nodes[tri]  # (3, 2)
    # Edge lengths squared (avoid sqrt for comparison)
    e0_sq = ((p[1] - p[2]) ** 2).sum()  # opposite v0
    e1_sq = ((p[0] - p[2]) ** 2).sum()  # opposite v1
    e2_sq = ((p[0] - p[1]) ** 2).sum()  # opposite v2

    lengths_sq = torch.stack([e0_sq, e1_sq, e2_sq])
    return int(lengths_sq.argmax().item())


# -------------------------------------------------------------------- #
# 3. Core refinement
# -------------------------------------------------------------------- #

def _refine_mesh_core(
    mesh: FEMMesh,
    marked_elements: torch.Tensor,
) -> Tuple['FEMMesh', Dict[int, Tuple[int, int]], Dict[int, int], frozenset]:
    """Refine the mesh by newest-vertex bisection with conforming closure.

    Each marked triangle is bisected along its longest edge. Neighbors
    sharing the bisected edge are also refined to maintain conformity
    (no hanging nodes). The process iterates until no new forced
    refinements are needed.

    Parameters
    ----------
    mesh : FEMMesh
        Current mesh.
    marked_elements : torch.Tensor, shape (E,), dtype=torch.bool
        Elements to refine (from ``compute_refinement_indicator``).

    Returns
    -------
    new_mesh : FEMMesh
        Refined mesh with all precomputed quantities.
    parent_map : dict
        ``{new_node_idx: (old_node_a, old_node_b)}`` for midpoint nodes.
        Existing nodes are NOT in this dict.
    child_map : dict
        ``{new_elem_idx: old_elem_idx}`` for every new element.
        Unrefined elements map to themselves.
    """
    nodes_np = mesh.nodes.cpu().numpy().copy()
    elems_np = mesh.elements.cpu().numpy().copy()
    n_old_nodes = nodes_np.shape[0]
    n_old_elems = elems_np.shape[0]

    # Collect which boundary node-sets each node belongs to, so we can
    # tag midpoint nodes that sit on a boundary edge.
    node_to_sets: Dict[int, set] = {}
    for set_name, idx_tensor in mesh.node_sets.items():
        for ni in idx_tensor.cpu().numpy().tolist():
            node_to_sets.setdefault(ni, set()).add(set_name)

    # --- Phase 1: propagate marks for conforming closure ---
    # Build edge -> elem adjacency
    edge_to_elem = _build_edge_to_elem(mesh.elements)

    # Determine the refinement edge for every element (vectorized)
    nodes_np = mesh.nodes.cpu().numpy()
    p = nodes_np[elems_np]  # (E, 3, 2)
    e0_sq = ((p[:, 1] - p[:, 2]) ** 2).sum(axis=1)  # opposite v0
    e1_sq = ((p[:, 0] - p[:, 2]) ** 2).sum(axis=1)  # opposite v1
    e2_sq = ((p[:, 0] - p[:, 1]) ** 2).sum(axis=1)  # opposite v2
    ref_vertex = np.stack([e0_sq, e1_sq, e2_sq], axis=1).argmax(axis=1).astype(np.int32)

    # Refinement edge node-pair per element
    # If ref_vertex[ei] == k, the bisection edge connects the other two vertices.
    _other = {0: (1, 2), 1: (0, 2), 2: (0, 1)}

    def _ref_edge(ei):
        a_loc, b_loc = _other[ref_vertex[ei]]
        na, nb = int(elems_np[ei, a_loc]), int(elems_np[ei, b_loc])
        return (min(na, nb), max(na, nb))

    to_refine = set(int(i) for i in torch.where(marked_elements)[0].cpu().numpy())

    # Propagate: if an element's refinement edge is shared and the neighbor
    # also needs that edge bisected, mark the neighbor.
    #
    # Conforming closure correctness: when neighbor nj is marked because it
    # shares the refinement edge of some marked element ei, nj's own
    # refinement edge (longest edge) may differ from the shared edge. In
    # the next while-loop iteration, nj is included in to_refine, so
    # _ref_edge(nj) is evaluated and *its* refinement-edge neighbors are
    # checked and marked if needed. This transitive propagation continues
    # until no new marks are added, ensuring every marked element's
    # refinement edge is shared only with another marked element (or is on
    # the boundary). NVB then bisects each marked element along its own
    # refinement edge, and the shared midpoint guarantees no hanging nodes.
    max_closure_iters = n_old_elems  # cannot mark more elements than exist
    changed = True
    for _closure_iter in range(max_closure_iters):
        if not changed:
            break
        changed = False
        new_marks = set()
        for ei in to_refine:
            edge = _ref_edge(ei)
            for nj in edge_to_elem.get(edge, []):
                if nj != ei and nj not in to_refine:
                    # Neighbor shares the bisected edge — mark it for
                    # refinement. Even if this edge is not nj's refinement
                    # edge, nj must be bisected to avoid a hanging node.
                    # nj's own refinement edge neighbors will be checked
                    # in subsequent while-loop iterations.
                    new_marks.add(nj)
        if new_marks:
            to_refine |= new_marks
            changed = True

    # --- Phase 2: bisect each marked element ---
    # Bookkeeping for midpoint nodes (avoid duplicates across shared edges)
    edge_to_midnode: Dict[Tuple[int, int], int] = {}
    new_nodes_list = list(nodes_np)  # grow by appending midpoints
    parent_map: Dict[int, Tuple[int, int]] = {}

    def _get_or_create_midnode(na: int, nb: int) -> int:
        edge = (min(na, nb), max(na, nb))
        if edge in edge_to_midnode:
            return edge_to_midnode[edge]
        mid = 0.5 * (new_nodes_list[na] + new_nodes_list[nb])
        mid_idx = len(new_nodes_list)
        new_nodes_list.append(mid)
        edge_to_midnode[edge] = mid_idx
        parent_map[mid_idx] = (edge[0], edge[1])
        return mid_idx

    new_elems_list = []
    child_map: Dict[int, int] = {}
    new_elem_idx = 0

    for ei in range(n_old_elems):
        tri = elems_np[ei]  # (3,) original vertices
        if ei not in to_refine:
            # Keep element as-is
            new_elems_list.append(tri.copy())
            child_map[new_elem_idx] = ei
            new_elem_idx += 1
        else:
            # Bisect along longest edge
            rv = ref_vertex[ei]
            a_loc, b_loc = _other[rv]
            v_apex = int(tri[rv])
            v_a = int(tri[a_loc])
            v_b = int(tri[b_loc])
            v_mid = _get_or_create_midnode(v_a, v_b)

            # Two children:
            #   child 0: (apex, v_a, mid)
            #   child 1: (apex, mid, v_b)
            new_elems_list.append(np.array([v_apex, v_a, v_mid], dtype=np.int64))
            child_map[new_elem_idx] = ei
            new_elem_idx += 1

            new_elems_list.append(np.array([v_apex, v_mid, v_b], dtype=np.int64))
            child_map[new_elem_idx] = ei
            new_elem_idx += 1

    # --- Phase 3: assign boundary node-sets to midpoint nodes ---
    new_node_sets: Dict[str, list] = {
        name: idx_tensor.cpu().numpy().tolist()
        for name, idx_tensor in mesh.node_sets.items()
    }

    for mid_idx, (na, nb) in parent_map.items():
        # A midpoint inherits any node-set that BOTH endpoints share
        sets_a = node_to_sets.get(na, set())
        sets_b = node_to_sets.get(nb, set())
        common_sets = sets_a & sets_b
        for s in common_sets:
            new_node_sets[s].append(mid_idx)

    # Convert node-set lists to tensors
    node_sets_tensors = {}
    for name, idx_list in new_node_sets.items():
        if idx_list:
            node_sets_tensors[name] = torch.tensor(
                sorted(idx_list), dtype=torch.long, device=mesh.device)

    # --- Phase 4: build new FEMMesh from tensors ---
    new_nodes_tensor = torch.tensor(
        np.array(new_nodes_list), dtype=mesh.dtype, device=mesh.device)
    new_elems_tensor = torch.tensor(
        np.stack(new_elems_list), dtype=torch.long, device=mesh.device)

    new_mesh = FEMMesh.from_tensors(
        nodes=new_nodes_tensor,
        elements=new_elems_tensor,
        node_sets=node_sets_tensors,
        device=mesh.device,
        dtype=mesh.dtype,
    )

    return new_mesh, parent_map, child_map, frozenset(to_refine)


def _edge_counts(elements: torch.Tensor) -> Dict[Tuple[int, int], int]:
    counts: Dict[Tuple[int, int], int] = {}
    for tri in elements.detach().cpu().tolist():
        for a, b in ((tri[0], tri[1]), (tri[1], tri[2]), (tri[2], tri[0])):
            edge = (int(a), int(b))
            if edge[1] < edge[0]:
                edge = (edge[1], edge[0])
            counts[edge] = counts.get(edge, 0) + 1
    return counts


def validate_refined_mesh(
    old_mesh: FEMMesh,
    new_mesh: FEMMesh,
    parent_map: Dict[int, Tuple[int, int]],
    child_map: Dict[int, int],
    *,
    area_rtol: float = 1.0e-10,
    area_atol: float = 1.0e-12,
) -> List[str]:
    """Return validation errors for a refined conforming T3 mesh."""
    errors: List[str] = []
    if getattr(new_mesh, "element_type", None) != "T3":
        errors.append(
            f"AMR supports T3 meshes, got {getattr(new_mesh, 'element_type', None)}")

    if len(child_map) != int(new_mesh.n_elems):
        errors.append(
            f"child_map has {len(child_map)} entries for "
            f"{int(new_mesh.n_elems)} elements")
    missing_children = set(range(int(new_mesh.n_elems))) - set(child_map)
    if missing_children:
        errors.append(
            f"child_map missing new elements {sorted(missing_children)}")
    bad_parents = [
        (int(new_e), int(old_e)) for new_e, old_e in child_map.items()
        if int(old_e) < 0 or int(old_e) >= int(old_mesh.n_elems)
    ]
    if bad_parents:
        errors.append(f"child_map contains invalid parents {bad_parents}")

    for mid_idx, (a, b) in parent_map.items():
        mid_idx = int(mid_idx)
        a = int(a)
        b = int(b)
        if mid_idx < old_mesh.n_nodes or mid_idx >= new_mesh.n_nodes:
            errors.append(f"midpoint node {mid_idx} outside new-node range")
        if a < 0 or b < 0 or a >= old_mesh.n_nodes or b >= old_mesh.n_nodes:
            errors.append(f"midpoint parent edge {(a, b)} outside old-node range")
            continue
        expected = 0.5 * (old_mesh.nodes[a] + old_mesh.nodes[b])
        if not torch.allclose(
                new_mesh.nodes[mid_idx], expected, rtol=1e-12, atol=1e-12):
            errors.append(
                f"midpoint node {mid_idx} is not the average of {(a, b)}")

    edge_counts = _edge_counts(new_mesh.elements)
    bad_edges = [
        edge for edge, count in edge_counts.items() if count not in (1, 2)
    ]
    if bad_edges:
        errors.append(
            f"nonmanifold or hanging-edge counts on edges {bad_edges[:8]}")

    if bool((new_mesh.areas <= 0).any().item()):
        errors.append("refined mesh contains non-positive area elements")

    old_area = old_mesh.areas.sum()
    new_area = new_mesh.areas.sum()
    if not torch.allclose(old_area, new_area, rtol=area_rtol, atol=area_atol):
        errors.append(
            f"area changed from {float(old_area):.16e} "
            f"to {float(new_area):.16e}")

    return errors


def refine_mesh_transaction(
    mesh: FEMMesh,
    marked_elements: torch.Tensor,
    options: Optional[RefinementOptions] = None,
) -> RefinementResult:
    """Refine a mesh and return provenance plus validation telemetry."""
    if options is None:
        options = RefinementOptions()

    requested = tuple(
        int(i) for i in torch.where(marked_elements)[0].cpu().tolist())
    effective_marked = marked_elements.clone()
    scores = effective_marked.to(dtype=mesh.dtype)

    max_marked: Optional[int] = None
    if options.max_refine_fraction is not None:
        max_marked = max(
            0,
            int(np.ceil(float(options.max_refine_fraction) * mesh.n_elems)),
        )
    if options.max_new_elements is not None:
        max_extra = max(0, int(options.max_new_elements) - int(mesh.n_elems))
        max_marked = (
            max_extra if max_marked is None else min(max_marked, max_extra)
        )
    if (max_marked is not None or options.min_h is not None):
        effective_marked = apply_refinement_budget(
            effective_marked,
            scores,
            max_marked=max_marked,
            mesh=mesh,
            min_h=options.min_h,
        )

    new_mesh, parent_map, child_map, refined_elements = _refine_mesh_core(
        mesh, effective_marked)
    refined = tuple(sorted(int(i) for i in refined_elements))
    requested_set = set(requested)
    forced = tuple(i for i in refined if i not in requested_set)

    errors: Tuple[str, ...] = ()
    if options.validate_topology:
        errors = tuple(
            validate_refined_mesh(mesh, new_mesh, parent_map, child_map))

    report = AMRStepReport(
        old_nodes=int(mesh.n_nodes),
        old_elements=int(mesh.n_elems),
        new_nodes=int(new_mesh.n_nodes),
        new_elements=int(new_mesh.n_elems),
        requested_elements=requested,
        refined_elements=refined,
        closure_forced_elements=forced,
        new_midpoint_nodes=tuple(sorted(parent_map)),
        min_h_before=float(mesh.h_min),
        min_h_after=float(new_mesh.h_min),
        area_before=float(mesh.areas.sum().detach().cpu().item()),
        area_after=float(new_mesh.areas.sum().detach().cpu().item()),
        topology_validated=bool(options.validate_topology),
        validation_errors=errors,
    )
    if errors:
        raise ValueError("invalid refined mesh: " + "; ".join(errors))
    return RefinementResult(new_mesh, parent_map, child_map, report)


def refine_mesh(
    mesh: FEMMesh,
    marked_elements: torch.Tensor,
) -> Tuple['FEMMesh', Dict[int, Tuple[int, int]], Dict[int, int]]:
    """Backward-compatible refinement API."""
    return refine_mesh_transaction(mesh, marked_elements).as_legacy_tuple()


# -------------------------------------------------------------------- #
# 4. Field interpolation (nodal)
# -------------------------------------------------------------------- #

def interpolate_field(
    old_mesh: FEMMesh,
    new_mesh: FEMMesh,
    field: torch.Tensor,
    parent_map: Dict[int, Tuple[int, int]],
) -> torch.Tensor:
    """Interpolate a nodal field from the old mesh to the refined mesh.

    Existing nodes retain their original values. New midpoint nodes
    receive the average of their two parent node values.

    Parameters
    ----------
    old_mesh : FEMMesh
        Mesh before refinement.
    new_mesh : FEMMesh
        Mesh after refinement.
    field : torch.Tensor
        Nodal field on ``old_mesh``. Shape ``(N_old,)`` for scalar,
        ``(N_old, D)`` for vector fields.
    parent_map : dict
        ``{new_node_idx: (old_node_a, old_node_b)}`` from ``refine_mesh``.

    Returns
    -------
    new_field : torch.Tensor
        Field on ``new_mesh`` with same trailing dimensions as ``field``.
    """
    is_vector = field.dim() > 1
    n_new = new_mesh.n_nodes
    n_old = old_mesh.n_nodes

    if is_vector:
        new_field = torch.zeros(
            n_new, field.shape[1], dtype=field.dtype, device=field.device)
    else:
        new_field = torch.zeros(n_new, dtype=field.dtype, device=field.device)

    # Copy values for existing (old) nodes
    new_field[:n_old] = field

    # Interpolate midpoint nodes
    for mid_idx, (na, nb) in parent_map.items():
        new_field[mid_idx] = 0.5 * (field[na] + field[nb])

    return new_field


# -------------------------------------------------------------------- #
# 5. Field interpolation (element)
# -------------------------------------------------------------------- #

def interpolate_elem_field(
    old_mesh: FEMMesh,
    new_mesh: FEMMesh,
    field: torch.Tensor,
    child_map: Dict[int, int],
) -> torch.Tensor:
    """Interpolate an element field from the old mesh to the refined mesh.

    Children inherit their parent element's value. This is appropriate
    for piecewise-constant element data such as the history variable H.

    Parameters
    ----------
    old_mesh : FEMMesh
        Mesh before refinement.
    new_mesh : FEMMesh
        Mesh after refinement.
    field : torch.Tensor
        Element field on ``old_mesh``, shape ``(E_old,)`` or ``(E_old, D)``.
    child_map : dict
        ``{new_elem_idx: old_elem_idx}`` from ``refine_mesh``.

    Returns
    -------
    new_field : torch.Tensor
        Field on ``new_mesh`` with same trailing dimensions as ``field``.
    """
    is_vector = field.dim() > 1
    n_new = new_mesh.n_elems

    if is_vector:
        new_field = torch.zeros(
            n_new, field.shape[1], dtype=field.dtype, device=field.device)
    else:
        new_field = torch.zeros(n_new, dtype=field.dtype, device=field.device)

    for new_ei, old_ei in child_map.items():
        new_field[new_ei] = field[old_ei]

    return new_field


# -------------------------------------------------------------------- #
# 6. Guarded Q4 refinement helpers
# -------------------------------------------------------------------- #

def refine_q4_mesh(
    mesh: FEMMesh,
    marked_elements: torch.Tensor,
) -> Tuple['FEMMesh', Dict[int, Tuple[int, int]], Dict[int, int]]:
    """Refine Q4 elements with conforming 1-to-4 red refinement.

    A marked Q4 is split into four child quads. Because that split bisects
    every edge of the parent, all edge-neighbours of marked cells are marked
    recursively before refinement. This guarantees a conforming Q4 mesh for
    the local connected patch, although highly fragmented marks can propagate
    through a large connected component. General red-green Q4 transition
    elements are deliberately not introduced here.
    """
    if getattr(mesh, 'element_type', 'T3') != 'Q4':
        raise ValueError("refine_q4_mesh requires a Q4 FEMMesh")
    if marked_elements.shape[0] != mesh.n_elems:
        raise ValueError(
            "marked_elements must have one boolean entry per mesh element")

    nodes_np = mesh.nodes.detach().cpu().numpy()
    elems_np = mesh.elements.detach().cpu().numpy()
    to_refine = set(
        int(i) for i in torch.where(
            marked_elements.to(torch.bool))[0].cpu().numpy()
    )
    edge_to_elem: Dict[Tuple[int, int], list] = {}
    for ei, quad in enumerate(elems_np):
        v0, v1, v2, v3 = [int(v) for v in quad]
        for na, nb in ((v0, v1), (v1, v2), (v2, v3), (v3, v0)):
            edge = (min(na, nb), max(na, nb))
            edge_to_elem.setdefault(edge, []).append(ei)

    changed = True
    while changed:
        changed = False
        new_marks = set()
        for ei in to_refine:
            v0, v1, v2, v3 = [int(v) for v in elems_np[ei]]
            for na, nb in ((v0, v1), (v1, v2), (v2, v3), (v3, v0)):
                edge = (min(na, nb), max(na, nb))
                for nj in edge_to_elem.get(edge, []):
                    if nj not in to_refine:
                        new_marks.add(int(nj))
        if new_marks:
            to_refine |= new_marks
            changed = True

    node_to_sets: Dict[int, set] = {}
    for set_name, idx_tensor in mesh.node_sets.items():
        for ni in idx_tensor.detach().cpu().numpy().tolist():
            node_to_sets.setdefault(int(ni), set()).add(set_name)

    new_nodes = [nodes_np[i].copy() for i in range(nodes_np.shape[0])]
    parent_map: Dict[int, Tuple[int, int]] = {}
    edge_to_midnode: Dict[Tuple[int, int], int] = {}
    center_parent_map: Dict[int, Tuple[int, int, int, int]] = {}

    def _midnode(na: int, nb: int) -> int:
        edge = (min(int(na), int(nb)), max(int(na), int(nb)))
        if edge in edge_to_midnode:
            return edge_to_midnode[edge]
        mid_idx = len(new_nodes)
        new_nodes.append(0.5 * (new_nodes[edge[0]] + new_nodes[edge[1]]))
        edge_to_midnode[edge] = mid_idx
        parent_map[mid_idx] = edge
        return mid_idx

    new_elems = []
    child_map: Dict[int, int] = {}
    new_elem_idx = 0
    for ei, quad in enumerate(elems_np):
        v0, v1, v2, v3 = [int(v) for v in quad]
        if ei not in to_refine:
            new_elems.append(np.array([v0, v1, v2, v3], dtype=np.int64))
            child_map[new_elem_idx] = ei
            new_elem_idx += 1
            continue

        m01 = _midnode(v0, v1)
        m12 = _midnode(v1, v2)
        m23 = _midnode(v2, v3)
        m30 = _midnode(v3, v0)
        center = len(new_nodes)
        new_nodes.append(0.25 * (
            new_nodes[v0] + new_nodes[v1] + new_nodes[v2] + new_nodes[v3]
        ))
        center_parent_map[center] = (v0, v1, v2, v3)
        parent_map[center] = (v0, v2)

        children = [
            [v0, m01, center, m30],
            [m01, v1, m12, center],
            [center, m12, v2, m23],
            [m30, center, m23, v3],
        ]
        for child in children:
            new_elems.append(np.array(child, dtype=np.int64))
            child_map[new_elem_idx] = ei
            new_elem_idx += 1

    new_node_sets: Dict[str, list] = {
        name: idx_tensor.detach().cpu().numpy().astype(np.int64).tolist()
        for name, idx_tensor in mesh.node_sets.items()
    }
    for new_idx, (na, nb) in parent_map.items():
        common_sets = (
            node_to_sets.get(int(na), set())
            & node_to_sets.get(int(nb), set())
        )
        for set_name in common_sets:
            new_node_sets.setdefault(set_name, []).append(new_idx)

    node_sets_tensors = {
        name: torch.tensor(
            sorted(set(idx_list)), dtype=torch.long, device=mesh.device)
        for name, idx_list in new_node_sets.items()
        if idx_list
    }
    new_mesh = FEMMesh.from_tensors(
        torch.tensor(np.asarray(new_nodes), dtype=mesh.dtype,
                     device=mesh.device),
        torch.tensor(np.asarray(new_elems), dtype=torch.long,
                     device=mesh.device),
        node_sets=node_sets_tensors,
        device=mesh.device,
        dtype=mesh.dtype,
        element_type='Q4',
    )
    new_mesh.q4_center_parent_map = center_parent_map
    return new_mesh, parent_map, child_map


@dataclass(frozen=True)
class Q4ConstraintMap:
    """Sparse nodal constraint map for locally refined Q4 meshes.

    ``free_values`` live on the unconstrained nodes. ``expand`` applies
    hanging-node interpolation and ``prolongation`` returns the same mapping
    as a sparse matrix ``P`` such that ``full_values = P @ free_values`` for
    scalar nodal fields.
    """

    n_full: int
    free_nodes: torch.Tensor
    constrained_nodes: torch.Tensor
    master_nodes: torch.Tensor
    weights: torch.Tensor

    @property
    def n_free(self) -> int:
        return int(self.free_nodes.numel())

    @property
    def n_constrained(self) -> int:
        return int(self.constrained_nodes.numel())

    @property
    def layout_signature(self) -> Tuple[int, int, int, int, int]:
        """Identity-based signature suitable for lightweight cache keys."""
        return (
            int(self.n_full),
            int(self.free_nodes.data_ptr()),
            int(self.constrained_nodes.data_ptr()),
            int(self.master_nodes.data_ptr()),
            int(self.weights.data_ptr()),
        )

    def expand(self, free_values: torch.Tensor) -> torch.Tensor:
        """Expand free nodal values to the full node set."""
        if free_values.shape[0] != self.n_free:
            raise ValueError(
                f"free_values first dimension must be {self.n_free}, got "
                f"{free_values.shape[0]}")

        out = torch.zeros(
            (int(self.n_full),) + tuple(free_values.shape[1:]),
            dtype=free_values.dtype,
            device=free_values.device,
        )
        free_nodes = self.free_nodes.to(device=free_values.device)
        constrained_nodes = self.constrained_nodes.to(device=free_values.device)
        master_nodes = self.master_nodes.to(device=free_values.device)
        weights = self.weights.to(
            device=free_values.device, dtype=free_values.dtype)

        out[free_nodes] = free_values
        if self.n_constrained:
            view_shape = weights.shape + (1,) * (free_values.ndim - 1)
            masters = out[master_nodes]
            out[constrained_nodes] = (
                masters * weights.reshape(view_shape)
            ).sum(dim=1)
        return out

    def restrict(self, full_values: torch.Tensor) -> torch.Tensor:
        """Return values on unconstrained nodes."""
        if full_values.shape[0] != int(self.n_full):
            raise ValueError(
                f"full_values first dimension must be {self.n_full}, got "
                f"{full_values.shape[0]}")
        return full_values[self.free_nodes.to(device=full_values.device)]

    def prolongation(
        self,
        *,
        dtype: Optional[torch.dtype] = None,
        device: Optional[torch.device] = None,
    ) -> torch.Tensor:
        """Return sparse COO prolongation from free to full scalar nodes."""
        if dtype is None:
            dtype = self.weights.dtype
        if device is None:
            device = self.free_nodes.device

        free_nodes = self.free_nodes.to(device=device)
        constrained_nodes = self.constrained_nodes.to(device=device)
        master_nodes = self.master_nodes.to(device=device)
        weights = self.weights.to(device=device, dtype=dtype)

        full_to_free = torch.full(
            (int(self.n_full),),
            -1,
            dtype=torch.long,
            device=device,
        )
        full_to_free[free_nodes] = torch.arange(
            self.n_free, dtype=torch.long, device=device)

        rows = [free_nodes]
        cols = [torch.arange(self.n_free, dtype=torch.long, device=device)]
        vals = [torch.ones(self.n_free, dtype=dtype, device=device)]

        if self.n_constrained:
            master_cols = full_to_free[master_nodes]
            if bool((master_cols < 0).any().item()):
                raise ValueError("constrained master node is not a free node")
            rows.append(constrained_nodes.repeat_interleave(2))
            cols.append(master_cols.reshape(-1))
            vals.append(weights.reshape(-1))

        indices = torch.stack([torch.cat(rows), torch.cat(cols)], dim=0)
        values = torch.cat(vals)
        return torch.sparse_coo_tensor(
            indices,
            values,
            size=(int(self.n_full), self.n_free),
            device=device,
            dtype=dtype,
        ).coalesce()


def refine_q4_mesh_local_constrained(
    mesh: FEMMesh,
    marked_elements: torch.Tensor,
) -> Tuple[
        'FEMMesh',
        Dict[int, Tuple[int, int]],
        Dict[int, int],
        Q4ConstraintMap,
]:
    """Refine marked Q4 cells locally and encode hanging nodes as constraints.

    Unlike :func:`refine_q4_mesh`, this routine does not propagate refinement
    to edge neighbours. Mid-edge nodes on refined/coarse interfaces are kept in
    the mesh and constrained to the average of their two coarse-edge endpoints.
    This provides the sparse prolongation contract needed for conforming local
    Q4 AMR without red-refining an entire connected patch.
    """
    if getattr(mesh, 'element_type', 'T3') != 'Q4':
        raise ValueError("refine_q4_mesh_local_constrained requires a Q4 FEMMesh")
    if marked_elements.shape[0] != mesh.n_elems:
        raise ValueError(
            "marked_elements must have one boolean entry per mesh element")

    nodes_np = mesh.nodes.detach().cpu().numpy()
    elems_np = mesh.elements.detach().cpu().numpy()
    to_refine = set(
        int(i) for i in torch.where(
            marked_elements.to(torch.bool))[0].cpu().numpy()
    )

    edge_to_elem: Dict[Tuple[int, int], list] = {}
    for ei, quad in enumerate(elems_np):
        v0, v1, v2, v3 = [int(v) for v in quad]
        for na, nb in ((v0, v1), (v1, v2), (v2, v3), (v3, v0)):
            edge = (min(na, nb), max(na, nb))
            edge_to_elem.setdefault(edge, []).append(ei)

    node_to_sets: Dict[int, set] = {}
    for set_name, idx_tensor in mesh.node_sets.items():
        for ni in idx_tensor.detach().cpu().numpy().tolist():
            node_to_sets.setdefault(int(ni), set()).add(set_name)

    new_nodes = [nodes_np[i].copy() for i in range(nodes_np.shape[0])]
    parent_map: Dict[int, Tuple[int, int]] = {}
    edge_to_midnode: Dict[Tuple[int, int], int] = {}
    center_parent_map: Dict[int, Tuple[int, int, int, int]] = {}
    existing_hanging: Dict[Tuple[int, int], int] = {}
    previous_constraints = getattr(mesh, 'q4_hanging_constraints', None)
    if previous_constraints is not None:
        constrained_nodes_prev = (
            previous_constraints.constrained_nodes.detach().cpu().tolist()
        )
        master_nodes_prev = previous_constraints.master_nodes.detach().cpu().tolist()
        for node_idx, masters in zip(constrained_nodes_prev, master_nodes_prev):
            edge = (min(int(masters[0]), int(masters[1])),
                    max(int(masters[0]), int(masters[1])))
            mid_idx = int(node_idx)
            edge_to_midnode[edge] = mid_idx
            existing_hanging[edge] = mid_idx

    def _midnode(na: int, nb: int) -> int:
        edge = (min(int(na), int(nb)), max(int(na), int(nb)))
        if edge in edge_to_midnode:
            return edge_to_midnode[edge]
        mid_idx = len(new_nodes)
        new_nodes.append(0.5 * (new_nodes[edge[0]] + new_nodes[edge[1]]))
        edge_to_midnode[edge] = mid_idx
        parent_map[mid_idx] = edge
        return mid_idx

    new_elems = []
    child_map: Dict[int, int] = {}
    new_elem_idx = 0
    for ei, quad in enumerate(elems_np):
        v0, v1, v2, v3 = [int(v) for v in quad]
        if ei not in to_refine:
            new_elems.append(np.array([v0, v1, v2, v3], dtype=np.int64))
            child_map[new_elem_idx] = ei
            new_elem_idx += 1
            continue

        m01 = _midnode(v0, v1)
        m12 = _midnode(v1, v2)
        m23 = _midnode(v2, v3)
        m30 = _midnode(v3, v0)
        center = len(new_nodes)
        new_nodes.append(0.25 * (
            new_nodes[v0] + new_nodes[v1] + new_nodes[v2] + new_nodes[v3]
        ))
        center_parent_map[center] = (v0, v1, v2, v3)
        parent_map[center] = (v0, v2)

        children = [
            [v0, m01, center, m30],
            [m01, v1, m12, center],
            [center, m12, v2, m23],
            [m30, center, m23, v3],
        ]
        for child in children:
            new_elems.append(np.array(child, dtype=np.int64))
            child_map[new_elem_idx] = ei
            new_elem_idx += 1

    new_node_sets: Dict[str, list] = {
        name: idx_tensor.detach().cpu().numpy().astype(np.int64).tolist()
        for name, idx_tensor in mesh.node_sets.items()
    }
    for new_idx, (na, nb) in parent_map.items():
        common_sets = (
            node_to_sets.get(int(na), set())
            & node_to_sets.get(int(nb), set())
        )
        for set_name in common_sets:
            new_node_sets.setdefault(set_name, []).append(new_idx)

    hanging: List[Tuple[int, Tuple[int, int]]] = []
    for edge, mid_idx in existing_hanging.items():
        adjacent = edge_to_elem.get(edge, [])
        if not any(int(ei) in to_refine for ei in adjacent):
            hanging.append((int(mid_idx), edge))
    for edge, mid_idx in edge_to_midnode.items():
        if edge in existing_hanging:
            continue
        adjacent = edge_to_elem.get(edge, [])
        has_refined = any(int(ei) in to_refine for ei in adjacent)
        has_coarse = any(int(ei) not in to_refine for ei in adjacent)
        if has_refined and has_coarse:
            hanging.append((int(mid_idx), edge))
    hanging.sort(key=lambda item: item[0])

    constrained_nodes = torch.tensor(
        [mid_idx for mid_idx, _edge in hanging],
        dtype=torch.long,
        device=mesh.device,
    )
    master_nodes = torch.tensor(
        [list(edge) for _mid_idx, edge in hanging],
        dtype=torch.long,
        device=mesh.device,
    )
    if master_nodes.numel() == 0:
        master_nodes = master_nodes.reshape(0, 2)
    weights = torch.full(
        (len(hanging), 2),
        0.5,
        dtype=mesh.dtype,
        device=mesh.device,
    )
    constrained_set = set(int(i) for i in constrained_nodes.detach().cpu())
    free_nodes = torch.tensor(
        [i for i in range(len(new_nodes)) if i not in constrained_set],
        dtype=torch.long,
        device=mesh.device,
    )
    constraints = Q4ConstraintMap(
        n_full=len(new_nodes),
        free_nodes=free_nodes,
        constrained_nodes=constrained_nodes,
        master_nodes=master_nodes,
        weights=weights,
    )

    node_sets_tensors = {
        name: torch.tensor(
            sorted(set(idx_list)), dtype=torch.long, device=mesh.device)
        for name, idx_list in new_node_sets.items()
        if idx_list
    }
    new_mesh = FEMMesh.from_tensors(
        torch.tensor(np.asarray(new_nodes), dtype=mesh.dtype,
                     device=mesh.device),
        torch.tensor(np.asarray(new_elems), dtype=torch.long,
                     device=mesh.device),
        node_sets=node_sets_tensors,
        device=mesh.device,
        dtype=mesh.dtype,
        element_type='Q4',
    )
    new_mesh.q4_center_parent_map = center_parent_map
    new_mesh.q4_hanging_constraints = constraints
    return new_mesh, parent_map, child_map, constraints


def interpolate_q4_gauss_field(
    old_mesh: FEMMesh,
    new_mesh: FEMMesh,
    field: torch.Tensor,
    child_map: Dict[int, int],
) -> torch.Tensor:
    """Transfer a Q4 Gauss-point field by conservative parent maximum.

    Q4 children do not inherit the same physical Gauss-point coordinates as
    their parent. Until a coordinate projection is available, use the parent
    maximum over its four Gauss points for every child Gauss point. This keeps
    phase-field history irreversible and avoids falsely lowering crack-driving
    energy during refinement.
    """
    if field.ndim < 2 or field.shape[1] != 4:
        raise ValueError(
            "Q4 Gauss field must have shape (n_elements, 4[, ...])")
    if field.shape[0] != old_mesh.n_elems:
        raise ValueError("field first dimension must match old_mesh.n_elems")
    trailing = field.shape[1:]
    out = torch.zeros(
        (new_mesh.n_elems,) + trailing,
        dtype=field.dtype,
        device=field.device,
    )
    for new_ei, old_ei in child_map.items():
        parent_values = field[old_ei]
        parent_max = parent_values.max(dim=0).values
        out[new_ei] = parent_max.unsqueeze(0).expand_as(parent_values)
    return out


def interpolate_q4_nodal_field(
    old_mesh: FEMMesh,
    new_mesh: FEMMesh,
    field: torch.Tensor,
    parent_map: Dict[int, Tuple[int, int]],
) -> torch.Tensor:
    """Interpolate a nodal field for Q4 red refinement.

    Edge midpoint nodes use the average of their two endpoints. Element-centre
    nodes created by :func:`refine_q4_mesh` use the average of all four parent
    corners when that provenance is available on ``new_mesh``.
    """
    new_field = interpolate_field(old_mesh, new_mesh, field, parent_map)
    center_parent_map = getattr(new_mesh, 'q4_center_parent_map', {})
    for center_idx, parents in center_parent_map.items():
        parent_values = torch.stack([field[int(p)] for p in parents], dim=0)
        new_field[int(center_idx)] = parent_values.mean(dim=0)
    return new_field


def refine_damage_state_q4(
    mesh: FEMMesh,
    marked_elements: torch.Tensor,
    d_prev: torch.Tensor,
    H_q4: torch.Tensor,
) -> Tuple['FEMMesh', torch.Tensor, torch.Tensor, Dict[int, Tuple[int, int]], Dict[int, int]]:
    """Refine a Q4 damage state and transfer nodal damage plus GP history."""
    new_mesh, parent_map, child_map = refine_q4_mesh(mesh, marked_elements)
    new_d = interpolate_q4_nodal_field(mesh, new_mesh, d_prev, parent_map)
    new_H = interpolate_q4_gauss_field(mesh, new_mesh, H_q4, child_map)
    return new_mesh, new_d, new_H, parent_map, child_map


def refine_damage_state_q4_local_constrained(
    mesh: FEMMesh,
    marked_elements: torch.Tensor,
    d_prev: torch.Tensor,
    H_q4: torch.Tensor,
) -> Tuple[
        'FEMMesh',
        torch.Tensor,
        torch.Tensor,
        Dict[int, Tuple[int, int]],
        Dict[int, int],
        Q4ConstraintMap,
]:
    """Refine a Q4 damage state locally and return hanging-node constraints."""
    new_mesh, parent_map, child_map, constraints = (
        refine_q4_mesh_local_constrained(mesh, marked_elements)
    )
    new_d = interpolate_q4_nodal_field(mesh, new_mesh, d_prev, parent_map)
    new_H = interpolate_q4_gauss_field(mesh, new_mesh, H_q4, child_map)
    return new_mesh, new_d, new_H, parent_map, child_map, constraints


def refine_q4_crack_zone(
    mesh: FEMMesh,
    d_prev: torch.Tensor,
    H_q4: torch.Tensor,
    *,
    grad_d_threshold: float = 0.3,
    d_threshold: float = 0.5,
    use_damage: bool = True,
    use_gradient: bool = True,
    use_neighborhood: bool = False,
    neighborhood_radius: float = 3.0,
) -> Tuple['FEMMesh', torch.Tensor, torch.Tensor, Dict[int, Tuple[int, int]], Dict[int, int], torch.Tensor]:
    """Mark and refine a Q4 damage state around the current crack zone."""
    if getattr(mesh, 'element_type', 'T3') != 'Q4':
        raise ValueError("refine_q4_crack_zone requires a Q4 FEMMesh")
    marked = compute_refinement_indicator(
        mesh,
        d_prev,
        grad_d_threshold=grad_d_threshold,
        d_threshold=d_threshold,
        use_damage=use_damage,
        use_gradient=use_gradient,
        use_neighborhood=use_neighborhood,
        neighborhood_radius=neighborhood_radius,
    )
    new_mesh, new_d, new_H, parent_map, child_map = refine_damage_state_q4(
        mesh, marked, d_prev, H_q4)
    return new_mesh, new_d, new_H, parent_map, child_map, marked


def refine_q4_crack_zone_local_constrained(
    mesh: FEMMesh,
    d_prev: torch.Tensor,
    H_q4: torch.Tensor,
    *,
    grad_d_threshold: float = 0.3,
    d_threshold: float = 0.5,
    use_damage: bool = True,
    use_gradient: bool = True,
    use_neighborhood: bool = False,
    neighborhood_radius: float = 3.0,
) -> Tuple[
        'FEMMesh',
        torch.Tensor,
        torch.Tensor,
        Dict[int, Tuple[int, int]],
        Dict[int, int],
        torch.Tensor,
        Q4ConstraintMap,
]:
    """Mark a Q4 crack zone and refine locally with hanging-node constraints."""
    if getattr(mesh, 'element_type', 'T3') != 'Q4':
        raise ValueError(
            "refine_q4_crack_zone_local_constrained requires a Q4 FEMMesh")
    marked = compute_refinement_indicator(
        mesh,
        d_prev,
        grad_d_threshold=grad_d_threshold,
        d_threshold=d_threshold,
        use_damage=use_damage,
        use_gradient=use_gradient,
        use_neighborhood=use_neighborhood,
        neighborhood_radius=neighborhood_radius,
    )
    new_mesh, new_d, new_H, parent_map, child_map, constraints = (
        refine_damage_state_q4_local_constrained(
            mesh, marked, d_prev, H_q4)
    )
    return (
        new_mesh, new_d, new_H, parent_map, child_map, marked, constraints)


def refine_q4_block_crack_zone(
    mesh: FEMMesh,
    d_prev: torch.Tensor,
    H_q4: torch.Tensor,
    *,
    block_shape: Tuple[int, int] = (16, 16),
    Gc: Optional[float] = None,
    l0: Optional[float] = None,
    predictive_fraction: float = 0.8,
    grad_d_threshold: float = 0.3,
    d_threshold: float = 0.5,
    use_damage: bool = True,
    use_gradient: bool = True,
    use_neighborhood: bool = False,
    neighborhood_radius: float = 3.0,
    use_predictive: bool = True,
) -> Tuple[
        'FEMMesh',
        torch.Tensor,
        torch.Tensor,
        Dict[int, Tuple[int, int]],
        Dict[int, int],
        torch.Tensor,
        torch.Tensor,
]:
    """Block-mark and refine a structured Q4 damage state around a crack zone."""
    if getattr(mesh, 'element_type', 'T3') != 'Q4':
        raise ValueError("refine_q4_block_crack_zone requires a Q4 FEMMesh")
    marked, block_ids = compute_q4_block_refinement_indicator(
        mesh,
        d_prev,
        H_q4,
        block_shape=block_shape,
        Gc=Gc,
        l0=l0,
        predictive_fraction=predictive_fraction,
        grad_d_threshold=grad_d_threshold,
        d_threshold=d_threshold,
        use_damage=use_damage,
        use_gradient=use_gradient,
        use_neighborhood=use_neighborhood,
        neighborhood_radius=neighborhood_radius,
        use_predictive=use_predictive,
    )
    new_mesh, new_d, new_H, parent_map, child_map = refine_damage_state_q4(
        mesh, marked, d_prev, H_q4)
    return (
        new_mesh,
        new_d,
        new_H,
        parent_map,
        child_map,
        marked,
        block_ids,
    )


def refine_q4_block_crack_zone_local_constrained(
    mesh: FEMMesh,
    d_prev: torch.Tensor,
    H_q4: torch.Tensor,
    *,
    block_shape: Tuple[int, int] = (16, 16),
    Gc: Optional[float] = None,
    l0: Optional[float] = None,
    predictive_fraction: float = 0.8,
    grad_d_threshold: float = 0.3,
    d_threshold: float = 0.5,
    use_damage: bool = True,
    use_gradient: bool = True,
    use_neighborhood: bool = False,
    neighborhood_radius: float = 3.0,
    use_predictive: bool = True,
) -> Tuple[
        'FEMMesh',
        torch.Tensor,
        torch.Tensor,
        Dict[int, Tuple[int, int]],
        Dict[int, int],
        torch.Tensor,
        torch.Tensor,
        Q4ConstraintMap,
]:
    """Block-mark a Q4 crack zone and refine locally with constraints."""
    if getattr(mesh, 'element_type', 'T3') != 'Q4':
        raise ValueError(
            "refine_q4_block_crack_zone_local_constrained requires a Q4 FEMMesh")
    marked, block_ids = compute_q4_block_refinement_indicator(
        mesh,
        d_prev,
        H_q4,
        block_shape=block_shape,
        Gc=Gc,
        l0=l0,
        predictive_fraction=predictive_fraction,
        grad_d_threshold=grad_d_threshold,
        d_threshold=d_threshold,
        use_damage=use_damage,
        use_gradient=use_gradient,
        use_neighborhood=use_neighborhood,
        neighborhood_radius=neighborhood_radius,
        use_predictive=use_predictive,
    )
    new_mesh, new_d, new_H, parent_map, child_map, constraints = (
        refine_damage_state_q4_local_constrained(
            mesh, marked, d_prev, H_q4)
    )
    return (
        new_mesh,
        new_d,
        new_H,
        parent_map,
        child_map,
        marked,
        block_ids,
        constraints,
    )


def refine_damage_state(
    mesh: FEMMesh,
    marked_elements: torch.Tensor,
    d_prev: torch.Tensor,
    H: torch.Tensor,
) -> Tuple['FEMMesh', torch.Tensor, torch.Tensor, Dict[int, Tuple[int, int]], Dict[int, int]]:
    """Refine a damage replay state for the mesh's native element type."""
    element_type = getattr(mesh, 'element_type', 'T3')
    if element_type == 'Q4':
        if H.ndim >= 2 and H.shape[1] == 4:
            return refine_damage_state_q4(mesh, marked_elements, d_prev, H)
        new_mesh, parent_map, child_map = refine_q4_mesh(mesh, marked_elements)
        new_d = interpolate_q4_nodal_field(mesh, new_mesh, d_prev, parent_map)
        new_H = interpolate_elem_field(mesh, new_mesh, H, child_map)
        return new_mesh, new_d, new_H, parent_map, child_map
    if element_type == 'T3':
        new_mesh, parent_map, child_map = refine_mesh(mesh, marked_elements)
        new_d = interpolate_field(mesh, new_mesh, d_prev, parent_map)
        new_H = interpolate_elem_field(mesh, new_mesh, H, child_map)
        return new_mesh, new_d, new_H, parent_map, child_map
    raise NotImplementedError(
        f"refine_damage_state supports T3 and Q4 meshes, got {element_type!r}")
