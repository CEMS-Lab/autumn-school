"""PhAST-native sparse matrix helpers.

The classes here keep sparse layout separate from differentiable values.  The
layout signature follows the TensorMesh idea of identity/version based cache
keys, avoiding value hashing or device synchronisation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import torch


Shape2D = Tuple[int, int]


@dataclass(frozen=True)
class SparsePattern:
    """COO sparse layout with an identity/version signature."""

    row: torch.Tensor
    col: torch.Tensor
    shape: Shape2D

    def __post_init__(self) -> None:
        if self.row.dtype != torch.long or self.col.dtype != torch.long:
            raise TypeError("SparsePattern row/col tensors must be torch.long")
        if self.row.shape != self.col.shape:
            raise ValueError(
                "SparsePattern row/col tensors must have the same shape, "
                f"got {tuple(self.row.shape)} and {tuple(self.col.shape)}")
        if len(self.shape) != 2:
            raise ValueError(f"SparsePattern shape must be 2D, got {self.shape!r}")

    @staticmethod
    def _tensor_identity(tensor: torch.Tensor):
        return (
            tensor.device.type,
            tensor.device.index,
            int(tensor.data_ptr()),
            int(getattr(tensor, "_version", 0)),
            tuple(tensor.shape),
            tuple(tensor.stride()),
            str(tensor.dtype),
        )

    @property
    def layout_signature(self):
        """Return a cache key for this sparse layout.

        The signature intentionally tracks tensor identity and version, not
        row/column contents. This keeps cache checks cheap and graph-friendly.
        """
        return (
            self._tensor_identity(self.row),
            self._tensor_identity(self.col),
            tuple(int(v) for v in self.shape),
        )

    @property
    def nnz(self) -> int:
        return int(self.row.numel())

    def indices(self, *, device=None) -> torch.Tensor:
        row = self.row if device is None else self.row.to(device=device)
        col = self.col if device is None else self.col.to(device=device)
        return torch.stack((row.reshape(-1), col.reshape(-1)), dim=0)

    def has_same_layout(self, other: "SparsePattern") -> bool:
        return self.layout_signature == other.layout_signature


class PhastSparseMatrix:
    """Sparse COO values plus a reusable :class:`SparsePattern`."""

    def __init__(self, values: torch.Tensor, pattern: SparsePattern):
        if values.ndim != 1:
            raise ValueError(
                f"PhastSparseMatrix values must be 1D, got {tuple(values.shape)}")
        if values.numel() != pattern.nnz:
            raise ValueError(
                "PhastSparseMatrix values length must match pattern nnz, "
                f"got {values.numel()} and {pattern.nnz}")
        self.values = values
        self.pattern = pattern

    @property
    def shape(self) -> Shape2D:
        return self.pattern.shape

    @property
    def layout_signature(self):
        return self.pattern.layout_signature

    @property
    def row(self) -> torch.Tensor:
        return self.pattern.row

    @property
    def col(self) -> torch.Tensor:
        return self.pattern.col

    @classmethod
    def from_local_blocks(
        cls,
        local_blocks: torch.Tensor,
        elements: torch.Tensor,
        *,
        shape: Shape2D | None = None,
    ) -> "PhastSparseMatrix":
        """Assemble scalar element blocks into COO values.

        Duplicate row/column pairs are preserved in COO form and summed by
        PyTorch sparse operations, which keeps gradients local to element
        contributions before coalescing.
        """
        if local_blocks.ndim != 3:
            raise ValueError(
                "local_blocks must have shape (n_elem, n_local, n_local), "
                f"got {tuple(local_blocks.shape)}")
        if elements.ndim != 2:
            raise ValueError(
                f"elements must have shape (n_elem, n_local), got {tuple(elements.shape)}")
        n_elem, n_a, n_b = local_blocks.shape
        if n_a != n_b:
            raise ValueError("local_blocks must be square in the two local axes")
        if elements.shape != (n_elem, n_a):
            raise ValueError(
                "elements shape must match local block element/local axes, "
                f"got {tuple(elements.shape)} for blocks {tuple(local_blocks.shape)}")

        elem = elements.to(device=local_blocks.device, dtype=torch.long)
        row = elem.unsqueeze(2).expand(n_elem, n_a, n_a).reshape(-1)
        col = elem.unsqueeze(1).expand(n_elem, n_a, n_a).reshape(-1)
        values = local_blocks.reshape(-1)
        if shape is None:
            n_nodes = int(elements.max().item()) + 1
            shape = (n_nodes, n_nodes)
        pattern = SparsePattern(
            row=row.detach().to(dtype=torch.long),
            col=col.detach().to(dtype=torch.long),
            shape=(int(shape[0]), int(shape[1])),
        )
        return cls(values, pattern)

    def to_sparse_coo(self, *, coalesce: bool = False) -> torch.Tensor:
        sparse = torch.sparse_coo_tensor(
            self.pattern.indices(device=self.values.device),
            self.values,
            self.shape,
            dtype=self.values.dtype,
            device=self.values.device,
        )
        return sparse.coalesce() if coalesce else sparse

    def to_dense(self) -> torch.Tensor:
        return self.to_sparse_coo(coalesce=True).to_dense()

    def matvec(self, vector: torch.Tensor) -> torch.Tensor:
        result = torch.sparse.mm(
            self.to_sparse_coo(coalesce=True),
            vector.reshape(-1, 1),
        )
        return result.reshape(-1)

    def solve(self, rhs: torch.Tensor, *, backend: str = "auto") -> torch.Tensor:
        from .sparse_solve import solve

        return solve(self.to_sparse_coo(coalesce=True), rhs, backend=backend)

    def with_fixed_dofs(
        self,
        rhs: torch.Tensor,
        *,
        fixed: torch.Tensor,
        values: torch.Tensor,
    ) -> tuple["PhastSparseMatrix", torch.Tensor]:
        """Return an eliminated system with fixed DOFs pinned to ``values``."""
        fixed = fixed.to(device=rhs.device, dtype=torch.bool)
        values = values.to(device=rhs.device, dtype=rhs.dtype)
        if fixed.shape != rhs.shape or values.shape != rhs.shape:
            raise ValueError(
                "fixed and values must have the same shape as rhs, got "
                f"{tuple(fixed.shape)}, {tuple(values.shape)}, {tuple(rhs.shape)}")

        known = torch.where(fixed, values, torch.zeros_like(rhs))
        reduced_rhs = rhs - self.matvec(known)
        coo = self.to_sparse_coo(coalesce=True)
        idx = coo.indices()
        coo_values = coo.values()
        fixed_idx = torch.nonzero(fixed, as_tuple=False).reshape(-1)
        free_entry = (~fixed[idx[0]]) & (~fixed[idx[1]])
        row = torch.cat((idx[0, free_entry], fixed_idx))
        col = torch.cat((idx[1, free_entry], fixed_idx))
        new_values = torch.cat((
            coo_values[free_entry],
            torch.ones(fixed_idx.numel(), dtype=coo_values.dtype,
                       device=coo_values.device),
        ))
        constrained = PhastSparseMatrix(
            new_values,
            SparsePattern(
                row.detach().to(torch.long),
                col.detach().to(torch.long),
                self.shape,
            ),
        )
        reduced_rhs = torch.where(fixed, values, reduced_rhs)
        return constrained, reduced_rhs

    def solve_with_fixed(
        self,
        rhs: torch.Tensor,
        *,
        fixed: torch.Tensor,
        values: torch.Tensor,
        backend: str = "auto",
    ) -> torch.Tensor:
        matrix, constrained_rhs = self.with_fixed_dofs(
            rhs, fixed=fixed, values=values)
        return matrix.solve(constrained_rhs, backend=backend)

    def to(self, *, device=None, dtype=None) -> "PhastSparseMatrix":
        values = self.values.to(device=device, dtype=dtype)
        row = self.pattern.row if device is None else self.pattern.row.to(device=device)
        col = self.pattern.col if device is None else self.pattern.col.to(device=device)
        return PhastSparseMatrix(
            values,
            SparsePattern(row=row, col=col, shape=self.pattern.shape),
        )
