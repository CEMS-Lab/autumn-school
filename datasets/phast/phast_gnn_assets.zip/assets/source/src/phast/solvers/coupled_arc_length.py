"""Experimental reduced-coordinate semismooth arc-length corrector.

This module is intentionally separate from the production staggered solver.
It supplies a small-problem verification path for history-field phase-field
models when an MPC-preserving Riks stagger loop stalls.  The method solves the
reduced rigid-connector kinematics ``u = T q`` and freezes both the hard-max
history branch and bound active set during each finite-difference Krylov step.

The established history-field formulation is retained. An opt-in
primal-dual-style classifier is available only to stabilize the irreversible
damage bounds inside the semismooth Newton row; it does not change the final
history, KKT, or field certificate. The method must not be used to collect
training data or make timing claims until independently validated at scale.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Callable

import numpy as np
import torch

from .damage_solver import damage_kkt_metrics
from .mechanics_solver import _build_rigid_connector_T, _infer_rigid_connector_thetas


def _arc_constraint_value(*, u: torch.Tensor, u_prev: torch.Tensor,
                          d: torch.Tensor, d_prev: torch.Tensor,
                          load_factor: float, lambda_prev: float,
                          alpha: float, ds: float,
                          damage_arc_weight: float = 0.0) -> float:
    """Evaluate a coupled displacement/load/damage arc constraint.

    ``damage_arc_weight`` is deliberately explicit because damage is
    dimensionless while displacement carries length units. A zero weight
    recovers the established displacement/load Riks row exactly. Positive
    weights constrain localization within a fully coupled corrector; they are
    not used by the staggered mechanics-only primitive.
    """

    if damage_arc_weight < 0.0:
        raise ValueError("damage_arc_weight must be non-negative")
    delta_u = u - u_prev
    delta_d = d - d_prev
    return float(
        (delta_u * delta_u).mean().item()
        + (alpha * (float(load_factor) - float(lambda_prev))) ** 2
        + float(damage_arc_weight) * (delta_d * delta_d).mean().item()
        - float(ds) ** 2)


def _mechanical_radius_squared(*, d: torch.Tensor, d_prev: torch.Tensor,
                               ds: float, damage_arc_weight: float) -> float:
    """Return the fixed-damage Riks radius left after the damage arc term."""

    if damage_arc_weight < 0.0:
        raise ValueError("damage_arc_weight must be non-negative")
    return float(ds) ** 2 - float(damage_arc_weight) * float(
        ((d - d_prev) * (d - d_prev)).mean().item())


def _fracture_energy_value(fem, d: torch.Tensor) -> float:
    """Return the phase-field fracture energy used by energy continuation."""
    surface, gradient = fem._fracture_energy_terms(d)
    return float(surface + gradient)


def _fracture_energy_gradient(fem, damage_solver, d: torch.Tensor) -> torch.Tensor:
    """Return the AT2 fracture-energy gradient on the damage nodes."""
    if getattr(damage_solver, "_pf_model", "AT2") != "AT2":
        raise NotImplementedError(
            "fracture-energy continuation currently supports AT2 damage only")
    zero_history = torch.zeros(
        fem.mesh.n_elems, dtype=d.dtype, device=d.device)
    zero_damage = torch.zeros_like(d)
    return (damage_solver.compute_residual(zero_history, d)
            - damage_solver.compute_residual(zero_history, zero_damage))


def _semismooth_damage_active_set(*, residual: torch.Tensor,
                                  d: torch.Tensor, d_prev: torch.Tensor,
                                  primal_dual_scale: float | torch.Tensor = 0.0,
                                  upper_bound: float = 1.0,
                                  bound_atol: float = 1.0e-12,
                                  fixed: torch.Tensor | None = None):
    """Classify irreversible damage bounds for a semismooth Newton row.

    A zero ``primal_dual_scale`` retains the historical exact-bound rule.
    A positive value activates the standard primal-dual inequalities
    ``d-d_prev <= c r`` and ``upper-d <= -c r``. This prevents a projected
    trial that is infinitesimally above a bound from being treated as an
    interior Newton unknown while its dual residual still points outward.
    """

    if residual.shape != d.shape or d_prev.shape != d.shape:
        raise ValueError("residual, d, and d_prev must share a shape")
    scale = torch.as_tensor(
        primal_dual_scale, device=d.device, dtype=d.dtype)
    if scale.ndim > 0 and scale.shape != d.shape:
        raise ValueError("tensor primal_dual_scale must match damage shape")
    if bool(torch.any(scale < 0.0)):
        raise ValueError("primal_dual_scale must be non-negative")
    saturated = d_prev >= upper_bound - bound_atol
    fixed_mask = saturated if fixed is None else (
        saturated | fixed.to(device=d.device, dtype=torch.bool))
    if bool(torch.all(scale == 0.0)):
        lower = ((d <= d_prev + bound_atol) & (residual >= 0.0))
        upper = ((d >= upper_bound - bound_atol) & (residual <= 0.0))
    else:
        lower = (d - d_prev <= bound_atol + scale * residual)
        upper = (upper_bound - d <= bound_atol - scale * residual)
    lower = lower & ~fixed_mask
    upper = upper & ~fixed_mask
    return lower, upper, fixed_mask


@dataclass(frozen=True)
class SemismoothArcResult:
    """State and diagnostics returned by :class:`SemismoothArcLengthCorrector`."""

    u: torch.Tensor
    d: torch.Tensor
    H_elem: torch.Tensor
    load_factor: float
    converged: bool
    iterations: int
    residual_l2: float
    history_active_stable: bool
    damage_kkt: dict[str, float | int | bool]
    iteration_diagnostics: list[dict[str, float | int | bool]]
    mechanics_predictor_converged: bool
    mechanics_predictor_residual: float
    mechanics_polish_converged: bool
    mechanics_polish_residual: float
    mechanics_polish_arc_constraint: float
    mechanics_polish_required: bool
    control_mode: str
    target_load: float | None
    fracture_energy_target: float | None
    damage_arc_weight: float
    damage_active_set_scale: float


class SemismoothArcLengthCorrector:
    """Finite-difference Newton-Krylov corrector for small history-field systems.

    The unpreconditioned mode is deliberately bounded to small regression
    problems.  An explicit opt-in block preconditioner factors the frozen
    reduced mechanics and damage diagonal blocks once per Newton iteration.
    It still has a conservative unknown-count guard because it does not yet
    include the Schur complement or a distributed sparse backend.
    """

    def __init__(self, fem, damage_solver, *, tol: float = 1.0e-8,
                 max_newton: int = 8, krylov_maxiter: int = 30,
                 max_unknowns: int = 4096,
                 use_block_preconditioner: bool = False,
                 max_preconditioned_unknowns: int = 100_000,
                 line_search_max_reductions: int = 12,
                 line_search_mode: str = "refreshed",
                 damage_kkt_relative_tolerance: float | None = None,
                 mechanics_relative_tolerance: float | None = None,
                 damage_active_set_scale: float = 0.0,
                 damage_active_set_diagonal_theta: float = 0.0,
                 mechanics_polish_cg_maxiter: int = 250):
        if tol <= 0.0:
            raise ValueError("tol must be positive")
        self.fem = fem
        self.damage_solver = damage_solver
        self.tol = float(tol)
        self.max_newton = int(max_newton)
        self.krylov_maxiter = int(krylov_maxiter)
        self.max_unknowns = int(max_unknowns)
        self.use_block_preconditioner = bool(use_block_preconditioner)
        self.max_preconditioned_unknowns = int(max_preconditioned_unknowns)
        if line_search_max_reductions < 1:
            raise ValueError("line_search_max_reductions must be positive")
        self.line_search_max_reductions = int(line_search_max_reductions)
        if line_search_mode not in {"refreshed", "frozen_active_set"}:
            raise ValueError(
                "line_search_mode must be 'refreshed' or 'frozen_active_set'")
        self.line_search_mode = line_search_mode
        if (damage_kkt_relative_tolerance is not None
                and damage_kkt_relative_tolerance <= 0.0):
            raise ValueError("damage_kkt_relative_tolerance must be positive")
        if (mechanics_relative_tolerance is not None
                and mechanics_relative_tolerance <= 0.0):
            raise ValueError("mechanics_relative_tolerance must be positive")
        if damage_active_set_scale < 0.0:
            raise ValueError("damage_active_set_scale must be non-negative")
        if damage_active_set_diagonal_theta < 0.0:
            raise ValueError(
                "damage_active_set_diagonal_theta must be non-negative")
        if (damage_active_set_scale > 0.0
                and damage_active_set_diagonal_theta > 0.0):
            raise ValueError(
                "choose either scalar or diagonal-scaled damage active set")
        if mechanics_polish_cg_maxiter < 1:
            raise ValueError("mechanics_polish_cg_maxiter must be positive")
        self.damage_kkt_relative_tolerance = damage_kkt_relative_tolerance
        self.mechanics_relative_tolerance = mechanics_relative_tolerance
        self.damage_active_set_scale = float(damage_active_set_scale)
        self.damage_active_set_diagonal_theta = float(
            damage_active_set_diagonal_theta)
        # The public Amor mesh makes each matrix-free MPC-CG iteration costly.
        # A polishing attempt is a certificate, not an unbounded recovery
        # loop: exhausting this fixed budget returns a rejected candidate.
        self.mechanics_polish_cg_maxiter = int(mechanics_polish_cg_maxiter)
        self._mechanics_linearizer = None
        self._fixed_load_mechanics = None
        self._damage_geometry = None
        self.last_gmres_info = None

    def solve(
            self,
            *,
            u_prev: torch.Tensor,
            d_prev: torch.Tensor,
            H_prev: torch.Tensor,
            f_ext_ref: torch.Tensor,
            bc_mask: torch.Tensor,
            bc_unit_vals: torch.Tensor,
            rigid_connectors,
            lambda_prev: float,
            lambda_init: float,
            ds: float,
            alpha: float = 1.0,
            secant_u: torch.Tensor | None = None,
            secant_d: torch.Tensor | None = None,
            secant_lambda: float | None = None,
            damage_arc_weight: float = 0.0,
            damage_control_index: int | None = None,
            damage_control_increment: float | None = None,
            fracture_energy_target: float | None = None,
            fixed_load: float | None = None,
            require_mechanics_polish: bool = True,
            pf_dirichlet_mask: torch.Tensor | None = None,
            pf_dirichlet_values: torch.Tensor | None = None) -> SemismoothArcResult:
        """Solve one small MPC-compatible coupled arc-length increment.

        ``H_prev`` is the accepted element history.  At every Newton outer
        iteration the hard-max branch is refreshed; inside GMRES the branch is
        frozen so the finite-difference directional operator is linear.  The
        damage lower/upper active set follows the same outer/inner discipline.
        """
        if not rigid_connectors:
            raise ValueError("SemismoothArcLengthCorrector requires rigid MPCs")
        if ds <= 0.0 or alpha <= 0.0:
            raise ValueError("ds and alpha must be positive")
        if damage_arc_weight < 0.0:
            raise ValueError("damage_arc_weight must be non-negative")
        if fixed_load is not None and damage_arc_weight != 0.0:
            raise ValueError(
                "damage_arc_weight is only defined for arc-length control")
        if (damage_control_index is None) != (damage_control_increment is None):
            raise ValueError(
                "pass both damage_control_index and damage_control_increment, or neither")
        if damage_control_index is not None:
            if fixed_load is not None:
                raise ValueError("damage control cannot be combined with fixed load")
            if not 0 <= int(damage_control_index) < d_prev.numel():
                raise ValueError("damage_control_index is outside the damage field")
            if float(damage_control_increment) <= 0.0:
                raise ValueError("damage_control_increment must be positive")
            damage_control_index = int(damage_control_index)
            damage_control_increment = float(damage_control_increment)
        if fracture_energy_target is not None:
            if not math.isfinite(float(fracture_energy_target)):
                raise ValueError("fracture_energy_target must be finite")
            if fixed_load is not None or damage_control_index is not None:
                raise ValueError(
                    "fracture-energy control cannot be combined with fixed or local damage control")
            fracture_energy_target = float(fracture_energy_target)
        if fixed_load is not None and not math.isfinite(float(fixed_load)):
            raise ValueError("fixed_load must be finite")
        if H_prev.ndim != 1 or H_prev.numel() != self.fem.mesh.n_elems:
            raise ValueError("H_prev must be an element-wise accepted history field")

        dtype = d_prev.dtype
        device = d_prev.device
        bc_mask = bc_mask.to(device=device, dtype=torch.bool)
        bc_unit_vals = bc_unit_vals.to(device=device, dtype=dtype)
        f_ext_ref = f_ext_ref.to(device=device, dtype=dtype)
        u_prev = u_prev.to(device=device, dtype=dtype)
        d_prev = d_prev.to(device=device, dtype=dtype)
        H_prev = H_prev.to(device=device, dtype=dtype)
        if (secant_u is None) != (secant_lambda is None):
            raise ValueError("pass both secant_u and secant_lambda, or neither")
        if secant_d is not None and secant_u is None:
            raise ValueError("secant_d requires a displacement/load secant")
        if secant_u is not None:
            if secant_u.shape != u_prev.shape:
                raise ValueError("secant_u must match u_prev shape")
            secant_u = secant_u.to(device=device, dtype=dtype)
            secant_lambda = float(secant_lambda)
        if secant_d is not None:
            if secant_d.shape != d_prev.shape:
                raise ValueError("secant_d must match d_prev shape")
            secant_d = secant_d.to(device=device, dtype=dtype)
            if bool(torch.any(secant_d < -1.0e-12)):
                raise ValueError("secant_d must respect damage irreversibility")

        T_csr, free_mask, free_idx, n_dof, n_rc, _ = _build_rigid_connector_T(
            rigid_connectors, self.fem, bc_mask)
        q_fixed = np.flatnonzero(bc_mask.detach().cpu().numpy().reshape(-1))
        unit_flat = bc_unit_vals.detach().cpu().numpy().astype(np.float64).reshape(-1)
        n_q_free = int(free_mask.sum())
        n_unknowns = n_q_free + d_prev.numel() + 1
        unknown_limit = (self.max_preconditioned_unknowns
                         if self.use_block_preconditioner else self.max_unknowns)
        if n_unknowns > unknown_limit:
            mode = "block-preconditioned" if self.use_block_preconditioner else "unpreconditioned"
            raise ValueError(
                f"experimental {mode} semismooth arc-length corrector is limited to "
                f"{unknown_limit} unknowns; "
                f"received {n_unknowns}")

        def q_to_u(q: np.ndarray) -> torch.Tensor:
            flat = T_csr @ q
            return torch.as_tensor(flat.reshape(-1, 2), dtype=dtype, device=device)

        seed_flat = u_prev.detach().cpu().numpy().astype(np.float64).reshape(-1)
        q_seed = np.zeros(n_dof + n_rc, dtype=np.float64)
        q_seed[:n_dof] = seed_flat
        q_seed[n_dof:] = _infer_rigid_connector_thetas(
            seed_flat, rigid_connectors, self.fem)
        q_hat = np.zeros(n_dof + n_rc, dtype=np.float64)
        q_hat[q_fixed] = unit_flat[q_fixed]
        u_hat_predictor = q_to_u(q_hat)
        predictor_norm = (
            float((u_hat_predictor * u_hat_predictor).sum().item())
            / max(1, u_prev.numel()) + alpha * alpha) ** 0.5
        control_mode = (
            "local_damage" if damage_control_index is not None
            else "fracture_energy" if fracture_energy_target is not None
            else "fixed_load" if fixed_load is not None else "arc_length")
        direction = 1.0 if lambda_init >= lambda_prev else -1.0
        lambda_predictor = (float(lambda_prev) + direction * ds / predictor_norm
                            if predictor_norm > 0.0 else float(lambda_init))
        if fixed_load is not None:
            lambda_predictor = float(fixed_load)
        elif damage_control_index is not None or fracture_energy_target is not None:
            # Damage control replaces the Riks row.  Seed it from the caller's
            # load estimate rather than an unrelated arc radius so the first
            # hard-max branch can activate before its scalar load sensitivity
            # is assembled.
            lambda_predictor = float(lambda_init)
        predictor_u_init = u_prev
        predictor_d_init = d_prev
        if (secant_u is not None and fixed_load is None
                and damage_control_index is None
                and fracture_energy_target is None):
            secant_norm = math.sqrt(
                float((secant_u * secant_u).sum().item()) / max(1, u_prev.numel())
                + (alpha * float(secant_lambda)) ** 2
                + float(damage_arc_weight) * (0.0 if secant_d is None else float(
                    (secant_d * secant_d).mean().item())))
            if math.isfinite(secant_norm) and secant_norm > 1.0e-18:
                scale = float(ds) / secant_norm
                predictor_u_init = u_prev + scale * secant_u
                lambda_predictor = float(lambda_prev) + scale * float(secant_lambda)
                if secant_d is not None and damage_arc_weight > 0.0:
                    predictor_d_init = torch.minimum(
                        torch.maximum(d_prev + scale * secant_d, d_prev),
                        torch.ones_like(d_prev))
        if damage_control_index is not None:
            predictor_d_init = predictor_d_init.clone()
            predictor_d_init[damage_control_index] = min(
                1.0, float(d_prev[damage_control_index].item())
                + float(damage_control_increment))
        q_seed[q_fixed] = lambda_predictor * unit_flat[q_fixed]
        f_ext_flat = f_ext_ref.detach().cpu().numpy().astype(np.float64).reshape(-1)
        mechanics_predictor_converged = False
        mechanics_predictor_residual = math.inf
        if self.use_block_preconditioner:
            # A boundary-only predictor leaves a large mechanics imbalance on
            # the public rigid-pin mesh. Use the established reduced Riks
            # mechanics path at frozen accepted damage so the coupled Newton
            # process starts from a mechanically equilibrated point.
            from .mechanics_solver import QuasiStaticSolver

            if self._mechanics_linearizer is None:
                self._mechanics_linearizer = QuasiStaticSolver(
                    self.fem, tol=self.tol, max_iter=max(20, self.max_newton),
                    backend="scipy")
            if (fixed_load is None and damage_control_index is None
                    and fracture_energy_target is None):
                predictor_u, predictor_lambda, predictor_converged, _ = (
                    self._mechanics_linearizer.solve_arc_length_dirichlet_mpc(
                        d_prev, f_ext_ref, bc_mask, bc_unit_vals,
                        u_prev=u_prev, lambda_prev=lambda_prev,
                        lambda_init=lambda_predictor, ds=ds, alpha=alpha,
                        u_init=predictor_u_init,
                        rigid_connectors=rigid_connectors))
                mechanics_predictor_residual = float(
                    self._mechanics_linearizer.last_arc_length_residual)
            else:
                predictor_load = (float(fixed_load) if fixed_load is not None
                                  else float(lambda_predictor))
                fixed_mechanics = self._fixed_load_mechanics_solver()
                predictor_u, predictor_converged, _ = fixed_mechanics.solve(
                    d_prev, predictor_load * f_ext_ref, bc_mask,
                    predictor_load * bc_unit_vals, u_init=u_prev,
                    rigid_connectors=rigid_connectors)
                predictor_lambda = predictor_load
                mechanics_predictor_residual = float(
                    fixed_mechanics.last_residual)
            if predictor_converged:
                mechanics_predictor_converged = True
                lambda_predictor = float(predictor_lambda)
                seed_flat = predictor_u.detach().cpu().numpy().astype(
                    np.float64).reshape(-1)
                q_seed = np.zeros(n_dof + n_rc, dtype=np.float64)
                q_seed[:n_dof] = seed_flat
                q_seed[n_dof:] = _infer_rigid_connector_thetas(
                    seed_flat, rigid_connectors, self.fem)
                q_seed[q_fixed] = lambda_predictor * unit_flat[q_fixed]

        x = np.concatenate((q_seed[free_idx], predictor_d_init.detach().cpu().numpy(),
                            np.asarray([lambda_predictor])))
        disp_weight = 1.0 / max(1, u_prev.numel())
        if (pf_dirichlet_mask is None) != (pf_dirichlet_values is None):
            raise ValueError(
                "pass both pf_dirichlet_mask and pf_dirichlet_values, or neither")
        fixed_pf = (None if pf_dirichlet_mask is None else pf_dirichlet_mask.to(
            device=device, dtype=torch.bool))
        fixed_pf_values = (None if pf_dirichlet_values is None else pf_dirichlet_values.to(
            device=device, dtype=dtype))
        if fixed_pf is not None and (fixed_pf.shape != d_prev.shape
                                     or fixed_pf_values.shape != d_prev.shape):
            raise ValueError("phase-field Dirichlet arrays must match d_prev")

        def unpack(values: np.ndarray) -> tuple[np.ndarray, torch.Tensor, float, torch.Tensor]:
            q = q_seed.copy()
            q[free_idx] = values[:n_q_free]
            lam = float(values[-1])
            q[q_fixed] = lam * unit_flat[q_fixed]
            u = q_to_u(q)
            # Do not project here: finite-difference Krylov products need the
            # frozen-active-set residual to remain linear in the perturbation.
            # Feasibility is enforced only before accepting an outer line step.
            d = torch.as_tensor(values[n_q_free:-1], dtype=dtype, device=device)
            if fixed_pf is not None:
                d = torch.where(fixed_pf, fixed_pf_values, d)
            return q, d, lam, u

        def project_feasible(values: np.ndarray) -> np.ndarray:
            """Project an outer trial onto the irreversible damage interval.

            The finite-difference operator must remain unprojected, but a
            semismooth outer Newton candidate may contain a tiny outward
            component at a bound. Rejecting it for every positive line-search
            length would prevent an active-set update altogether. Projection
            is therefore applied only after GMRES, before merit evaluation;
            the next outer iteration refreshes the active set from this state.
            """
            out = values.copy()
            lower = d_prev.detach().cpu().numpy()
            damage = np.maximum(out[n_q_free:-1], lower)
            damage = np.minimum(damage, 1.0)
            if fixed_pf is not None:
                fixed_np = fixed_pf.detach().cpu().numpy()
                values_np = fixed_pf_values.detach().cpu().numpy()
                damage[fixed_np] = values_np[fixed_np]
            out[n_q_free:-1] = damage
            if fixed_load is not None:
                out[-1] = float(fixed_load)
            return out

        def history_for(u: torch.Tensor, *, active: torch.Tensor | None) -> tuple[torch.Tensor, torch.Tensor]:
            psi = self.fem.compute_driving_force(u, d=None)
            if active is None:
                active = psi > H_prev
            return torch.where(active, psi, H_prev), active

        def damage_active(residual: torch.Tensor, d: torch.Tensor,
                          primal_dual_scale: float | torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
            fixed = d_prev >= 1.0 - 1.0e-12
            if fixed_pf is not None:
                fixed = fixed | fixed_pf
            return _semismooth_damage_active_set(
                residual=residual, d=d, d_prev=d_prev,
                primal_dual_scale=primal_dual_scale,
                fixed=fixed)

        def damage_active_scale(H: torch.Tensor, d: torch.Tensor) -> float | torch.Tensor:
            if self.damage_active_set_diagonal_theta == 0.0:
                return self.damage_active_set_scale
            damage_diagonal = self._assemble_damage_block(H).diagonal()
            if (not np.isfinite(damage_diagonal).all()
                    or np.any(damage_diagonal < 0.0)):
                raise RuntimeError(
                    "damage tangent diagonal must be non-negative and finite")
            scale = np.zeros_like(damage_diagonal)
            supported = damage_diagonal > 0.0
            scale[supported] = (
                self.damage_active_set_diagonal_theta / damage_diagonal[supported])
            return torch.as_tensor(
                scale,
                dtype=d.dtype, device=d.device)

        def kkt_converged(certificate: dict[str, float | int | bool],
                          H: torch.Tensor) -> bool:
            if self.damage_kkt_relative_tolerance is None:
                return float(certificate["kkt_projected_linf"]) <= self.tol
            # The raw obstacle residual includes valid lower-bound
            # multipliers. Normalize the projected KKT violation by the
            # assembled right-hand side, not by that multiplier-contaminated
            # residual norm. This matches the outer continuation certificate.
            rhs = self.damage_solver.compute_residual(H, torch.zeros_like(d_prev))
            relative = float(certificate["kkt_projected_l2"]) / max(
                float(torch.linalg.vector_norm(rhs).item()), 1.0e-16)
            return relative <= self.damage_kkt_relative_tolerance

        def residual_function(values: np.ndarray, *, history_active: torch.Tensor,
                              lower_active: torch.Tensor, upper_active: torch.Tensor,
                              fixed_active: torch.Tensor,
                              scales: np.ndarray) -> np.ndarray:
            q, d, lam, u = unpack(values)
            H, _ = history_for(u, active=history_active)
            r_full = lam * f_ext_flat - self.fem.internal_force(u, d).detach().cpu().numpy().reshape(-1)
            r_q = np.asarray(T_csr.T @ r_full, dtype=np.float64)[free_idx]
            r_d = self.damage_solver.compute_residual(H, d)
            r_d_np = r_d.detach().cpu().numpy().astype(np.float64)
            # Semismooth active-set equations replace stationarity only on
            # constrained damage entries. They are refreshed at outer steps.
            d_np = d.detach().cpu().numpy().astype(np.float64)
            r_d_np[lower_active | fixed_active] = (
                d_np[lower_active | fixed_active]
                - d_prev.detach().cpu().numpy()[lower_active | fixed_active])
            r_d_np[upper_active] = d_np[upper_active] - 1.0
            if damage_control_index is not None:
                control_residual = (
                    float(d[damage_control_index].item())
                    - float(d_prev[damage_control_index].item())
                    - float(damage_control_increment))
            elif fracture_energy_target is not None:
                control_residual = (
                    _fracture_energy_value(self.fem, d)
                    - float(fracture_energy_target))
            elif fixed_load is None:
                control_residual = _arc_constraint_value(
                    u=u, u_prev=u_prev, d=d, d_prev=d_prev,
                    load_factor=lam, lambda_prev=lambda_prev, alpha=alpha,
                    ds=ds, damage_arc_weight=damage_arc_weight)
            else:
                control_residual = lam - float(fixed_load)
            raw = np.concatenate((r_q, r_d_np, np.asarray([control_residual])))
            return raw / scales

        previous_history_active = None
        previous_lower_active = None
        previous_upper_active = None
        converged = False
        residual_l2 = math.inf
        damage_certificate: dict[str, float | int | bool] = {}
        final_H = H_prev.clone()
        iteration_diagnostics: list[dict[str, float | int | bool]] = []
        for outer in range(self.max_newton):
            _, d, _lam, u = unpack(x)
            H, history_active = history_for(u, active=None)
            history_driving_force = self.fem.compute_driving_force(u, d=None)
            history_scale = torch.maximum(
                torch.maximum(history_driving_force.abs(), H_prev.abs()),
                torch.ones_like(H_prev))
            history_near_tie = (history_driving_force - H_prev).abs() <= (
                1.0e-10 * history_scale)
            raw_d = self.damage_solver.compute_residual(H, d)
            lower_active, upper_active, fixed_active = damage_active(
                raw_d, d, damage_active_scale(H, d))
            # Fixed block scales avoid one physical residual dominating GMRES.
            # The full force vector includes reactions on prescribed master
            # and slave coordinates. Scale the mechanics block by exactly the
            # free reduced residual used in ``residual_function`` and in the
            # external MPC certificate; otherwise large reactions can hide a
            # poorly converged free-equilibrium row from the coupled merit.
            raw_mech_full = self.fem.internal_force(u, d) - _lam * f_ext_ref
            raw_mech = np.asarray(
                T_csr.T @ raw_mech_full.detach().cpu().numpy().reshape(-1),
                dtype=np.float64)[free_idx]
            mech_scale = max(float(np.linalg.norm(raw_mech)), 1.0)
            damage_scale = max(float(torch.linalg.vector_norm(raw_d).item()), 1.0)
            scales = np.concatenate((
                np.full(n_q_free, mech_scale),
                np.full(d_prev.numel(), damage_scale),
                # A local damage-control equation has units of damage, unlike
                # the quadratic arc equation.  Scaling it by ``ds**2`` makes
                # the control row dominate the Krylov merit by orders of
                # magnitude and is not a valid continuation linearization.
                np.asarray([(
                    damage_scale if (damage_control_index is not None
                                     or fracture_energy_target is not None)
                    else max(ds * ds, 1.0e-12) if fixed_load is None else 1.0
                )]),
            ))
            residual = residual_function(
                x, history_active=history_active, lower_active=lower_active,
                upper_active=upper_active, fixed_active=fixed_active, scales=scales)
            residual_l2 = float(np.linalg.norm(residual))
            damage_certificate = damage_kkt_metrics(raw_d, d, d_prev, fixed=fixed_active)
            history_stable = (previous_history_active is not None
                              and bool(torch.equal(history_active, previous_history_active)))
            diagnostic = {
                "outer_iteration": outer + 1,
                "residual_l2": residual_l2,
                "mechanics_residual_l2": float(np.linalg.norm(raw_mech)),
                "damage_kkt_relative": float(damage_certificate["kkt_projected_l2"])
                / max(float(torch.linalg.vector_norm(raw_d).item()), 1.0e-16),
                "history_active_count": int(history_active.sum().item()),
                "history_active_stable": history_stable,
                "history_near_tie_count": int(history_near_tie.sum().item()),
                "history_active_changed_count": (
                    None if previous_history_active is None else int(
                        torch.count_nonzero(
                            history_active ^ previous_history_active).item())),
                "damage_lower_active_count": int(lower_active.sum().item()),
                "damage_upper_active_count": int(upper_active.sum().item()),
                "damage_active_set_diagonal_theta": (
                    self.damage_active_set_diagonal_theta),
                "damage_lower_active_changed_count": (
                    None if previous_lower_active is None else int(
                        torch.count_nonzero(
                            lower_active ^ previous_lower_active).item())),
                "damage_upper_active_changed_count": (
                    None if previous_upper_active is None else int(
                        torch.count_nonzero(
                            upper_active ^ previous_upper_active).item())),
            }
            # Fixed-load continuation is accepted only after the final exact
            # mechanics polish, so this small scaled-residual buffer merely
            # permits one deterministic active-set refresh before that polish.
            # The public acceptance gate below remains ``self.tol`` on the
            # recomputed reduced mechanics residual and target-load error.
            inner_tolerance = (
                10.0 * self.tol if fixed_load is not None else self.tol)
            if (residual_l2 <= inner_tolerance and history_stable
                    and kkt_converged(damage_certificate, H)):
                converged = True
                final_H = H
                diagnostic["accepted_line_search"] = True
                diagnostic["line_search_reduction"] = 0
                iteration_diagnostics.append(diagnostic)
                break

            def matvec(direction: np.ndarray) -> np.ndarray:
                norm_v = float(np.linalg.norm(direction))
                if norm_v == 0.0:
                    return np.zeros_like(direction)
                eps = math.sqrt(np.finfo(np.float64).eps) * max(
                    1.0, float(np.linalg.norm(x))) / norm_v
                return (residual_function(
                    x + eps * direction, history_active=history_active,
                    lower_active=lower_active, upper_active=upper_active,
                    fixed_active=fixed_active, scales=scales) - residual) / eps

            preconditioner = None
            if self.use_block_preconditioner:
                preconditioner = self._build_block_preconditioner(
                    u=u, d=d, H=H, T_csr=T_csr, free_idx=free_idx,
                    n_dof=n_dof, n_rc=n_rc,
                    damage_active=(lower_active | upper_active | fixed_active),
                    scales=scales, n_q_free=n_q_free, u_prev=u_prev,
                    lambda_current=_lam, lambda_prev=lambda_prev,
                    alpha=alpha, disp_weight=disp_weight, q_fixed=q_fixed,
                    unit_flat=unit_flat, f_ext_ref=f_ext_ref,
                    fixed_load=fixed_load,
                    damage_control_index=damage_control_index,
                    fracture_energy_target=fracture_energy_target,
                    history_active=history_active,
                    damage_arc_weight=damage_arc_weight,
                    d_prev=d_prev)
            step = self._gmres(matvec, -residual, preconditioner=preconditioner)
            accepted = False
            best_trial_residual_l2 = math.inf
            for reduction in range(self.line_search_max_reductions):
                trial = project_feasible(x + (0.5 ** reduction) * step)
                _, trial_d, _trial_lam, trial_u = unpack(trial)
                # The default globalisation evaluates the refreshed piecewise
                # residual. The alternate merit uses the frozen branch of the
                # semismooth JVP, then forces a refreshed branch/KKT test at
                # the next outer iterate and before final acceptance.
                trial_H, trial_history_active = history_for(trial_u, active=None)
                trial_r_d = self.damage_solver.compute_residual(trial_H, trial_d)
                trial_lower_active, trial_upper_active, trial_fixed_active = damage_active(
                    trial_r_d, trial_d, damage_active_scale(trial_H, trial_d))
                trial_certificate = damage_kkt_metrics(
                    trial_r_d, trial_d, d_prev, fixed=trial_fixed_active)
                if self.line_search_mode == "refreshed":
                    trial_residual = residual_function(
                        trial, history_active=trial_history_active,
                        lower_active=trial_lower_active, upper_active=trial_upper_active,
                        fixed_active=trial_fixed_active, scales=scales)
                else:
                    trial_residual = residual_function(
                        trial, history_active=history_active,
                        lower_active=lower_active, upper_active=upper_active,
                        fixed_active=fixed_active, scales=scales)
                trial_residual_l2 = float(np.linalg.norm(trial_residual))
                best_trial_residual_l2 = min(
                    best_trial_residual_l2, trial_residual_l2)
                if reduction == 0:
                    diagnostic["line_search_full_residual_l2"] = trial_residual_l2
                if (bool(trial_certificate["kkt_feasible"])
                        and np.isfinite(trial_residual).all()
                        and trial_residual_l2 < residual_l2):
                    x = trial
                    accepted = True
                    diagnostic["accepted_line_search"] = True
                    diagnostic["line_search_reduction"] = reduction
                    diagnostic["line_search_mode"] = self.line_search_mode
                    break
            if not accepted:
                diagnostic["accepted_line_search"] = False
                diagnostic["line_search_reduction"] = -1
                diagnostic["line_search_mode"] = self.line_search_mode
            diagnostic["gmres_info"] = self.last_gmres_info
            diagnostic["line_search_best_residual_l2"] = best_trial_residual_l2
            iteration_diagnostics.append(diagnostic)
            if not accepted:
                if (fixed_load is not None
                        and residual_l2 <= 10.0 * self.tol
                        and kkt_converged(damage_certificate, H)):
                    # The trial line search can legitimately have no descent
                    # once the state is already within the scaled fixed-load
                    # inner tolerance. Repeat the same state once so the
                    # hard-max branch is observed to be deterministic before
                    # invoking the strict fixed-damage mechanics polish.
                    previous_history_active = history_active.clone()
                    previous_lower_active = lower_active.clone()
                    previous_upper_active = upper_active.clone()
                    final_H = H
                    continue
                break
            previous_history_active = history_active.clone()
            previous_lower_active = lower_active.clone()
            previous_upper_active = upper_active.clone()
            final_H = H

        _, d_final, lambda_final, u_final = unpack(x)
        final_H, final_active = history_for(u_final, active=None)
        final_damage_residual = self.damage_solver.compute_residual(final_H, d_final)
        damage_certificate = damage_kkt_metrics(
            final_damage_residual, d_final, d_prev, fixed=fixed_pf)
        # A prior outer mask is a globalization diagnostic, not the physical
        # history fixed-point condition. A tiny accepted arc step can already
        # satisfy the physical KKT system before it accepts a Newton update,
        # leaving no previous mask to compare. Re-evaluate the hard maximum
        # from the final state itself; the ensuing KKT and mechanics-polish
        # gates still use this physical history field.
        rechecked_final_H, rechecked_final_active = history_for(
            u_final, active=None)
        final_history_stable = bool(
            torch.equal(final_active, rechecked_final_active)
            and torch.allclose(final_H, rechecked_final_H, rtol=0.0,
                               atol=1.0e-14)
            and torch.all(final_H >= H_prev))
        mechanics_polish_converged = False
        mechanics_polish_residual = math.inf
        mechanics_polish_arc_constraint = math.inf
        mechanics_polish_residuals: list[float] = []

        # If the coupled solve has closed the history/damage residual but a
        # final damage update left a small mechanics imbalance, use the same
        # reduced-coordinate Riks primitive that supplied the predictor to
        # restore equilibrium at fixed damage. Recheck all hard-history/KKT
        # conditions afterwards; this is not an acceptance relaxation.
        # The outer semismooth merit is scaled for Krylov globalization, so a
        # nonzero scaled value alone is not a physical certificate failure.
        # Once the *unscaled* KKT conditions and hard-history fixed point are
        # satisfied, the exact reduced-coordinate mechanics polish is the
        # appropriate final coupled check. Its post-polish certificate below
        # still enforces mechanics, arc control, history, and KKT gates before
        # it can set ``converged``. This only avoids discarding a candidate
        # because an active-set merit stalled after the actual KKT condition
        # had already closed.
        final_damage_kkt_converged = kkt_converged(
            damage_certificate, final_H)
        final_certificate_ready = (
            final_history_stable and final_damage_kkt_converged)
        polish_ready = (
            require_mechanics_polish
            and self.use_block_preconditioner
            and self._mechanics_linearizer is not None
            and final_certificate_ready
        )
        if polish_ready:
            polish_load = (float(lambda_final) if (damage_control_index is not None
                                                   or fracture_energy_target is not None)
                           else fixed_load)
            local_mechanics_scale = max(
                float(torch.linalg.vector_norm(
                    self.fem.internal_force(u_final, d_final)).item()),
                float(torch.linalg.vector_norm(lambda_final * f_ext_ref).item()),
                1.0)
            mechanics_polish_tolerance = self.tol
            if ((damage_control_index is not None
                    or fracture_energy_target is not None)
                    and self.mechanics_relative_tolerance is not None):
                mechanics_polish_tolerance = max(
                    self.tol,
                    self.mechanics_relative_tolerance * local_mechanics_scale)
            if polish_load is None:
                mechanical_radius_sq = _mechanical_radius_squared(
                    d=d_final, d_prev=d_prev, ds=ds,
                    damage_arc_weight=damage_arc_weight)
                if mechanical_radius_sq > 0.0:
                    polished_u, polished_lambda, polished_converged, _ = (
                        self._mechanics_linearizer.solve_arc_length_dirichlet_mpc(
                            d_final, f_ext_ref, bc_mask, bc_unit_vals,
                            u_prev=u_prev, lambda_prev=lambda_prev,
                            lambda_init=lambda_final,
                            ds=math.sqrt(mechanical_radius_sq), alpha=alpha,
                            u_init=u_final, rigid_connectors=rigid_connectors))
                    mechanics_polish_residual = float(
                        self._mechanics_linearizer.last_arc_length_residual)
                    mechanics_polish_arc_constraint = float(
                        self._mechanics_linearizer.last_arc_length_constraint)
                else:
                    polished_u = u_final.detach()
                    polished_lambda = float(lambda_final)
                    polished_converged = False
                    mechanics_polish_residual = math.inf
                    mechanics_polish_arc_constraint = math.inf
            else:
                # Sparse MPC mechanics on the public Amor mesh is expensive
                # per factorisation. Take a bounded sequence of one-step
                # reduced Newton corrections and evaluate the *post-step*
                # residual ourselves. This avoids an opaque 20-iteration
                # mechanics call while keeping the same strict residual gate.
                polished_u = u_final.detach()
                polished_force = (
                    float(polish_load) * f_ext_ref
                    - self.fem.internal_force(polished_u, d_final))
                polished_reduced = np.asarray(
                    T_csr.T @ polished_force.detach().cpu().numpy().reshape(-1),
                    dtype=np.float64)[free_idx]
                mechanics_polish_residual = float(np.linalg.norm(polished_reduced))
                polished_converged = bool(
                    math.isfinite(mechanics_polish_residual)
                    and mechanics_polish_residual <= mechanics_polish_tolerance)
                if polished_converged:
                    mechanics_polish_residuals.append(mechanics_polish_residual)
                fixed_mechanics = self._fixed_load_mechanics_solver()
                original_max_iter = fixed_mechanics.max_iter
                try:
                    if not polished_converged:
                        fixed_mechanics.max_iter = 1
                        for polish_iteration in range(min(12, self.max_newton)):
                            candidate_u, _solver_flag, _ = fixed_mechanics.solve(
                                d_final, float(polish_load) * f_ext_ref, bc_mask,
                                float(polish_load) * bc_unit_vals, u_init=polished_u,
                                rigid_connectors=rigid_connectors)
                            candidate_force = (
                                float(polish_load) * f_ext_ref
                                - self.fem.internal_force(candidate_u, d_final))
                            candidate_reduced = np.asarray(
                                T_csr.T @ candidate_force.detach().cpu().numpy().reshape(-1),
                                dtype=np.float64)[free_idx]
                            candidate_residual = float(np.linalg.norm(candidate_reduced))
                            mechanics_polish_residuals.append(candidate_residual)
                            # A correction is useful only when it improves the
                            # reduced equilibrium certificate. Retaining the
                            # best coupled state prevents a failed tangent
                            # polish from replacing a lower-residual iterate.
                            if candidate_residual < mechanics_polish_residual:
                                polished_u = candidate_u
                                mechanics_polish_residual = candidate_residual
                            if math.isfinite(mechanics_polish_residual) and (
                                    mechanics_polish_residual <= mechanics_polish_tolerance):
                                polished_converged = True
                                break
                finally:
                    fixed_mechanics.max_iter = original_max_iter
                polished_lambda = float(polish_load)
                mechanics_polish_arc_constraint = (
                    abs(float(d_final[damage_control_index].item())
                        - float(d_prev[damage_control_index].item())
                        - float(damage_control_increment))
                    if damage_control_index is not None else (
                        abs(_fracture_energy_value(self.fem, d_final)
                            - float(fracture_energy_target))
                        if fracture_energy_target is not None
                        else abs(float(polished_lambda) - float(polish_load))))
            polished_H, polished_active = history_for(polished_u, active=None)
            polished_damage_residual = self.damage_solver.compute_residual(
                polished_H, d_final)
            polished_certificate = damage_kkt_metrics(
                polished_damage_residual, d_final, d_prev, fixed=fixed_pf)
            polished_arc = (
                (float(d_final[damage_control_index].item())
                 - float(d_prev[damage_control_index].item())
                 - float(damage_control_increment))
                if damage_control_index is not None else (
                    _fracture_energy_value(self.fem, d_final)
                    - float(fracture_energy_target)
                    if fracture_energy_target is not None else _arc_constraint_value(
                    u=polished_u, u_prev=u_prev, d=d_final, d_prev=d_prev,
                    load_factor=float(polished_lambda), lambda_prev=lambda_prev,
                    alpha=alpha, ds=ds, damage_arc_weight=damage_arc_weight)
                    if polish_load is None else float(polished_lambda) - float(polish_load)))
            # The mechanics polish changes displacement, so equality with the
            # preceding Newton mask is not a valid fixed-point condition. The
            # correct check is that hard-max history is deterministic at the
            # polished state and remains irreversible relative to H_prev.
            rechecked_H, rechecked_active = history_for(polished_u, active=None)
            polished_mask_fixed = bool(torch.equal(polished_active, rechecked_active))
            polished_field_fixed = bool(torch.allclose(
                polished_H, rechecked_H, rtol=0.0, atol=1.0e-14))
            polished_history_irreversible = bool(torch.all(polished_H >= H_prev))
            polished_history_stable = bool(
                polished_mask_fixed and polished_field_fixed
                and polished_history_irreversible)
            # The direct mechanics primitive may return ``False`` after a
            # line-search stall even though its final residual and constraint
            # already satisfy the declared gate. Use the numerical mechanics
            # certificate itself, not that opaque control-flow flag.
            polished_gate_passed = (math.isfinite(mechanics_polish_residual)
                    and math.isfinite(mechanics_polish_arc_constraint)
                    and mechanics_polish_residual <= mechanics_polish_tolerance
                    and abs(mechanics_polish_arc_constraint) <= self.tol
                    and abs(polished_arc) <= self.tol
                    and polished_history_stable
                    and kkt_converged(polished_certificate, polished_H))
            iteration_diagnostics.append({
                "outer_iteration": len(iteration_diagnostics) + 1,
                "mechanics_polish": True,
                "control_mode": control_mode,
                "mechanics_polish_solver_flag": bool(polished_converged),
                "mechanics_polish_gate_passed": bool(polished_gate_passed),
                "mechanics_polish_residual": mechanics_polish_residual,
                "mechanics_polish_arc_constraint": mechanics_polish_arc_constraint,
                "arc_constraint": float(polished_arc),
                "mechanics_polish_kkt_linf": float(
                    polished_certificate["kkt_projected_linf"]),
                "mechanics_polish_residuals": mechanics_polish_residuals,
                "history_active_count": int(polished_active.sum().item()),
                "history_mask_fixed": polished_mask_fixed,
                "history_field_fixed": polished_field_fixed,
                "history_irreversible": polished_history_irreversible,
                "history_active_stable": polished_history_stable,
            })
            if polished_gate_passed:
                u_final = polished_u.detach()
                lambda_final = float(polished_lambda)
                final_H = polished_H.detach()
                final_active = polished_active
                damage_certificate = polished_certificate
                final_history_stable = polished_history_stable
                mechanics_polish_converged = True
                converged = True
        # ``require_mechanics_polish`` is a solver contract, not a reporting
        # preference. A semismooth iterate may close its frozen residual while
        # the final reduced-MPC correction still fails. Never expose that
        # state as converged when the caller requested the polish certificate.
        if require_mechanics_polish and not mechanics_polish_converged:
            converged = False
        return SemismoothArcResult(
            u=u_final.detach(), d=d_final.detach(), H_elem=final_H.detach(),
            load_factor=lambda_final, converged=converged, iterations=outer + 1,
            residual_l2=residual_l2,
            history_active_stable=final_history_stable,
            damage_kkt=damage_certificate,
            iteration_diagnostics=iteration_diagnostics,
            mechanics_predictor_converged=mechanics_predictor_converged,
            mechanics_predictor_residual=mechanics_predictor_residual,
            mechanics_polish_converged=mechanics_polish_converged,
            mechanics_polish_residual=mechanics_polish_residual,
            mechanics_polish_arc_constraint=mechanics_polish_arc_constraint,
            mechanics_polish_required=bool(require_mechanics_polish),
            control_mode=control_mode,
            target_load=None if fixed_load is None else float(fixed_load),
            fracture_energy_target=fracture_energy_target,
            damage_arc_weight=float(damage_arc_weight),
            damage_active_set_scale=float(self.damage_active_set_scale),
        )

    def _fixed_load_mechanics_solver(self):
        """Return an MPC mechanics solver with the consistent Amor tangent.

        The sparse-direct MPC route intentionally uses a frozen secant tangent
        for Amor/spectral materials. That approximation is useful inside the
        block preconditioner, but its full fixed-load Newton correction need
        not be a descent direction. The CG backend retains the established
        autograd-JVP tangent and the reduced residual line search.
        """
        from .mechanics_solver import QuasiStaticSolver

        if self._fixed_load_mechanics is None:
            self._fixed_load_mechanics = QuasiStaticSolver(
                self.fem, tol=self.tol, max_iter=max(20, self.max_newton),
                cg_max_iter=self.mechanics_polish_cg_maxiter, backend="cg")
        return self._fixed_load_mechanics

    def _build_block_preconditioner(
            self, *, u: torch.Tensor, d: torch.Tensor, H: torch.Tensor,
            T_csr, free_idx: np.ndarray, n_dof: int, n_rc: int,
            damage_active: torch.Tensor, scales: np.ndarray,
            n_q_free: int, u_prev: torch.Tensor, lambda_current: float,
            lambda_prev: float, alpha: float, disp_weight: float,
            q_fixed: np.ndarray, unit_flat: np.ndarray,
            f_ext_ref: torch.Tensor,
            fixed_load: float | None = None,
            damage_control_index: int | None = None,
            fracture_energy_target: float | None = None,
            history_active: torch.Tensor | None = None,
            damage_arc_weight: float = 0.0,
            d_prev: torch.Tensor | None = None) -> Callable[[np.ndarray], np.ndarray]:
        """Factor frozen reduced mechanics/damage blocks for right preconditioning.

        The semismooth Jacobian is not block diagonal: load and history/damage
        couplings remain in the matrix-free operator.  This preconditioner
        nevertheless removes the two dominant elliptic blocks while GMRES
        resolves the remaining coupling and control row.
        """
        from scipy import sparse as sp
        from scipy.sparse.linalg import splu
        from .mechanics_solver import QuasiStaticSolver

        if (getattr(self.damage_solver, "_native_q4_damage", False)
                or getattr(self.damage_solver, "_nodal_H", False)
                or self.damage_solver._viscous_coefficient() > 0.0):
            raise NotImplementedError(
                "block-preconditioned semismooth arc solve currently supports "
                "non-viscous element-history T3 AT1/AT2 damage only")

        if self._mechanics_linearizer is None:
            self._mechanics_linearizer = QuasiStaticSolver(
                self.fem, tol=self.tol, max_iter=1, backend="scipy")
        split = getattr(self.fem.material, "energy_split", "isotropic")
        if split == "isotropic":
            indices, values, n_dof_check = self._mechanics_linearizer._assemble_K_isotropic(d)
        else:
            indices, values, n_dof_check = self._mechanics_linearizer._assemble_K_secant(u, d)
        if int(n_dof_check) != int(n_dof):
            raise RuntimeError("mechanics preconditioner tangent dimension changed")
        K_full = sp.coo_matrix(
            (values.detach().cpu().numpy().astype(np.float64),
             (indices[0].detach().cpu().numpy(), indices[1].detach().cpu().numpy())),
            shape=(n_dof, n_dof)).tocsr()
        K_reduced = (T_csr.T @ K_full @ T_csr).tocsr()
        K_factor = splu(K_reduced[free_idx][:, free_idx].tocsc())

        A_damage = self._assemble_damage_block(H)
        active = damage_active.detach().cpu().numpy().astype(bool)
        if np.any(active):
            keep = (~active).astype(np.float64)
            A_damage = (sp.diags(keep) @ A_damage @ sp.diags(keep)).tolil()
            A_damage[active, active] = 1.0
            A_damage = A_damage.tocsc()
        else:
            A_damage = A_damage.tocsc()
        # This matrix is a preconditioner block, not the physical damage
        # operator. Near a localization event an active-set elimination can
        # leave an almost singular free block. A scale-aware diagonal shift
        # stabilizes the factorization while the unmodified residual/KKT rows
        # remain the sole convergence and acceptance criteria.
        damage_diagonal = np.abs(A_damage.diagonal())
        damage_regularization = max(
            float(np.max(damage_diagonal, initial=0.0)), 1.0) * 1.0e-8
        A_factor = splu((A_damage + damage_regularization * sp.eye(
            A_damage.shape[0], format="csc")).tocsc())
        n_damage = A_damage.shape[0]

        mechanics_scale = scales[:n_q_free]
        damage_scale = scales[n_q_free:n_q_free + n_damage]
        control_scale = float(scales[-1])
        if fixed_load is not None:
            # The fixed-load Jacobian has a prescribed scalar control row,
            # ``d(lambda - lambda_target)/d(lambda) = 1``. Reusing the Riks
            # Schur complement here couples this row to displacement and can
            # turn an otherwise diagonal control correction into a poor
            # preconditioner on the public mesh.
            def apply_fixed_load(rhs: np.ndarray) -> np.ndarray:
                raw_q = rhs[:n_q_free] * mechanics_scale
                raw_d = rhs[n_q_free:n_q_free + n_damage] * damage_scale
                q = -K_factor.solve(raw_q)
                damage = A_factor.solve(raw_d)
                lam = rhs[-1] * control_scale
                if not (np.isfinite(q).all() and np.isfinite(damage).all()
                        and math.isfinite(float(lam))):
                    raise RuntimeError("non-finite fixed-load block preconditioner application")
                return np.concatenate((q, damage, np.asarray([lam])))

            return apply_fixed_load

        if fracture_energy_target is not None:
            if history_active is None:
                raise ValueError(
                    "fracture-energy control requires the frozen history branch")
            def apply_energy_diagonal(rhs: np.ndarray) -> np.ndarray:
                raw_q = rhs[:n_q_free] * mechanics_scale
                raw_d = rhs[n_q_free:n_q_free + n_damage] * damage_scale
                q = -K_factor.solve(raw_q)
                damage = A_factor.solve(raw_d)
                lam = rhs[-1] * control_scale
                if not (np.isfinite(q).all() and np.isfinite(damage).all()
                        and math.isfinite(float(lam))):
                    raise RuntimeError(
                        "non-finite diagonal fracture-energy preconditioner application")
                return np.concatenate((q, damage, np.asarray([lam])))

            # The exact matrix-free Jacobian carries the energy/load coupling.
            # A block-diagonal preconditioner is deliberately used here: the
            # frozen active-set Schur estimate becomes ill-conditioned as the
            # crack initiates and must not contaminate a bounded Krylov solve.
            return apply_energy_diagonal

        if damage_control_index is not None:
            if history_active is None:
                raise ValueError("local damage control requires the frozen history branch")
            control_index = int(damage_control_index)
            if not 0 <= control_index < n_damage:
                raise ValueError("local damage-control index is outside the damage block")

            # Prescribed local damage determines the load through the frozen
            # history-to-damage coupling. This block triangular approximation
            # retains that scalar sensitivity while the matrix-free JVP keeps
            # the full mechanics/damage coupling for the actual Newton step.
            q_lambda_full = np.zeros(n_dof + n_rc, dtype=np.float64)
            q_lambda_full[q_fixed] = unit_flat[q_fixed]
            u_hat = torch.as_tensor(
                (T_csr @ q_lambda_full).reshape(-1, 2),
                dtype=u.dtype, device=u.device)
            b_q = np.asarray(T_csr.T @ (
                f_ext_ref.detach().cpu().numpy().reshape(-1)
                - K_full @ u_hat.detach().cpu().numpy().reshape(-1)),
                dtype=np.float64)[free_idx]
            q_lambda = K_factor.solve(b_q)
            q_lambda_full[free_idx] = q_lambda
            u_lambda = torch.as_tensor(
                (T_csr @ q_lambda_full).reshape(-1, 2),
                dtype=u.dtype, device=u.device)
            direction_norm = float(torch.linalg.vector_norm(u_lambda).item())
            eps = math.sqrt(np.finfo(np.float64).eps) * max(
                1.0, float(torch.linalg.vector_norm(u).item())) / max(
                    direction_norm, 1.0e-16)
            psi = self.fem.compute_driving_force(u, d=None)
            psi_plus = self.fem.compute_driving_force(u + eps * u_lambda, d=None)
            H_plus = torch.where(history_active, H + (psi_plus - psi), H)
            B_lambda = (
                self.damage_solver.compute_residual(H_plus, d)
                - self.damage_solver.compute_residual(H, d)
            ).detach().cpu().numpy().astype(np.float64) / eps
            damage_lambda = -A_factor.solve(B_lambda)
            control_sensitivity = float(damage_lambda[control_index])
            if (not math.isfinite(control_sensitivity)
                    or abs(control_sensitivity) < 1.0e-14):
                raise RuntimeError(
                    "local damage-control preconditioner has singular load sensitivity")

            def apply_local_damage(rhs: np.ndarray) -> np.ndarray:
                raw_q = rhs[:n_q_free] * mechanics_scale
                raw_d = rhs[n_q_free:n_q_free + n_damage] * damage_scale
                raw_control = float(rhs[-1] * control_scale)
                q_zero = -K_factor.solve(raw_q)
                damage_zero = A_factor.solve(raw_d)
                lam = (raw_control - float(damage_zero[control_index])) / control_sensitivity
                q = q_zero + q_lambda * lam
                damage = damage_zero + damage_lambda * lam
                if not (np.isfinite(q).all() and np.isfinite(damage).all()
                        and math.isfinite(lam)):
                    raise RuntimeError(
                        "non-finite local damage-control block preconditioner application")
                return np.concatenate((q, damage, np.asarray([lam])))

            return apply_local_damage

        if d_prev is None:
            raise ValueError("arc-length block preconditioner requires d_prev")

        q_hat = np.zeros(n_dof + n_rc, dtype=np.float64)
        q_hat[q_fixed] = unit_flat[q_fixed]
        u_hat = torch.as_tensor((T_csr @ q_hat).reshape(-1, 2),
                                dtype=u.dtype, device=u.device)
        arc_diagonal = (
            2.0 * disp_weight * float(((u - u_prev) * u_hat).sum().item())
            + 2.0 * alpha * alpha * (lambda_current - lambda_prev))
        delta_flat = (u - u_prev).detach().cpu().numpy().reshape(-1)
        c_q = np.asarray(2.0 * disp_weight * (T_csr.T @ delta_flat), dtype=np.float64)[free_idx]
        c_d = (2.0 * float(damage_arc_weight) / max(1, int(d.numel()))
               * (d - d_prev).detach().cpu().numpy().astype(np.float64))
        u_hat_flat = u_hat.detach().cpu().numpy().reshape(-1)
        f_ext_flat = f_ext_ref.detach().cpu().numpy().reshape(-1)
        # Holding q-free fixed, lambda changes prescribed displacement by
        # u_hat and equilibrium by f_ext - K*u_hat.
        b_q = np.asarray(T_csr.T @ (f_ext_flat - K_full @ u_hat_flat),
                         dtype=np.float64)[free_idx]
        q_lambda = K_factor.solve(b_q)
        if not (np.isfinite(c_q).all() and np.isfinite(q_lambda).all()):
            raise RuntimeError("non-finite frozen mechanics/arc preconditioner block")
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            schur = arc_diagonal + float(c_q @ q_lambda)
        if not math.isfinite(schur):
            raise RuntimeError("non-finite frozen mechanics/arc Schur complement")
        if abs(schur) < 1.0e-14:
            schur = math.copysign(1.0e-14, schur or 1.0)

        def apply(rhs: np.ndarray) -> np.ndarray:
            raw_q = rhs[:n_q_free] * mechanics_scale
            raw_d = rhs[n_q_free:n_q_free + n_damage] * damage_scale
            # Solve the frozen Riks mechanics/arc block exactly. R_q is
            # lambda*f - f_int, so its q-free tangent is -Kq.
            q_zero = -K_factor.solve(raw_q)
            damage = A_factor.solve(raw_d)
            raw_arc = rhs[-1] * control_scale
            with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                lam = (raw_arc - float(c_q @ q_zero) - float(c_d @ damage)) / schur
            q = q_zero + q_lambda * lam
            if not (np.isfinite(q).all() and np.isfinite(damage).all()
                    and math.isfinite(float(lam))):
                raise RuntimeError("non-finite block preconditioner application")
            return np.concatenate((q, damage, np.asarray([lam])))

        return apply

    def _assemble_damage_block(self, H: torch.Tensor):
        """Assemble the linear T3 AT1/AT2 damage stiffness for one frozen H."""
        from .multigrid import _assemble_sparse_cpu

        mesh = self.fem.mesh
        if self._damage_geometry is None:
            elements = mesh.elements.detach().cpu()
            areas = mesh.areas.detach().cpu().to(torch.float64)
            grad = mesh.grad_phi.detach().cpu().to(torch.float64)
            areas_col = areas[:, None, None]
            K_local = areas_col * (
                grad[:, :, 0:1] * grad[:, None, :, 0]
                + grad[:, :, 1:2] * grad[:, None, :, 1])
            rows, cols = [], []
            for row_local in range(3):
                for col_local in range(3):
                    rows.append(elements[:, row_local].numpy())
                    cols.append(elements[:, col_local].numpy())
            self._damage_geometry = (
                K_local, areas, np.concatenate(rows), np.concatenate(cols),
                int(mesh.n_nodes))
        K_local, areas, rows, cols, n_nodes = self._damage_geometry
        H_cpu = H.detach().cpu().to(torch.float64)
        ratio = self.damage_solver._Gc_over_l0_e
        if ratio is None:
            ratio = self.damage_solver._Gc_over_l0
        elif torch.is_tensor(ratio):
            ratio = ratio.detach().cpu().to(torch.float64)
        coeff = self.damage_solver._Gc_l0_e
        if coeff is None:
            coeff = self.damage_solver._Gc_l0
        elif torch.is_tensor(coeff):
            coeff = coeff.detach().cpu().to(torch.float64)
        reaction = (2.0 * H_cpu + ratio) * areas / 12.0
        return _assemble_sparse_cpu(K_local, reaction, coeff, rows, cols, n_nodes)

    def _gmres(self, matvec: Callable[[np.ndarray], np.ndarray], rhs: np.ndarray,
               *, preconditioner: Callable[[np.ndarray], np.ndarray] | None = None) -> np.ndarray:
        """Solve a left-preconditioned Krylov system with bounded Arnoldi steps.

        SciPy's compiled GMRES can overflow internally after a badly scaled
        preconditioned basis vector, bypassing the continuation driver's
        cutback ledger. This compact restarted implementation keeps every
        operation inspectable and returns an inexact finite direction at its
        declared iteration budget, as the outer residual/KKT certificate is
        still authoritative.
        """

        def checked(values: np.ndarray, *, label: str) -> np.ndarray:
            array = np.asarray(values, dtype=np.float64)
            if (array.shape != rhs.shape or not np.isfinite(array).all()
                    or np.max(np.abs(array), initial=0.0) > 1.0e100):
                raise FloatingPointError(
                    f"semismooth GMRES {label} is non-finite or exceeds the "
                    "Krylov safety magnitude")
            return array

        rhs = checked(rhs, label="right-hand side")

        def checked_matvec(direction: np.ndarray) -> np.ndarray:
            return checked(matvec(checked(direction, label="basis vector")),
                           label="Jacobian-vector product")

        def apply_left(values: np.ndarray) -> np.ndarray:
            if preconditioner is None:
                return checked(values, label="unpreconditioned residual")
            return checked(preconditioner(checked(values, label="preconditioner input")),
                           label="preconditioner output")

        # Keep the established SciPy path on small systems, where it is both
        # faster and independently exercised by the unit suite. The bounded
        # implementation below is reserved for public-mesh systems that have
        # exhibited a compiled-Arnoldi overflow.
        if rhs.size <= 10_000:
            from scipy.sparse.linalg import LinearOperator, gmres

            operator = LinearOperator(
                (rhs.size, rhs.size), matvec=checked_matvec, dtype=np.float64)
            preconditioner_op = (None if preconditioner is None else LinearOperator(
                (rhs.size, rhs.size), matvec=apply_left, dtype=np.float64))
            solution, info = gmres(
                operator, rhs, rtol=min(self.tol, 1.0e-6), atol=0.0,
                restart=min(20, rhs.size), maxiter=self.krylov_maxiter,
                M=preconditioner_op)
            solution = checked(solution, label="solution")
            self.last_gmres_info = int(info)
            if info < 0:
                raise RuntimeError(f"semismooth GMRES failed (info={info})")
            return solution

        restart = min(20, rhs.size)
        solution = np.zeros_like(rhs)
        initial_residual = apply_left(rhs)
        # Use a tighter inner threshold than the nonlinear gate. The frozen
        # block preconditioner is only approximate, so a nominally converged
        # preconditioned residual can otherwise leave no line-search descent.
        target = min(self.tol, 1.0e-8) * max(float(np.linalg.norm(initial_residual)), 1.0)
        for cycle in range(1, self.krylov_maxiter + 1):
            residual = apply_left(rhs - checked_matvec(solution))
            beta = float(np.linalg.norm(residual))
            if not math.isfinite(beta):
                raise FloatingPointError("semismooth GMRES preconditioned residual is non-finite")
            if beta <= target:
                self.last_gmres_info = 0
                return solution
            basis = np.zeros((rhs.size, restart + 1), dtype=np.float64)
            hessenberg = np.zeros((restart + 1, restart), dtype=np.float64)
            basis[:, 0] = residual / beta
            rhs_small = np.zeros(restart + 1, dtype=np.float64)
            rhs_small[0] = beta
            best_y = None
            for column in range(restart):
                vector = apply_left(checked_matvec(basis[:, column]))
                for row in range(column + 1):
                    coefficient = float(np.dot(basis[:, row], vector))
                    hessenberg[row, column] = coefficient
                    vector -= coefficient * basis[:, row]
                next_norm = float(np.linalg.norm(vector))
                if not math.isfinite(next_norm) or next_norm > 1.0e100:
                    raise FloatingPointError("semismooth GMRES Arnoldi norm is non-finite")
                hessenberg[column + 1, column] = next_norm
                rows = column + 2
                y, *_ = np.linalg.lstsq(hessenberg[:rows, :column + 1],
                                         rhs_small[:rows], rcond=None)
                if not np.isfinite(y).all() or np.max(np.abs(y), initial=0.0) > 1.0e100:
                    raise FloatingPointError("semismooth GMRES least-squares iterate is non-finite")
                best_y = y
                small_residual = float(np.linalg.norm(
                    rhs_small[:rows] - hessenberg[:rows, :column + 1] @ y))
                if not math.isfinite(small_residual):
                    raise FloatingPointError("semismooth GMRES least-squares residual is non-finite")
                if small_residual <= target:
                    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                        update = basis[:, :column + 1] @ y
                        candidate = solution + update
                    solution = checked(candidate, label="solution")
                    self.last_gmres_info = 0
                    return solution
                if next_norm <= 1.0e-14:
                    break
                basis[:, column + 1] = vector / next_norm
            if best_y is None:
                raise RuntimeError("semismooth GMRES Arnoldi iteration produced no direction")
            with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                update = basis[:, :best_y.size] @ best_y
                candidate = solution + update
            solution = checked(candidate, label="restart solution")
        self.last_gmres_info = int(self.krylov_maxiter)
        return solution


class ReducedMPCPrimalDualActiveSetCorrector:
    """Fixed-load reduced-MPC staggered corrector with exact PDAS damage rows.

    This is deliberately distinct from :class:`SemismoothArcLengthCorrector`.
    The latter forms a finite-difference Newton-Krylov system over displacement,
    damage, and (optionally) load.  This corrector keeps the prescribed load
    fixed, solves the reduced rigid-MPC mechanics equilibrium at each outer
    iteration, and solves the linear AT1/AT2 damage variational inequality by
    a primal-dual active-set method.  It is intended as a robust continuation
    diagnostic for the public notched-holed plate, not as a replacement for the
    production staggered solver.
    """

    def __init__(self, fem, damage_solver, *, tol: float = 1.0e-8,
                 max_outer: int = 20, max_active_set: int = 30,
                 damage_kkt_relative_tolerance: float | None = None,
                 damage_active_set_scale: float = 0.0,
                 damage_active_set_diagonal_theta: float = 0.0,
                 mechanics_backend: str = "scipy",
                 mechanics_max_iter: int = 8,
                 mechanics_cg_maxiter: int = 250):
        if tol <= 0.0:
            raise ValueError("tol must be positive")
        if max_outer < 1 or max_active_set < 1:
            raise ValueError("PDAS iteration limits must be positive")
        if (damage_kkt_relative_tolerance is not None
                and damage_kkt_relative_tolerance <= 0.0):
            raise ValueError("damage_kkt_relative_tolerance must be positive")
        if damage_active_set_scale < 0.0:
            raise ValueError("damage_active_set_scale must be non-negative")
        if damage_active_set_diagonal_theta < 0.0:
            raise ValueError(
                "damage_active_set_diagonal_theta must be non-negative")
        if (damage_active_set_scale > 0.0
                and damage_active_set_diagonal_theta > 0.0):
            raise ValueError(
                "choose either scalar or diagonal-scaled damage active set")
        if mechanics_backend not in {"cg", "scipy"}:
            raise ValueError("mechanics_backend must be 'cg' or 'scipy'")
        if mechanics_max_iter < 1 or mechanics_cg_maxiter < 1:
            raise ValueError("mechanics iteration limits must be positive")
        self.fem = fem
        self.damage_solver = damage_solver
        self.tol = float(tol)
        self.max_outer = int(max_outer)
        self.max_active_set = int(max_active_set)
        self.damage_kkt_relative_tolerance = damage_kkt_relative_tolerance
        self.damage_active_set_scale = float(damage_active_set_scale)
        self.damage_active_set_diagonal_theta = float(
            damage_active_set_diagonal_theta)
        self.mechanics_backend = mechanics_backend
        self.mechanics_max_iter = int(mechanics_max_iter)
        self.mechanics_cg_maxiter = int(mechanics_cg_maxiter)
        self._damage_geometry = None
        self._mechanics = None

    def _assemble_damage_block(self, H: torch.Tensor):
        """Assemble the frozen linear T3 damage matrix on CPU float64."""
        from .multigrid import _assemble_sparse_cpu

        if (getattr(self.damage_solver, "_native_q4_damage", False)
                or getattr(self.damage_solver, "_nodal_H", False)
                or self.damage_solver._viscous_coefficient() > 0.0):
            raise NotImplementedError(
                "reduced-MPC PDAS supports non-viscous element-history T3 "
                "AT1/AT2 damage only")
        mesh = self.fem.mesh
        if self._damage_geometry is None:
            elements = mesh.elements.detach().cpu()
            areas = mesh.areas.detach().cpu().to(torch.float64)
            grad = mesh.grad_phi.detach().cpu().to(torch.float64)
            areas_col = areas[:, None, None]
            K_local = areas_col * (
                grad[:, :, 0:1] * grad[:, None, :, 0]
                + grad[:, :, 1:2] * grad[:, None, :, 1])
            rows, cols = [], []
            for row_local in range(3):
                for col_local in range(3):
                    rows.append(elements[:, row_local].numpy())
                    cols.append(elements[:, col_local].numpy())
            self._damage_geometry = (
                K_local, areas, np.concatenate(rows), np.concatenate(cols),
                int(mesh.n_nodes))
        K_local, areas, rows, cols, n_nodes = self._damage_geometry
        H_cpu = H.detach().cpu().to(torch.float64)
        ratio = self.damage_solver._Gc_over_l0_e
        if ratio is None:
            ratio = self.damage_solver._Gc_over_l0
        elif torch.is_tensor(ratio):
            ratio = ratio.detach().cpu().to(torch.float64)
        coeff = self.damage_solver._Gc_l0_e
        if coeff is None:
            coeff = self.damage_solver._Gc_l0
        elif torch.is_tensor(coeff):
            coeff = coeff.detach().cpu().to(torch.float64)
        reaction = (2.0 * H_cpu + ratio) * areas / 12.0
        return _assemble_sparse_cpu(K_local, reaction, coeff, rows, cols, n_nodes)

    def _relative_damage_kkt(self, certificate, H: torch.Tensor,
                             d_prev: torch.Tensor) -> float:
        rhs = -self.damage_solver.compute_residual(H, torch.zeros_like(d_prev))
        return float(certificate["kkt_projected_l2"]) / max(
            float(torch.linalg.vector_norm(rhs).item()), 1.0e-16)

    def _damage_pdas(self, *, H: torch.Tensor, d_prev: torch.Tensor,
                     d_initial: torch.Tensor, fixed: torch.Tensor | None,
                     fixed_values: torch.Tensor | None):
        """Solve the frozen damage obstacle problem by active-set elimination."""
        from scipy.sparse.linalg import splu

        A = self._assemble_damage_block(H).tocsc()
        d_prev_cpu = d_prev.detach().cpu().numpy().astype(np.float64)
        d = np.clip(
            d_initial.detach().cpu().numpy().astype(np.float64), d_prev_cpu, 1.0)
        b = (-self.damage_solver.compute_residual(
            H, torch.zeros_like(d_prev)).detach().cpu().numpy().astype(np.float64))
        fixed_cpu = (np.zeros_like(d, dtype=bool) if fixed is None else
                     fixed.detach().cpu().numpy().astype(bool))
        fixed_cpu |= d_prev_cpu >= 1.0 - 1.0e-12
        fixed_values_cpu = (None if fixed_values is None else
                            fixed_values.detach().cpu().numpy().astype(np.float64))
        previous_masks = None
        diagnostics = []
        certificate = None
        for iteration in range(self.max_active_set):
            d_t = torch.as_tensor(d, dtype=d_prev.dtype, device=d_prev.device)
            residual = self.damage_solver.compute_residual(H, d_t)
            if self.damage_active_set_diagonal_theta == 0.0:
                scale = self.damage_active_set_scale
            else:
                diagonal = A.diagonal()
                if not np.isfinite(diagonal).all() or np.any(diagonal <= 0.0):
                    raise RuntimeError("PDAS damage diagonal must be positive and finite")
                scale = torch.as_tensor(
                    self.damage_active_set_diagonal_theta / diagonal,
                    dtype=d_t.dtype, device=d_t.device)
            lower, upper, fixed_mask = _semismooth_damage_active_set(
                residual=residual, d=d_t, d_prev=d_prev,
                primal_dual_scale=scale,
                fixed=torch.as_tensor(fixed_cpu, device=d_t.device))
            lower_cpu = lower.detach().cpu().numpy().astype(bool)
            upper_cpu = upper.detach().cpu().numpy().astype(bool)
            constrained = lower_cpu | upper_cpu | fixed_cpu
            values = np.empty_like(d)
            values[lower_cpu] = d_prev_cpu[lower_cpu]
            values[upper_cpu] = 1.0
            if fixed_values_cpu is not None:
                values[fixed_cpu] = fixed_values_cpu[fixed_cpu]
            else:
                values[fixed_cpu] = d_prev_cpu[fixed_cpu]
            free = ~constrained
            trial = values.copy()
            if np.any(free):
                rhs = b[free]
                if np.any(constrained):
                    rhs = rhs - A[free][:, constrained] @ values[constrained]
                trial[free] = splu(A[free][:, free].tocsc()).solve(rhs)
            trial = np.minimum(np.maximum(trial, d_prev_cpu), 1.0)
            if fixed_values_cpu is not None:
                trial[fixed_cpu] = fixed_values_cpu[fixed_cpu]
            d_trial = torch.as_tensor(
                trial, dtype=d_prev.dtype, device=d_prev.device)
            trial_residual = self.damage_solver.compute_residual(H, d_trial)
            certificate = damage_kkt_metrics(
                trial_residual, d_trial, d_prev,
                fixed=torch.as_tensor(fixed_cpu, device=d_trial.device))
            rel_kkt = self._relative_damage_kkt(certificate, H, d_prev)
            next_lower, next_upper, _ = _semismooth_damage_active_set(
                residual=trial_residual, d=d_trial, d_prev=d_prev,
                primal_dual_scale=scale,
                fixed=torch.as_tensor(fixed_cpu, device=d_trial.device))
            masks = (next_lower.detach().cpu().numpy().astype(bool),
                     next_upper.detach().cpu().numpy().astype(bool), fixed_cpu)
            stable = (previous_masks is not None
                      and all(np.array_equal(a, b) for a, b in zip(masks, previous_masks)))
            diagnostics.append({
                "pdas_iteration": iteration + 1,
                "lower_active_count": int(masks[0].sum()),
                "upper_active_count": int(masks[1].sum()),
                "fixed_count": int(fixed_cpu.sum()),
                "relative_kkt": rel_kkt,
                "active_set_stable": stable,
            })
            d = trial
            if (stable and bool(certificate["kkt_feasible"])
                    and rel_kkt <= (self.damage_kkt_relative_tolerance
                                    if self.damage_kkt_relative_tolerance is not None
                                    else self.tol)):
                return d_trial, certificate, True, diagnostics
            previous_masks = masks
        return (torch.as_tensor(d, dtype=d_prev.dtype, device=d_prev.device),
                certificate, False, diagnostics)

    def _mechanics_solver(self):
        if self._mechanics is None:
            from .mechanics_solver import QuasiStaticSolver
            self._mechanics = QuasiStaticSolver(
                self.fem, tol=self.tol, max_iter=self.mechanics_max_iter,
                cg_max_iter=self.mechanics_cg_maxiter,
                backend=self.mechanics_backend,
                # The sparse-direct Amor tangent is a frozen secant. Retain
                # that declared model rather than silently paying for an
                # autograd-JVP inside a bounded PDAS diagnostic.
                consistent_tangent=False)
        return self._mechanics

    def solve(self, *, u_prev: torch.Tensor, d_prev: torch.Tensor,
              H_prev: torch.Tensor, f_ext_ref: torch.Tensor,
              bc_mask: torch.Tensor, bc_unit_vals: torch.Tensor,
              rigid_connectors, fixed_load: float,
              pf_dirichlet_mask: torch.Tensor | None = None,
              pf_dirichlet_values: torch.Tensor | None = None) -> SemismoothArcResult:
        """Correct one prescribed-load state and return the established certificate."""
        if not rigid_connectors:
            raise ValueError("ReducedMPCPrimalDualActiveSetCorrector requires rigid MPCs")
        if not math.isfinite(float(fixed_load)):
            raise ValueError("fixed_load must be finite")
        if H_prev.ndim != 1 or H_prev.numel() != self.fem.mesh.n_elems:
            raise ValueError("H_prev must be an element-wise accepted history field")
        if (pf_dirichlet_mask is None) != (pf_dirichlet_values is None):
            raise ValueError(
                "pass both pf_dirichlet_mask and pf_dirichlet_values, or neither")

        dtype, device = d_prev.dtype, d_prev.device
        d = d_prev.detach().clone()
        u = u_prev.detach().clone()
        bc_mask = bc_mask.to(device=device, dtype=torch.bool)
        bc_unit_vals = bc_unit_vals.to(device=device, dtype=dtype)
        f_ext_ref = f_ext_ref.to(device=device, dtype=dtype)
        fixed_pf = (None if pf_dirichlet_mask is None else
                    pf_dirichlet_mask.to(device=device, dtype=torch.bool))
        fixed_pf_values = (None if pf_dirichlet_values is None else
                           pf_dirichlet_values.to(device=device, dtype=dtype))
        T_csr, _free_mask, free_idx, _n_dof, _n_rc, _ = _build_rigid_connector_T(
            rigid_connectors, self.fem, bc_mask)
        mechanics = self._mechanics_solver()
        prior_history_active = None
        diagnostics = []
        final_H = H_prev.detach().clone()
        final_certificate = damage_kkt_metrics(
            self.damage_solver.compute_residual(final_H, d), d, d_prev,
            fixed=fixed_pf)
        mechanics_residual = math.inf
        mechanics_converged = False
        history_stable = False
        pdas_converged = False

        for outer in range(self.max_outer):
            u, mechanics_flag, _ = mechanics.solve(
                d, float(fixed_load) * f_ext_ref, bc_mask,
                float(fixed_load) * bc_unit_vals, u_init=u,
                rigid_connectors=rigid_connectors)
            reduced_force = np.asarray(T_csr.T @ (
                float(fixed_load) * f_ext_ref - self.fem.internal_force(u, d)
            ).detach().cpu().numpy().reshape(-1), dtype=np.float64)[free_idx]
            mechanics_residual = float(np.linalg.norm(reduced_force))
            mechanics_converged = bool(
                math.isfinite(mechanics_residual) and mechanics_residual <= self.tol)
            H_drive = self.fem.compute_driving_force(u, d=None)
            H = torch.maximum(H_prev, H_drive)
            history_active = H_drive > H_prev
            history_stable = (prior_history_active is not None
                              and bool(torch.equal(history_active, prior_history_active)))
            d_next, certificate, pdas_converged, pdas_diagnostics = self._damage_pdas(
                H=H, d_prev=d_prev, d_initial=d, fixed=fixed_pf,
                fixed_values=fixed_pf_values)
            damage_change = float(torch.linalg.vector_norm(d_next - d).item())
            relative_kkt = self._relative_damage_kkt(certificate, H, d_prev)
            diagnostics.append({
                "outer_iteration": outer + 1,
                "mechanics_solver_flag": bool(mechanics_flag),
                "mechanics_residual_l2": mechanics_residual,
                "mechanics_converged": mechanics_converged,
                "history_active_count": int(history_active.sum().item()),
                "history_active_stable": history_stable,
                "damage_change_l2": damage_change,
                "damage_kkt_relative": relative_kkt,
                "pdas_converged": pdas_converged,
                "pdas_iterations": len(pdas_diagnostics),
                "accepted_line_search": bool(pdas_converged),
            })
            final_H, final_certificate = H, certificate
            if (mechanics_converged and history_stable and pdas_converged
                    and damage_change <= self.tol):
                return SemismoothArcResult(
                    u=u.detach(), d=d_next.detach(), H_elem=H.detach(),
                    load_factor=float(fixed_load), converged=True,
                    iterations=outer + 1, residual_l2=max(
                        mechanics_residual, relative_kkt),
                    history_active_stable=True, damage_kkt=certificate,
                    iteration_diagnostics=diagnostics,
                    mechanics_predictor_converged=True,
                    mechanics_predictor_residual=mechanics_residual,
                    mechanics_polish_converged=True,
                    mechanics_polish_residual=mechanics_residual,
                    mechanics_polish_arc_constraint=0.0,
                    mechanics_polish_required=True, control_mode="fixed_load_pdas",
                    target_load=float(fixed_load), fracture_energy_target=None,
                    damage_arc_weight=0.0,
                    damage_active_set_scale=float(self.damage_active_set_scale))
            d = d_next.detach()
            prior_history_active = history_active.detach().clone()

        return SemismoothArcResult(
            u=u.detach(), d=d.detach(), H_elem=final_H.detach(),
            load_factor=float(fixed_load), converged=False,
            iterations=self.max_outer,
            residual_l2=max(mechanics_residual, self._relative_damage_kkt(
                final_certificate, final_H, d_prev)),
            history_active_stable=history_stable, damage_kkt=final_certificate,
            iteration_diagnostics=diagnostics,
            mechanics_predictor_converged=mechanics_converged,
            mechanics_predictor_residual=mechanics_residual,
            mechanics_polish_converged=mechanics_converged,
            mechanics_polish_residual=mechanics_residual,
            mechanics_polish_arc_constraint=0.0,
            mechanics_polish_required=True, control_mode="fixed_load_pdas",
            target_load=float(fixed_load), fracture_energy_target=None,
            damage_arc_weight=0.0,
            damage_active_set_scale=float(self.damage_active_set_scale))
