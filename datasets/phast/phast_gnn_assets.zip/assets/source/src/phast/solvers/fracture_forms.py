"""Tensorized fracture form kernels for damage operators."""

from __future__ import annotations

from dataclasses import dataclass
import math

import torch

from .sparse_matrix import PhastSparseMatrix


@dataclass
class DamageForm:
    """Element-local scalar damage form and global emission helpers."""

    local_matrix: torch.Tensor
    local_rhs: torch.Tensor
    elements: torch.Tensor
    n_nodes: int
    element_type: str
    pf_model: str

    def assemble_sparse(self) -> PhastSparseMatrix:
        return PhastSparseMatrix.from_local_blocks(
            self.local_matrix,
            self.elements,
            shape=(self.n_nodes, self.n_nodes),
        )

    def assemble_rhs(self) -> torch.Tensor:
        rhs = torch.zeros(
            self.n_nodes,
            dtype=self.local_rhs.dtype,
            device=self.local_rhs.device,
        )
        rhs.scatter_add_(0, self.elements.reshape(-1), self.local_rhs.reshape(-1))
        return rhs

    def apply(self, damage: torch.Tensor) -> torch.Tensor:
        d_e = damage[self.elements]
        local_action = torch.einsum("eab,eb->ea", self.local_matrix, d_e)
        out = torch.zeros(
            self.n_nodes,
            dtype=local_action.dtype,
            device=local_action.device,
        )
        out.scatter_add_(0, self.elements.reshape(-1), local_action.reshape(-1))
        return out


@dataclass
class MoonRationalFormResult:
    """Global residual and scalar energy for the Moon rational AT2 form."""

    residual: torch.Tensor
    energy: torch.Tensor


class FractureFormAssembler(torch.nn.Module):
    """Small fracture-native form assembler for T3/Q4 damage kernels."""

    def __init__(self, mesh, material):
        super().__init__()
        self.element_type = getattr(mesh, "element_type", "T3").upper()
        self.n_nodes = int(mesh.n_nodes)
        self.n_elems = int(mesh.n_elems)
        self.pf_model = getattr(material, "pf_model", "AT2").upper()
        self.material = material

        self.register_buffer("elements", mesh.elements.detach().clone().to(torch.long))
        self.register_buffer(
            "Gc",
            torch.as_tensor(
                getattr(material, "Gc", 1.0),
                dtype=mesh.dtype,
                device=mesh.nodes.device,
            ).clone(),
        )
        self.register_buffer(
            "l0",
            torch.as_tensor(
                getattr(material, "l0", 1.0),
                dtype=mesh.dtype,
                device=mesh.nodes.device,
            ).clone(),
        )

        if self.element_type == "T3":
            self.register_buffer("areas", mesh.areas.detach().clone())
            self.register_buffer("grad_phi", mesh.grad_phi.detach().clone())
        elif self.element_type == "Q4":
            self.register_buffer("quad_N", mesh.quad_N.detach().clone())
            self.register_buffer("quad_grad_phi", mesh.quad_grad_phi.detach().clone())
            self.register_buffer("quad_wdetJ", mesh.quad_wdetJ.detach().clone())
        else:
            raise ValueError(
                f"FractureFormAssembler supports T3 and Q4, got {self.element_type!r}")

    def _coefficients(self, *, dtype, device, Gc=None, l0=None):
        Gc = (
            self.Gc.to(dtype=dtype, device=device)
            if Gc is None else torch.as_tensor(Gc, dtype=dtype, device=device)
        )
        l0 = (
            self.l0.to(dtype=dtype, device=device)
            if l0 is None else torch.as_tensor(l0, dtype=dtype, device=device)
        )
        if self.pf_model == "AT2":
            return Gc * l0, Gc / l0, torch.zeros((), dtype=dtype, device=device)
        if self.pf_model == "AT1":
            return (
                0.75 * Gc * l0,
                torch.zeros((), dtype=dtype, device=device),
                3.0 * Gc / (8.0 * l0),
            )
        if self.pf_model == "PFCZM":
            raise NotImplementedError(
                "PF-CZM damage is nonlinear; linear_damage_form is limited to "
                "AT1/AT2 until a PF-CZM residual/Jacobian form is added.")
        raise ValueError(f"Unsupported phase-field model {self.pf_model!r}")

    @staticmethod
    def _as_element_or_scalar(value: torch.Tensor, n_elems: int, name: str):
        if value.ndim == 0:
            return value
        if value.shape == (n_elems,):
            return value
        raise ValueError(
            f"{name} must be a scalar tensor or shape ({n_elems},), "
            f"got {tuple(value.shape)}")

    @staticmethod
    def _validate_positive_coefficient(
        value: torch.Tensor, name: str
    ) -> torch.Tensor:
        if not bool(torch.all(torch.isfinite(value) & (value > 0.0))):
            raise ValueError(
                f"{name} must contain finite, strictly positive values"
            )
        return value

    @staticmethod
    def _element_scale(value: torch.Tensor) -> torch.Tensor:
        return value.view(-1, 1, 1) if value.ndim > 0 else value

    @staticmethod
    def _element_density(value: torch.Tensor) -> torch.Tensor:
        return value.unsqueeze(1) if value.ndim > 0 else value

    @staticmethod
    def _element_vector(value: torch.Tensor, n_elems: int) -> torch.Tensor:
        return value.expand(n_elems) if value.ndim == 0 else value

    def linear_damage_form(
        self,
        H_input: torch.Tensor,
        *,
        Gc: torch.Tensor | float | None = None,
        l0: torch.Tensor | float | None = None,
    ) -> DamageForm:
        """Build the AT1/AT2 scalar damage form.

        T3 accepts element history ``(E,)``. Q4 accepts element history ``(E,)``
        or Gauss-point history ``(E, 4)``.
        """
        H = H_input.to(device=self.elements.device)
        Gc_t = None if Gc is None else torch.as_tensor(
            Gc, dtype=H.dtype, device=H.device)
        l0_t = None if l0 is None else torch.as_tensor(
            l0, dtype=H.dtype, device=H.device)
        if Gc_t is not None:
            Gc_t = self._as_element_or_scalar(Gc_t, self.n_elems, "Gc")
        if l0_t is not None:
            l0_t = self._as_element_or_scalar(l0_t, self.n_elems, "l0")
        if self.element_type == "T3":
            return self._linear_damage_form_t3(H, Gc=Gc_t, l0=l0_t)
        return self._linear_damage_form_q4(H, Gc=Gc_t, l0=l0_t)

    def moon_rational_residual_energy(
        self,
        H_input: torch.Tensor,
        damage: torch.Tensor,
        *,
        Gc: torch.Tensor | float | None = None,
        l0: torch.Tensor | float | None = None,
    ) -> MoonRationalFormResult:
        """Assemble the differentiable Moon rational AT2 functional.

        ``damage`` must be nodal with shape ``(N,)``. T3 history is
        elementwise with shape ``(E,)``; Q4 history may be elementwise or
        supplied at the native quadrature points with shape ``(E, nq)``.
        ``Gc`` and ``l0`` default to the material values and each accepts a
        positive scalar or an elementwise ``(E,)`` tensor.

        Both returned tensors retain autograd connections to ``damage``,
        ``H_input``, and tensor coefficient overrides.
        """
        if self.pf_model != "AT2":
            raise ValueError(
                "moon_rational_residual_energy requires pf_model='AT2', "
                f"got {self.pf_model!r}"
            )
        H = H_input.to(device=self.elements.device)
        d = damage.to(device=H.device, dtype=H.dtype)
        Gc_t = self.Gc.to(dtype=H.dtype, device=H.device) if Gc is None else (
            torch.as_tensor(Gc, dtype=H.dtype, device=H.device)
        )
        l0_t = self.l0.to(dtype=H.dtype, device=H.device) if l0 is None else (
            torch.as_tensor(l0, dtype=H.dtype, device=H.device)
        )
        if d.shape != (self.n_nodes,):
            raise ValueError(
                f"damage must have shape ({self.n_nodes},), got {tuple(d.shape)}"
            )
        Gc_t = self._as_element_or_scalar(Gc_t, self.n_elems, "Gc")
        l0_t = self._as_element_or_scalar(l0_t, self.n_elems, "l0")
        Gc_t = self._validate_positive_coefficient(Gc_t, "Gc")
        l0_t = self._validate_positive_coefficient(l0_t, "l0")
        if self.element_type == "T3":
            return self._moon_rational_residual_energy_t3(H, d, Gc_t, l0_t)
        return self._moon_rational_residual_energy_q4(H, d, Gc_t, l0_t)

    def _moon_rational_residual_energy_t3(
        self,
        H: torch.Tensor,
        damage: torch.Tensor,
        Gc: torch.Tensor,
        l0: torch.Tensor,
    ) -> MoonRationalFormResult:
        if H.shape != (self.n_elems,):
            raise ValueError(
                f"T3 Moon rational form expects H shape ({self.n_elems},), "
                f"got {tuple(H.shape)}"
            )
        elements = self.elements.to(device=H.device)
        areas = self.areas.to(dtype=H.dtype, device=H.device)
        gp = self.grad_phi.to(dtype=H.dtype, device=H.device)
        d_e = damage[elements]
        N = torch.as_tensor(
            [
                [2.0 / 3.0, 1.0 / 6.0, 1.0 / 6.0],
                [1.0 / 6.0, 2.0 / 3.0, 1.0 / 6.0],
                [1.0 / 6.0, 1.0 / 6.0, 2.0 / 3.0],
            ],
            dtype=H.dtype,
            device=H.device,
        )
        d_q = torch.einsum("qa,ea->eq", N, d_e)
        weight = (areas / 3.0).unsqueeze(1)
        g, g_p, _g_pp = self.material.moon_rational_degradation_derivatives(
            d_q
        )
        Gc_e = self._element_vector(Gc, self.n_elems)
        l0_e = self._element_vector(l0, self.n_elems)
        q = H.unsqueeze(1) * g_p + (Gc_e / l0_e).unsqueeze(1) * d_q
        mass_contrib = torch.einsum("qa,eq->ea", N, q * weight)

        gd_x = (gp[:, :, 0] * d_e).sum(1)
        gd_y = (gp[:, :, 1] * d_e).sum(1)
        lap_contrib = (Gc_e * l0_e).unsqueeze(1) * (
            areas.unsqueeze(1)
            * (
                gp[:, :, 0] * gd_x.unsqueeze(1)
                + gp[:, :, 1] * gd_y.unsqueeze(1)
            )
        )
        residual = torch.zeros(
            self.n_nodes, dtype=H.dtype, device=H.device
        )
        residual.scatter_add_(
            0, elements.reshape(-1), (mass_contrib + lap_contrib).reshape(-1)
        )

        local_energy = (
            weight
            * (
                H.unsqueeze(1) * g
                + 0.5 * (Gc_e / l0_e).unsqueeze(1) * d_q.square()
            )
        ).sum()
        grad_energy = (
            0.5
            * Gc_e
            * l0_e
            * areas
            * (gd_x.square() + gd_y.square())
        ).sum()
        return MoonRationalFormResult(residual, local_energy + grad_energy)

    def _moon_rational_residual_energy_q4(
        self,
        H: torch.Tensor,
        damage: torch.Tensor,
        Gc: torch.Tensor,
        l0: torch.Tensor,
    ) -> MoonRationalFormResult:
        n_q = int(self.quad_N.shape[0])
        if H.shape == (self.n_elems,):
            H_q = H.unsqueeze(1).expand(-1, n_q)
        elif H.shape == (self.n_elems, n_q):
            H_q = H
        else:
            raise ValueError(
                "Q4 Moon rational form expects H shape "
                f"({self.n_elems},) or ({self.n_elems}, {n_q}), "
                f"got {tuple(H.shape)}"
            )
        elements = self.elements.to(device=H.device)
        N = self.quad_N.to(dtype=H.dtype, device=H.device)
        gp = self.quad_grad_phi.to(dtype=H.dtype, device=H.device)
        wdet = self.quad_wdetJ.to(dtype=H.dtype, device=H.device)
        d_e = damage[elements]
        d_q = torch.einsum("qa,ea->eq", N, d_e)
        gd_x = torch.einsum("eqa,ea->eq", gp[..., 0], d_e)
        gd_y = torch.einsum("eqa,ea->eq", gp[..., 1], d_e)
        g, g_p, _g_pp = self.material.moon_rational_degradation_derivatives(
            d_q
        )
        Gc_e = self._element_vector(Gc, self.n_elems)
        l0_e = self._element_vector(l0, self.n_elems)
        q = H_q * g_p + (Gc_e / l0_e).unsqueeze(1) * d_q
        mass_contrib = torch.einsum("qa,eq->ea", N, q * wdet)
        lap_contrib = (Gc_e * l0_e).view(-1, 1) * (
            wdet.unsqueeze(2)
            * (
                gp[..., 0] * gd_x.unsqueeze(2)
                + gp[..., 1] * gd_y.unsqueeze(2)
            )
        ).sum(dim=1)
        residual = torch.zeros(
            self.n_nodes, dtype=H.dtype, device=H.device
        )
        residual.scatter_add_(
            0, elements.reshape(-1), (mass_contrib + lap_contrib).reshape(-1)
        )
        energy = (
            wdet
            * (
                H_q * g
                + 0.5 * (Gc_e / l0_e).unsqueeze(1) * d_q.square()
                + 0.5
                * (Gc_e * l0_e).unsqueeze(1)
                * (gd_x.square() + gd_y.square())
            )
        ).sum()
        return MoonRationalFormResult(residual, energy)

    def pfczm_damage_form(
        self,
        H_input: torch.Tensor,
        damage: torch.Tensor,
        *,
        Gc: torch.Tensor | float | None = None,
        l0: torch.Tensor | float | None = None,
    ) -> DamageForm:
        """Build the PF-CZM residual and tangent form at ``damage``.

        The returned ``DamageForm.local_rhs`` is the nonlinear residual
        contribution, while ``local_matrix`` is the consistent tangent used for
        Newton/diagnostic sparse actions.
        """
        if self.pf_model != "PFCZM":
            raise ValueError(
                f"pfczm_damage_form requires pf_model='PFCZM', got {self.pf_model!r}")
        H = H_input.to(device=self.elements.device)
        d = damage.to(device=self.elements.device, dtype=H.dtype)
        Gc_t = None if Gc is None else torch.as_tensor(
            Gc, dtype=H.dtype, device=H.device)
        l0_t = None if l0 is None else torch.as_tensor(
            l0, dtype=H.dtype, device=H.device)
        if Gc_t is not None:
            Gc_t = self._as_element_or_scalar(Gc_t, self.n_elems, "Gc")
        if l0_t is not None:
            l0_t = self._as_element_or_scalar(l0_t, self.n_elems, "l0")
        if self.element_type == "T3":
            return self._pfczm_damage_form_t3(H, d, Gc=Gc_t, l0=l0_t)
        return self._pfczm_damage_form_q4(H, d, Gc=Gc_t, l0=l0_t)

    def _linear_damage_form_t3(self, H: torch.Tensor, *, Gc=None, l0=None) -> DamageForm:
        if H.shape != (self.n_elems,):
            raise ValueError(
                f"T3 damage form expects H shape ({self.n_elems},), "
                f"got {tuple(H.shape)}")
        dtype = H.dtype
        device = H.device
        areas = self.areas.to(dtype=dtype, device=device)
        gp = self.grad_phi.to(dtype=dtype, device=device)
        elements = self.elements.to(device=device)
        Gc_l0, Gc_over_l0, at1_source = self._coefficients(
            dtype=dtype, device=device, Gc=Gc, l0=l0)

        K_local = areas.view(-1, 1, 1) * (
            gp[..., 0].unsqueeze(2) * gp[..., 0].unsqueeze(1)
            + gp[..., 1].unsqueeze(2) * gp[..., 1].unsqueeze(1)
        )
        mass_template = (
            torch.ones((3, 3), dtype=dtype, device=device)
            + torch.eye(3, dtype=dtype, device=device)
        )
        reaction_coeff = (2.0 * H + Gc_over_l0) * areas / 12.0
        local_matrix = (
            self._element_scale(Gc_l0) * K_local
            + reaction_coeff.view(-1, 1, 1) * mass_template.view(1, 3, 3)
        )
        rhs_density = 2.0 * H - at1_source
        local_rhs = (rhs_density * areas / 3.0).view(-1, 1).expand(-1, 3)
        return DamageForm(
            local_matrix=local_matrix,
            local_rhs=local_rhs,
            elements=elements,
            n_nodes=self.n_nodes,
            element_type="T3",
            pf_model=self.pf_model,
        )

    def _pfczm_a1(self, Gc: torch.Tensor, l0: torch.Tensor) -> torch.Tensor:
        scale = max(1.0 - float(self.material.eta_residual), 1.0e-30)
        return (
            4.0 * float(self.material.E) * Gc
            / (math.pi * l0 * float(self.material.sigma_ts) ** 2 * scale)
        )

    def _pfczm_damage_form_t3(self, H: torch.Tensor, damage: torch.Tensor,
                              *, Gc=None, l0=None) -> DamageForm:
        if H.shape != (self.n_elems,):
            raise ValueError(
                f"T3 PF-CZM form expects H shape ({self.n_elems},), "
                f"got {tuple(H.shape)}")
        dtype = H.dtype
        device = H.device
        areas = self.areas.to(dtype=dtype, device=device)
        gp = self.grad_phi.to(dtype=dtype, device=device)
        elements = self.elements.to(device=device)
        d_e = damage[elements]
        Gc_base = self.Gc.to(dtype=dtype, device=device) if Gc is None else Gc
        l0_base = self.l0.to(dtype=dtype, device=device) if l0 is None else l0
        Gc_e = self._element_vector(Gc_base, self.n_elems)
        l0_e = self._element_vector(l0_base, self.n_elems)

        a1 = self._pfczm_a1(Gc_e, l0_e)
        _g, gp_d, gpp_d = self.material.pfczm_degradation_derivatives(d_e, a1=a1)
        alpha_p = self.material.pfczm_alpha_prime(d_e)
        alpha_pp = torch.full_like(d_e, -2.0)
        q = H.unsqueeze(1) * gp_d + (Gc_e / (math.pi * l0_e)).unsqueeze(1) * alpha_p
        qprime = H.unsqueeze(1) * gpp_d + (
            Gc_e / (math.pi * l0_e)).unsqueeze(1) * alpha_pp

        q_sum = q.sum(dim=1)
        local_rhs = (areas / 12.0).unsqueeze(1) * (q + q_sum.unsqueeze(1))
        mass_tangent = (
            (areas / 12.0).view(-1, 1, 1)
            * (torch.ones((3, 3), dtype=dtype, device=device)
               + torch.eye(3, dtype=dtype, device=device)).view(1, 3, 3)
            * qprime.unsqueeze(1)
        )

        K_local = areas.view(-1, 1, 1) * (
            gp[..., 0].unsqueeze(2) * gp[..., 0].unsqueeze(1)
            + gp[..., 1].unsqueeze(2) * gp[..., 1].unsqueeze(1)
        )
        lap_coeff = 2.0 * Gc_e * l0_e / math.pi
        gd_x = (gp[:, :, 0] * d_e).sum(1)
        gd_y = (gp[:, :, 1] * d_e).sum(1)
        local_rhs = local_rhs + lap_coeff.unsqueeze(1) * (
            areas.unsqueeze(1) * (
                gp[:, :, 0] * gd_x.unsqueeze(1)
                + gp[:, :, 1] * gd_y.unsqueeze(1)))
        local_matrix = self._element_scale(lap_coeff) * K_local + mass_tangent
        return DamageForm(local_matrix, local_rhs, elements, self.n_nodes, "T3", "PFCZM")

    def _pfczm_damage_form_q4(self, H: torch.Tensor, damage: torch.Tensor,
                              *, Gc=None, l0=None) -> DamageForm:
        n_q = int(self.quad_N.shape[0])
        if H.shape == (self.n_elems,):
            H_q = H.unsqueeze(1).expand(-1, n_q)
        elif H.shape == (self.n_elems, n_q):
            H_q = H
        else:
            raise ValueError(
                "Q4 PF-CZM form expects H shape "
                f"({self.n_elems},) or ({self.n_elems}, {n_q}), "
                f"got {tuple(H.shape)}")
        dtype = H_q.dtype
        device = H_q.device
        N = self.quad_N.to(dtype=dtype, device=device)
        gp = self.quad_grad_phi.to(dtype=dtype, device=device)
        wdet = self.quad_wdetJ.to(dtype=dtype, device=device)
        elements = self.elements.to(device=device)
        d_e = damage[elements]
        d_q = torch.einsum("qa,ea->eq", N, d_e)
        Gc_base = self.Gc.to(dtype=dtype, device=device) if Gc is None else Gc
        l0_base = self.l0.to(dtype=dtype, device=device) if l0 is None else l0
        Gc_e = self._element_vector(Gc_base, self.n_elems)
        l0_e = self._element_vector(l0_base, self.n_elems)
        a1 = self._pfczm_a1(Gc_e, l0_e)
        _g, gp_d, gpp_d = self.material.pfczm_degradation_derivatives(d_q, a1=a1)
        alpha_p = self.material.pfczm_alpha_prime(d_q)
        alpha_pp = torch.full_like(d_q, -2.0)
        q = H_q * gp_d + (Gc_e / (math.pi * l0_e)).unsqueeze(1) * alpha_p
        qprime = H_q * gpp_d + (Gc_e / (math.pi * l0_e)).unsqueeze(1) * alpha_pp
        local_rhs = torch.einsum("qa,eq->ea", N, q * wdet)
        mass_tangent = torch.einsum("eq,qa,qb->eab", qprime * wdet, N, N)
        K_local = (
            torch.einsum("eq,eqa,eqb->eab", wdet, gp[..., 0], gp[..., 0])
            + torch.einsum("eq,eqa,eqb->eab", wdet, gp[..., 1], gp[..., 1])
        )
        lap_coeff = 2.0 * Gc_e * l0_e / math.pi
        gd_x = torch.einsum("eqa,ea->eq", gp[..., 0], d_e)
        gd_y = torch.einsum("eqa,ea->eq", gp[..., 1], d_e)
        local_rhs = local_rhs + lap_coeff.unsqueeze(1) * (
            wdet.unsqueeze(2)
            * (
                gp[..., 0] * gd_x.unsqueeze(2)
                + gp[..., 1] * gd_y.unsqueeze(2)
            )
        ).sum(dim=1)
        local_matrix = self._element_scale(lap_coeff) * K_local + mass_tangent
        return DamageForm(local_matrix, local_rhs, elements, self.n_nodes, "Q4", "PFCZM")

    def _linear_damage_form_q4(self, H: torch.Tensor, *, Gc=None, l0=None) -> DamageForm:
        n_q = int(self.quad_N.shape[0])
        if H.shape == (self.n_elems,):
            H_q = H.unsqueeze(1).expand(-1, n_q)
        elif H.shape == (self.n_elems, n_q):
            H_q = H
        else:
            raise ValueError(
                "Q4 damage form expects H shape "
                f"({self.n_elems},) or ({self.n_elems}, {n_q}), "
                f"got {tuple(H.shape)}")

        dtype = H_q.dtype
        device = H_q.device
        N = self.quad_N.to(dtype=dtype, device=device)
        gp = self.quad_grad_phi.to(dtype=dtype, device=device)
        wdet = self.quad_wdetJ.to(dtype=dtype, device=device)
        elements = self.elements.to(device=device)
        Gc_l0, Gc_over_l0, at1_source = self._coefficients(
            dtype=dtype, device=device, Gc=Gc, l0=l0)

        K_local = (
            torch.einsum("eq,eqa,eqb->eab", wdet, gp[..., 0], gp[..., 0])
            + torch.einsum("eq,eqa,eqb->eab", wdet, gp[..., 1], gp[..., 1])
        )
        reaction_density = 2.0 * H_q + self._element_density(Gc_over_l0)
        M_local = torch.einsum("eq,qa,qb->eab", reaction_density * wdet, N, N)
        local_matrix = self._element_scale(Gc_l0) * K_local + M_local
        rhs_density = 2.0 * H_q - self._element_density(at1_source)
        local_rhs = torch.einsum("qa,eq->ea", N, rhs_density * wdet)
        return DamageForm(
            local_matrix=local_matrix,
            local_rhs=local_rhs,
            elements=elements,
            n_nodes=self.n_nodes,
            element_type="Q4",
            pf_model=self.pf_model,
        )
