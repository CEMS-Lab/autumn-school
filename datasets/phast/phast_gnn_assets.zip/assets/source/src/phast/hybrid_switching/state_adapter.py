"""Bridge :class:`StaggeredSolver` state dicts to the controller ``State`` protocol.

Used by ``ResidualGatedSwitch`` and the W3 smoke gate (issue #511) so the
hybrid loop can:

1. **snapshot** the solver into a controller-visible ``State`` mapping,
2. let a ``LearnedStepper`` propose a new state,
3. let the ``AT2Auditor`` (this package) accept or reject the proposal,
4. on accept: write the proposed state back into the solver,
5. on reject: restore the snapshot so the trajectory rolls back to the last
   accepted state.

The adapter is **deliberately thin**: it does not modify physics. It only
moves tensors between two representations and enforces rollback semantics
by deep-copying tensors on snapshot so subsequent in-place mutations of the
solver state do not leak into the snapshot.

Notes
-----
- ``StaggeredSolver.get_state()`` already ``clone()``-s its tensors, but we
  do not rely on that; the adapter clones again so the contract is owned
  here, not in the solver.
- ``StaggeredSolver.set_state()`` accepts the dict back; for rollback we
  feed the *snapshot* dict, not the proposal. Rollback restores the full
  path-dependent dynamic state, including velocity, acceleration, history,
  load bookkeeping, and installed heterogeneous fields when present.
- The proposal dict produced by a learned stepper may carry *only* the
  damage tensor ``d``. :meth:`StateAdapter.apply_proposal` will then keep
  the solver's existing ``u``, ``v``, ``a``, ``H_elem``, ``H_nodal``, and
  ``step``, replacing only ``d``. This matches Paper 4's primary "damage
  surrogate" mode (see ``papers/paper4/experiment_matrix.md`` §3).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Mapping

import torch

from .protocols import State

if TYPE_CHECKING:  # pragma: no cover -- typing only
    from phast.staggered_solver import StaggeredSolver


# Keys the solver state dict exposes (per StaggeredSolver.get_state) and that
# a full-state proposal may legally replace. Most learned proposals carry only
# "d", but dynamic live gates may pass a complete accepted state.
SOLVER_STATE_KEYS: tuple[str, ...] = (
    "u", "v", "a", "d", "H_elem", "H_nodal", "f_ext", "step", "dt",
    "load_factor", "_explicit_step_count", "_last_stagger_iter",
    "_last_residual", "_last_mechanics_converged", "_last_mechanics_iter",
    "_last_dt_used", "_last_strain", "d_prev", "diff_Gc_field",
    "diff_E_field", "diff_nu_field",
)

# Minimum fields that define a safe rollback boundary for phase-field fracture.
# Optional extras such as ``d_prev``, ``_last_strain``, and heterogeneous fields
# are still cloned/restored when present, but these base fields must exist before
# the hybrid controller is allowed to speculate.
REQUIRED_ROLLBACK_KEYS: tuple[str, ...] = (
    "u", "v", "a", "d", "H_elem", "H_nodal", "f_ext", "step", "dt",
    "load_factor",
)


class RollbackContractError(ValueError):
    """Raised when a solver state is missing rollback-critical fields."""


def _clone_value(v: Any) -> Any:
    if isinstance(v, torch.Tensor):
        return v.detach().clone()
    return v


def clone_state(state: Mapping[str, Any]) -> dict[str, Any]:
    """Deep-copy a state mapping; clones tensors, leaves scalars untouched."""
    return {k: _clone_value(v) for k, v in state.items()}


def validate_rollback_state(
    state: Mapping[str, Any],
    *,
    required_keys: tuple[str, ...] = REQUIRED_ROLLBACK_KEYS,
    context: str = "rollback state",
) -> None:
    """Validate that a state mapping can serve as a rollback boundary.

    Phase-field fracture is path-dependent: rejected learned proposals must
    restore displacement, damage, history, load bookkeeping, and inertial state.
    Missing fields are therefore a correctness bug, not just a logging gap.
    """
    missing = tuple(key for key in required_keys if key not in state)
    if missing:
        raise RollbackContractError(
            f"{context} missing rollback-critical keys {missing}; "
            "hybrid fallback would risk corrupting path-dependent state."
        )


class StateAdapter:
    """Wrap a :class:`StaggeredSolver` instance for controller use.

    Parameters
    ----------
    solver
        A live :class:`StaggeredSolver` instance whose ``get_state()`` /
        ``set_state()`` methods follow the schema in
        ``staggered_solver.py`` (see ``SOLVER_STATE_KEYS``).

    Example
    -------
    >>> adapter = StateAdapter(solver)                 # doctest: +SKIP
    >>> snap = adapter.snapshot()                      # before learned step
    >>> proposed_d = learned_stepper(snap)["d"]        # raw NN output
    >>> proposed = {"d": proposed_d}
    >>> ok = auditor.audit(snap, proposed).accepted
    >>> if ok:
    ...     adapter.apply_proposal(proposed)
    ... else:
    ...     adapter.rollback(snap)
    """

    def __init__(
        self,
        solver: "StaggeredSolver",
        *,
        required_rollback_keys: tuple[str, ...] = REQUIRED_ROLLBACK_KEYS,
    ) -> None:
        self.solver = solver
        self.required_rollback_keys = tuple(required_rollback_keys)

    # ------------------------------------------------------------------
    # Snapshot / restore (rollback)
    # ------------------------------------------------------------------

    def snapshot(self) -> dict[str, Any]:
        """Return a deep-copied dict of the current solver state."""
        state = clone_state(self.solver.get_state())
        validate_rollback_state(
            state,
            required_keys=self.required_rollback_keys,
            context="StateAdapter.snapshot",
        )
        return state

    def rollback(self, snapshot: Mapping[str, Any]) -> None:
        """Restore the solver to a previously captured snapshot.

        ``snapshot`` should have been produced by :meth:`snapshot`. The
        method calls the solver's own ``set_state``; no field is re-derived
        beyond what the solver itself recomputes on assignment.
        """
        validate_rollback_state(
            snapshot,
            required_keys=self.required_rollback_keys,
            context="StateAdapter.rollback",
        )
        # Clone again on the way in: prevents downstream mutations of the
        # snapshot dict from corrupting the solver.
        self.solver.set_state(clone_state(snapshot))

    # ------------------------------------------------------------------
    # Proposal application (accept path)
    # ------------------------------------------------------------------

    def apply_proposal(self, proposed: Mapping[str, Any]) -> None:
        """Merge a learned proposal into the solver state and write it back.

        The proposal may carry any subset of ``SOLVER_STATE_KEYS``. Keys
        absent from ``proposed`` are inherited from the solver's *current*
        state (i.e., from before the proposal). This is the natural
        semantic for "damage-only surrogate" mode: the surrogate outputs
        only ``d``; everything else is preserved.

        Numerical safety
        ----------------
        Tensors in ``proposed`` are moved to the solver's device and dtype
        via :meth:`StaggeredSolver.set_state` (the solver does the cast).
        No clamping or projection is performed here. A physics-aware live
        controller must pass the auditor's projected proposal on acceptance;
        the adapter remains physics-blind.
        """
        merged = dict(self.solver.get_state())
        validate_rollback_state(
            merged,
            required_keys=self.required_rollback_keys,
            context="StateAdapter.apply_proposal current state",
        )
        for k, v in proposed.items():
            if k not in SOLVER_STATE_KEYS:
                # Reject unknown keys early -- catches typos.
                raise KeyError(
                    f"StateAdapter.apply_proposal: unknown state key {k!r}; "
                    f"allowed keys are {SOLVER_STATE_KEYS}."
                )
            merged[k] = _clone_value(v)
        validate_rollback_state(
            merged,
            required_keys=self.required_rollback_keys,
            context="StateAdapter.apply_proposal merged state",
        )
        self.solver.set_state(merged)

    # ------------------------------------------------------------------
    # Read-only views (no copying; for the auditor)
    # ------------------------------------------------------------------

    def view(self) -> dict[str, Any]:
        """Return the solver's current state without deep copy.

        Use this for read-only audits (residual evaluation). Do not mutate.
        """
        return dict(self.solver.get_state())
