"""Controllers for residual-gated learned-model switching."""

from __future__ import annotations

from dataclasses import dataclass
from typing import AbstractSet

from .protocols import AuditResult, LearnedStepper, ReferenceStepper, ResidualAuditor, State, StepDecision


def _merge_state(current: State, proposed: State) -> dict:
    """Return an accepted learned proposal as a complete next state.

    Learned fracture proposals are often damage-only. A path-dependent dynamic
    rollout must not drop displacement, velocity, acceleration, history, or
    solver bookkeeping just because the proposal only contains ``d``.
    """

    merged = dict(current)
    merged.update(proposed)
    return merged


def _with_horizon_metrics(
    audit: AuditResult,
    *,
    horizon_before: int,
    horizon_after: int,
    reject_divisor: int,
    accept_streak_after: int,
) -> AuditResult:
    """Attach numeric horizon-transition diagnostics to an audit result."""

    metrics = dict(audit.metrics)
    metrics.update({
        "horizon_before": float(horizon_before),
        "horizon_after": float(horizon_after),
        "horizon_changed": float(horizon_before != horizon_after),
        "horizon_reject_divisor": float(reject_divisor),
        "horizon_accept_streak_after": float(accept_streak_after),
    })
    return AuditResult(
        residual=audit.residual,
        accepted=audit.accepted,
        reason=audit.reason,
        metrics=metrics,
    )


@dataclass
class SwitchingStats:
    learned_steps: int = 0
    reference_steps: int = 0
    rejected_steps: int = 0

    @property
    def total_steps(self) -> int:
        return self.learned_steps + self.reference_steps

    @property
    def learned_fraction(self) -> float:
        return self.learned_steps / self.total_steps if self.total_steps else 0.0


class ResidualGatedSwitch:
    """Accept learned proposals only when the auditor approves them."""

    def __init__(
        self,
        learned: LearnedStepper,
        reference: ReferenceStepper,
        auditor: ResidualAuditor,
        *,
        horizon: int = 1,
        min_horizon: int = 1,
        max_horizon: int = 1,
        grow_after_accepts: int = 3,
    ) -> None:
        if min_horizon < 1 or horizon < 1 or max_horizon < 1:
            raise ValueError("horizons must be positive")
        if min_horizon > max_horizon:
            raise ValueError("min_horizon cannot exceed max_horizon")
        self.learned = learned
        self.reference = reference
        self.auditor = auditor
        self.horizon = min(max(horizon, min_horizon), max_horizon)
        self.min_horizon = min_horizon
        self.max_horizon = max_horizon
        self.grow_after_accepts = max(int(grow_after_accepts), 1)
        self.stats = SwitchingStats()
        self._accept_streak = 0

    def step(self, state: State) -> StepDecision:
        """Run one controller step.

        The learned model proposes at the current horizon. If the audit fails,
        the reference solver advances one trusted step and the horizon is
        reduced. This conservative policy keeps the reference solver as the
        final authority.
        """

        horizon_before = self.horizon
        proposed = self.learned.propose(state, horizon=horizon_before)
        audit = self.auditor.audit(state, proposed)
        used_reference = not audit.accepted
        reject_divisor = 1

        if audit.accepted:
            next_state = _merge_state(state, proposed)
            self.stats.learned_steps += 1
            self._accept_streak += 1
            if (
                self.horizon < self.max_horizon
                and self._accept_streak >= self.grow_after_accepts
            ):
                self.horizon += 1
                self._accept_streak = 0
        else:
            next_state = self.reference.step(state)
            self.stats.reference_steps += 1
            self.stats.rejected_steps += 1
            self._accept_streak = 0
            reject_divisor = 2
            self.horizon = max(self.min_horizon, self.horizon // reject_divisor)

        audit = _with_horizon_metrics(
            audit,
            horizon_before=horizon_before,
            horizon_after=self.horizon,
            reject_divisor=reject_divisor,
            accept_streak_after=self._accept_streak,
        )

        return StepDecision(
            state=next_state,
            used_reference=used_reference,
            audit=audit,
            horizon=self.horizon,
        )

    def summary(self) -> dict[str, float]:
        """Return scalar counters suitable for CSV or JSON logs."""

        return {
            "learned_steps": float(self.stats.learned_steps),
            "reference_steps": float(self.stats.reference_steps),
            "rejected_steps": float(self.stats.rejected_steps),
            "learned_fraction": self.stats.learned_fraction,
            "horizon": float(self.horizon),
        }


class AdaptiveResidualGatedSwitch(ResidualGatedSwitch):
    """Adaptive residual switch with stronger shrink-on-rejection rules.

    This variant is useful for Paper 4 trust-region studies (#514/#526):
    it keeps the conservative fallback semantics of
    :class:`ResidualGatedSwitch` but shrinks prediction horizon based on
    rejection reason and residual magnitude.
    """

    def __init__(
        self,
        learned: LearnedStepper,
        reference: ReferenceStepper,
        auditor: ResidualAuditor,
        *,
        horizon: int = 1,
        min_horizon: int = 1,
        max_horizon: int = 1,
        grow_after_accepts: int = 3,
        reject_divisor: int = 2,
        strong_reject_divisor: int = 4,
        strong_reject_reasons: AbstractSet[str] | tuple[str, ...] = (
            "residual_high",
            "residual_nonfinite",
            "shape_mismatch",
        ),
        strong_reject_metric_threshold: float | None = None,
        residual_metric_key: str = "residual_relative",
    ) -> None:
        super().__init__(
            learned=learned,
            reference=reference,
            auditor=auditor,
            horizon=horizon,
            min_horizon=min_horizon,
            max_horizon=max_horizon,
            grow_after_accepts=grow_after_accepts,
        )
        if reject_divisor < 1 or strong_reject_divisor < 1:
            raise ValueError("reject_divisors must be >= 1")
        self.reject_divisor = int(reject_divisor)
        self.strong_reject_divisor = int(strong_reject_divisor)
        self.strong_reject_metric_threshold = strong_reject_metric_threshold
        self.residual_metric_key = residual_metric_key
        self.strong_reject_reasons = frozenset(strong_reject_reasons)

    def _residual_metric(self, audit: AuditResult) -> float:
        return float(audit.metrics.get(self.residual_metric_key, audit.residual))

    def _reject_divisor(self, audit: AuditResult) -> int:
        divisor = self.reject_divisor
        if audit.reason in self.strong_reject_reasons:
            divisor = self.strong_reject_divisor
        if (
            self.strong_reject_metric_threshold is not None
            and self._residual_metric(audit) >= self.strong_reject_metric_threshold
        ):
            divisor = max(divisor, self.strong_reject_divisor)
        return max(1, divisor)

    def step(self, state: State) -> StepDecision:
        horizon_before = self.horizon
        proposed = self.learned.propose(state, horizon=horizon_before)
        audit = self.auditor.audit(state, proposed)
        used_reference = not audit.accepted
        divisor = 1

        if audit.accepted:
            next_state = _merge_state(state, proposed)
            self.stats.learned_steps += 1
            self._accept_streak += 1
            if (
                self.horizon < self.max_horizon
                and self._accept_streak >= self.grow_after_accepts
            ):
                self.horizon += 1
                self._accept_streak = 0
        else:
            next_state = self.reference.step(state)
            self.stats.reference_steps += 1
            self.stats.rejected_steps += 1
            self._accept_streak = 0
            divisor = self._reject_divisor(audit)
            self.horizon = max(self.min_horizon, self.horizon // divisor)

        audit = _with_horizon_metrics(
            audit,
            horizon_before=horizon_before,
            horizon_after=self.horizon,
            reject_divisor=divisor,
            accept_streak_after=self._accept_streak,
        )

        return StepDecision(
            state=next_state,
            used_reference=used_reference,
            audit=audit,
            horizon=self.horizon,
        )
