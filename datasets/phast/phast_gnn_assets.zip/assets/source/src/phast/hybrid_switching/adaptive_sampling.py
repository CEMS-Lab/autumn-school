"""Mesh-native adaptive sampling for physics-informed hybrid models.

The finite-element mesh remains unchanged.  This module only chooses which
existing nodes, elements, or Gauss points receive extra training or audit
attention during a hybrid solve.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class AdaptivePhysicsSamplingConfig:
    """Weights and exploration controls for mesh-native point selection."""

    kkt_weight: float = 1.0
    gradient_weight: float = 1.0
    history_weight: float = 0.5
    increment_weight: float = 1.0
    uncertainty_weight: float = 0.5
    uniform_fraction: float = 0.2
    temperature: float = 1.0
    eps: float = 1.0e-12

    def __post_init__(self) -> None:
        weights = (
            self.kkt_weight,
            self.gradient_weight,
            self.history_weight,
            self.increment_weight,
            self.uncertainty_weight,
        )
        if any(weight < 0.0 for weight in weights):
            raise ValueError("indicator weights must be non-negative")
        if not any(weight > 0.0 for weight in weights):
            raise ValueError("at least one indicator weight must be positive")
        if not 0.0 <= self.uniform_fraction <= 1.0:
            raise ValueError("uniform_fraction must lie in [0, 1]")
        if self.temperature <= 0.0:
            raise ValueError("temperature must be positive")
        if self.eps <= 0.0:
            raise ValueError("eps must be positive")


@dataclass(frozen=True)
class AdaptivePhysicsSample:
    """Selected flat indices, split by adaptive and background sampling."""

    adaptive_indices: torch.Tensor
    uniform_indices: torch.Tensor
    scores: torch.Tensor

    @property
    def indices(self) -> torch.Tensor:
        return torch.cat((self.adaptive_indices, self.uniform_indices))


def _normalise_indicator(indicator: torch.Tensor, eps: float) -> torch.Tensor:
    values = torch.nan_to_num(
        indicator.abs(), nan=0.0, posinf=0.0, neginf=0.0
    )
    scale = values.amax()
    return torch.where(scale > eps, values / scale.clamp_min(eps), values)


def _check_shape(name: str, value: torch.Tensor, shape: torch.Size) -> None:
    if value.shape != shape:
        raise ValueError(
            f"{name} has shape {tuple(value.shape)}, expected {tuple(shape)}"
        )


def physics_sampling_scores(
    *,
    kkt_residual: torch.Tensor,
    grad_damage: torch.Tensor,
    history: torch.Tensor,
    damage_increment: torch.Tensor,
    uncertainty: torch.Tensor | None = None,
    length_scale: float | torch.Tensor = 1.0,
    config: AdaptivePhysicsSamplingConfig | None = None,
) -> torch.Tensor:
    """Build a dimensionless importance score on an existing FE point set.

    Each input is a nodal, element, or Gauss-point scalar field with the same
    shape. ``grad_damage`` is the magnitude of the damage gradient.  The score
    combines normalised indicators, so quantities with different units do not
    dominate merely because of their numerical scale.
    """

    cfg = config or AdaptivePhysicsSamplingConfig()
    shape = kkt_residual.shape
    for name, value in (
        ("grad_damage", grad_damage),
        ("history", history),
        ("damage_increment", damage_increment),
    ):
        _check_shape(name, value, shape)
    if uncertainty is not None:
        _check_shape("uncertainty", uncertainty, shape)

    if isinstance(length_scale, torch.Tensor):
        if length_scale.numel() != 1:
            _check_shape("length_scale", length_scale, shape)
        scaled_gradient = grad_damage * length_scale.to(
            device=grad_damage.device, dtype=grad_damage.dtype
        )
    else:
        scaled_gradient = grad_damage * float(length_scale)

    score = cfg.kkt_weight * _normalise_indicator(kkt_residual, cfg.eps)
    score = score + cfg.gradient_weight * _normalise_indicator(
        scaled_gradient, cfg.eps
    )
    score = score + cfg.history_weight * _normalise_indicator(history, cfg.eps)
    score = score + cfg.increment_weight * _normalise_indicator(
        damage_increment, cfg.eps
    )
    if uncertainty is not None and cfg.uncertainty_weight > 0.0:
        score = score + cfg.uncertainty_weight * _normalise_indicator(
            uncertainty, cfg.eps
        )
    return torch.nan_to_num(score, nan=0.0, posinf=0.0, neginf=0.0)


def sample_mesh_physics_points(
    scores: torch.Tensor,
    num_samples: int,
    *,
    eligible_mask: torch.Tensor | None = None,
    config: AdaptivePhysicsSamplingConfig | None = None,
    generator: torch.Generator | None = None,
) -> AdaptivePhysicsSample:
    """Sample unique flat FE-point indices from a score/background mixture."""

    cfg = config or AdaptivePhysicsSamplingConfig()
    if num_samples < 0:
        raise ValueError("num_samples must be non-negative")

    flat_scores = torch.nan_to_num(
        scores.detach().reshape(-1), nan=0.0, posinf=0.0, neginf=0.0
    ).clamp_min(0.0)
    if eligible_mask is None:
        eligible = torch.ones_like(flat_scores, dtype=torch.bool)
    else:
        if eligible_mask.shape != scores.shape:
            raise ValueError("eligible_mask must have the same shape as scores")
        eligible = eligible_mask.detach().reshape(-1).to(
            device=scores.device, dtype=torch.bool
        )

    pool = torch.nonzero(eligible, as_tuple=False).flatten()
    if num_samples > pool.numel():
        raise ValueError(
            f"requested {num_samples} samples from {pool.numel()} eligible points"
        )
    if num_samples == 0:
        empty = pool[:0]
        return AdaptivePhysicsSample(empty, empty, scores)

    uniform_count = int(round(num_samples * cfg.uniform_fraction))
    if cfg.uniform_fraction > 0.0:
        uniform_count = max(1, uniform_count)
    uniform_count = min(num_samples, uniform_count)
    adaptive_count = num_samples - uniform_count

    available = eligible.clone()
    adaptive_parts: list[torch.Tensor] = []
    if adaptive_count:
        pool_scores = flat_scores[pool]
        weights = pool_scores.pow(1.0 / cfg.temperature)
        positive_count = int(torch.count_nonzero(weights > cfg.eps).item())
        weighted_count = min(adaptive_count, positive_count)
        if weighted_count:
            local = torch.multinomial(
                weights, weighted_count, replacement=False, generator=generator
            )
            chosen = pool[local]
            adaptive_parts.append(chosen)
            available[chosen] = False

        remainder = adaptive_count - weighted_count
        if remainder:
            remaining_pool = torch.nonzero(available, as_tuple=False).flatten()
            order = torch.randperm(
                remaining_pool.numel(), device=scores.device, generator=generator
            )
            chosen = remaining_pool[order[:remainder]]
            adaptive_parts.append(chosen)
            available[chosen] = False

    adaptive_indices = (
        torch.cat(adaptive_parts) if adaptive_parts else pool[:0]
    )
    remaining_pool = torch.nonzero(available, as_tuple=False).flatten()
    order = torch.randperm(
        remaining_pool.numel(), device=scores.device, generator=generator
    )
    uniform_indices = remaining_pool[order[:uniform_count]]

    return AdaptivePhysicsSample(adaptive_indices, uniform_indices, scores)
