"""Residual helpers for hybrid switching controllers."""

from __future__ import annotations

import math
from typing import Callable

import torch

from .protocols import AuditResult, State


def relative_norm(residual: torch.Tensor, rhs: torch.Tensor | None = None) -> float:
    """Return ``||residual|| / max(||rhs||, 1)`` as a finite Python float."""

    denom = 1.0
    if rhs is not None:
        denom = max(float(torch.linalg.vector_norm(rhs.detach()).item()), 1.0)
    value = float(torch.linalg.vector_norm(residual.detach()).item()) / denom
    if not math.isfinite(value):
        return math.inf
    return value


class TensorResidualAuditor:
    """Adapter from a tensor residual function to ``AuditResult``.

    Parameters
    ----------
    residual_fn:
        Callable receiving ``(current, proposed)`` and returning either a
        residual tensor or ``(residual, rhs)``.
    threshold:
        Accepted relative residual threshold.
    physical_check:
        Optional callable for irreversibility, bounds, or energy checks.
    """

    def __init__(
        self,
        residual_fn: Callable[[State, State], torch.Tensor | tuple[torch.Tensor, torch.Tensor]],
        threshold: float,
        physical_check: Callable[[State, State], tuple[bool, str]] | None = None,
    ) -> None:
        self.residual_fn = residual_fn
        self.threshold = float(threshold)
        self.physical_check = physical_check

    def audit(self, current: State, proposed: State) -> AuditResult:
        out = self.residual_fn(current, proposed)
        if isinstance(out, tuple):
            residual, rhs = out
        else:
            residual, rhs = out, None
        rel = relative_norm(residual, rhs)
        accepted = rel <= self.threshold
        reason = "residual_ok" if accepted else "residual_high"

        if accepted and self.physical_check is not None:
            physical_ok, physical_reason = self.physical_check(current, proposed)
            accepted = bool(physical_ok)
            reason = physical_reason if not accepted else reason

        return AuditResult(
            residual=rel,
            accepted=accepted,
            reason=reason,
            metrics={"relative_residual": rel},
        )
