"""Closed-loop rollout utilities for hybrid solver / learned switching."""

from __future__ import annotations

import csv
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Mapping, Protocol

from .protocols import State, StepDecision
from .replay_buffer import ReplayRecord, ZarrReplayBufferWriter


POLICY_LOG_FIELDS: tuple[str, ...] = (
    "step",
    "accepted",
    "used_reference",
    "residual",
    "horizon",
    "reason",
    "wall_time_s",
    "learned_steps",
    "reference_steps",
    "rejected_steps",
    "learned_fraction",
)

_SUMMARY_FIELDS: tuple[str, ...] = (
    "learned_steps",
    "reference_steps",
    "rejected_steps",
    "learned_fraction",
)


class RolloutController(Protocol):
    """Minimal controller interface consumed by :func:`run_rollout`."""

    def step(self, state: State) -> StepDecision:
        ...

    def summary(self) -> Mapping[str, float]:
        ...


@dataclass(frozen=True)
class PolicyLogRecord:
    """One row of ``policy_log.csv`` for a hybrid rollout."""

    step: int
    accepted: bool
    used_reference: bool
    residual: float
    horizon: int
    reason: str
    wall_time_s: float
    summary: Mapping[str, float] = field(default_factory=dict)
    metrics: Mapping[str, float] = field(default_factory=dict)

    def to_row(self) -> dict[str, float | int | bool | str]:
        """Return a flat CSV row with stable base columns.

        Auditor metrics are prefixed with ``metric_``; non-standard
        controller summary values are prefixed with ``summary_``.
        """

        row: dict[str, float | int | bool | str] = {
            "step": self.step,
            "accepted": self.accepted,
            "used_reference": self.used_reference,
            "residual": self.residual,
            "horizon": self.horizon,
            "reason": self.reason,
            "wall_time_s": self.wall_time_s,
        }
        for key in _SUMMARY_FIELDS:
            row[key] = float(self.summary.get(key, 0.0))
        for key, value in self.summary.items():
            if key in _SUMMARY_FIELDS or key == "horizon":
                continue
            row[f"summary_{key}"] = float(value)
        for key, value in self.metrics.items():
            row[f"metric_{key}"] = float(value)
        return row


@dataclass(frozen=True)
class HybridRolloutResult:
    """Final state and policy records from a closed-loop rollout."""

    final_state: State
    records: list[PolicyLogRecord]
    summary: dict[str, float]


StepCallback = Callable[[int, StepDecision, PolicyLogRecord], None]
ReplayRecordFn = Callable[[int, State, StepDecision, PolicyLogRecord], ReplayRecord]


def run_rollout(
    controller: RolloutController,
    initial_state: State,
    n_steps: int,
    *,
    csv_path: str | Path | None = None,
    replay_path: str | Path | None = None,
    replay_writer: ZarrReplayBufferWriter | None = None,
    replay_required_fields: Mapping[str, tuple[str, ...]] | None = None,
    replay_record_fn: ReplayRecordFn | None = None,
    step_callback: StepCallback | None = None,
) -> HybridRolloutResult:
    """Advance ``n_steps`` with a hybrid controller and optional CSV logging.

    The controller remains the only authority for accept/reject/fallback
    policy. This runner records the resulting decisions and advances from
    ``decision.state`` each step.
    """

    if n_steps < 0:
        raise ValueError("n_steps must be non-negative")

    if replay_path is not None and replay_writer is not None:
        raise ValueError("provide either replay_path or replay_writer, not both")
    if replay_required_fields is not None and replay_writer is not None:
        raise ValueError("provide replay_required_fields with replay_path, not an existing writer")
    owned_replay_writer: ZarrReplayBufferWriter | None = None
    if replay_path is not None:
        owned_replay_writer = ZarrReplayBufferWriter(
            replay_path,
            overwrite=True,
            required_fields=replay_required_fields,
        )
        replay_writer = owned_replay_writer

    state = initial_state
    records: list[PolicyLogRecord] = []
    try:
        for step in range(n_steps):
            state_before = state
            start = time.perf_counter()
            decision = controller.step(state_before)
            wall_time_s = time.perf_counter() - start
            summary = dict(controller.summary())
            record = PolicyLogRecord(
                step=step,
                accepted=decision.audit.accepted,
                used_reference=decision.used_reference,
                residual=float(decision.audit.residual),
                horizon=int(decision.horizon),
                reason=decision.audit.reason,
                wall_time_s=wall_time_s,
                summary=summary,
                metrics=dict(decision.audit.metrics),
            )
            records.append(record)
            if replay_writer is not None:
                replay = (
                    replay_record_fn(step, state_before, decision, record)
                    if replay_record_fn is not None
                    else _default_replay_record(step, state_before, decision, record)
                )
                replay_writer.append(replay)
            state = decision.state
            if step_callback is not None:
                step_callback(step, decision, record)
    finally:
        if owned_replay_writer is not None:
            owned_replay_writer.close()

    if csv_path is not None:
        write_policy_log(records, csv_path)

    return HybridRolloutResult(
        final_state=state,
        records=records,
        summary=dict(controller.summary()),
    )


def write_policy_log(records: list[PolicyLogRecord], path: str | Path) -> None:
    """Write rollout policy records to CSV with deterministic column order."""

    rows = [record.to_row() for record in records]
    fieldnames = _policy_log_fieldnames(rows)
    out_path = Path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def _policy_log_fieldnames(rows: list[dict[str, object]]) -> list[str]:
    fieldnames = list(POLICY_LOG_FIELDS)
    extra_fields: set[str] = set()
    for row in rows:
        extra_fields.update(row)
    for name in sorted(extra_fields):
        if name not in fieldnames:
            fieldnames.append(name)
    return fieldnames


def _default_replay_record(
    step: int,
    state_before: State,
    decision: StepDecision,
    record: PolicyLogRecord,
) -> ReplayRecord:
    """Build a conservative replay row from generic rollout information.

    Generic controllers do not expose the raw rejected proposal. The default
    record therefore stores the pre-step state, the accepted proposal state when
    accepted, or the trusted fallback state when reference was used. Paper 4
    model-specific live scripts can pass ``replay_record_fn`` to include raw
    proposals, projected proposals, and solver corrections.
    """

    audits = {
        "residual": record.residual,
        "accepted": record.accepted,
        "used_reference": record.used_reference,
        "reason": record.reason,
    }
    audits.update(record.metrics)
    metadata = {
        "step": step,
        "horizon": record.horizon,
        "wall_time_s": record.wall_time_s,
    }
    metadata.update({f"summary_{k}": v for k, v in record.summary.items()})
    if decision.used_reference:
        return ReplayRecord(
            state_t=state_before,
            reference_t1=decision.state,
            audits=audits,
            metadata=metadata,
        )
    return ReplayRecord(
        state_t=state_before,
        proposal_t1=decision.state,
        projected_t1=decision.state,
        audits=audits,
        metadata=metadata,
    )
