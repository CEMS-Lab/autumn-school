"""Small interfaces for learned-step / reference-solver switching.

The controller deliberately works with a plain state mapping so it can wrap
the current solver state, PF-Hetero-Bench samples, or lightweight tests.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol


State = Mapping[str, Any]


@dataclass(frozen=True)
class AuditResult:
    """Physics audit of a proposed learned state."""

    residual: float
    accepted: bool
    reason: str = ""
    metrics: dict[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class StepDecision:
    """Outcome of one hybrid switching step."""

    state: State
    used_reference: bool
    audit: AuditResult
    horizon: int


class LearnedStepper(Protocol):
    """Predict one or more future states from the current state."""

    def propose(self, state: State, horizon: int = 1) -> State:
        ...


class ReferenceStepper(Protocol):
    """Advance with the trusted solver."""

    def step(self, state: State) -> State:
        ...


class ResidualAuditor(Protocol):
    """Audit a learned proposal against physical diagnostics."""

    def audit(self, current: State, proposed: State) -> AuditResult:
        ...
