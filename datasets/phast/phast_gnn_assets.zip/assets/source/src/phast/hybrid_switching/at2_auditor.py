"""AT2-residual + energy + irreversibility auditor for the W3 smoke gate.

Implements :class:`AT2Auditor`, the production auditor for Paper 4 V2
controllers. Wraps the differentiable solver's own residual + physics-loss
machinery to score a learned damage proposal on three criteria:

1. **AT2 weak damage residual.** Calls
   ``PhaseFieldDamageSolver.compute_residual(H_input, d)``; the proposal
   passes when its free-DOF residual, normalised by the pre-damage residual,
   is below ``tau_r``.
2. **Fixed-displacement energy increase.** When FEM energy evaluation is
   available, rejects a proposal that raises the damage-subproblem total
   energy by more than ``tau_E`` relative to the pre-damage state.
3. **Irreversibility.** Counts and bounds nodes where
   ``d_proposed < d_prev``. The hard rule is "zero hard violations after
   projection" (per ``papers/paper4/experiment_matrix.md`` §4).

Per **D12-1** (``related_work.md`` §12, transferred mechanism from
NeuralGCM-class hard inference projections), the proposal is **projected**
before residual evaluation::

    d_proj = max(d_proposed.clip(0, 1), d_prev)

This means the residual is always computed on a *physical* proposal, never
the raw NN output. Without this projection, the auditor would mistake
irreversibility violations or out-of-bounds NN noise for high residual,
which would trigger fallback when in fact a tiny clamp would have saved
the step.

Notes
-----
- AT1 / PF-CZM models are not yet supported; the auditor raises
  ``NotImplementedError`` if the underlying solver is configured for them
  (mirrors ``FEMOperators.compute_physics_loss``).
- The auditor is read-only with respect to the solver. It computes
  diagnostics; it does not mutate solver state. State application is
  ``StateAdapter.apply_proposal``'s job.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping

import torch

from .protocols import AuditResult, State


@dataclass(frozen=True)
class AT2AuditConfig:
    """Threshold + weighting policy for :class:`AT2Auditor`.

    Defaults are placeholders calibrated for SENT smoke tier. Real values
    must be calibrated on a held-out R0 trajectory before publishable
    speedup claims, per Paper 4 ``CLAIMS_LOG.md`` P4-C4 + P4-C6.
    """

    # Relative AT2 weak-residual threshold (BoTorch D8 search range
    # [1e-4, 1e-1]; default at the more conservative end).
    tau_r: float = 1e-2

    # Relative fixed-displacement energy-increase threshold ([1e-4, 1e-1]).
    tau_E: float = 1e-2

    # Irreversibility tolerance: a "violation" is d_proposed < d_prev - eps.
    irrev_eps: float = 1e-6

    # Maximum number of irreversibility violations tolerated *after* the
    # hard projection. The projection ensures zero violations
    # mathematically, but float roundoff can leave a handful; the cap
    # catches a broken proposal that the projection cannot save.
    max_irrev_violations: int = 0

    # Damage bounds eps for the [0, 1] projection.
    bounds_eps: float = 1e-9


def project_damage_irreversible(
    d_proposed: torch.Tensor,
    d_prev: torch.Tensor,
    *,
    eps: float = 1e-9,
) -> torch.Tensor:
    """Hard pre-audit projection (D12-1).

    Returns ``max(d_proposed.clip(0, 1), d_prev)`` element-wise. The
    resulting tensor satisfies (i) ``0 <= d <= 1``, (ii) ``d >= d_prev``,
    by construction -- so the residual computed on it reflects a *valid*
    physical state, not the raw NN output.
    """
    d_clip = d_proposed.clamp(min=0.0 - eps, max=1.0 + eps)
    return torch.maximum(d_clip, d_prev)


class AT2Auditor:
    """Residual + energy + irreversibility auditor for learned damage proposals.

    Parameters
    ----------
    solver
        A :class:`StaggeredSolver` instance. The auditor calls
        ``solver.damage_solver.compute_residual()`` for the AT2 weak-form
        residual and reads ``mesh`` / ``material`` from it.
    fem_ops
        Optional :class:`FEMOperators`; if given,
        ``fem_ops.compute_physics_loss(u, d, H_elem)`` is used as the
        scalar mechanics + damage residual signal. If ``None``, only the
        damage residual is checked (cheaper, weaker).
    config
        :class:`AT2AuditConfig`. Calibrate at the smoke tier; tune via
        BoTorch at Dev tier (D8).

    Notes
    -----
    The auditor is intentionally protocol-compatible with
    ``hybrid_switching.protocols.ResidualAuditor``: it exposes a single
    ``audit(current: State, proposed: State) -> AuditResult`` method.
    """

    def __init__(self, solver: Any, fem_ops: Any = None,
                 config: AT2AuditConfig | None = None) -> None:
        self.solver = solver
        self.fem_ops = fem_ops
        self.config = config or AT2AuditConfig()

        # Verify the solver advertises the AT2 hooks we rely on.
        if not hasattr(solver, "damage_solver"):
            raise ValueError(
                "AT2Auditor: solver lacks a 'damage_solver' attribute; "
                "expected an instance of StaggeredSolver with an attached "
                "PhaseFieldDamageSolver."
            )
        if not hasattr(solver.damage_solver, "compute_residual"):
            raise ValueError(
                "AT2Auditor: solver.damage_solver lacks compute_residual; "
                "rebuild on a recent phast (>= PR #298 era)."
            )

        mat = getattr(solver, "material", None)
        pf_model = (getattr(mat, "pf_model", "AT2") or "AT2").upper()
        if pf_model != "AT2":
            raise NotImplementedError(
                f"AT2Auditor currently supports AT2 only; got pf_model={pf_model!r}. "
                "Wire a model-specific residual before using this auditor "
                "for AT1/PF-CZM."
            )

    # ------------------------------------------------------------------
    # Public API (ResidualAuditor protocol)
    # ------------------------------------------------------------------

    def audit(self, current: State, proposed: State) -> AuditResult:
        """Audit a learned damage proposal.

        Parameters
        ----------
        current : State
            Mapping with at least ``d`` (previous damage, (N,)) and
            ``H_elem`` or ``H_nodal`` (history variable).
        proposed : State
            Mapping with at least ``d`` (proposed damage, (N,)). Other
            keys are ignored at audit time; ``StateAdapter`` handles their
            propagation if accepted.

        Returns
        -------
        AuditResult
            ``accepted`` is true iff *all three* checks pass after D12-1
            projection: residual <= tau_r, energy drift <= tau_E,
            irreversibility violations <= max_irrev_violations.
            ``metrics`` carries the diagnostic scalars for logging / F3
            / `policy_log.csv`.
        """
        cfg = self.config
        d_prev = _get_tensor(current, "d")
        d_proposed = _get_tensor(proposed, "d")
        if d_proposed.shape != d_prev.shape:
            return _reject(
                math.inf,
                reason="shape_mismatch",
                metrics={
                    "shape_d_prev": float(d_prev.numel()),
                    "shape_d_proposed": float(d_proposed.numel()),
                },
            )

        # ---- D12-1 hard projection ----------------------------------
        projected = self.project_proposal(current, proposed)
        d_proj = _get_tensor(projected, "d")
        fixed_mask, _fixed_values = self._pf_dirichlet()

        # ---- check 1: residual on the projected proposal ------------
        H_input = self._get_history(current)
        residual = self.solver.damage_solver.compute_residual(H_input, d_proj)
        reference_residual = self.solver.damage_solver.compute_residual(
            H_input, d_prev)
        if fixed_mask is not None:
            residual = residual.clone()
            reference_residual = reference_residual.clone()
            residual[fixed_mask] = 0.0
            reference_residual[fixed_mask] = 0.0
        residual_l2 = float(torch.linalg.vector_norm(residual.detach()).item())
        reference_l2 = float(
            torch.linalg.vector_norm(reference_residual.detach()).item())
        rel_res = self._relative_norm(residual, reference_residual)

        # ---- check 2: irreversibility violations after projection --
        n_violations = int(((d_proposed.detach() < d_prev.detach() - cfg.irrev_eps)
                            & (d_proj.detach() < d_prev.detach() - cfg.irrev_eps)).sum().item())

        # ---- check 3: energy-balance drift (optional, if fem_ops) --
        # Mechanics residual ||R_u|| via compute_physics_loss provides a
        # complementary signal; we surface it as a metric.
        physics_loss = None
        energy_relative_increase = None
        if self.fem_ops is not None:
            u_cur = _get_tensor(current, "u")
            H_elem = _get_tensor(current, "H_elem")
            try:
                physics_loss = float(
                    self.fem_ops.compute_physics_loss(u_cur.detach(), d_proj.detach(), H_elem.detach())
                    .detach()
                    .item()
                )
            except Exception as exc:  # noqa: BLE001 -- defensive metric
                physics_loss = math.inf
            try:
                energy_before = float(self.fem_ops.compute_total_energy(
                    u_cur.detach(), d_prev.detach()))
                energy_after = float(self.fem_ops.compute_total_energy(
                    u_cur.detach(), d_proj.detach()))
                energy_relative_increase = max(
                    energy_after - energy_before, 0.0) / max(
                        abs(energy_before), torch.finfo(d_proj.dtype).tiny)
            except Exception:  # noqa: BLE001 -- optional but explicit gate
                energy_relative_increase = math.inf

        metrics: dict[str, float] = {
            "residual_relative": rel_res,
            "residual_l2": residual_l2,
            "residual_reference_l2": reference_l2,
            "n_irrev_violations": float(n_violations),
            "d_proj_max": float(d_proj.max().item()),
            "d_proj_min": float(d_proj.min().item()),
            "raw_d_max": float(d_proposed.max().item()),
            "raw_d_min": float(d_proposed.min().item()),
        }
        if physics_loss is not None:
            metrics["physics_loss"] = physics_loss
        if energy_relative_increase is not None:
            metrics["energy_relative_increase"] = energy_relative_increase

        # ---- decision ------------------------------------------------
        if not math.isfinite(rel_res):
            return _reject(rel_res, reason="residual_nonfinite", metrics=metrics)
        if rel_res > cfg.tau_r:
            return _reject(rel_res, reason="residual_high", metrics=metrics)
        if (energy_relative_increase is not None
                and (not math.isfinite(energy_relative_increase)
                     or energy_relative_increase > cfg.tau_E)):
            return _reject(rel_res, reason="energy_increase_high", metrics=metrics)
        if n_violations > cfg.max_irrev_violations:
            return _reject(rel_res, reason="irreversibility_violation", metrics=metrics)
        return AuditResult(
            residual=rel_res, accepted=True, reason="all_checks_passed", metrics=metrics,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _relative_norm(residual: torch.Tensor, rhs: torch.Tensor | None = None) -> float:
        numerator = float(torch.linalg.vector_norm(residual.detach()).item())
        if rhs is None:
            denom = max(numerator, torch.finfo(residual.dtype).tiny)
        else:
            denom = max(
                float(torch.linalg.vector_norm(rhs.detach()).item()),
                torch.finfo(residual.dtype).tiny,
            )
        value = numerator / denom
        if not math.isfinite(value):
            return math.inf
        return value

    def project_proposal(
        self, current: State, proposed: State
    ) -> dict[str, Any]:
        """Return the exact physical proposal audited on the accept path."""
        d_prev = _get_tensor(current, "d")
        d_raw = _get_tensor(proposed, "d")
        d_proj = project_damage_irreversible(
            d_raw, d_prev, eps=self.config.bounds_eps)
        fixed_mask, fixed_values = self._pf_dirichlet()
        if fixed_mask is not None:
            d_proj = d_proj.clone()
            d_proj[fixed_mask] = fixed_values[fixed_mask]
        result = dict(proposed)
        result["d"] = d_proj
        return result

    def _pf_dirichlet(
        self,
    ) -> tuple[torch.Tensor | None, torch.Tensor | None]:
        bcs = getattr(self.solver, "bcs", None)
        if bcs is None or not getattr(bcs, "pf_dirichlet_bcs", None):
            return None, None
        mask, values = bcs.get_pf_dirichlet_mask_values()
        d = getattr(self.solver, "d", None)
        if d is not None:
            mask = mask.to(device=d.device, dtype=torch.bool)
            values = values.to(device=d.device, dtype=d.dtype)
        return mask, values

    def _get_history(self, state: Mapping[str, Any]) -> torch.Tensor:
        """Return history with the shape expected by ``compute_residual``."""

        use_nodal = bool(getattr(self.solver.damage_solver, "_nodal_H", False))
        preferred = ("H_nodal", "H_elem") if use_nodal else ("H_elem", "H_nodal")
        for key in preferred:
            if key in state and state[key] is not None:
                return _ensure_tensor(state[key])
        raise KeyError(
            "AT2Auditor.audit: current state has neither 'H_nodal' nor 'H_elem'."
        )


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

def _get_tensor(state: Mapping[str, Any], key: str) -> torch.Tensor:
    if key not in state:
        raise KeyError(f"State missing required key {key!r}; have {list(state.keys())}.")
    return _ensure_tensor(state[key])


def _ensure_tensor(v: Any) -> torch.Tensor:
    if isinstance(v, torch.Tensor):
        return v
    return torch.as_tensor(v)


def _reject(rel_res: float, *, reason: str, metrics: dict[str, float]) -> AuditResult:
    return AuditResult(residual=rel_res, accepted=False, reason=reason, metrics=metrics)
