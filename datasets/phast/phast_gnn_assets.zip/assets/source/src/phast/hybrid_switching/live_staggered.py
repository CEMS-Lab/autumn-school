"""Live staggered-solver controller for residual-gated switching.

This bridges the tested controller API to the execution order required by a
live :class:`StaggeredSolver`:

1. snapshot the path-dependent state,
2. advance mechanics and update strain/history,
3. let the learned model propose the damage update,
4. audit the proposal,
5. accept by installing the proposal and advancing time, or reject by rolling
   back the full state and running the trusted solver step.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping, TYPE_CHECKING, AbstractSet

import torch

from .protocols import AuditResult, ResidualAuditor, State, StepDecision
from .state_adapter import StateAdapter

if TYPE_CHECKING:  # pragma: no cover -- typing only
    from phast.staggered_solver import StaggeredSolver


DamageProposalFn = Callable[
    ["StaggeredSolver", State, torch.Tensor, int, int],
    Mapping[str, Any] | torch.Tensor,
]


@dataclass
class LiveStaggeredStats:
    learned_steps: int = 0
    reference_steps: int = 0
    rejected_steps: int = 0
    forced_reference_steps: int = 0
    correction_gate_rejections: int = 0
    ensemble_gate_rejections: int = 0
    profile_gate_rejections: int = 0
    accepted_hybrid_wall_s: float = 0.0
    rejected_proposal_wall_s: float = 0.0
    fallback_reference_wall_s: float = 0.0
    total_hybrid_wall_s: float = 0.0

    @property
    def total_steps(self) -> int:
        return self.learned_steps + self.reference_steps

    @property
    def learned_fraction(self) -> float:
        return self.learned_steps / self.total_steps if self.total_steps else 0.0


@dataclass(frozen=True)
class ProposalResult:
    """Damage proposal plus proposal-side metrics for post-audit gates."""

    proposed: Mapping[str, Any]
    metrics: Mapping[str, float]


class LiveStaggeredGatedSwitch:
    """Residual-gated live controller for a staggered fracture solver.

    The generic :class:`ResidualGatedSwitch` is state-map-only. A live
    phase-field fracture step has ordering constraints: mechanics and history
    must be advanced before the surrogate proposes damage, while rejection must
    restore the full pre-step state before the trusted solver correction. This
    wrapper keeps those semantics in one tested API.
    """

    def __init__(
        self,
        solver: "StaggeredSolver",
        proposal_fn: DamageProposalFn,
        auditor: ResidualAuditor,
        *,
        horizon: int = 1,
        min_horizon: int = 1,
        max_horizon: int = 1,
        grow_after_accepts: int = 3,
        max_learned_streak: int | None = None,
        max_correction_l2: float | None = None,
        max_ensemble_spread_l2: float | None = None,
        max_profile_metrics: Mapping[str, float] | None = None,
        reject_divisor: int = 2,
        strong_reject_divisor: int = 4,
        strong_reject_reasons: AbstractSet[str] | tuple[str, ...] = (
            "residual_high",
            "residual_nonfinite",
            "shape_mismatch",
        ),
        strong_reject_metric_threshold: float | None = None,
        residual_metric_key: str = "residual_relative",
    ) -> None:
        if min_horizon < 1 or horizon < 1 or max_horizon < 1:
            raise ValueError("horizons must be positive")
        if min_horizon > max_horizon:
            raise ValueError("min_horizon cannot exceed max_horizon")
        if reject_divisor < 1 or strong_reject_divisor < 1:
            raise ValueError("reject_divisors must be >= 1")
        self.solver = solver
        self.adapter = StateAdapter(solver)
        self.proposal_fn = proposal_fn
        self.auditor = auditor
        self.horizon = min(max(horizon, min_horizon), max_horizon)
        self.min_horizon = min_horizon
        self.max_horizon = max_horizon
        self.grow_after_accepts = max(int(grow_after_accepts), 1)
        self.max_learned_streak = max_learned_streak
        self.max_correction_l2 = max_correction_l2
        self.max_ensemble_spread_l2 = max_ensemble_spread_l2
        self.max_profile_metrics = {
            str(key): float(value)
            for key, value in (max_profile_metrics or {}).items()
            if value is not None and float(value) > 0.0
        }
        self.reject_divisor = int(reject_divisor)
        self.strong_reject_divisor = int(strong_reject_divisor)
        self.residual_metric_key = residual_metric_key
        self.strong_reject_reasons = frozenset(strong_reject_reasons)
        self.strong_reject_metric_threshold = strong_reject_metric_threshold
        self.stats = LiveStaggeredStats()
        self._accept_streak = 0
        self._learned_streak = 0
        self._step_index = 0

    def _residual_metric(self, audit: AuditResult) -> float:
        return float(audit.metrics.get(self.residual_metric_key, audit.residual))

    def _reject_divisor(self, audit: AuditResult) -> int:
        divisor = self.reject_divisor
        if audit.reason in self.strong_reject_reasons:
            divisor = self.strong_reject_divisor
        if (
            self.strong_reject_metric_threshold is not None
            and self._residual_metric(audit) >= self.strong_reject_metric_threshold
        ):
            divisor = max(divisor, self.strong_reject_divisor)
        return max(1, divisor)

    @staticmethod
    def _with_timing_metrics(
        audit: AuditResult,
        *,
        proposal_audit_wall_s: float,
        accepted_hybrid_wall_s: float,
        rejected_proposal_wall_s: float,
        fallback_reference_wall_s: float,
        total_hybrid_wall_s: float,
        horizon_before: int,
        horizon_after: int,
        horizon_reject_divisor: int,
        horizon_accept_streak_after: int,
    ) -> AuditResult:
        metrics = dict(audit.metrics)
        metrics.update({
            "proposal_audit_wall_s": float(proposal_audit_wall_s),
            "accepted_hybrid_wall_s": float(accepted_hybrid_wall_s),
            "rejected_proposal_wall_s": float(rejected_proposal_wall_s),
            "fallback_reference_wall_s": float(fallback_reference_wall_s),
            "total_hybrid_wall_s": float(total_hybrid_wall_s),
            "horizon_before": float(horizon_before),
            "horizon_after": float(horizon_after),
            "horizon_changed": float(horizon_before != horizon_after),
            "horizon_reject_divisor": float(horizon_reject_divisor),
            "horizon_accept_streak_after": float(horizon_accept_streak_after),
        })
        return AuditResult(
            residual=audit.residual,
            accepted=audit.accepted,
            reason=audit.reason,
            metrics=metrics,
        )

    def step(self, state: State) -> StepDecision:
        """Run one live hybrid step with full-state rollback on rejection."""

        step_t0 = time.perf_counter()
        # Align the live solver with the caller's initial state once. After
        # that, this controller is the authority for advancing/rolling back
        # the live solver. Replaying the returned snapshot through set_state()
        # at every step can perturb solver-private caches that are not part of
        # the public state mapping, while the trusted rollback boundary below
        # remains the explicit per-step snapshot.
        if self._step_index == 0:
            self.adapter.rollback(state)
        step_start = self.adapter.snapshot()
        horizon_before = self.horizon

        self.solver.step_mechanics()
        strain = self.solver.fem.compute_strain(self.solver.u)
        self.solver._last_strain = strain
        self.solver.step_compute_driving_force(strain=strain)
        pre_damage = self.adapter.snapshot()

        proposal = self.proposal_fn(
            self.solver, pre_damage, strain, self._step_index, self.horizon)
        if isinstance(proposal, ProposalResult):
            proposed = proposal.proposed
            proposal_metrics = dict(proposal.metrics)
        elif isinstance(proposal, torch.Tensor):
            proposed: Mapping[str, Any] = {"d": proposal}
            proposal_metrics = {}
        else:
            proposed = proposal
            proposal_metrics = {}

        audit = self.auditor.audit(pre_damage, proposed)
        if proposal_metrics:
            audit = AuditResult(
                residual=audit.residual,
                accepted=audit.accepted,
                reason=audit.reason,
                metrics={**audit.metrics, **proposal_metrics},
            )
        proposal_audit_wall_s = time.perf_counter() - step_t0
        correction_gate_fail = (
            self.max_correction_l2 is not None
            and float(audit.metrics.get("correction_l2", 0.0)) > self.max_correction_l2
        )
        ensemble_gate_fail = (
            self.max_ensemble_spread_l2 is not None
            and float(audit.metrics.get("ensemble_spread_l2", 0.0)) > self.max_ensemble_spread_l2
        )
        profile_gate_fail = False
        profile_gate_metric = ""
        profile_gate_value = 0.0
        profile_gate_threshold = 0.0
        for metric_name, threshold in self.max_profile_metrics.items():
            metric_value = float(audit.metrics.get(metric_name, 0.0))
            if metric_value > threshold:
                profile_gate_fail = True
                profile_gate_metric = metric_name
                profile_gate_value = metric_value
                profile_gate_threshold = threshold
                break
        force_reference = (
            self.max_learned_streak is not None
            and self.max_learned_streak > 0
            and self._learned_streak >= self.max_learned_streak
        )

        if (
            audit.accepted
            and not force_reference
            and not correction_gate_fail
            and not ensemble_gate_fail
            and not profile_gate_fail
        ):
            self.adapter.rollback(pre_damage)
            # Install the same physical field that was audited. Auditors may
            # expose a hard projection (bounds, irreversibility, pinned PF
            # values); installing the raw proposal after auditing a projected
            # copy would invalidate the acceptance certificate.
            project = getattr(self.auditor, "project_proposal", None)
            accepted_proposal = (
                project(pre_damage, proposed) if callable(project) else proposed)
            self.adapter.apply_proposal(accepted_proposal)
            if hasattr(self.solver, "_apply_pf_dirichlet"):
                self.solver._apply_pf_dirichlet()
            self.solver.advance_step()
            self.solver._last_stagger_iter = 1
            self.solver._last_residual = float(audit.residual)
            self.solver._last_dt_used = (
                float(self.solver.dt) if self.solver.dt is not None else 0.0)
            self.stats.learned_steps += 1
            self._learned_streak += 1
            self._accept_streak += 1
            used_reference = False
            if (
                self.horizon < self.max_horizon
                and self._accept_streak >= self.grow_after_accepts
            ):
                self.horizon += 1
                self._accept_streak = 0
            total_hybrid_wall_s = time.perf_counter() - step_t0
            self.stats.accepted_hybrid_wall_s += total_hybrid_wall_s
            self.stats.total_hybrid_wall_s += total_hybrid_wall_s
            audit = self._with_timing_metrics(
                audit,
                proposal_audit_wall_s=proposal_audit_wall_s,
                accepted_hybrid_wall_s=total_hybrid_wall_s,
                rejected_proposal_wall_s=0.0,
                fallback_reference_wall_s=0.0,
                total_hybrid_wall_s=total_hybrid_wall_s,
                horizon_before=horizon_before,
                horizon_after=self.horizon,
                horizon_reject_divisor=1,
                horizon_accept_streak_after=self._accept_streak,
            )
        else:
            self.adapter.rollback(step_start)
            reference_t0 = time.perf_counter()
            self.solver.step_full()
            fallback_reference_wall_s = time.perf_counter() - reference_t0
            self.stats.reference_steps += 1
            divisor = self.reject_divisor
            if ensemble_gate_fail:
                self.stats.ensemble_gate_rejections += 1
                audit = AuditResult(
                    residual=audit.residual,
                    accepted=False,
                    reason="ensemble_spread_high",
                    metrics=dict(audit.metrics),
                )
                self.stats.rejected_steps += 1
                divisor = self._reject_divisor(audit)
            elif correction_gate_fail:
                self.stats.correction_gate_rejections += 1
                audit = AuditResult(
                    residual=audit.residual,
                    accepted=False,
                    reason="correction_l2_high",
                    metrics=dict(audit.metrics),
                )
                self.stats.rejected_steps += 1
                divisor = self._reject_divisor(audit)
            elif profile_gate_fail:
                self.stats.profile_gate_rejections += 1
                metrics = dict(audit.metrics)
                metrics["profile_gate_value"] = profile_gate_value
                metrics["profile_gate_threshold"] = profile_gate_threshold
                audit = AuditResult(
                    residual=audit.residual,
                    accepted=False,
                    reason=f"proposal_profile_high:{profile_gate_metric}",
                    metrics=metrics,
                )
                self.stats.rejected_steps += 1
                divisor = self._reject_divisor(audit)
            elif force_reference and audit.accepted:
                self.stats.forced_reference_steps += 1
                audit = AuditResult(
                    residual=audit.residual,
                    accepted=False,
                    reason="forced_reference",
                    metrics=dict(audit.metrics),
                )
                divisor = self._reject_divisor(audit)
            else:
                self.stats.rejected_steps += 1
                divisor = self._reject_divisor(audit)
            self._learned_streak = 0
            self._accept_streak = 0
            self.horizon = max(self.min_horizon, self.horizon // divisor)
            used_reference = True
            total_hybrid_wall_s = time.perf_counter() - step_t0
            self.stats.rejected_proposal_wall_s += proposal_audit_wall_s
            self.stats.fallback_reference_wall_s += fallback_reference_wall_s
            self.stats.total_hybrid_wall_s += total_hybrid_wall_s
            audit = self._with_timing_metrics(
                audit,
                proposal_audit_wall_s=proposal_audit_wall_s,
                accepted_hybrid_wall_s=0.0,
                rejected_proposal_wall_s=proposal_audit_wall_s,
                fallback_reference_wall_s=fallback_reference_wall_s,
                total_hybrid_wall_s=total_hybrid_wall_s,
                horizon_before=horizon_before,
                horizon_after=self.horizon,
                horizon_reject_divisor=divisor,
                horizon_accept_streak_after=self._accept_streak,
            )

        self._step_index += 1
        return StepDecision(
            state=self.adapter.snapshot(),
            used_reference=used_reference,
            audit=audit,
            horizon=self.horizon,
        )

    def summary(self) -> dict[str, float]:
        return {
            "learned_steps": float(self.stats.learned_steps),
            "reference_steps": float(self.stats.reference_steps),
            "rejected_steps": float(self.stats.rejected_steps),
            "forced_reference_steps": float(self.stats.forced_reference_steps),
            "correction_gate_rejections": float(self.stats.correction_gate_rejections),
            "ensemble_gate_rejections": float(self.stats.ensemble_gate_rejections),
            "profile_gate_rejections": float(self.stats.profile_gate_rejections),
            "learned_fraction": self.stats.learned_fraction,
            "horizon": float(self.horizon),
            "accepted_hybrid_wall_s": float(self.stats.accepted_hybrid_wall_s),
            "rejected_proposal_wall_s": float(self.stats.rejected_proposal_wall_s),
            "fallback_reference_wall_s": float(self.stats.fallback_reference_wall_s),
            "total_hybrid_wall_s": float(self.stats.total_hybrid_wall_s),
        }
