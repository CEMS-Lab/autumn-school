"""Residual-gated hybrid solver / learned-model switching."""

from .adaptive_sampling import (
    AdaptivePhysicsSample,
    AdaptivePhysicsSamplingConfig,
    physics_sampling_scores,
    sample_mesh_physics_points,
)
from .at2_auditor import AT2AuditConfig, AT2Auditor, project_damage_irreversible
from .controllers import AdaptiveResidualGatedSwitch, ResidualGatedSwitch
from .live_staggered import (
    LiveStaggeredGatedSwitch,
    LiveStaggeredStats,
    ProposalResult,
)
from .protocols import AuditResult, LearnedStepper, ReferenceStepper, StepDecision
from .replay_buffer import (
    REPLAY_FORMAT,
    REPLAY_REQUIRED_FIELDS,
    ReplayRecord,
    ZarrReplayBufferReader,
    ZarrReplayBufferWriter,
)
from .residuals import TensorResidualAuditor, relative_norm
from .rollout import (
    HybridRolloutResult,
    PolicyLogRecord,
    ReplayRecordFn,
    run_rollout,
    write_policy_log,
)
from .state_adapter import (
    REQUIRED_ROLLBACK_KEYS,
    SOLVER_STATE_KEYS,
    RollbackContractError,
    StateAdapter,
    clone_state,
    validate_rollback_state,
)

__all__ = [
    "AdaptivePhysicsSample",
    "AdaptivePhysicsSamplingConfig",
    "AT2AuditConfig",
    "AT2Auditor",
    "AuditResult",
    "HybridRolloutResult",
    "LearnedStepper",
    "LiveStaggeredGatedSwitch",
    "LiveStaggeredStats",
    "PolicyLogRecord",
    "ProposalResult",
    "REPLAY_FORMAT",
    "ReferenceStepper",
    "ReplayRecordFn",
    "REPLAY_REQUIRED_FIELDS",
    "ResidualGatedSwitch",
    "AdaptiveResidualGatedSwitch",
    "ReplayRecord",
    "REQUIRED_ROLLBACK_KEYS",
    "RollbackContractError",
    "SOLVER_STATE_KEYS",
    "StateAdapter",
    "StepDecision",
    "TensorResidualAuditor",
    "ZarrReplayBufferReader",
    "ZarrReplayBufferWriter",
    "clone_state",
    "project_damage_irreversible",
    "physics_sampling_scores",
    "relative_norm",
    "run_rollout",
    "sample_mesh_physics_points",
    "validate_rollback_state",
    "write_policy_log",
]
