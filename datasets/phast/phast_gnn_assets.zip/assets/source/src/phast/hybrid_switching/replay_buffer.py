"""Appendable Zarr replay buffer for solver-in-the-loop hybrid rollouts.

The buffer stores fixed-shape fields by namespace:

``state_t/``
    State before a learned proposal.
``proposal_t1/``
    Raw learned proposal.
``projected_t1/``
    Proposal after hard physical projection.
``reference_t1/``
    Trusted solver correction/fallback state when available.
``audits/``
    Residual, UQ, energy, acceptance, and fallback diagnostics.
``metadata/``
    Case, split, policy/model version, step, load, and similar scalars.

It is intentionally low-level: callers decide which fields to write. The only
contract enforced here is appendability, fixed per-field shapes, and durable
Zarr storage suitable for Dev/Production replay training.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

import numpy as np

try:  # pragma: no cover - exercised through tests when torch is installed
    import torch
except Exception:  # pragma: no cover
    torch = None  # type: ignore[assignment]


REPLAY_FORMAT = "phast.hybrid_switching.replay_buffer.zarr"

_NAMESPACES: tuple[str, ...] = (
    "state_t",
    "proposal_t1",
    "projected_t1",
    "reference_t1",
    "audits",
    "metadata",
)

# Minimum fields expected by Paper 4 artifact contract when strict replay logging
# is enabled. The buffer remains permissive by default so existing experiments
# can continue writing partial logs.
REPLAY_REQUIRED_FIELDS: dict[str, tuple[str, ...]] = {
    "state_t": ("d", "u"),
    "audits": ("accepted", "residual"),
    "metadata": ("step", "provenance_id"),
}


@dataclass(frozen=True)
class ReplayRecord:
    """One solver-in-the-loop training record."""

    state_t: Mapping[str, Any] = field(default_factory=dict)
    proposal_t1: Mapping[str, Any] = field(default_factory=dict)
    projected_t1: Mapping[str, Any] = field(default_factory=dict)
    reference_t1: Mapping[str, Any] = field(default_factory=dict)
    audits: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def namespaces(self) -> dict[str, Mapping[str, Any]]:
        return {
            "state_t": self.state_t,
            "proposal_t1": self.proposal_t1,
            "projected_t1": self.projected_t1,
            "reference_t1": self.reference_t1,
            "audits": self.audits,
            "metadata": self.metadata,
        }


class ZarrReplayBufferWriter:
    """Append fixed-shape replay records to a Zarr directory store."""

    def __init__(
        self,
        path: str | Path,
        *,
        overwrite: bool = False,
        attrs: Mapping[str, Any] | None = None,
        required_fields: Mapping[str, tuple[str, ...]] | None = None,
    ) -> None:
        import zarr

        self.path = Path(path)
        mode = "w" if overwrite else "a"
        self.root = zarr.open(str(self.path), mode=mode)
        self.root.attrs.setdefault("format", REPLAY_FORMAT)
        self._required_fields = dict(required_fields or {})
        if required_fields:
            for namespace, fields in required_fields.items():
                self._required_fields[namespace] = tuple(fields)
        self.root.attrs.setdefault("n_records", 0)
        for namespace, fields in self._required_fields.items():
            self.root.attrs[f"required_fields::{namespace}"] = list(fields)
        for key, value in (attrs or {}).items():
            self.root.attrs[key] = _jsonable_attr(value)
        for namespace in _NAMESPACES:
            self.root.require_group(namespace)

    @property
    def n_records(self) -> int:
        return int(self.root.attrs.get("n_records", 0))

    def append(self, record: ReplayRecord) -> int:
        """Append one record and return its row index."""

        row = self.n_records
        touched: set[tuple[str, str]] = set()
        for namespace, fields in record.namespaces().items():
            group = self.root[namespace]
            required = self._required_fields.get(namespace, ())
            missing = [k for k in required if k not in fields]
            if missing:
                raise ValueError(
                    f"replay namespace {namespace!r} missing required fields: {missing}"
                )
            for key, value in fields.items():
                arr = _to_numpy(value)
                ds = _require_append_dataset(group, key, arr, row)
                ds.resize((row + 1,) + tuple(arr.shape))
                ds[row] = arr
                touched.add((namespace, key))
        for namespace in _NAMESPACES:
            group = self.root[namespace]
            for key in group.array_keys():
                if (namespace, key) in touched:
                    continue
                ds = group[key]
                ds.resize((row + 1,) + tuple(ds.shape[1:]))
                ds[row] = _missing_value(tuple(ds.shape[1:]), np.dtype(ds.dtype))
        self.root.attrs["n_records"] = row + 1
        return row

    def close(self) -> None:
        """Flush metadata for stores that expose a close hook."""

        store = getattr(self.root, "store", None)
        close = getattr(store, "close", None)
        if callable(close):
            close()


class ZarrReplayBufferReader:
    """Read records from a Zarr replay buffer."""

    def __init__(self, path: str | Path) -> None:
        import zarr

        self.path = Path(path)
        self.root = zarr.open(str(self.path), mode="r")
        fmt = self.root.attrs.get("format")
        if fmt != REPLAY_FORMAT:
            raise ValueError(f"not a phast replay buffer: {fmt!r}")

    def __len__(self) -> int:
        return int(self.root.attrs.get("n_records", 0))

    @property
    def required_fields(self) -> dict[str, tuple[str, ...]]:
        """Return required-field contract recorded in store attributes."""
        required: dict[str, tuple[str, ...]] = {}
        for namespace in _NAMESPACES:
            raw = self.root.attrs.get(f"required_fields::{namespace}", ())
            if isinstance(raw, str):
                fields = (raw,)
            else:
                fields = tuple(str(item) for item in raw)
            if fields:
                required[namespace] = fields
        return required

    def available_fields(self) -> dict[str, tuple[str, ...]]:
        """Return array field names available in each replay namespace."""
        available: dict[str, tuple[str, ...]] = {}
        for namespace in _NAMESPACES:
            group = self.root[namespace]
            available[namespace] = tuple(sorted(str(key) for key in group.array_keys()))
        return available

    def validate_required_fields(
        self,
        required_fields: Mapping[str, tuple[str, ...]] | None = None,
    ) -> tuple[str, ...]:
        """Return missing required replay fields without loading arrays.

        If ``required_fields`` is omitted, the method uses the required-field
        schema recorded in the store attrs by :class:`ZarrReplayBufferWriter`.
        """
        required = dict(required_fields or self.required_fields)
        available = self.available_fields()
        missing: list[str] = []
        for namespace, fields in required.items():
            _validate_namespace(namespace)
            present = set(available.get(namespace, ()))
            for field_name in fields:
                if field_name not in present:
                    missing.append(f"{namespace}/{field_name}")
        return tuple(missing)

    def field(self, namespace: str, key: str) -> np.ndarray:
        """Return an entire stored field as a NumPy array."""

        _validate_namespace(namespace)
        return np.asarray(self.root[namespace][key])

    def record(self, index: int) -> ReplayRecord:
        """Load one record into memory."""

        if index < 0 or index >= len(self):
            raise IndexError(index)
        loaded: dict[str, dict[str, Any]] = {}
        for namespace in _NAMESPACES:
            group = self.root[namespace]
            loaded[namespace] = {
                key: _decode_value(np.asarray(group[key][index]))
                for key in group.array_keys()
            }
        return ReplayRecord(**loaded)


def _require_append_dataset(group: Any, key: str, value: np.ndarray, row: int) -> Any:
    if key in group:
        ds = group[key]
        expected = tuple(ds.shape[1:])
        if expected != tuple(value.shape):
            raise ValueError(
                f"replay field {group.name}/{key} has shape {expected}; "
                f"cannot append value with shape {tuple(value.shape)}"
            )
        if np.dtype(ds.dtype) != value.dtype:
            raise ValueError(
                f"replay field {group.name}/{key} has dtype {ds.dtype}; "
                f"cannot append dtype {value.dtype}"
            )
        return ds

    chunks = (1,) + tuple(value.shape)
    shape = (row + 1,) + tuple(value.shape)
    ds = group.create_dataset(
        key,
        shape=shape,
        chunks=chunks,
        dtype=value.dtype,
    )
    if row:
        ds[:row] = _missing_value((row,) + tuple(value.shape), value.dtype)
    return ds


def _missing_value(shape: tuple[int, ...], dtype: np.dtype) -> np.ndarray:
    if np.issubdtype(dtype, np.floating):
        fill: Any = np.nan
    elif np.issubdtype(dtype, np.bool_):
        fill = False
    elif np.issubdtype(dtype, np.integer):
        fill = 0
    elif np.issubdtype(dtype, np.str_) or np.issubdtype(dtype, np.bytes_):
        fill = ""
    else:
        fill = 0
    return np.full(shape, fill, dtype=dtype)


def _to_numpy(value: Any) -> np.ndarray:
    if torch is not None and isinstance(value, torch.Tensor):
        value = value.detach().cpu().numpy()
    elif isinstance(value, (str, bytes)):
        value = np.asarray(str(value), dtype="<U256")
    elif isinstance(value, (bool, int, float, np.number)):
        value = np.asarray(value)
    elif not isinstance(value, np.ndarray):
        value = np.asarray(value)

    arr = np.asarray(value)
    if arr.dtype == object:
        arr = arr.astype("<U256")
    return arr


def _decode_value(value: np.ndarray) -> Any:
    if value.shape == ():
        item = value.item()
        if isinstance(item, bytes):
            return item.decode("utf-8")
        return item
    return value


def _jsonable_attr(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    return value


def _validate_namespace(namespace: str) -> None:
    if namespace not in _NAMESPACES:
        raise KeyError(f"unknown replay namespace {namespace!r}")


__all__ = [
    "REPLAY_REQUIRED_FIELDS",
    "REPLAY_FORMAT",
    "ReplayRecord",
    "ZarrReplayBufferReader",
    "ZarrReplayBufferWriter",
]
