"""Sample packager — writes one ``.zarr`` directory per
phase-field-fracture sample to the on-disk layout pinned in
``schema.py``.

The packager is intentionally *transport-only*: it does not invoke the
solver.  Caller hands it a fully-realised trajectory dict (the same
shape the future solver-wiring will produce); the packager casts
state to float32, computes conditioning labels, and writes Zstd-Zarr.
New neural-operator and large dataset-generation workflows are
Zarr-only. Legacy solver ``training_data.h5`` remains supported by the
benchmark/post-processing path, not by this dataset packager.

Conditioning-label formulas
---------------------------
- ``n_branches``: connected components of nodes with ``d[final] > 0.5``,
  minus 1 (background).  Uses 1-ring node neighbourhood from
  ``elements``.  Returns 0 for an intact specimen.
- ``total_crack_length``: sum over elements with mean nodal damage
  > 0.5 of ``sqrt(2 * area_e)`` (characteristic element length).
- ``tortuosity``: ``total_crack_length / euclidean(initial_notch_tip,
  final_crack_tip)`` if a crack exists, else NaN.
- ``branching_time``: first keyframe time ``t`` where the connected-
  component count of damaged nodes exceeds 1; NaN if never.
- ``energy_split``, ``model``, ``plane_strain``, ``loading_mode``:
  copied verbatim from the caller's CLI args dict.
"""
from __future__ import annotations

import base64
import csv
import datetime
import os
from pathlib import Path
from typing import Any, Mapping, Optional

import numpy as np

from . import __version__ as PACKAGE_VERSION
from .schema import (
    SCHEMA_VERSION, NUM_KEYFRAMES, STATE_DTYPE, GEOMETRY_DTYPE,
    ELEMENT_INDEX_DTYPE, GEOMETRY_FIELDS, MATERIAL_FIELDS,
    KEYFRAME_FIELDS, PER_STEP_FIELDS, TELEMETRY_FIELDS,
    CONDITIONING_LABELS,
)


# ----------------------------------------------------------------------
# Conditioning-label computation (deterministic, derivable from saved
# fields).  Documented at module head.
# ----------------------------------------------------------------------

def _node_adjacency(elements: np.ndarray, n_nodes: int) -> list:
    """1-ring node neighbours from triangular connectivity."""
    adj = [set() for _ in range(n_nodes)]
    for tri in elements:
        a, b, c = int(tri[0]), int(tri[1]), int(tri[2])
        adj[a].update((b, c))
        adj[b].update((a, c))
        adj[c].update((a, b))
    return adj


def _connected_components(damaged_node_idx, adj):
    """BFS connected-components on a subset of nodes."""
    if len(damaged_node_idx) == 0:
        return 0
    in_set = set(int(i) for i in damaged_node_idx)
    seen = set()
    n_components = 0
    for start in in_set:
        if start in seen:
            continue
        n_components += 1
        stack = [start]
        while stack:
            node = stack.pop()
            if node in seen:
                continue
            seen.add(node)
            for nb in adj[node]:
                if nb in in_set and nb not in seen:
                    stack.append(nb)
    return n_components


def _element_areas(nodes: np.ndarray, elements: np.ndarray) -> np.ndarray:
    """Area of every triangle (CCW positive)."""
    p0 = nodes[elements[:, 0]]
    p1 = nodes[elements[:, 1]]
    p2 = nodes[elements[:, 2]]
    return 0.5 * np.abs(
        (p1[:, 0] - p0[:, 0]) * (p2[:, 1] - p0[:, 1])
        - (p2[:, 0] - p0[:, 0]) * (p1[:, 1] - p0[:, 1])
    )


def _crack_tip_from_d(d_nodes: np.ndarray, nodes: np.ndarray,
                     start_xy: np.ndarray) -> Optional[np.ndarray]:
    """Pick the most damaged node farthest from ``start_xy``.

    A coarse but stable proxy for the crack-tip position; only used
    inside ``tortuosity`` (the per-step CSV from the solver carries the
    proper streamed crack tip).
    """
    mask = d_nodes > 0.5
    if not mask.any():
        return None
    dists = np.linalg.norm(nodes[mask] - start_xy, axis=1)
    return nodes[mask][np.argmax(dists)]


def _compute_conditioning_labels(geometry: Mapping[str, Any],
                                  trajectory: Mapping[str, Any],
                                  cli_labels: Mapping[str, Any]) -> dict:
    """Derive the conditioning labels listed in schema.CONDITIONING_LABELS."""
    nodes = np.asarray(geometry["nodes"], dtype=np.float64)
    elements = np.asarray(geometry["elements"], dtype=np.int64)
    d_keyframes = np.asarray(trajectory["d"], dtype=np.float64)  # (K, N)
    keyframe_times = np.asarray(
        trajectory["keyframe_times"], dtype=np.float64)

    adj = _node_adjacency(elements, nodes.shape[0])

    # n_branches at final keyframe
    final_d = d_keyframes[-1]
    damaged_idx = np.where(final_d > 0.5)[0]
    n_components = _connected_components(damaged_idx, adj)
    # connected-component count -> branch count: a single straight crack
    # is one component, two-pronged branching is two, etc.  Subtract one
    # so an intact specimen reports 0.
    n_branches = max(0, n_components - 1)

    # total_crack_length: sum of element characteristic-length over
    # damaged elements
    elem_d = d_keyframes[-1, elements].mean(axis=1)
    elem_areas = _element_areas(nodes, elements)
    crack_elems = elem_d > 0.5
    total_crack_length = float(
        np.sum(np.sqrt(2.0 * elem_areas[crack_elems])))

    # tortuosity: arc / chord
    pre_crack_mask = np.asarray(geometry.get("pre_crack_mask",
                                            np.zeros(nodes.shape[0], dtype=np.uint8)))
    if pre_crack_mask.any():
        # initial notch tip = last pre-crack node along x (heuristic;
        # caller should override in CLI args if not appropriate)
        pre_idx = np.where(pre_crack_mask > 0)[0]
        start_xy = nodes[pre_idx][np.argmax(nodes[pre_idx, 0])]
    else:
        start_xy = nodes.mean(axis=0)
    end_xy = _crack_tip_from_d(final_d, nodes, start_xy)
    if end_xy is None or total_crack_length == 0.0:
        tortuosity = float("nan")
    else:
        chord = float(np.linalg.norm(end_xy - start_xy))
        tortuosity = float(total_crack_length / chord) if chord > 0 else float("nan")

    # branching_time: first keyframe with > 1 connected damaged component
    branching_time = float("nan")
    for k in range(d_keyframes.shape[0]):
        idx_k = np.where(d_keyframes[k] > 0.5)[0]
        if _connected_components(idx_k, adj) > 1:
            branching_time = float(keyframe_times[k])
            break

    # Verbatim from CLI args (string labels, not derivable)
    energy_split = str(cli_labels.get("energy_split", "spectral"))
    model = str(cli_labels.get("model", "AT2"))
    plane_strain = bool(cli_labels.get("plane_strain", False))
    loading_mode = str(cli_labels.get("loading_mode",
                                       "dynamic" if "v" in trajectory and trajectory["v"] is not None
                                       else "quasi_static"))

    return {
        "energy_split": energy_split,
        "model": model,
        "plane_strain": plane_strain,
        "loading_mode": loading_mode,
        "n_branches": int(n_branches),
        "total_crack_length": total_crack_length,
        "tortuosity": tortuosity,
        "branching_time": branching_time,
    }


# ----------------------------------------------------------------------
# I/O helpers
# ----------------------------------------------------------------------

def _zarr_compressor():
    """Zstd compressor with a level that's a sensible default for PF
    trajectories (smooth fields + lots of zeros in d)."""
    from numcodecs import Zstd
    return Zstd(level=5)


def _zarr_directory_store(zarr_module, path: Path):
    """Return a directory-backed store for both Zarr 2 and Zarr 3."""
    directory_store = getattr(zarr_module, "DirectoryStore", None)
    if directory_store is not None:
        return directory_store(str(path))

    storage = getattr(zarr_module, "storage", None)
    local_store = getattr(storage, "LocalStore", None) if storage is not None else None
    if local_store is not None:
        return local_store(str(path))

    raise RuntimeError(
        "No directory-backed Zarr store found. Expected zarr.DirectoryStore "
        "(Zarr 2) or zarr.storage.LocalStore (Zarr 3)."
    )


def _encode_rng_state(state) -> str:
    """Pickle + base64-encode a numpy/torch RNG state for portable storage."""
    import pickle
    return base64.b64encode(pickle.dumps(state)).decode("ascii")


def _read_telemetry_csv(path: Path) -> dict:
    """Parse the solver_telemetry.csv format from PR #304 into arrays.

    Schema:
    ``step, time, newton_iters, pcg_iters_mech, pcg_iters_pf, residual,
    relative_residual, mechanics_residual, mechanics_relative_residual, dt``.
    """
    cols = {
        "step": ("int64", []),
        "time": ("float64", []),
        "newton_iters": ("int64", []),
        "pcg_iters_mech": ("int64", []),
        "pcg_iters_pf": ("int64", []),
        "residual": ("float64", []),
        "relative_residual": ("float64", []),
        "mechanics_residual": ("float64", []),
        "mechanics_relative_residual": ("float64", []),
        "dt": ("float64", []),
    }
    with open(path, "r", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            for k, (_, lst) in cols.items():
                v = row.get(k, "")
                if v == "" or v.lower() == "nan":
                    v = float("nan")
                lst.append(v)
    return {k: np.asarray(lst, dtype=dt) for k, (dt, lst) in cols.items()}


# ----------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------

class SamplePackager:
    """Serializes one PF-fracture sample at a time.

    Parameters
    ----------
    out_dir : Path-like
        Destination directory; one ``sample_{id:06d}.zarr`` per call.
    generator_seed : int
        Top-level seed shared across all samples in the run.
    generator_version : str
        Pinned version string of the generator class (e.g. ``"0.1.0"``).
    solver_sha : str
        ``git rev-parse HEAD`` of the solver at trajectory-time.
    cli_args : dict
        Full CLI-args dict used to drive the solver.  Stored verbatim
        as JSON-serialisable metadata so any sample can be replayed.
    """

    def __init__(self, out_dir, generator_seed: int,
                 generator_version: str, solver_sha: str,
                 cli_args: Mapping[str, Any]):
        self.out_dir = Path(out_dir)
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.generator_seed = int(generator_seed)
        self.generator_version = str(generator_version)
        self.solver_sha = str(solver_sha)
        self.cli_args = dict(cli_args)

    # ------------------------------------------------------------------
    # main entry point
    # ------------------------------------------------------------------
    def write_sample(self, sample_id: int, *,
                     geometry: Mapping[str, Any],
                     material: Mapping[str, Any],
                     trajectory: Mapping[str, Any],
                     telemetry_csv: Optional[Path] = None,
                     conditioning: Optional[Mapping[str, Any]] = None,
                     store_format: str = "zarr",
                     compress: str = "zstd",
                     numpy_rng_state=None,
                     torch_rng_state=None) -> Path:
        """Write one sample to disk.  Returns the path written."""
        if store_format != "zarr":
            raise ValueError(
                "PF-Hetero-Bench samples are Zarr-only. "
                "Use store_format='zarr'; legacy training_data.h5 is "
                "retained only for existing solver benchmark/post-processing "
                "workflows (#530)."
            )
        if compress not in ("zstd",):
            raise ValueError(f"compress must be 'zstd' (only Zstd supported in v1)")

        suffix = ".zarr"
        path = self.out_dir / f"sample_{sample_id:06d}{suffix}"
        if path.exists():
            import shutil
            shutil.rmtree(path)

        # Compute conditioning labels (override-able via ``conditioning``)
        cli_labels = dict(conditioning or {})
        for k in ("energy_split", "model", "plane_strain", "loading_mode"):
            cli_labels.setdefault(k, self.cli_args.get(k))
        derived = _compute_conditioning_labels(geometry, trajectory, cli_labels)

        # Telemetry: parse CSV if provided; else store empty per-step arrays
        if telemetry_csv is not None and Path(telemetry_csv).exists():
            telem = _read_telemetry_csv(Path(telemetry_csv))
        else:
            n_steps = len(trajectory.get("step_times", trajectory.get(
                "energies", [[None]])))
            if isinstance(n_steps, int) is False:
                n_steps = 0
            telem = {
                "step": np.zeros(0, dtype=np.int64),
                "time": np.zeros(0, dtype=np.float64),
                "newton_iters": np.zeros(0, dtype=np.int64),
                "pcg_iters_mech": np.zeros(0, dtype=np.int64),
                "pcg_iters_pf": np.zeros(0, dtype=np.int64),
                "residual": np.zeros(0, dtype=np.float64),
                "relative_residual": np.zeros(0, dtype=np.float64),
                "mechanics_residual": np.zeros(0, dtype=np.float64),
                "mechanics_relative_residual": np.zeros(0, dtype=np.float64),
                "dt": np.zeros(0, dtype=np.float64),
            }

        self._write_zarr(path, geometry, material, trajectory, telem,
                         derived, numpy_rng_state, torch_rng_state)
        return path

    # ------------------------------------------------------------------
    # back-end: Zarr
    # ------------------------------------------------------------------
    def _write_zarr(self, path: Path, geometry, material, trajectory,
                    telem, derived, numpy_rng_state, torch_rng_state):
        import zarr
        comp = _zarr_compressor()

        store = _zarr_directory_store(zarr, path)
        root = zarr.group(store=store, overwrite=True)

        # --- geometry (float64 / int64 — kept high-precision) ----------
        nodes = np.asarray(geometry["nodes"], dtype=np.float64)
        elements = np.asarray(geometry["elements"], dtype=np.int64)
        boundary_tags = np.asarray(geometry["boundary_tags"], dtype=np.int64)
        boundary_set_names = np.asarray(
            geometry["boundary_set_names"], dtype="<U64")
        material_tag = np.asarray(geometry["material_tag"], dtype=np.int64)
        pre_crack_mask = np.asarray(
            geometry["pre_crack_mask"], dtype=np.uint8)

        root.create_dataset("nodes", data=nodes, compressor=comp)
        root.create_dataset("elements", data=elements, compressor=comp)
        root.create_dataset("boundary_tags", data=boundary_tags, compressor=comp)
        # Object arrays don't compress with Zstd; store uncompressed.
        root.create_dataset("boundary_set_names",
                             data=boundary_set_names, compressor=None)
        root.create_dataset("material_tag", data=material_tag, compressor=comp)
        root.create_dataset("pre_crack_mask",
                             data=pre_crack_mask, compressor=comp)

        # --- material (per-element float64) -----------------------------
        for spec in MATERIAL_FIELDS:
            arr = np.asarray(material[spec.name], dtype=np.float64)
            root.create_dataset(spec.name, data=arr, compressor=comp)

        # --- keyframes (float64 -> float32 cast at write) ---------------
        kt = np.asarray(trajectory["keyframe_times"], dtype=np.float32)
        root.create_dataset("keyframe_times", data=kt, compressor=comp)

        u = np.asarray(trajectory["u"], dtype=np.float32)
        root.create_dataset("u", data=u, compressor=comp)

        if trajectory.get("v") is not None:
            v = np.asarray(trajectory["v"], dtype=np.float32)
            root.create_dataset("v", data=v, compressor=comp)

        d = np.asarray(trajectory["d"], dtype=np.float32)
        root.create_dataset("d", data=d, compressor=comp)
        psi_p = np.asarray(trajectory["psi_plus"], dtype=np.float32)
        psi_m = np.asarray(trajectory["psi_minus"], dtype=np.float32)
        root.create_dataset("psi_plus", data=psi_p, compressor=comp)
        root.create_dataset("psi_minus", data=psi_m, compressor=comp)

        # --- per-step (float32 cast) ------------------------------------
        for fieldname in ("step_times", "E_elastic", "E_dissipated",
                           "E_kinetic", "E_external", "crack_tip_speed"):
            arr = np.asarray(trajectory[fieldname], dtype=np.float32)
            root.create_dataset(fieldname, data=arr, compressor=comp)
        f_react = np.asarray(trajectory["f_reaction"], dtype=np.float32)
        root.create_dataset("f_reaction", data=f_react, compressor=comp)
        ct_xy = np.asarray(trajectory["crack_tip_xy"], dtype=np.float32)
        root.create_dataset("crack_tip_xy", data=ct_xy, compressor=comp)

        # --- telemetry (one Zarr group, byte-for-byte from #300 CSV) ----
        tgrp = root.create_group("telemetry")
        for k, dt in (("step", np.int64), ("time", np.float64),
                       ("newton_iters", np.int64),
                       ("pcg_iters_mech", np.int64),
                       ("pcg_iters_pf", np.int64),
                       ("residual", np.float64),
                       ("relative_residual", np.float64),
                       ("mechanics_residual", np.float64),
                       ("mechanics_relative_residual", np.float64),
                       ("dt", np.float64)):
            tgrp.create_dataset(k, data=np.asarray(telem[k], dtype=dt),
                                 compressor=comp)

        # --- conditioning labels (Zarr attrs) ---------------------------
        for label, value in derived.items():
            root.attrs[label] = self._jsonify(value)

        # --- metadata (Zarr attrs) --------------------------------------
        n_keyframes = u.shape[0]
        T_final = float(kt[-1]) if kt.size > 0 else 0.0
        root.attrs.update({
            "schema_version": SCHEMA_VERSION,
            "package_version": PACKAGE_VERSION,
            "generator_class": str(self.cli_args.get("generator_class", "")),
            "generator_seed": int(self.cli_args.get("sample_seed", self.generator_seed)),
            "generator_version": self.generator_version,
            "solver_git_sha": self.solver_sha,
            "cli_args": self._jsonify(self.cli_args),
            "numpy_rng_state_b64":
                _encode_rng_state(numpy_rng_state) if numpy_rng_state is not None else "",
            "torch_rng_state_b64":
                _encode_rng_state(torch_rng_state) if torch_rng_state is not None else "",
            "T_final": T_final,
            "n_steps": int(telem["step"].size),
            "n_keyframes": int(n_keyframes),
            "n_nodes": int(nodes.shape[0]),
            "n_elements": int(elements.shape[0]),
            "n_boundary_sets": int(boundary_set_names.size),
            "package_timestamp":
                datetime.datetime.utcnow().isoformat(timespec="seconds") + "Z",
        })

    # ------------------------------------------------------------------
    # JSON-safe coercion for Zarr attributes
    # ------------------------------------------------------------------
    @staticmethod
    def _jsonify(value):
        """Coerce nested dicts/lists into JSON-clean primitives."""
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        if isinstance(value, dict):
            return {str(k): SamplePackager._jsonify(v)
                    for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [SamplePackager._jsonify(v) for v in value]
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, (np.integer,)):
            return int(value)
        if isinstance(value, (np.floating,)):
            return float(value)
        return str(value)


__all__ = ["SamplePackager"]
