"""Circular voids — modelled as degraded-Gc (and softened-E) patches.

PF-Hetero-Bench class #5 (issue #298).

Honest framing
--------------
A *true* void requires geometric carving from the mesh (a hole, not a
material patch).  v1 of PF-Hetero-Bench does NOT carve geometric holes;
instead each "void" is a circular region of:

  - heavily-degraded Gc:  Gc(x) = Gc_nominal * (1 - α_g * mask(x))
  - heavily-softened E:   E(x)  = E_nominal  * (1 - α_e * mask(x))

with a smooth raised-cosine ``mask`` over the void radius.  This is the
same approach as ``inverse_problems/demos/demo_hole_topology.py`` and
``demo_inverse_microstructure.py``: smooth, fully differentiable,
mesh-independent.  Cracks crossing a void have ~95% reduced toughness
so they propagate through the patch with negligible resistance — a
reasonable proxy for a free-surface hole at the resolution of PF.

Limitation
~~~~~~~~~~
This proxy gets the local-toughness contribution right but not the
near-field stress-concentration boundary condition that a true free
surface imposes.  Crack–void interaction tests in v1 should be
interpreted with that caveat in mind.

v2 alternative
~~~~~~~~~~~~~~
:mod:`dataset_benchmark.generators.geometric_voids` ships the
gmsh-based geometric counterpart to this class.  ``geometric_voids``
carves real holes from the mesh (free surfaces around each disk,
nodes removed) so the missing physics noted above is recovered, at
the cost of an unstructured mesh and a gmsh dependency.  This v1
``voids`` class is preserved both for back-compat with PR #321
samples and as a graceful-degradation path when gmsh is not
available — :class:`GeometricVoidsGenerator` falls back to this
class with a :class:`RuntimeWarning` in that case.
"""
from __future__ import annotations

import numpy as np

from ._base import GeneratorOutput, SampleGenerator
from .homogeneous import _structured_tri_mesh


class VoidsGenerator(SampleGenerator):
    """Random plate with N circular degraded-Gc void patches."""

    CLASS_NAME = "voids"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        "n_voids_range": (1, 5),            # inclusive on both ends
        "void_radius_frac_range": (0.03, 0.10),  # fraction of min(W,H)
        "Gc_degradation": 0.95,             # Gc -> 5% of nominal at centre
        "E_degradation": 0.95,              # E  -> 5% of nominal at centre
        "nx_per_l0": 2,
        "ny_per_l0": 2,
        "max_nodes": 8_000,
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E_nominal = float(rng.uniform(*p["E_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc_nominal = float(rng.uniform(*p["Gc_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        n_voids_lo, n_voids_hi = p["n_voids_range"]
        n_voids = int(rng.integers(int(n_voids_lo), int(n_voids_hi) + 1))

        h_target = l0 / float(p["nx_per_l0"])
        nx = max(2, int(round(W / h_target)))
        ny = max(2, int(round(H / h_target)))
        if (nx + 1) * (ny + 1) > p["max_nodes"]:
            scale = ((nx + 1) * (ny + 1) / p["max_nodes"]) ** 0.5
            nx = max(2, int(round(nx / scale)))
            ny = max(2, int(round(ny / scale)))
        nodes, elements = _structured_tri_mesh(W, H, nx, ny)
        n_elems = elements.shape[0]
        centroids = nodes[elements].mean(axis=1)

        # Void radii + centres.  Centres rejection-sampled inside
        # [r, W-r] × [r, H-r] so the void disk is contained.
        rad_min = p["void_radius_frac_range"][0] * min(W, H)
        rad_max = p["void_radius_frac_range"][1] * min(W, H)
        radii = rng.uniform(rad_min, rad_max, size=n_voids)
        cx = np.empty(n_voids); cy = np.empty(n_voids)
        for k in range(n_voids):
            r = radii[k]
            cx[k] = rng.uniform(r, max(W - r, r + 1e-9))
            cy[k] = rng.uniform(r, max(H - r, r + 1e-9))

        # Smooth raised-cosine mask: 1 inside (r < radius), 0 outside,
        # cos transition over the outer 20% of the radius.  Not strictly
        # mesh-independent (centroid evaluation only), but matches the
        # smoothing approach in the inverse-problem demos.
        mask = np.zeros(n_elems, dtype=np.float64)
        for k in range(n_voids):
            dx = centroids[:, 0] - cx[k]
            dy = centroids[:, 1] - cy[k]
            r = np.sqrt(dx * dx + dy * dy)
            R = radii[k]
            inner = r < 0.8 * R
            outer = (r >= 0.8 * R) & (r < R)
            local = np.where(inner, 1.0, 0.0)
            local = np.where(outer,
                             0.5 * (1.0 + np.cos(np.pi * (r - 0.8 * R)
                                                  / (0.2 * R))),
                             local)
            # Combine voids by max (overlapping voids stay at full deg.)
            mask = np.maximum(mask, local)

        Gc_field = Gc_nominal * (1.0 - p["Gc_degradation"] * mask)
        E_field = E_nominal * (1.0 - p["E_degradation"] * mask)
        # Floor to keep both strictly positive
        Gc_field = np.maximum(Gc_field, 0.05 * Gc_nominal)
        E_field = np.maximum(E_field, 0.05 * E_nominal)

        # Material tag: 0 = solid, 1 = inside any void (mask > 0.5)
        material_tag = (mask > 0.5).astype(np.int64)

        x = nodes[:, 0]; y = nodes[:, 1]
        eps = 1e-6 * max(W, H)
        sets = {
            "left":   np.where(x < eps)[0],
            "right":  np.where(x > W - eps)[0],
            "bottom": np.where(y < eps)[0],
            "top":    np.where(y > H - eps)[0],
        }
        boundary_set_names = sorted(sets.keys())
        boundary_tags = np.zeros(nodes.shape[0], dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        slit_y = 0.5 * H
        crack_band = max(0.5 * l0, 0.51 * H / ny)  # see spatial_gc.py
        pre_crack_mask = (
            (np.abs(y - slit_y) < crack_band)
            & (x >= 0.0) & (x <= a)
        ).astype(np.uint8)

        material = {
            "E":   E_field.astype(np.float64),
            "nu":  np.full(n_elems, nu,  dtype=np.float64),
            "Gc":  Gc_field.astype(np.float64),
            "l0":  np.full(n_elems, l0,  dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        bcs = {
            "left":   {"type": "fix", "component": 0},
            "top":    {"type": "traction", "component": 1, "value":  1.0},
            "bottom": {"type": "traction", "component": 1, "value": -1.0},
            "_params": {
                "W": W, "H": H, "a": a,
                "E_nominal": E_nominal, "nu": nu, "Gc_nominal": Gc_nominal,
                "l0": l0, "rho": rho,
                "nx": nx, "ny": ny,
                "n_voids": n_voids,
                "Gc_degradation": float(p["Gc_degradation"]),
                "E_degradation": float(p["E_degradation"]),
            },
            "_class_meta": {
                "void_x": cx, "void_y": cy, "void_radius": radii,
            },
        }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
        }
        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


__all__ = ["VoidsGenerator"]
