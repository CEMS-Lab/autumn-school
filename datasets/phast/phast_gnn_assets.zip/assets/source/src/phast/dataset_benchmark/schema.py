"""PF-Hetero-Bench v1 schema (locked 2026-05-08, see issue #298 comment).

Source-of-truth for the per-sample on-disk layout.  Every field below
must be present in every sample produced by every generator class;
``validator.validate_sample`` enforces this.

Conventions
-----------
- Generate float64, store float32 for *state* fields (u, v, d, psi_*,
  energies, f_reaction, crack_tip_*).  Geometry (nodes, elements)
  stays float64 / int64.
- 100 uniform keyframes per sample.  ``keyframe_times[0] == 0`` and
  ``keyframe_times[-1] == T_final`` are explicit.
- Solver telemetry (CSV from issue #300, PR #304) is copied
  byte-for-byte into the sample as ``solver_telemetry/`` arrays.
- Conditioning labels are computed at packaging time, derivable from
  the saved fields (no provenance loss).

Notes on what is *not* saved
----------------------------
- Stress per element: recoverable from u + material + d via
  constitutive at packaging or training time.  Saves ~30 % storage.
- Sensitivity bank: deferred to v2 (#298 schema-lock comment).  Seed +
  solver SHA + full CLI args make every sample forward-replayable;
  adjoints can be added on the ~1k samples a downstream paper
  actually needs, not on all 50k.

Underspecified items resolved here
----------------------------------
- ``f_reaction`` shape: ``(n_steps, n_node_sets, 2)``.  Per-node-set
  matches ``FEM.compute_reaction_force`` signature in this repo.
  Per-segment is more general but unused.  Follow-up issue if needed.
- ``v`` (velocity) shape: ``(K, N, 2)``.  ``None`` for quasi-static
  samples (caller passes ``None`` and packager writes a zero-shape
  marker array; validator treats absence as legal iff
  ``loading_mode == 'quasi_static'``).
"""
from __future__ import annotations

# Stdlib dataclasses keep the schema dependency-free.  Pydantic was
# considered but adds nothing here: every FieldSpec is a static
# definition, no runtime validation.
from dataclasses import dataclass, field as _field  # noqa: F401


# ----------------------------------------------------------------------
# Schema constants — load-bearing; do NOT modify without bumping the
# package version and re-running every existing sample through the
# validator.
# ----------------------------------------------------------------------

SCHEMA_VERSION = "v1"
"""Bump when on-disk layout changes incompatibly."""

NUM_KEYFRAMES = 100
"""Uniform keyframes per sample.  k=0 is t=0, k=99 is t=T_final."""

STATE_DTYPE = "float32"
"""Storage dtype for state fields after the float64 -> float32 cast."""

GEOMETRY_DTYPE = "float64"
"""Geometry stays float64 (mesh-quality-sensitive, negligible storage)."""

ELEMENT_INDEX_DTYPE = "int64"
"""Element connectivity / boundary-tag indices."""


# ----------------------------------------------------------------------
# Field specifications.  Each entry pins (axis names, dtype, units,
# notes); the validator iterates this dict.
# ----------------------------------------------------------------------

@dataclass
class FieldSpec:
    """One on-disk array's contract."""
    name: str
    axes: tuple
    dtype: str
    units: str
    optional: bool = False
    notes: str = ""


GEOMETRY_FIELDS = (
    FieldSpec(
        name="nodes",
        axes=("N", "2"),
        dtype=GEOMETRY_DTYPE,
        units="mm",
        notes="2-D nodal coordinates.",
    ),
    FieldSpec(
        name="elements",
        axes=("E", "3"),
        dtype=ELEMENT_INDEX_DTYPE,
        units="-",
        notes="Triangular connectivity (CCW).",
    ),
    FieldSpec(
        name="boundary_tags",
        axes=("N",),
        dtype=ELEMENT_INDEX_DTYPE,
        units="-",
        notes=(
            "Per-node boundary-set membership bitmask.  Bit k is set "
            "iff the node belongs to ``boundary_set_names[k]``."
        ),
    ),
    FieldSpec(
        name="boundary_set_names",
        axes=("Sets",),
        dtype="<U64",
        units="-",
        notes="Sorted list of node-set names (matches bitmask order).",
    ),
    FieldSpec(
        name="material_tag",
        axes=("E",),
        dtype=ELEMENT_INDEX_DTYPE,
        units="-",
        notes="Per-element phase ID (0 = matrix, 1+ = inclusions/voids).",
    ),
    FieldSpec(
        name="pre_crack_mask",
        axes=("N",),
        dtype="uint8",
        units="-",
        notes="1 where the phase field is pre-broken (d=1) at t=0.",
    ),
)


MATERIAL_FIELDS = (
    FieldSpec(name="E",   axes=("E",), dtype=GEOMETRY_DTYPE, units="MPa",       notes="Young's modulus per element."),
    FieldSpec(name="nu",  axes=("E",), dtype=GEOMETRY_DTYPE, units="-",         notes="Poisson's ratio per element."),
    FieldSpec(name="Gc",  axes=("E",), dtype=GEOMETRY_DTYPE, units="N/mm",      notes="Critical energy release rate per element."),
    FieldSpec(name="l0",  axes=("E",), dtype=GEOMETRY_DTYPE, units="mm",        notes="PF length scale per element."),
    FieldSpec(name="rho", axes=("E",), dtype=GEOMETRY_DTYPE, units="t/mm^3",    notes="Density per element."),
)


KEYFRAME_FIELDS = (
    FieldSpec(name="keyframe_times", axes=("K",),         dtype=STATE_DTYPE, units="s",  notes="K = NUM_KEYFRAMES; uniform from 0 to T_final inclusive."),
    FieldSpec(name="u",              axes=("K", "N", "2"), dtype=STATE_DTYPE, units="mm", notes="Displacement field per keyframe."),
    FieldSpec(name="v",              axes=("K", "N", "2"), dtype=STATE_DTYPE, units="mm/s", optional=True, notes="Velocity per keyframe; absent for quasi-static samples."),
    FieldSpec(name="d",              axes=("K", "N"),     dtype=STATE_DTYPE, units="-",   notes="Phase field per keyframe (0 = intact, 1 = broken)."),
    FieldSpec(name="psi_plus",       axes=("K", "E"),     dtype=STATE_DTYPE, units="MPa", notes="Tensile elastic energy density per element per keyframe."),
    FieldSpec(name="psi_minus",      axes=("K", "E"),     dtype=STATE_DTYPE, units="MPa", notes="Compressive elastic energy density per element per keyframe."),
)


PER_STEP_FIELDS = (
    FieldSpec(name="step_times",       axes=("S",),         dtype=STATE_DTYPE, units="s", notes="S = num_steps."),
    FieldSpec(name="E_elastic",        axes=("S",),         dtype=STATE_DTYPE, units="mJ", notes="Elastic energy per step."),
    FieldSpec(name="E_dissipated",     axes=("S",),         dtype=STATE_DTYPE, units="mJ", notes="Dissipated (fracture) energy per step."),
    FieldSpec(name="E_kinetic",        axes=("S",),         dtype=STATE_DTYPE, units="mJ", notes="Kinetic energy per step (zero for quasi-static)."),
    FieldSpec(name="E_external",       axes=("S",),         dtype=STATE_DTYPE, units="mJ", notes="External work per step."),
    FieldSpec(name="f_reaction",       axes=("S", "Sets", "2"), dtype=STATE_DTYPE, units="N", notes="Per-step, per-named-node-set reaction force (x, y)."),
    FieldSpec(name="crack_tip_xy",     axes=("S", "2"),     dtype=STATE_DTYPE, units="mm",  notes="Crack-tip position per step; NaN before initiation."),
    FieldSpec(name="crack_tip_speed",  axes=("S",),         dtype=STATE_DTYPE, units="mm/s", notes="Crack-tip speed per step; NaN before initiation."),
)


# Solver telemetry (#300) is plumbed by run_config.py as CSV; we copy
# the rows into Zarr arrays at packaging time.  Dtype matches the CSV.
TELEMETRY_FIELDS = (
    FieldSpec(name="telemetry/step",            axes=("S",), dtype="int64",   units="-",  notes="Step index (0..S-1)."),
    FieldSpec(name="telemetry/time",            axes=("S",), dtype="float64", units="s",  notes="Physical time at step."),
    FieldSpec(name="telemetry/newton_iters",    axes=("S",), dtype="int64",   units="-",  notes="Staggered iterations to convergence."),
    FieldSpec(name="telemetry/pcg_iters_mech",  axes=("S",), dtype="int64",   units="-",  notes="PCG iterations in the mechanics solve."),
    FieldSpec(name="telemetry/pcg_iters_pf",    axes=("S",), dtype="int64",   units="-",  notes="PCG iterations in the phase-field solve."),
    FieldSpec(name="telemetry/residual",        axes=("S",), dtype="float64", units="-",  notes="Absolute residual at staggered convergence; NaN for explicit dynamics."),
    FieldSpec(name="telemetry/relative_residual", axes=("S",), dtype="float64", units="-", notes="Residual normalised by the first residual in the accepted solve."),
    FieldSpec(name="telemetry/mechanics_residual", axes=("S",), dtype="float64", units="-", notes="Final mechanics residual from the inner quasi-static solve."),
    FieldSpec(name="telemetry/mechanics_relative_residual", axes=("S",), dtype="float64", units="-", notes="Mechanics residual normalised by its initial value."),
    FieldSpec(name="telemetry/dt",              axes=("S",), dtype="float64", units="s",  notes="Time step actually taken."),
)


# Conditioning labels are scalars / short strings stored as Zarr
# attributes (not arrays) so they're cheap to filter on.
CONDITIONING_LABELS = (
    "energy_split",        # str  ("spectral" | "amor" | "rankine" | ...)
    "model",               # str  ("AT1" | "AT2")
    "plane_strain",        # bool
    "loading_mode",        # str  ("dynamic" | "quasi_static")
    "n_branches",          # int   computed at packaging
    "total_crack_length",  # float computed at packaging (mm)
    "tortuosity",          # float computed at packaging (-)
    "branching_time",      # float computed at packaging (s); NaN if no branching
)


METADATA_KEYS = (
    "schema_version",       # str
    "package_version",      # str  (dataset_benchmark.__version__)
    "generator_class",      # str  ("homogeneous" | "spatial_gc" | ...)
    "generator_seed",       # int
    "generator_version",    # str  (e.g. "0.1.0")
    "solver_git_sha",       # str
    "cli_args",             # dict (full configuration the solver saw)
    "numpy_rng_state_b64",  # str  (base64-encoded numpy state, replayable)
    "torch_rng_state_b64",  # str  (base64-encoded torch CPU state)
    "T_final",              # float (s)
    "n_steps",              # int
    "n_keyframes",          # int (= NUM_KEYFRAMES)
    "n_nodes",              # int
    "n_elements",           # int
    "n_boundary_sets",      # int
    "package_timestamp",    # str  ISO-8601
)


# ----------------------------------------------------------------------
# Convenience helpers used by packager + validator.
# ----------------------------------------------------------------------

def all_required_fields():
    """Iterate every (group, FieldSpec) pair the validator must check."""
    for spec in GEOMETRY_FIELDS:
        yield "geometry", spec
    for spec in MATERIAL_FIELDS:
        yield "material", spec
    for spec in KEYFRAME_FIELDS:
        yield "keyframes", spec
    for spec in PER_STEP_FIELDS:
        yield "per_step", spec
    for spec in TELEMETRY_FIELDS:
        yield "telemetry", spec


def required_zarr_paths():
    """Flat list of required array paths inside the sample's .zarr."""
    out = []
    for group, spec in all_required_fields():
        if spec.optional:
            continue
        out.append(spec.name)
    return out


__all__ = [
    "SCHEMA_VERSION",
    "NUM_KEYFRAMES",
    "STATE_DTYPE",
    "GEOMETRY_DTYPE",
    "ELEMENT_INDEX_DTYPE",
    "FieldSpec",
    "GEOMETRY_FIELDS",
    "MATERIAL_FIELDS",
    "KEYFRAME_FIELDS",
    "PER_STEP_FIELDS",
    "TELEMETRY_FIELDS",
    "CONDITIONING_LABELS",
    "METADATA_KEYS",
    "all_required_fields",
    "required_zarr_paths",
]
