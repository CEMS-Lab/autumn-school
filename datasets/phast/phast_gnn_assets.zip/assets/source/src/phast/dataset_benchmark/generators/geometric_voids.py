"""Geometric voids generator (gmsh-based hole carving).

PF-Hetero-Bench class #11 (issue #298 v2 follow-up).  This is the
*geometric* counterpart of :mod:`voids` (which represents voids as
degraded-Gc patches without removing material).  Here voids are carved
out of the mesh via gmsh: nodes inside the disk are absent, the disk
boundary becomes a free surface, and the material that remains is
homogeneous.

Why a separate class
--------------------
The v1 ``voids`` generator (PR #321) ships a degraded-Gc proxy. That
captures local toughness reduction but misses two physical effects of a
true hole:

  1. **Free-surface boundary condition** — a hole edge carries
     traction-free Neumann data, producing the Kirsch-style stress
     concentration around the void.
  2. **Topological compliance change** — material is *missing*, not
     just locally soft, so global stiffness and dynamic-fracture path
     selection differ.

Bleyer (2017) Sec. 4.2 (perforated SENT plate) is the canonical
reference for this physics.  We use the same gmsh-based recipe as
:func:`mesh_generator.plate_with_holes`, but driven by the
``SampleGenerator`` random-draw protocol so it slots into the
PF-Hetero-Bench batch pipeline.

Per-sample geometry
-------------------
- Number of voids: random pick from ``{1, 2, 3, 5, 8}``.
- Radii: each ``r ~ U(0.5*l0, 4*l0)`` (clamped to ``min(W,H)/3`` so a
  single void cannot devour the plate).
- Positions: rejection-sampled inside the plate with margins of
  ``r + 2*l0`` from every edge AND a ``2*l0`` clearance from the
  pre-crack slit (so the slit never intersects a void).
- Pre-crack: standard horizontal slit of length ``a`` from the left
  edge at ``y = H/2`` (same as :class:`HomogeneousGenerator`).

Material
--------
Uniform single-phase across all remaining elements.  Heterogeneity is
purely topological (the mesh).  Gc, E, nu, l0, rho are scalar broadcasts
to the post-carve element count.

Boundary sets
-------------
Five sets in alphabetical order: ``bottom, left, right, top,
void_boundary``.  The fifth set lists every node on a void rim; it has
no associated Neumann/Dirichlet entry in :attr:`bcs`, so the dataset
runner leaves it traction-free by default (see
:func:`dataset_benchmark.runner._build_bcs_from_generator`).

Determinism
-----------
gmsh's Frontal-Delaunay mesher is seeded explicitly via
``Mesh.RandomSeed`` in :func:`_run_gmsh_with_seed` so two
``generate(seed=k)`` calls within the same Python process produce
byte-identical node coordinates and connectivity.  Cross-version /
cross-platform byte equality is **not** guaranteed (gmsh internals
change between releases) — the determinism contract here matches the
"in-process reproducibility" expectation of every other generator that
uses gmsh.

Fallback
--------
If gmsh is missing at import time we fall back to the v1
:class:`VoidsGenerator` (degraded-Gc patches).  The fallback emits a
:class:`RuntimeWarning` so the missing-gmsh state is observable in test
output AND in the dataset's per-sample metadata (the runner records the
generator class label, not the fallback's, so a follow-up release-notes
audit still has the right hook).
"""
from __future__ import annotations

import os
import tempfile
import warnings
from typing import Any, Mapping

import numpy as np

from ._base import GeneratorOutput, SampleGenerator
from .homogeneous import _structured_tri_mesh
from .voids import VoidsGenerator


def _gmsh_available() -> bool:
    """Return ``True`` iff the ``gmsh`` Python module imports cleanly."""
    try:
        import gmsh  # noqa: F401
        return True
    except Exception:
        return False


def _run_gmsh_with_seed(geo_path: str, msh_path: str, seed: int):
    """Mesh ``geo_path`` deterministically and return ``(nodes, elements,
    physical_groups)`` arrays.

    Differs from :func:`mesh_generator._run_gmsh` in two points:

    - Sets ``Mesh.RandomSeed = seed`` so the Frontal-Delaunay output is
      reproducible.
    - Returns the in-memory arrays directly (no meshio round-trip)
      together with the mapping from physical-group name to node-tag set.
    """
    import gmsh

    own_init = not gmsh.isInitialized()
    if own_init:
        gmsh.initialize()
    try:
        gmsh.option.setNumber("General.Verbosity", 0)
        gmsh.option.setNumber("Mesh.RandomSeed", float(int(seed) % (2**31)))
        # Same rendering knobs as the homogeneous gmsh path so node
        # ordering matches the rest of mesh_generator.py.
        gmsh.option.setNumber("Mesh.Algorithm", 6)  # Frontal-Delaunay

        gmsh.open(geo_path)
        gmsh.model.mesh.generate(2)
        gmsh.model.mesh.renumberNodes()
        gmsh.model.mesh.renumberElements()

        node_tags, node_coords, _ = gmsh.model.mesh.getNodes()
        # gmsh node tags are 1-based; build a 0-based dense array with
        # contiguous indexing so element connectivity is straightforward.
        node_tags = np.asarray(node_tags, dtype=np.int64)
        node_coords = np.asarray(node_coords, dtype=np.float64).reshape(-1, 3)
        max_tag = int(node_tags.max()) if node_tags.size else 0
        tag_to_idx = np.full(max_tag + 1, -1, dtype=np.int64)
        tag_to_idx[node_tags] = np.arange(node_tags.size, dtype=np.int64)
        nodes = node_coords[:, :2].copy()  # 2-D plate

        # Triangular elements only (type 2).
        elem_types, elem_tags, elem_nodes = gmsh.model.mesh.getElements(2)
        elements = None
        for etype, etags, enodes in zip(elem_types, elem_tags, elem_nodes):
            if int(etype) == 2:  # 3-node triangle
                conn = np.asarray(enodes, dtype=np.int64).reshape(-1, 3)
                elements = tag_to_idx[conn]
                break
        if elements is None:
            elements = np.zeros((0, 3), dtype=np.int64)

        # Map each physical-curve name to the set of node indices that
        # appear on it.  For 1-D physical curves we ask gmsh for the
        # boundary nodes of every entity in the group.
        groups: dict[str, np.ndarray] = {}
        for dim, tag in gmsh.model.getPhysicalGroups(1):
            name = gmsh.model.getPhysicalName(dim, tag)
            if not name:
                continue
            try:
                gnode_tags, _ = gmsh.model.mesh.getNodesForPhysicalGroup(
                    dim, tag)
            except Exception:
                continue
            gnode_tags = np.asarray(gnode_tags, dtype=np.int64)
            if gnode_tags.size == 0:
                groups[name] = np.zeros(0, dtype=np.int64)
                continue
            # Some tags can exceed our dense map if gmsh added auxiliary
            # nodes — clamp to the max-tag we built tag_to_idx for.
            mask = (gnode_tags >= 0) & (gnode_tags <= max_tag)
            gnode_tags = gnode_tags[mask]
            idx = tag_to_idx[gnode_tags]
            idx = idx[idx >= 0]
            groups[name] = np.unique(idx).astype(np.int64)
    finally:
        gmsh.clear()
        if own_init:
            try:
                gmsh.finalize()
            except Exception:
                pass

    return nodes, elements, groups


def _intersects_pre_crack(cx: float, cy: float, r: float,
                            slit_y: float, a: float,
                            crack_band: float, clearance: float) -> bool:
    """Return ``True`` if the disk ``(cx, cy, r)`` is too close to the
    horizontal pre-crack slit ``y = slit_y, x in [0, a]``.

    Treats the slit as a line segment with a thickness of ``crack_band``
    on each side and demands the disk centre be at distance >=
    ``r + crack_band + clearance`` from the segment.
    """
    # Closest point on the slit segment to (cx, cy):
    px = max(0.0, min(a, cx))
    dx = cx - px
    dy = cy - slit_y
    d2 = dx * dx + dy * dy
    threshold = r + crack_band + clearance
    return d2 < threshold * threshold


def _build_geo_text(W: float, H: float, holes: list[tuple[float, float, float]],
                     h_target: float, h_void: float) -> str:
    """Build a gmsh ``.geo`` source for a rectangular plate with circular
    holes.  Mirrors :func:`mesh_generator.plate_with_holes` but with the
    plate dimensions specialised to W x H (not square)."""
    lines: list[str] = [
        "// PF-Hetero-Bench geometric_voids — auto-generated",
        "",
        f"h_void = {h_void:.12g};",
        f"h_target = {h_target:.12g};",
        f"W = {W:.12g};",
        f"H = {H:.12g};",
        "",
        "// Outer boundary",
        "Point(1) = {0, 0, 0, h_target};",
        "Point(2) = {W, 0, 0, h_target};",
        "Point(3) = {W, H, 0, h_target};",
        "Point(4) = {0, H, 0, h_target};",
        "",
        "Line(1) = {1, 2};  // bottom",
        "Line(2) = {2, 3};  // right",
        "Line(3) = {3, 4};  // top",
        "Line(4) = {4, 1};  // left",
        "",
        "Curve Loop(1) = {1, 2, 3, 4};",
        "",
    ]
    n_holes = len(holes)
    hole_arc_tags: list[int] = []
    for i, (cx, cy, r) in enumerate(holes):
        pc = 100 + 5 * i
        pe = 101 + 5 * i
        pn = 102 + 5 * i
        pw = 103 + 5 * i
        ps = 104 + 5 * i
        ca = 200 + 4 * i  # arcs offset above outer-line ids
        cb = 201 + 4 * i
        cc = 202 + 4 * i
        cd = 203 + 4 * i
        cl = 50 + i
        lines += [
            f"// Hole {i}: ({cx:.6g}, {cy:.6g}, r={r:.6g})",
            f"Point({pc}) = {{{cx:.12g}, {cy:.12g}, 0, h_void}};",
            f"Point({pe}) = {{{cx + r:.12g}, {cy:.12g}, 0, h_void}};",
            f"Point({pn}) = {{{cx:.12g}, {cy + r:.12g}, 0, h_void}};",
            f"Point({pw}) = {{{cx - r:.12g}, {cy:.12g}, 0, h_void}};",
            f"Point({ps}) = {{{cx:.12g}, {cy - r:.12g}, 0, h_void}};",
            f"Circle({ca}) = {{{pe}, {pc}, {pn}}};",
            f"Circle({cb}) = {{{pn}, {pc}, {pw}}};",
            f"Circle({cc}) = {{{pw}, {pc}, {ps}}};",
            f"Circle({cd}) = {{{ps}, {pc}, {pe}}};",
            f"Curve Loop({cl}) = {{{ca}, {cb}, {cc}, {cd}}};",
            "",
        ]
        hole_arc_tags.extend([ca, cb, cc, cd])

    if n_holes:
        loops = ", ".join(str(50 + i) for i in range(n_holes))
        lines.append(f"Plane Surface(1) = {{1, {loops}}};")
    else:
        lines.append("Plane Surface(1) = {1};")
    lines.append("")

    # Physical groups — one per outer side, one combined "void_boundary"
    # for ALL hole arcs (we don't need per-hole resolution downstream).
    lines += [
        'Physical Curve("bottom") = {1};',
        'Physical Curve("right") = {2};',
        'Physical Curve("top") = {3};',
        'Physical Curve("left") = {4};',
    ]
    if hole_arc_tags:
        arc_str = ", ".join(str(t) for t in hole_arc_tags)
        lines.append(f'Physical Curve("void_boundary") = {{{arc_str}}};')
    lines += [
        'Physical Surface("plate") = {1};',
        "",
        "Mesh.MeshSizeExtendFromBoundary = 1;",
        "Mesh.MeshSizeFromPoints = 1;",
        "Mesh.MeshSizeFromCurvature = 0;",
        "Mesh.Algorithm = 6;  // Frontal-Delaunay",
        "Mesh.ElementOrder = 1;",
    ]
    return "\n".join(lines) + "\n"


class GeometricVoidsGenerator(SampleGenerator):
    """Random plate with N geometrically-carved circular voids.

    Falls back to :class:`VoidsGenerator` (degraded-Gc proxy) if gmsh is
    not importable.
    """

    CLASS_NAME = "geometric_voids"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        "n_voids_choices": (1, 2, 3, 5, 8),
        "void_radius_l0_range": (0.5, 4.0),  # multiples of l0
        "void_pre_crack_clearance_l0": 2.0,    # clearance from slit, in l0
        "void_edge_clearance_l0": 2.0,         # clearance from outer edges
        "max_position_attempts": 200,
        "nx_per_l0": 2,                        # mesh-coarseness target
        "ny_per_l0": 2,
        "max_nodes": 8_000,
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        if not _gmsh_available():
            warnings.warn(
                "[geometric_voids] gmsh import failed; falling back to "
                "the v1 VoidsGenerator (degraded-Gc proxy). The fallback "
                "produces the 4-set boundary list (no `void_boundary`) "
                "and degraded-Gc patches instead of carved holes.",
                RuntimeWarning, stacklevel=2,
            )
            return VoidsGenerator().generate(seed)

        try:
            return self._generate_geometric(seed)
        except Exception as exc:  # pragma: no cover - defensive
            warnings.warn(
                f"[geometric_voids] gmsh meshing failed ({exc!r}); "
                "falling back to the v1 VoidsGenerator (degraded-Gc proxy).",
                RuntimeWarning, stacklevel=2,
            )
            return VoidsGenerator().generate(seed)

    # ------------------------------------------------------------------
    def _generate_geometric(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E = float(rng.uniform(*p["E_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc = float(rng.uniform(*p["Gc_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        n_voids_choices = tuple(int(c) for c in p["n_voids_choices"])
        n_voids = int(rng.choice(np.asarray(n_voids_choices, dtype=np.int64)))

        # Mesh-size targets: target h ~ l0 / nx_per_l0 globally, with a
        # finer h_void near the carved arcs (matches mesh_generator's
        # plate_with_holes helper).  We also cap h_target by a node-budget
        # heuristic: for an unstructured triangulation, n_nodes ~
        # 2 * area / h^2 (roughly; the '2' covers refinement around arcs).
        h_target = l0 / float(p["nx_per_l0"])
        h_void = max(h_target * 0.5, 0.25 * l0)

        slit_y = 0.5 * H
        # crack_band: half-thickness of the pre-crack node band
        crack_band = max(0.5 * l0, 0.51 * h_target)
        clearance_pc = float(p["void_pre_crack_clearance_l0"]) * l0
        clearance_edge = float(p["void_edge_clearance_l0"]) * l0

        rad_lo, rad_hi = (float(p["void_radius_l0_range"][0]) * l0,
                           float(p["void_radius_l0_range"][1]) * l0)
        # Hard cap so a void can never exceed plate/3 in radius.
        rad_cap = min(W, H) / 3.0
        rad_hi = min(rad_hi, rad_cap)
        rad_lo = min(rad_lo, rad_hi)

        holes: list[tuple[float, float, float]] = []
        max_attempts_per_void = int(p["max_position_attempts"])
        for _ in range(n_voids):
            placed = False
            for _attempt in range(max_attempts_per_void):
                r = float(rng.uniform(rad_lo, rad_hi))
                margin = r + clearance_edge
                if margin >= 0.5 * W or margin >= 0.5 * H:
                    # Disk wouldn't fit — shrink it.
                    r = max(rad_lo,
                            min(0.4 * W - clearance_edge,
                                0.4 * H - clearance_edge,
                                r))
                    margin = r + clearance_edge
                cx = float(rng.uniform(margin, max(W - margin, margin + 1e-9)))
                cy = float(rng.uniform(margin, max(H - margin, margin + 1e-9)))
                if _intersects_pre_crack(cx, cy, r, slit_y, a,
                                          crack_band, clearance_pc):
                    continue
                # Pairwise non-overlap (centre-to-centre > sum of radii
                # + 2 * h_void so meshing doesn't choke).
                ok = True
                for (cx2, cy2, r2) in holes:
                    if (cx - cx2) ** 2 + (cy - cy2) ** 2 < (
                            r + r2 + 2.0 * h_void) ** 2:
                        ok = False
                        break
                if ok:
                    holes.append((cx, cy, r))
                    placed = True
                    break
            if not placed:
                # Could not find a slot; emit the remaining voids
                # against the wall instead of looping forever.
                break

        # Reduce the global node target if the heuristic mesh size
        # would blow past max_nodes.  Unstructured triangulations on
        # plates with carved holes have n_nodes ~ k * (W*H/h^2) with
        # k between 2 and 4 (refinement around arcs adds the multiplier);
        # we use k=4 for a conservative bound that keeps actual gmsh
        # output under the cap most of the time.
        max_nodes = int(p["max_nodes"])
        est_nodes = 4.0 * (W * H) / (h_target * h_target)
        if est_nodes > max_nodes:
            scale = (est_nodes / max_nodes) ** 0.5
            h_target = h_target * scale
            h_void = h_void * scale

        # Build the .geo, mesh it, parse arrays back.
        with tempfile.TemporaryDirectory() as td:
            geo_path = os.path.join(td, f"geo_voids_{seed}.geo")
            msh_path = os.path.join(td, f"geo_voids_{seed}.msh")
            with open(geo_path, "w") as f:
                f.write(_build_geo_text(W, H, holes, h_target, h_void))
            nodes, elements, groups = _run_gmsh_with_seed(
                geo_path, msh_path, seed=seed)

        n_nodes = nodes.shape[0]
        n_elems = elements.shape[0]

        # Boundary node-sets.  Coordinate-based detection for the four
        # outer sides (matches the homogeneous generator), gmsh-physical
        # group lookup for the void boundary.
        x = nodes[:, 0]
        y = nodes[:, 1]
        eps = 1e-6 * max(W, H)
        sets: dict[str, np.ndarray] = {
            "left":   np.where(x < eps)[0].astype(np.int64),
            "right":  np.where(x > W - eps)[0].astype(np.int64),
            "bottom": np.where(y < eps)[0].astype(np.int64),
            "top":    np.where(y > H - eps)[0].astype(np.int64),
            "void_boundary": np.asarray(
                groups.get("void_boundary", np.zeros(0, dtype=np.int64)),
                dtype=np.int64),
        }
        boundary_set_names = sorted(sets.keys())  # alphabetical
        boundary_tags = np.zeros(n_nodes, dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        # Pre-crack mask: same horizontal slit as homogeneous, but
        # applied to the carved mesh.  Some nodes that would have been
        # in the band are now missing (carved away), which is fine.
        pre_crack_mask = (
            (np.abs(y - slit_y) < crack_band)
            & (x >= 0.0) & (x <= a)
        ).astype(np.uint8)

        # Material fields — uniform across all remaining elements.
        material = {
            "E":   np.full(n_elems, E,   dtype=np.float64),
            "nu":  np.full(n_elems, nu,  dtype=np.float64),
            "Gc":  np.full(n_elems, Gc,  dtype=np.float64),
            "l0":  np.full(n_elems, l0,  dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }
        material_tag = np.zeros(n_elems, dtype=np.int64)

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        # No BC entry for void_boundary — runner leaves it traction-free
        # by default (see runner._build_bcs_from_generator: any node-set
        # without a {fix, traction, prescribe} entry is unused).
        bcs: dict[str, Any] = {
            "left":   {"type": "fix", "component": 0},
            "top":    {"type": "traction", "component": 1, "value":  1.0},
            "bottom": {"type": "traction", "component": 1, "value": -1.0},
            "_params": {
                "W": W, "H": H, "a": a,
                "E": E, "nu": nu, "Gc": Gc, "l0": l0, "rho": rho,
                "n_voids_drawn": len(holes),
                "n_voids_requested": int(n_voids),
                "h_target": h_target,
                "h_void": h_void,
            },
            "_class_meta": {
                "void_x":      np.asarray([h[0] for h in holes],
                                          dtype=np.float64),
                "void_y":      np.asarray([h[1] for h in holes],
                                          dtype=np.float64),
                "void_radius": np.asarray([h[2] for h in holes],
                                          dtype=np.float64),
                "n_void_boundary_nodes": int(sets["void_boundary"].size),
            },
        }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
        }
        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


__all__ = ["GeometricVoidsGenerator"]
