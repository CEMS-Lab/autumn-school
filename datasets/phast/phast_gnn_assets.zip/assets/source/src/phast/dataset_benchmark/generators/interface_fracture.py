"""Diffuse interface fracture generator (Hansen-Doerr et al. 2020).

PF-Hetero-Bench class #10 (issue #325).  A static interface geometry is
encoded directly into per-element ``Gc`` and ``E`` fields, mimicking the
diffuse interface model proposed by

    Hansen-Doerr, Dammass, de Borst, Kaestner (2020), "Phase-Field
    Modeling of Crack Branching and Deflection in Heterogeneous Media",
    Eng. Fract. Mech. 232: 107004,
    DOI 10.1016/j.engfracmech.2020.107004.

In the original paper the interface is represented as a STATIC
phase-field that does not evolve — separate from the dynamic crack PF —
and combines two mechanisms at the interface:

    1. Local toughness reduction (Gc contrast).
    2. Hyperbolic-tangent smoothing of E and nu across the interface
       (elastic-property contrast).

We do not represent the static interface PF as its own field here.
Instead the generator BAKES the modifications into per-element ``Gc``
and ``E`` arrays, so the standard bulk PF model (single d-field, no
cohesive law) reads them transparently. This is intentional: it slots
straight into the PR #321 / PR #323 dataset infrastructure with no
solver changes.

Honest framing
--------------
This is a **bulk-only PF model** with spatial Gc/E modifications that
mimic interface behaviour. It is NOT a true cohesive-zone formulation:
there is no traction-separation law, no displacement jump, no separate
interface degree of freedom. For heavier alternatives:

  - PF-CZM v2 (issue #247) — proper cohesive-zone phase-field after
    Wu (2018, JMPS).
  - Discrete cohesive v3 (issue #261) — explicit mesh-line cohesive
    elements with traction-separation.

If a sampled interface line is far from the crack-tip path, the
interface will not visibly affect crack propagation in a 200-step smoke
run.  That is **expected behaviour, not a bug** — the smoke tier is
geometry-determinism + plumbing, not a physics validation.

Per-sample geometry
-------------------
- Number of interfaces drawn with weighted choice: ``P(n=1) = 0.5``,
  ``P(n=2) = 0.3``, ``P(n=3) = 0.2``.
- Each interface is a line segment defined by random endpoints inside
  the plate (with 5*l0 inset clearance from all four sides), rejection-
  sampled to keep both endpoints AND any interior point at least 5*l0
  from the standard left-edge pre-crack zone.
- Interface half-thickness ``h_i = uniform(2, 4) * (W/nx)``, the
  regularization band over which Gc/E vary.
- ``alpha_Gc ~ U(0.1, 0.9)`` — toughness reduction fraction.
- 50%% probability the sample carries an E-contrast across the
  interface; if active, ``E_left/E_right ~ U(0.5, 2.0)``.

Field formulas
--------------
For each element with centroid ``x``, let ``d_i(x)`` be the *unsigned*
perpendicular distance to the nearest interface line and
``d_i_signed(x)`` be the *signed* perpendicular distance to that nearest
line (sign = side of the line in the line-local +n direction). Then:

    Gc(x) = Gc_bulk * (1 - alpha_Gc * exp(-(d_i / h_i)**2 / 2))
    E(x)  = E_avg + 0.5 * (E_right - E_left) * tanh(d_i_signed / h_i)

(Gc kernel is the Hansen-Doerr Gaussian; E kernel is the Hansen-Doerr
hyperbolic-tangent.)

``nu`` and ``rho`` are scalar uniforms across the plate, per the v1
runner plumbing limitation noted in PR #323's CHANGELOG.
"""
from __future__ import annotations

import numpy as np

from ._base import GeneratorOutput, SampleGenerator
from .homogeneous import _structured_tri_mesh
from .pre_cracked import _dist_to_segment


def _signed_dist_to_line(px: np.ndarray, py: np.ndarray,
                          ax: float, ay: float,
                          bx: float, by: float) -> np.ndarray:
    """Signed perpendicular distance from (px, py) to the INFINITE line
    through (ax, ay)->(bx, by). Sign follows the line-local +n direction
    (rotation of the line tangent by +90 degrees CCW).
    """
    ux = bx - ax; uy = by - ay
    L = float(np.sqrt(ux * ux + uy * uy))
    if L < 1e-30:
        # Degenerate line — fall back to Euclidean distance from a.
        return np.sqrt((px - ax) ** 2 + (py - ay) ** 2)
    # Unit normal: (-uy/L, ux/L)
    nx = -uy / L
    ny =  ux / L
    return (px - ax) * nx + (py - ay) * ny


class InterfaceFractureGenerator(SampleGenerator):
    """Random plate with 1-3 diffuse interface lines (Hansen-Doerr 2020)."""

    CLASS_NAME = "interface_fracture"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        # Number of interfaces per sample: weighted choice {1: 0.5, 2: 0.3, 3: 0.2}.
        # Tests can override via ``n_interfaces_choices=(1,)`` to force a single
        # interface (used in test_interface_fracture_geometry's least-squares fit).
        "n_interfaces_choices":  (1, 2, 3),
        "n_interfaces_weights":  (0.5, 0.3, 0.2),
        "h_i_elem_widths_range": (2.0, 4.0),    # half-thickness in element widths
        "alpha_Gc_range":        (0.1, 0.9),    # toughness reduction fraction
        "E_contrast_prob":       0.5,           # P(sample has E contrast)
        "E_ratio_range":         (0.5, 2.0),    # E_left / E_right
        "min_clearance_l0":      5.0,
        "max_reject_attempts":   50,
        "nx_per_l0": 2,
        "ny_per_l0": 2,
        "max_nodes": 8_000,
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        # ---- random parameter draws ---------------------------------
        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E_bulk = float(rng.uniform(*p["E_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc_bulk = float(rng.uniform(*p["Gc_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        # ---- mesh ---------------------------------------------------
        h_target = l0 / float(p["nx_per_l0"])
        nx = max(2, int(round(W / h_target)))
        ny = max(2, int(round(H / h_target)))
        if (nx + 1) * (ny + 1) > p["max_nodes"]:
            scale = ((nx + 1) * (ny + 1) / p["max_nodes"]) ** 0.5
            nx = max(2, int(round(nx / scale)))
            ny = max(2, int(round(ny / scale)))
        nodes, elements = _structured_tri_mesh(W, H, nx, ny)
        n_elems = elements.shape[0]
        n_nodes = nodes.shape[0]
        centroids = nodes[elements].mean(axis=1)
        cx = centroids[:, 0]; cy = centroids[:, 1]

        # ---- interface count + per-sample interface params ----------
        choices = list(p["n_interfaces_choices"])
        weights = list(p["n_interfaces_weights"])
        # Restrict weights to active choices and renormalise (lets tests
        # pass ``n_interfaces_choices=(1,)`` without also resetting weights).
        weights = weights[:len(choices)]
        wsum = float(sum(weights))
        if wsum <= 0:
            weights = [1.0 / len(choices)] * len(choices)
        else:
            weights = [w / wsum for w in weights]
        n_interfaces = int(rng.choice(choices, p=weights))

        elem_width = W / float(nx)
        h_i = float(rng.uniform(*p["h_i_elem_widths_range"])) * elem_width
        alpha_Gc = float(rng.uniform(*p["alpha_Gc_range"]))
        has_E_contrast = bool(rng.random() < float(p["E_contrast_prob"]))
        if has_E_contrast:
            E_ratio = float(rng.uniform(*p["E_ratio_range"]))
            # Geometric mean of E_left and E_right is E_bulk.
            E_left  = E_bulk * np.sqrt(E_ratio)
            E_right = E_bulk / np.sqrt(E_ratio)
        else:
            E_ratio = 1.0
            E_left = E_right = E_bulk

        # ---- pre-crack geometry (needed for clearance check) --------
        slit_y = 0.5 * H
        crack_band = max(0.5 * l0, 0.51 * H / max(ny, 1))
        clearance = float(p["min_clearance_l0"]) * l0
        max_attempts = int(p["max_reject_attempts"])

        # ---- sample interface line segments -------------------------
        # Endpoints inside the plate (clearance from edges); rejection-
        # sample to keep the whole segment >= 5*l0 from the pre-crack.
        line_segs: list[tuple[float, float, float, float]] = []
        attempt = 0
        # Bound total attempts so a pathological draw does not hang.
        attempt_budget = max_attempts * max(1, n_interfaces) * 2
        while len(line_segs) < n_interfaces and attempt < attempt_budget:
            attempt += 1
            ax = rng.uniform(clearance, W - clearance)
            ay = rng.uniform(clearance, H - clearance)
            bx = rng.uniform(clearance, W - clearance)
            by = rng.uniform(clearance, H - clearance)
            # Reject too-short segments (< 1/4 of the plate diagonal) so the
            # interface actually traverses meaningful distance.
            length = float(np.hypot(bx - ax, by - ay))
            if length < 0.25 * np.hypot(W, H):
                continue
            # Sample many points along the candidate segment, check
            # distance to the pre-crack zone.
            ts = np.linspace(0.0, 1.0, 21)
            sx = ax + ts * (bx - ax); sy = ay + ts * (by - ay)
            d_to_pre = _dist_to_segment(sx, sy, 0.0, slit_y, a, slit_y)
            if d_to_pre.min() < clearance:
                continue
            line_segs.append((ax, ay, bx, by))
        # If rejection sampling failed to fill the budget, fall back to
        # a horizontal interface above the pre-crack — guaranteed to satisfy
        # the clearance constraint when (H/2 - clearance) > clearance.
        while len(line_segs) < n_interfaces:
            y_above = slit_y + clearance + 0.1 * H * (len(line_segs) + 1)
            y_above = float(min(y_above, H - clearance))
            line_segs.append((clearance, y_above, W - clearance, y_above))

        seg_array = np.asarray(line_segs, dtype=np.float64)  # (n_interfaces, 4)

        # ---- per-element distance to nearest interface --------------
        # Unsigned distance for the Gc kernel (Gaussian, even).
        # Signed distance to the *nearest* line for the E kernel (tanh).
        unsigned_dists = np.empty((n_interfaces, n_elems), dtype=np.float64)
        signed_dists   = np.empty((n_interfaces, n_elems), dtype=np.float64)
        for i, (ax, ay, bx, by) in enumerate(line_segs):
            unsigned_dists[i] = _dist_to_segment(cx, cy, ax, ay, bx, by)
            signed_dists[i]   = _signed_dist_to_line(cx, cy, ax, ay, bx, by)

        nearest_idx = np.argmin(unsigned_dists, axis=0)         # (n_elems,)
        d_unsigned = unsigned_dists[nearest_idx, np.arange(n_elems)]
        d_signed   = signed_dists[nearest_idx, np.arange(n_elems)]

        # ---- Gc field: Gaussian reduction along the interface --------
        gauss = np.exp(-(d_unsigned / h_i) ** 2 / 2.0)
        Gc_field = Gc_bulk * (1.0 - alpha_Gc * gauss)

        # ---- E field: tanh contrast across the (signed) interface ----
        if has_E_contrast:
            E_avg = 0.5 * (E_left + E_right)
            E_field = E_avg + 0.5 * (E_right - E_left) * np.tanh(d_signed / h_i)
        else:
            E_field = np.full(n_elems, E_bulk, dtype=np.float64)

        # ---- pre-crack mask -----------------------------------------
        x = nodes[:, 0]; y = nodes[:, 1]
        pre_crack_mask = (
            (np.abs(y - slit_y) < crack_band)
            & (x >= 0.0) & (x <= a)
        ).astype(np.uint8)

        # ---- boundary node-sets -------------------------------------
        eps = 1e-6 * max(W, H)
        sets = {
            "left":   np.where(x < eps)[0],
            "right":  np.where(x > W - eps)[0],
            "bottom": np.where(y < eps)[0],
            "top":    np.where(y > H - eps)[0],
        }
        boundary_set_names = sorted(sets.keys())
        boundary_tags = np.zeros(n_nodes, dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        # ---- material fields ----------------------------------------
        # material_tag = nearest-interface index per element; identifies
        # which interface dominates each element's Gc / E modification.
        material_tag = nearest_idx.astype(np.int64)

        material = {
            "E":   E_field.astype(np.float64),
            "nu":  np.full(n_elems, nu,  dtype=np.float64),
            "Gc":  Gc_field.astype(np.float64),
            "l0":  np.full(n_elems, l0,  dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        bcs = {
            "left":   {"type": "fix", "component": 0},
            "top":    {"type": "traction", "component": 1, "value":  1.0},
            "bottom": {"type": "traction", "component": 1, "value": -1.0},
            "_params": {
                "W": W, "H": H, "a": a,
                "E_bulk": E_bulk, "nu": nu, "Gc_bulk": Gc_bulk,
                "l0": l0, "rho": rho,
                "nx": nx, "ny": ny,
                "n_interfaces": n_interfaces,
                "h_i": h_i,
                "alpha_Gc": alpha_Gc,
                "has_E_contrast": has_E_contrast,
                "E_ratio": E_ratio,
                "E_left": E_left,
                "E_right": E_right,
            },
            "_class_meta": {
                "interface_segments": seg_array,
            },
        }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
        }
        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


__all__ = ["InterfaceFractureGenerator"]
