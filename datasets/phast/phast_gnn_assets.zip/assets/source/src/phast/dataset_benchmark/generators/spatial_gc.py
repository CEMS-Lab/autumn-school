"""Spatial random Gc(x) field — sum of K=5 Gaussian bumps.

PF-Hetero-Bench class #2 (issue #298).  The toughness varies in space
according to

    Gc(x) = Gc_nominal * (1 + Σ_k A_k * exp(-||x - x_k||² / (2 σ_k²)))

with K = 5 random Gaussian bumps, each parameterised by
``(x_k, y_k, σ_k, A_k)``.

Why a sum of Gaussian bumps and not a true Gaussian-process draw?
-----------------------------------------------------------------
A length-scale-conditioned GP via Karhunen–Loève would be the
mathematically clean choice, but at production-tier element counts
(≈ 50 k–100 k) sampling a full GP is O(N²) memory / O(N³) factorisation
(Cholesky of a 50 k × 50 k covariance kernel).  The K-bump mixture is a
low-rank approximation: every realisation is a smooth, twice-differentiable
field with controllable mean length-scale and amplitude, but evaluation
is O(K · N) and storage is O(K).  Bump amplitudes are drawn from a
*signed* range U(-0.4, +0.4) so the resulting field is genuinely
non-monotonic (positive bumps strengthen, negative weaken) — purely
positive amplitudes would bias every realisation toward a tougher mean.

For a true GP-conditioned Gc field at production resolution, consider
follow-up issue (FFT-based circulant embedding for stationary kernels
on rectangular domains, O(N log N)).
"""
from __future__ import annotations

import numpy as np

from ._base import GeneratorOutput, SampleGenerator
from .homogeneous import _structured_tri_mesh


class SpatialGcGenerator(SampleGenerator):
    """Random plate with a Gc(x) field built from K Gaussian bumps."""

    CLASS_NAME = "spatial_gc"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_nominal_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        # K Gaussian bumps; each (x_k, y_k, sigma_k, A_k)
        "K_bumps": 5,
        "sigma_frac_range": (0.05, 0.20),   # sigma in fraction of min(W,H)
        "amplitude_range": (-0.4, 0.4),     # signed -> non-monotonic
        "nx_per_l0": 2,
        "ny_per_l0": 2,
        "max_nodes": 8_000,
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E = float(rng.uniform(*p["E_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc_nominal = float(rng.uniform(*p["Gc_nominal_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        # ---- mesh ----
        h_target = l0 / float(p["nx_per_l0"])
        nx = max(2, int(round(W / h_target)))
        ny = max(2, int(round(H / h_target)))
        if (nx + 1) * (ny + 1) > p["max_nodes"]:
            scale = ((nx + 1) * (ny + 1) / p["max_nodes"]) ** 0.5
            nx = max(2, int(round(nx / scale)))
            ny = max(2, int(round(ny / scale)))
        nodes, elements = _structured_tri_mesh(W, H, nx, ny)
        n_elems = elements.shape[0]
        centroids = nodes[elements].mean(axis=1)  # (n_elems, 2)

        # ---- K random Gaussian bumps ----
        K = int(p["K_bumps"])
        sigma_min = float(p["sigma_frac_range"][0]) * min(W, H)
        sigma_max = float(p["sigma_frac_range"][1]) * min(W, H)
        bump_x = rng.uniform(0.0, W, size=K)
        bump_y = rng.uniform(0.0, H, size=K)
        bump_s = rng.uniform(sigma_min, sigma_max, size=K)
        bump_A = rng.uniform(*p["amplitude_range"], size=K)

        # Sum of bumps -> per-element multiplier
        mult = np.zeros(n_elems, dtype=np.float64)
        for k in range(K):
            dx = centroids[:, 0] - bump_x[k]
            dy = centroids[:, 1] - bump_y[k]
            mult += bump_A[k] * np.exp(
                -(dx * dx + dy * dy) / (2.0 * bump_s[k] ** 2))
        # Clamp to keep Gc strictly positive (1 + mult must be > 0).  A
        # single bump amplitude is bounded < 1, but their *sum* could in
        # principle dip below -1 if they cluster.  Floor at 0.05 -> Gc
        # never less than 5% of nominal.
        Gc_field = Gc_nominal * np.maximum(1.0 + mult, 0.05)

        # ---- boundary node-sets ----
        x = nodes[:, 0]; y = nodes[:, 1]
        eps = 1e-6 * max(W, H)
        sets = {
            "left":   np.where(x < eps)[0],
            "right":  np.where(x > W - eps)[0],
            "bottom": np.where(y < eps)[0],
            "top":    np.where(y > H - eps)[0],
        }
        boundary_set_names = sorted(sets.keys())
        boundary_tags = np.zeros(nodes.shape[0], dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        # ---- pre-crack mask: same convention as homogeneous ----
        slit_y = 0.5 * H
        # Widen crack band when mesh is coarser than l0 -- without this
        # guard the nearest row of nodes can sit just outside l0/2 of
        # the slit and the pre-crack mask comes out empty (latent bug
        # from homogeneous.py with max_nodes capped meshes).
        crack_band = max(0.5 * l0, 0.51 * H / ny)
        pre_crack_mask = (
            (np.abs(y - slit_y) < crack_band)
            & (x >= 0.0) & (x <= a)
        ).astype(np.uint8)

        # ---- material fields ----
        material = {
            "E":   np.full(n_elems, E,   dtype=np.float64),
            "nu":  np.full(n_elems, nu,  dtype=np.float64),
            "Gc":  Gc_field.astype(np.float64),
            "l0":  np.full(n_elems, l0,  dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }
        material_tag = np.zeros(n_elems, dtype=np.int64)

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        bcs = {
            "left":   {"type": "fix", "component": 0},
            "top":    {"type": "traction", "component": 1, "value":  1.0},
            "bottom": {"type": "traction", "component": 1, "value": -1.0},
            "_params": {
                "W": W, "H": H, "a": a,
                "E": E, "nu": nu, "Gc_nominal": Gc_nominal,
                "l0": l0, "rho": rho,
                "nx": nx, "ny": ny, "K_bumps": K,
            },
            "_class_meta": {
                "bump_x": bump_x, "bump_y": bump_y,
                "bump_sigma": bump_s, "bump_amplitude": bump_A,
            },
        }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
        }
        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


__all__ = ["SpatialGcGenerator"]
