"""End-to-end orchestrator: generator -> StaggeredSolver -> SamplePackager.

Issue #298 follow-up to PR #318 (skeleton) and PR #304 (telemetry CSV).

Why this lives outside ``run_config.py``
----------------------------------------
``run_config.py`` is a 580-line CLI driver tightly coupled to YAML
parsing, gmsh subprocess meshing, h5 init, and the post-processing
pipeline. A dataset run wants none of that — it owns its own mesh
(from a generator), its own loop, and writes through the packager
rather than the CLI's bespoke artefacts. Reusing ``run_config.py``
would mean threading a callback through argparse + YAML resolution
just so the solver can hand keyframes back. Inlining the per-step
logic (the body of ``run_config.py`` lines 358-450) is cleaner and
keeps coupling one-way: ``runner`` imports from ``staggered_solver``,
not from ``run_config``.

Schema constraint
-----------------
``schema.NUM_KEYFRAMES = 100`` is hard-checked by the validator
(see ``validator._check_shape``). Keyframe captures therefore use
``K = NUM_KEYFRAMES`` regardless of the caller-supplied
``n_keyframes`` hint; the latter is plumbed for forward compat but
ignored as long as the schema is locked at v1. The smoke test in
``tests/test_dataset_runner.py`` documents this.
"""
from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, List, Mapping, Optional

import numpy as np
import torch

from . import __version__ as PACKAGE_VERSION
from .generators._base import GeneratorOutput, SampleGenerator
from .packager import SamplePackager
from .schema import NUM_KEYFRAMES


# ----------------------------------------------------------------------
# Solver-SHA helper (best-effort; never raises)
# ----------------------------------------------------------------------

def _resolve_solver_sha(repo_dir: Optional[Path] = None) -> str:
    """``git rev-parse HEAD`` from the solver repo; ``"unknown"`` on failure.

    Stored in every sample's metadata so a downstream consumer can
    forward-replay the run.
    """
    cwd = repo_dir if repo_dir is not None else Path(__file__).resolve().parent.parent
    try:
        out = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(cwd), capture_output=True, text=True, timeout=5,
        )
        if out.returncode == 0 and out.stdout.strip():
            return out.stdout.strip()
    except Exception:
        pass
    return "unknown"


# ----------------------------------------------------------------------
# Solver-side wiring helpers
# ----------------------------------------------------------------------

def _build_mesh_from_generator(gen_out: GeneratorOutput, *,
                                device: str, dtype: torch.dtype):
    """Materialise a :class:`FEMMesh` from the generator's mesh dict.

    Decodes the per-node ``boundary_tags`` bitmask back into named
    node sets (one set per bit, in ``boundary_set_names`` order) and
    routes through :meth:`FEMMesh.from_tensors` — bypassing the gmsh
    file I/O the CLI driver uses.
    """
    from phast.mesh import FEMMesh

    mesh_data = gen_out.mesh
    nodes_np = np.asarray(mesh_data["nodes"], dtype=np.float64)
    elements_np = np.asarray(mesh_data["elements"], dtype=np.int64)
    boundary_tags = np.asarray(mesh_data["boundary_tags"], dtype=np.int64)
    boundary_set_names = list(mesh_data["boundary_set_names"])

    node_sets: dict = {}
    for bit, name in enumerate(boundary_set_names):
        idx = np.where(boundary_tags & (1 << bit))[0].astype(np.int64)
        node_sets[name] = torch.from_numpy(idx)

    nodes_t = torch.from_numpy(nodes_np)
    elems_t = torch.from_numpy(elements_np)

    mesh = FEMMesh.from_tensors(
        nodes=nodes_t, elements=elems_t,
        node_sets=node_sets, device=device, dtype=dtype,
    )
    return mesh


# Tolerance for treating a per-element material array as homogeneous.
# rtol=1e-12 lets numerical noise from generators (e.g., float64 round-off
# in ``np.full(n_elems, value)``) collapse cleanly to the scalar path
# while real heterogeneity (≥0.05 contrast in any 8-class generator)
# always trips the path that installs per-element fields.
_HETERO_RTOL = 1e-12


def _is_homogeneous(arr: np.ndarray, *, rtol: float = _HETERO_RTOL) -> bool:
    """Return ``True`` if all elements of ``arr`` agree to within ``rtol``.

    Implementation note: ``np.allclose`` with ``rtol`` matches the
    relative-tolerance contract in the issue spec; we fall back to
    ``atol=0`` so a literally-uniform field always returns True even
    when the mean is exactly zero (avoids a divide-by-zero in the
    relative comparison).
    """
    a = np.asarray(arr).ravel()
    if a.size <= 1:
        return True
    ref = float(a[0])
    return bool(np.allclose(a, ref, rtol=rtol, atol=0.0))


def _detect_heterogeneity(gen_out: GeneratorOutput) -> dict:
    """Per-field heterogeneity flags ``{'E': bool, 'Gc': bool, 'nu': bool, 'rho': bool}``.

    Centralises the rtol comparison so both ``_build_material_from_generator``
    (for the energy-split / gamma_correction overrides) and
    ``_install_heterogeneous_fields`` (for the actual ``install_diff_*``
    calls) see one consistent answer.
    """
    m = gen_out.material
    return {
        "E":   not _is_homogeneous(m.get("E",   np.array([0.0]))),
        "Gc":  not _is_homogeneous(m.get("Gc",  np.array([0.0]))),
        "nu":  not _is_homogeneous(m.get("nu",  np.array([0.0]))),
        "rho": not _is_homogeneous(m.get("rho", np.array([0.0]))),
    }


def _build_material_from_generator(gen_out: GeneratorOutput):
    """Build a scalar :class:`Material`, auto-switching the energy-split
    and gamma-correction flags so heterogeneous E / Gc fields actually
    propagate when ``install_diff_E_field`` / ``Gc_field`` are wired in
    by ``_install_heterogeneous_fields`` after solver construction.

    Why we auto-switch the flags
    ----------------------------
    The 8 heterogeneity-class generators (PR #321) emit per-element
    arrays for ``E``, ``Gc``, ``nu``, ``rho`` but do *not* set
    ``energy_split`` / ``pf_model`` / ``gamma_correction`` in
    ``bcs['_params']`` — those are solver-side concerns. The runner is
    the layer that turns the generator's physics intent (a non-uniform
    Gc / E field) into a working solver, and two solver flags are
    *required* for the per-element path to engage:

    - ``install_diff_E_field`` supports the differentiable per-element
      stiffness path for the solver splits that route stress and ``psi+``
      through ``_resolve_lame``. The dataset runner still keeps the
      historical ``energy_split → 'amor'`` override for heterogeneous
      generator output until generator-level split validation is made
      explicit.
    - The differentiable ``Gc_field`` adjoint path requires
      ``solver._gamma_correction == True`` because it reuses the
      per-element ``_Gc_l0_e`` / ``_Gc_over_l0_e`` / ``_at1_source_e``
      arrays. The forward-only dataset path can temporarily install a
      prescribed field without gamma correction, including with a
      ``pf_dirichlet`` pre-crack, but we still override
      ``gamma_correction → True`` for heterogeneous Gc so generated data
      follows the same mesh-resolution convention as inverse demos.

    Both overrides are idempotent on truly uniform fields (the
    ``install`` call is skipped, gamma_correction = a per-element
    weighting that collapses to identity when h_e is mesh-uniform).
    The scalar ``E``, ``Gc``, etc. passed to :class:`Material` remain
    the array means — they serve as the bulk fallback if a downstream
    consumer reads ``material.E`` directly, and as the initial seed
    that ``install_diff_*`` then overwrites per-element.

    Limitations
    -----------
    ``nu`` and ``rho`` heterogeneity are *not* installed at the
    per-element level: the solver has no ``install_diff_nu_field`` /
    ``install_diff_rho_field`` hook in v1 (Lamé parameters are derived
    from a scalar ``material.nu`` and the mass matrix from a scalar
    ``material.rho``). For these two fields we fall back to the array
    mean and emit a one-line note via ``_install_heterogeneous_fields``;
    the generator-side per-element data is still round-tripped to the
    zarr by the packager so a v2 follow-up can wire it in without
    touching the dataset schema. Today only the ``layered`` and
    ``random_microstructure`` classes can produce a non-uniform ``nu``
    or ``rho`` field, and even those default to uniform draws so the
    limitation is dormant in practice.
    """
    from phast.material import Material

    cli = gen_out.bcs.get("_params", {})
    energy_split = str(cli.get("energy_split", "spectral"))
    pf_model = str(cli.get("pf_model", "AT2"))
    plane_stress = bool(cli.get("plane_stress", False))
    gamma_correction = bool(cli.get("gamma_correction", False))

    hetero = _detect_heterogeneity(gen_out)
    if hetero["E"] and energy_split != "amor":
        # Keep the legacy dataset-generation default stable; inverse drivers
        # may opt into isotropic/spectral/star-convex ``diff_E_field``
        # directly through their own solver configs.
        energy_split = "amor"
    if hetero["Gc"]:
        # Keep dataset generation aligned with the differentiable spatial-Gc
        # convention, even though forward-only Gc_field solves no longer need
        # gamma correction to coexist with pf_dirichlet pre-cracks.
        gamma_correction = True

    m = gen_out.material
    return Material(
        E=float(np.asarray(m["E"]).mean()),
        nu=float(np.asarray(m["nu"]).mean()),
        Gc=float(np.asarray(m["Gc"]).mean()),
        l0=float(np.asarray(m["l0"]).mean()),
        rho=float(np.asarray(m["rho"]).mean()),
        energy_split=energy_split,
        pf_model=pf_model,
        plane_stress=plane_stress,
        gamma_correction=gamma_correction,
    )


def _install_heterogeneous_fields(solver, gen_out: GeneratorOutput,
                                    *, device: str,
                                    dtype: torch.dtype) -> dict:
    """Wire per-element ``E_field`` / ``Gc_field`` into the solver.

    Mirrors the hook pattern used by the inverse demos (see
    ``inverse_problems/_tbptt.py::make_install_E_field`` /
    ``make_install_Gc_field``):

    - **E**: ``solver.install_diff_E_field(E_t)`` — also rebuilds the
      mechanics solver so the explicit ``dt_cfl`` reflects the new
      max(E). Must run BEFORE the caller reads ``solver.dt`` (otherwise
      the dataset loop runs on the stale homogeneous-mean dt).
    - **Gc**: ``solver.diff_Gc_field = Gc_t`` — picked up by every
      ``step_full`` -> ``step_solve_damage`` invocation through the
      ``getattr(self, 'diff_Gc_field', None)`` lookup at line 508 of
      ``staggered_solver.py``. No CFL impact (Gc affects only the
      damage solve, which is implicit).

    Tensors are detached float64 to match the forward path; we never
    enable ``requires_grad`` here — gradient autograd is the inverse-
    problem use case, not the dataset-generation use case.

    Returns a dict of the per-field installation status, useful for
    the caller's metadata + tests.
    """
    hetero = _detect_heterogeneity(gen_out)
    installed: dict = {"E": False, "Gc": False, "nu_warned": False,
                       "rho_warned": False}

    if hetero["E"]:
        E_np = np.asarray(gen_out.material["E"], dtype=np.float64)
        E_t = torch.from_numpy(E_np).to(device=device, dtype=dtype)
        solver.install_diff_E_field(E_t)
        installed["E"] = True

    if hetero["Gc"]:
        Gc_np = np.asarray(gen_out.material["Gc"], dtype=np.float64)
        Gc_t = torch.from_numpy(Gc_np).to(device=device, dtype=dtype)
        solver.diff_Gc_field = Gc_t
        installed["Gc"] = True

    # nu / rho heterogeneity is not pluggable at the per-element level
    # in v1 (no install hook on the solver). Generators flag it via the
    # heterogeneity check; we record the limitation but proceed with
    # the scalar mean already in ``solver.material``. See module-level
    # CHANGELOG entry + ``_build_material_from_generator`` docstring.
    if hetero["nu"]:
        installed["nu_warned"] = True
    if hetero["rho"]:
        installed["rho_warned"] = True

    return installed


def _build_bcs_from_generator(gen_out: GeneratorOutput, mesh,
                               *, device: str, dtype: torch.dtype):
    """Translate the generator's free-form BC dict into a
    :class:`BoundaryConditions` object.

    Recognised entries
    ------------------
    ``{"type": "fix", "component": 0|1}`` -> ``bcs.fix(...)``.
    ``{"type": "traction", "component": 0|1, "value": v}`` ->
        ``bcs.add_neumann(...)`` with traction vector ``[v, 0]`` or
        ``[0, v]``.
    Any other key (notably ``_params``) is ignored; the packager records
    it via ``cli_args``.

    The pre-crack mask is realised as a ``pf_dirichlet`` BC at
    ``value=1.0``, which the solver re-enforces after every damage
    solve (matches COMSOL convention; see issue #213).
    """
    from phast.boundary_conditions import BoundaryConditions

    bcs = BoundaryConditions(mesh.n_nodes, device=device, dtype=dtype)
    for name, entry_or_entries in gen_out.bcs.items():
        if name.startswith("_"):
            continue
        if name not in mesh.node_sets:
            continue
        entries = (
            entry_or_entries
            if isinstance(entry_or_entries, (list, tuple))
            else [entry_or_entries]
        )
        for entry in entries:
            if not isinstance(entry, Mapping):
                continue
            kind = str(entry.get("type", "")).lower()
            comp = int(entry.get("component", 1))
            if kind == "fix":
                bcs.fix(mesh.node_sets[name], component=comp)
            elif kind in ("traction", "neumann"):
                v = float(entry.get("value", 0.0))
                t_vec = [0.0, 0.0]
                t_vec[comp] = v
                bcs.add_neumann(mesh.node_sets[name], traction=t_vec)
            elif kind == "prescribe":
                v = float(entry.get("value", 0.0))
                bcs.add(mesh.node_sets[name], component=comp, value=v)

    pre_crack_mask = np.asarray(gen_out.mesh["pre_crack_mask"], dtype=np.uint8)
    if pre_crack_mask.any():
        idx = torch.from_numpy(np.where(pre_crack_mask > 0)[0].astype(np.int64))
        bcs.add_pf_dirichlet(idx, value=1.0)

    return bcs


def _pf_dirichlet_node_mask(bcs, n_nodes: int) -> np.ndarray:
    """Return nodes pinned by phase-field Dirichlet BCs as a NumPy mask."""

    mask = np.zeros(n_nodes, dtype=bool)
    for bc in getattr(bcs, "pf_dirichlet_bcs", []) or []:
        idx = bc.node_indices.detach().cpu().numpy().astype(np.int64, copy=False)
        idx = idx[(idx >= 0) & (idx < n_nodes)]
        mask[idx] = True
    return mask


def _estimate_crack_tip_xy(
    nodes: np.ndarray,
    d_nodes: np.ndarray,
    *,
    precrack_mask: np.ndarray | None = None,
    threshold: float = 0.5,
) -> np.ndarray | None:
    """Estimate a crack tip from nodal damage.

    Pre-notched PF-Hetero-Bench samples pin the initial notch at ``d=1``.
    Returning ``NaN`` until new damage appears makes the whole
    ``crack_tip_*`` trace useless on smoke data. For those samples, the
    pinned notch tip is a valid initial crack-tip location; once damage
    appears outside the precrack mask, the farthest damaged non-precrack
    node becomes the tracked tip.
    """

    coords = np.asarray(nodes, dtype=np.float64)
    d = np.asarray(d_nodes, dtype=np.float64).reshape(-1)
    if coords.ndim != 2 or coords.shape[0] != d.shape[0] or coords.shape[1] < 2:
        return None

    if precrack_mask is not None:
        pre = np.asarray(precrack_mask, dtype=bool).reshape(-1)
        if pre.shape[0] == d.shape[0] and pre.any():
            pre_idx = np.where(pre)[0]
            notch_tip = coords[pre_idx][np.argmax(coords[pre_idx, 0]), :2]
            candidates = (d > threshold) & ~pre & (coords[:, 0] >= notch_tip[0])
            if candidates.any():
                pts = coords[candidates, :2]
                distances = np.linalg.norm(pts - notch_tip, axis=1)
                return pts[int(np.argmax(distances))].copy()
            return notch_tip.copy()

    candidates = d > threshold
    if not candidates.any():
        return None
    pts = coords[candidates, :2]
    i_tip = int(np.argmax(pts[:, 0]))
    return pts[i_tip].copy()


# ----------------------------------------------------------------------
# Public class
# ----------------------------------------------------------------------

@dataclass
class DatasetRunner:
    """Forward generator -> solver -> packager pipeline.

    Parameters
    ----------
    generator : SampleGenerator
        Yields :class:`GeneratorOutput` for a given seed.
    packager : SamplePackager
        Already-constructed packager bound to an ``out_dir`` and
        ``cli_args`` dict.
    n_steps : int
        Number of explicit-dynamics timesteps per sample.
    n_keyframes : int, default ``schema.NUM_KEYFRAMES`` (=100)
        Forward-compat hint; the packager + validator hard-pin K=100
        in v1, so any other value is silently coerced.
    dt_safety : float, default 0.8
        CFL safety factor for the explicit timestep.
    device : str, default 'cpu'
        ``'cpu' | 'cuda' | 'mps'`` — passed to ``StaggeredSolver``.
    dtype : torch.dtype, default ``torch.float64``
        Solver-internal precision; storage is float32 (packager casts).
    enable_damage : bool, default True
        ``False`` runs pure elastic — fast geometry-coverage check.
    """

    generator: SampleGenerator
    packager: SamplePackager
    n_steps: int
    n_keyframes: int = NUM_KEYFRAMES
    dt_safety: float = 0.8
    device: str = "cpu"
    dtype: torch.dtype = torch.float64
    enable_damage: bool = True

    # ------------------------------------------------------------------
    def run_one(self, seed: int, *, dry_run: bool = False) -> Optional[Path]:
        """Generate one sample. Returns the written zarr path
        (or ``None`` for a dry run)."""
        # 1) Generator
        gen_out = self.generator.generate(seed)
        if dry_run:
            return None

        # 2) Solver assembly
        from phast.staggered_solver import (
            StaggeredSolver, SolverConfig)

        mesh = _build_mesh_from_generator(
            gen_out, device=self.device, dtype=self.dtype)
        material = _build_material_from_generator(gen_out)
        bcs = _build_bcs_from_generator(
            gen_out, mesh, device=self.device, dtype=self.dtype)

        solver_cfg = SolverConfig(
            solver_type="explicit",
            dt_safety=self.dt_safety,
            num_steps=self.n_steps,
            damage_every=1,
            use_multigrid=False,
            enable_damage=self.enable_damage,
        )

        solver = StaggeredSolver(mesh, material, bcs, config=solver_cfg)

        # Inject per-element material fields BEFORE reading ``solver.dt``
        # — ``install_diff_E_field`` rebuilds the mechanics solver so its
        # internal dt reflects the per-element ``max(E)``. Reading dt
        # before installation would lock the loop to the stale
        # homogeneous-mean CFL bound. Gc-field installation has no CFL
        # impact but is sequenced here for consistency.
        installed = _install_heterogeneous_fields(
            solver, gen_out, device=self.device, dtype=self.dtype)

        # Apply Neumann tractions once (constant-ramp generator BCs)
        f0 = bcs.get_neumann_forces(mesh)
        if f0 is not None:
            solver.f_ext = f0.clone()

        dt = float(solver.dt)
        T_final = dt * max(1, self.n_steps)
        K = NUM_KEYFRAMES  # schema-locked; honour despite the hint

        # 3) Forward loop with keyframe capture
        accumulated = self._run_forward(
            solver, mesh, bcs, dt=dt, n_steps=self.n_steps, K=K)

        # 4) Telemetry CSV (written to a per-sample sub-dir; the
        #    packager copies its rows into the zarr's telemetry/ group).
        sample_dir = self.packager.out_dir / f"_telemetry_{seed:06d}"
        sample_dir.mkdir(parents=True, exist_ok=True)
        telemetry_csv = sample_dir / "solver_telemetry.csv"
        self._write_telemetry_csv(telemetry_csv, accumulated["_telemetry_rows"])

        # 5) Package
        cli = dict(self.packager.cli_args)
        cli.setdefault("sample_seed", int(seed))
        cli.setdefault("loading_mode", "dynamic")
        cli.setdefault("energy_split", material.energy_split)
        cli.setdefault("model", material.pf_model)
        cli.setdefault("plane_strain", not material.plane_stress)
        # The packager records cli_args; refresh the seed in case the
        # caller reuses one packager across many seeds.
        self.packager.cli_args["sample_seed"] = int(seed)

        traj = {k: v for k, v in accumulated.items()
                if not k.startswith("_")}

        path = self.packager.write_sample(
            sample_id=int(seed),
            geometry=gen_out.mesh,
            material=gen_out.material,
            trajectory=traj,
            telemetry_csv=telemetry_csv,
            conditioning={
                "energy_split": material.energy_split,
                "model": material.pf_model,
                "plane_strain": not material.plane_stress,
                "loading_mode": "dynamic",
            },
            store_format="zarr",
            compress="zstd",
            numpy_rng_state=np.random.get_state(),
        )
        return path

    # ------------------------------------------------------------------
    def run_batch(self, seeds: List[int]) -> List[Path]:
        """Sequentially run all seeds, returning the written paths.

        Kept simple (no multiprocessing) because:
        - HPC dispatch already schedules one job per seed range.
        - On a single GPU the solver is the bottleneck; concurrency
          would just thrash CUDA contexts.
        Parallelism is a follow-up at the dispatcher level (#298).
        """
        out: List[Path] = []
        for s in seeds:
            p = self.run_one(int(s))
            if p is not None:
                out.append(p)
        return out

    # ------------------------------------------------------------------
    # Internal: the inner solver loop, mirroring run_config.py:358-450
    # ------------------------------------------------------------------
    def _run_forward(self, solver, mesh, bcs, *, dt: float,
                     n_steps: int, K: int) -> dict:
        """Drive the explicit-dynamics loop; collect keyframes + per-step.

        Returns a dict shaped to feed straight into
        ``SamplePackager.write_sample``.
        """
        N = mesh.n_nodes
        E = mesh.n_elems
        n_sets = max(1, len(mesh.node_sets))
        sorted_set_names = sorted(mesh.node_sets.keys())

        # Pre-allocate keyframe stores (numpy float64; packager casts)
        u_kf = np.zeros((K, N, 2), dtype=np.float64)
        v_kf = np.zeros((K, N, 2), dtype=np.float64)
        d_kf = np.zeros((K, N), dtype=np.float64)
        psi_p_kf = np.zeros((K, E), dtype=np.float64)
        psi_m_kf = np.zeros((K, E), dtype=np.float64)
        keyframe_times = np.linspace(
            0.0, dt * max(1, n_steps), K, dtype=np.float64)

        # Per-step stores
        E_elastic = np.zeros(n_steps, dtype=np.float64)
        E_dissipated = np.zeros(n_steps, dtype=np.float64)
        E_kinetic = np.zeros(n_steps, dtype=np.float64)
        E_external = np.zeros(n_steps, dtype=np.float64)
        f_reaction = np.zeros((n_steps, n_sets, 2), dtype=np.float64)
        crack_tip_xy = np.full((n_steps, 2), np.nan, dtype=np.float64)
        crack_tip_speed = np.full(n_steps, np.nan, dtype=np.float64)
        step_times = np.linspace(0.0, dt * max(1, n_steps - 1),
                                  max(1, n_steps), dtype=np.float64)
        nodes_np = mesh.nodes.detach().cpu().numpy()
        precrack_mask = _pf_dirichlet_node_mask(bcs, N)
        prev_tip = _estimate_crack_tip_xy(
            nodes_np,
            solver.d.detach().cpu().numpy(),
            precrack_mask=precrack_mask,
        )

        telemetry_rows: List[tuple] = []

        # Keyframe schedule: K uniform indices across [0, n_steps]
        # incl. step 0 (pre-loop) and step n_steps-1 (final).
        keyframe_steps = self._keyframe_indices(n_steps, K)
        # Map step -> keyframe-slot for O(1) lookup inside the loop.
        step_to_slot = {int(s): k for k, s in enumerate(keyframe_steps)}

        # Capture k=0 BEFORE any solver step (matches schema:
        # keyframe_times[0] == 0).
        self._snapshot_keyframe(
            solver, slot=0,
            u_kf=u_kf, v_kf=v_kf, d_kf=d_kf,
            psi_p_kf=psi_p_kf, psi_m_kf=psi_m_kf,
        )

        cum_W_ext = 0.0
        u_prev = solver.u.detach().clone()

        for step in range(n_steps):
            psi = solver.step_full()
            # --- per-step quantities ---------------------------------
            energies = solver.fem.compute_energy_components(
                solver.u, solver.d,
                getattr(solver, 'v', None), psi_plus=psi)
            E_elastic[step] = float(energies['elastic'])
            E_dissipated[step] = float(energies['fracture'])
            E_kinetic[step] = float(energies['kinetic'])

            # External work increment: f_ext . delta_u (numerical).
            # Documented in module docstring: cumulative numerical
            # estimate, sufficient for energy-balance plots.
            with torch.no_grad():
                du = solver.u - u_prev
                dW = float((solver.f_ext * du).sum().item())
            cum_W_ext += dW
            E_external[step] = cum_W_ext
            u_prev = solver.u.detach().clone()

            # Reaction force per (named-set, component)
            for s_idx, sname in enumerate(sorted_set_names):
                idx = mesh.node_sets[sname]
                for comp in (0, 1):
                    R = solver.fem.compute_reaction_force(
                        solver.u, solver.d, idx, component=comp)
                    f_reaction[step, s_idx, comp] = float(R)

            tip = _estimate_crack_tip_xy(
                nodes_np,
                solver.d.detach().cpu().numpy(),
                precrack_mask=precrack_mask,
            )
            if tip is not None:
                crack_tip_xy[step] = tip
                if prev_tip is None:
                    crack_tip_speed[step] = 0.0
                else:
                    crack_tip_speed[step] = float(np.linalg.norm(tip - prev_tip) / dt)
                prev_tip = tip

            # --- telemetry -------------------------------------------
            telemetry_rows.append((
                step,
                float(step * dt),
                int(getattr(solver, '_last_stagger_iter', 0)),
                int(getattr(solver.mechanics, 'last_iter', 0)),
                int(getattr(solver.damage_solver, 'last_iter', 0)),
                float(getattr(solver, '_last_residual', float('nan'))),
                float(getattr(solver, '_last_relative_residual', float('nan'))),
                float(getattr(solver, '_last_mechanics_residual', float('nan'))),
                float(getattr(solver, '_last_mechanics_relative_residual',
                              float('nan'))),
                float(getattr(solver, '_last_dt_used', dt) or dt),
            ))

            # --- keyframe snapshot (after step) ---------------------
            slot = step_to_slot.get(step + 1)
            if slot is not None and slot < K:
                self._snapshot_keyframe(
                    solver, slot=slot,
                    u_kf=u_kf, v_kf=v_kf, d_kf=d_kf,
                    psi_p_kf=psi_p_kf, psi_m_kf=psi_m_kf,
                )

        return {
            "keyframe_times": keyframe_times,
            "u": u_kf,
            "v": v_kf,
            "d": d_kf,
            "psi_plus": psi_p_kf,
            "psi_minus": psi_m_kf,
            "step_times": step_times,
            "E_elastic": E_elastic,
            "E_dissipated": E_dissipated,
            "E_kinetic": E_kinetic,
            "E_external": E_external,
            "f_reaction": f_reaction,
            "crack_tip_xy": crack_tip_xy,
            "crack_tip_speed": crack_tip_speed,
            "_telemetry_rows": telemetry_rows,
        }

    # ------------------------------------------------------------------
    @staticmethod
    def _keyframe_indices(n_steps: int, K: int) -> np.ndarray:
        """K uniform indices in [0, n_steps]. Slot 0 is pre-loop (step
        before any solver advance); the last slot is at step n_steps."""
        if n_steps <= 0:
            return np.zeros(K, dtype=np.int64)
        return np.linspace(0, n_steps, K, dtype=np.int64)

    # ------------------------------------------------------------------
    @staticmethod
    def _snapshot_keyframe(solver, *, slot: int,
                            u_kf, v_kf, d_kf, psi_p_kf, psi_m_kf):
        """Copy current solver state into the slot-th keyframe row."""
        with torch.no_grad():
            u_kf[slot] = solver.u.detach().cpu().numpy()
            v = getattr(solver, 'v', None)
            if v is not None:
                v_kf[slot] = v.detach().cpu().numpy()
            d_kf[slot] = solver.d.detach().cpu().numpy()
            strain = solver.fem.compute_strain(solver.u)
            psi_plus = solver.fem.compute_psi_plus(solver.u, strain=strain)
            # psi_minus = full elastic - psi+ (matches packager docstring)
            psi_full = solver.fem._psi_plus_isotropic(strain)
            psi_p_kf[slot] = psi_plus.detach().cpu().numpy()
            psi_m_kf[slot] = (psi_full - psi_plus).detach().cpu().numpy()

    # ------------------------------------------------------------------
    @staticmethod
    def _write_telemetry_csv(path: Path, rows: List[tuple]) -> None:
        """Mirror the schema written by ``run_config.py``."""
        with open(path, "w") as fh:
            fh.write("step,time,newton_iters,pcg_iters_mech,"
                     "pcg_iters_pf,residual,relative_residual,"
                     "mechanics_residual,mechanics_relative_residual,dt\n")
            for r in rows:
                fh.write(f"{r[0]},{r[1]:.9e},{r[2]},{r[3]},{r[4]},"
                         f"{r[5]:.9e},{r[6]:.9e},{r[7]:.9e},"
                         f"{r[8]:.9e},{r[9]:.9e}\n")


__all__ = [
    "DatasetRunner",
    "_resolve_solver_sha",
    "_detect_heterogeneity",
    "_install_heterogeneous_fields",
    "_is_homogeneous",
]
