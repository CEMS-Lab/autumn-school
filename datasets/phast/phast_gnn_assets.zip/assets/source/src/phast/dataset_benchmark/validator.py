"""Schema validator for PF-Hetero-Bench samples (issue #298).

Reads a packaged ``.zarr`` sample and reports any field
that is missing, has the wrong shape/dtype, or fails a basic
sanity bound.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, List, Optional

import numpy as np

from .schema import (
    SCHEMA_VERSION, NUM_KEYFRAMES, GEOMETRY_FIELDS, MATERIAL_FIELDS,
    KEYFRAME_FIELDS, PER_STEP_FIELDS, TELEMETRY_FIELDS,
    CONDITIONING_LABELS, METADATA_KEYS,
)


@dataclass
class ValidationReport:
    """Outcome of one ``validate_sample`` call."""
    path: str
    schema_version: str = ""
    missing_fields: List[str] = field(default_factory=list)
    shape_errors: List[str] = field(default_factory=list)
    dtype_errors: List[str] = field(default_factory=list)
    value_errors: List[str] = field(default_factory=list)
    missing_attributes: List[str] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return not (self.missing_fields or self.shape_errors
                    or self.dtype_errors or self.value_errors
                    or self.missing_attributes)

    def summary(self) -> str:
        lines = [f"Sample: {self.path}",
                 f"  schema: {self.schema_version}",
                 f"  is_valid: {self.is_valid}"]
        for label, items in (("missing_fields", self.missing_fields),
                              ("shape_errors", self.shape_errors),
                              ("dtype_errors", self.dtype_errors),
                              ("value_errors", self.value_errors),
                              ("missing_attributes",
                               self.missing_attributes)):
            if items:
                lines.append(f"  {label}:")
                for it in items:
                    lines.append(f"    - {it}")
        return "\n".join(lines)


def _open_sample(path: Path):
    """Open a sample directory (.zarr) as a dict-like."""
    suffix = path.suffix
    if suffix == ".zarr" or path.is_dir():
        import zarr
        return zarr.open(str(path), mode="r"), "zarr"
    raise ValueError(f"Unrecognised sample format: {path}")


def _array_attr(group, name: str):
    """Fetch a sub-array. Returns None if missing."""
    try:
        return group[name]
    except (KeyError, IndexError):
        return None


def _check_dtype(actual_dtype, expected_dtype: str) -> bool:
    """Compare without distinguishing endianness."""
    a = np.dtype(actual_dtype).str.lstrip("<").lstrip(">").lstrip("=")
    e = np.dtype(expected_dtype).str.lstrip("<").lstrip(">").lstrip("=")
    return a == e


def _check_shape(actual_shape, expected_axes, dim_resolver) -> Optional[str]:
    """Resolve symbolic axes (N, E, K, S, ...) and compare."""
    if len(actual_shape) != len(expected_axes):
        return (f"rank mismatch: got {len(actual_shape)}D, "
                f"expected {len(expected_axes)}D ({expected_axes})")
    for ax, expected in zip(actual_shape, expected_axes):
        if expected.isdigit():
            if ax != int(expected):
                return f"axis {expected} expected {expected}, got {ax}"
            continue
        resolved = dim_resolver.get(expected)
        if resolved is None:
            # First sighting; remember it.
            dim_resolver[expected] = ax
            continue
        if ax != resolved:
            return (f"axis {expected} inconsistent: previously {resolved}, "
                    f"now {ax}")
    return None


def validate_sample(path) -> ValidationReport:
    """Validate one packaged PF-Hetero-Bench sample.

    Parameters
    ----------
    path : str | Path
        Path to a ``sample_*.zarr`` directory.

    Returns
    -------
    ValidationReport
        ``is_valid`` is True iff zero issues.
    """
    path = Path(path)
    report = ValidationReport(path=str(path))

    if not path.exists():
        report.missing_fields.append("(sample path does not exist)")
        return report

    root, _fmt = _open_sample(path)

    # Schema-version attribute
    attrs = dict(root.attrs.asdict() if hasattr(root.attrs, "asdict")
                 else root.attrs)
    report.schema_version = str(attrs.get("schema_version", ""))
    if report.schema_version != SCHEMA_VERSION:
        report.value_errors.append(
            f"schema_version='{report.schema_version}' "
            f"(expected '{SCHEMA_VERSION}')")

    # Required-attribute presence
    for k in METADATA_KEYS:
        if k not in attrs:
            report.missing_attributes.append(k)
    for k in CONDITIONING_LABELS:
        if k not in attrs:
            report.missing_attributes.append(k)

    # Required-field presence + shape/dtype
    dim_resolver: dict = {}

    def _check_group(specs, group):
        for spec in specs:
            arr = _array_attr(group, spec.name)
            if arr is None:
                if spec.optional:
                    continue
                report.missing_fields.append(spec.name)
                continue
            shape_err = _check_shape(tuple(arr.shape), spec.axes,
                                      dim_resolver)
            if shape_err:
                report.shape_errors.append(f"{spec.name}: {shape_err}")
            if not _check_dtype(arr.dtype, spec.dtype):
                report.dtype_errors.append(
                    f"{spec.name}: dtype {arr.dtype} != expected {spec.dtype}")

    _check_group(GEOMETRY_FIELDS, root)
    _check_group(MATERIAL_FIELDS, root)
    _check_group(KEYFRAME_FIELDS, root)
    _check_group(PER_STEP_FIELDS, root)

    # Telemetry lives in a sub-group; its FieldSpec ``name`` carries
    # the prefix ``telemetry/``.
    for spec in TELEMETRY_FIELDS:
        prefix, leaf = spec.name.split("/", 1)
        tgrp = _array_attr(root, prefix)
        if tgrp is None:
            report.missing_fields.append(spec.name)
            continue
        arr = _array_attr(tgrp, leaf)
        if arr is None:
            report.missing_fields.append(spec.name)
            continue
        shape_err = _check_shape(tuple(arr.shape), spec.axes,
                                  dim_resolver)
        if shape_err:
            report.shape_errors.append(f"{spec.name}: {shape_err}")
        if not _check_dtype(arr.dtype, spec.dtype):
            report.dtype_errors.append(
                f"{spec.name}: dtype {arr.dtype} != expected {spec.dtype}")

    # Sanity checks --------------------------------------------------
    if "K" in dim_resolver and dim_resolver["K"] != NUM_KEYFRAMES:
        report.value_errors.append(
            f"keyframe count {dim_resolver['K']} != "
            f"NUM_KEYFRAMES={NUM_KEYFRAMES}")

    kt = _array_attr(root, "keyframe_times")
    if kt is not None:
        kt_arr = np.asarray(kt[:])
        if kt_arr.size > 1:
            if kt_arr[0] != 0.0:
                report.value_errors.append(
                    f"keyframe_times[0]={kt_arr[0]} (expected 0.0)")
            # Check uniform spacing within float32 tolerance
            spacing = np.diff(kt_arr)
            if spacing.size > 0:
                rel_jitter = (spacing.max() - spacing.min()) / max(
                    spacing.mean(), 1e-30)
                if rel_jitter > 1e-3:
                    report.value_errors.append(
                        f"keyframe_times not uniformly spaced "
                        f"(rel jitter {rel_jitter:.2e})")

    return report


__all__ = ["ValidationReport", "validate_sample"]
