"""Generator registry for PF-Hetero-Bench (issue #298).

Eleven heterogeneity classes are registered.  PR #318 shipped the
simplest (``homogeneous``) and the dataset-skeleton, the eight #321
classes followed, PR #325 (Hansen-Doerr 2020 diffuse model) added
``interface_fracture``, and the v2 follow-up to #298 added
``geometric_voids`` (gmsh-based hole carving — true free-surface
voids vs the v1 ``voids`` proxy of degraded-Gc patches).

Adding a new generator is a three-step operation:

1. Subclass ``SampleGenerator`` in a new file (see ``homogeneous.py``).
2. Register it in ``REGISTRY`` below.
3. Add a smoke-tier sample to ``tests/test_dataset_generators.py``.

See ``dataset_benchmark/README.md`` for full instructions.
"""
from __future__ import annotations

from ._base import SampleGenerator
from .geometric_voids import GeometricVoidsGenerator
from .homogeneous import HomogeneousGenerator
from .interface_fracture import InterfaceFractureGenerator
from .layered import LayeredGenerator
from .pre_cracked import PreCrackedGenerator
from .random_microstructure import RandomMicrostructureGenerator
from .spatial_e import SpatialEGenerator
from .spatial_gc import SpatialGcGenerator
from .stiff_inclusions import StiffInclusionsGenerator
from .voids import VoidsGenerator
from .voronoi_polycrystalline import VoronoiPolycrystallineGenerator

REGISTRY: dict[str, type[SampleGenerator]] = {
    "homogeneous":             HomogeneousGenerator,
    "spatial_gc":              SpatialGcGenerator,
    "spatial_e":               SpatialEGenerator,
    "stiff_inclusions":        StiffInclusionsGenerator,
    "voids":                   VoidsGenerator,
    "geometric_voids":         GeometricVoidsGenerator,
    "voronoi_polycrystalline": VoronoiPolycrystallineGenerator,
    "layered":                 LayeredGenerator,
    "random_microstructure":   RandomMicrostructureGenerator,
    "pre_cracked":             PreCrackedGenerator,
    "interface_fracture":      InterfaceFractureGenerator,
}

__all__ = [
    "SampleGenerator",
    "HomogeneousGenerator",
    "SpatialGcGenerator",
    "SpatialEGenerator",
    "StiffInclusionsGenerator",
    "VoidsGenerator",
    "GeometricVoidsGenerator",
    "VoronoiPolycrystallineGenerator",
    "LayeredGenerator",
    "RandomMicrostructureGenerator",
    "PreCrackedGenerator",
    "InterfaceFractureGenerator",
    "REGISTRY",
]
