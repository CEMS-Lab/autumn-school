"""Voronoi polycrystalline microstructure with grain-by-grain Gc contrast.

PF-Hetero-Bench class #6 (issue #298).  ``n_grains`` random seed points
partition the plate into Voronoi cells; each cell is assigned a random
fracture toughness drawn from a log-normal distribution centred on
``Gc_nominal``.  Per-element Gc is set to the toughness of the
*nearest seed*.

Toughness contrast distribution
-------------------------------
``Gc_k = Gc_nominal * exp(σ_log * Z_k)`` with ``Z_k ~ N(0, 1)``.  At
``σ_log = 0.4`` (default) the 1-σ contrast is exp(±0.4) ≈ 0.67 –
1.49, i.e. the toughest grains are roughly 2× as tough as the weakest.
This matches the polycrystal contrast typical of metallic alloys
(Schwartz et al., Mater. Sci. Eng. A, 2022).

Cost
----
Nearest-seed assignment is O(n_elem · n_grains) via vectorised numpy
argmin (no kd-tree); fine for ``n_grains ≤ 30`` and ``n_elem ≤ 100 k``
(≤ 3 M FLOPs, < 50 ms).  At larger ``n_grains`` use scipy.spatial.cKDTree.
"""
from __future__ import annotations

import numpy as np

from ._base import GeneratorOutput, SampleGenerator
from .homogeneous import _structured_tri_mesh


class VoronoiPolycrystallineGenerator(SampleGenerator):
    """Random plate with Voronoi grain boundaries and grain-by-grain Gc."""

    CLASS_NAME = "voronoi_polycrystalline"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_nominal_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        # Grain-count drawn from a small set so n_elem * n_grains stays
        # bounded for the production tier.
        "n_grains_choices": (5, 10, 20, 30),
        "sigma_log_Gc": 0.4,    # 1-sigma contrast factor
        "nx_per_l0": 2,
        "ny_per_l0": 2,
        "max_nodes": 8_000,
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E = float(rng.uniform(*p["E_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc_nominal = float(rng.uniform(*p["Gc_nominal_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        choices = list(p["n_grains_choices"])
        n_grains = int(choices[rng.integers(0, len(choices))])
        sigma_log = float(p["sigma_log_Gc"])

        h_target = l0 / float(p["nx_per_l0"])
        nx = max(2, int(round(W / h_target)))
        ny = max(2, int(round(H / h_target)))
        if (nx + 1) * (ny + 1) > p["max_nodes"]:
            scale = ((nx + 1) * (ny + 1) / p["max_nodes"]) ** 0.5
            nx = max(2, int(round(nx / scale)))
            ny = max(2, int(round(ny / scale)))
        nodes, elements = _structured_tri_mesh(W, H, nx, ny)
        n_elems = elements.shape[0]
        centroids = nodes[elements].mean(axis=1)

        # Grain seed positions: uniform in the plate.  Order = rng order.
        grain_x = rng.uniform(0.0, W, size=n_grains)
        grain_y = rng.uniform(0.0, H, size=n_grains)
        # Per-grain toughness from log-normal.
        Z = rng.standard_normal(n_grains)
        Gc_per_grain = Gc_nominal * np.exp(sigma_log * Z)

        # Nearest-seed assignment via vectorised pairwise distances.
        # (n_elems, n_grains) — fine for n_grains <= 30, n_elems <= 100 k.
        dx = centroids[:, 0:1] - grain_x[None, :]
        dy = centroids[:, 1:2] - grain_y[None, :]
        d2 = dx * dx + dy * dy
        nearest = np.argmin(d2, axis=1)              # (n_elems,)
        Gc_field = Gc_per_grain[nearest]
        material_tag = nearest.astype(np.int64)

        x = nodes[:, 0]; y = nodes[:, 1]
        eps = 1e-6 * max(W, H)
        sets = {
            "left":   np.where(x < eps)[0],
            "right":  np.where(x > W - eps)[0],
            "bottom": np.where(y < eps)[0],
            "top":    np.where(y > H - eps)[0],
        }
        boundary_set_names = sorted(sets.keys())
        boundary_tags = np.zeros(nodes.shape[0], dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        slit_y = 0.5 * H
        crack_band = max(0.5 * l0, 0.51 * H / ny)  # see spatial_gc.py
        pre_crack_mask = (
            (np.abs(y - slit_y) < crack_band)
            & (x >= 0.0) & (x <= a)
        ).astype(np.uint8)

        material = {
            "E":   np.full(n_elems, E,   dtype=np.float64),
            "nu":  np.full(n_elems, nu,  dtype=np.float64),
            "Gc":  Gc_field.astype(np.float64),
            "l0":  np.full(n_elems, l0,  dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        bcs = {
            "left":   {"type": "fix", "component": 0},
            "top":    {"type": "traction", "component": 1, "value":  1.0},
            "bottom": {"type": "traction", "component": 1, "value": -1.0},
            "_params": {
                "W": W, "H": H, "a": a,
                "E": E, "nu": nu, "Gc_nominal": Gc_nominal,
                "l0": l0, "rho": rho,
                "nx": nx, "ny": ny,
                "n_grains": n_grains, "sigma_log_Gc": sigma_log,
            },
            "_class_meta": {
                "grain_x": grain_x, "grain_y": grain_y,
                "Gc_per_grain": Gc_per_grain,
            },
        }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
        }
        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


__all__ = ["VoronoiPolycrystallineGenerator"]
