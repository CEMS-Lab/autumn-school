"""Layered composites — alternating horizontal layers with E or Gc contrast.

PF-Hetero-Bench class #7 (issue #298).  The plate is partitioned into
``n_layers ∈ [3, 7]`` horizontal bands of equal thickness; each layer is
assigned an alternating high/low value for *one* of {E, Gc} (chosen
50/50 per sample).  Layer thicknesses are uniform; layer values are
drawn so the contrast ratio per sample is uniform in U(2, 5).

Despite the name, only horizontal layers are produced in v1 — vertical
layering is achievable by rotating the loading direction (post-process).
The follow-up could add a 50/50 horizontal/vertical orientation flag.
"""
from __future__ import annotations

import numpy as np

from ._base import GeneratorOutput, SampleGenerator
from .homogeneous import _structured_tri_mesh


class LayeredGenerator(SampleGenerator):
    """Random plate with alternating horizontal E or Gc layers."""

    CLASS_NAME = "layered"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        "n_layers_range": (3, 7),       # inclusive on both ends
        "contrast_range": (2.0, 5.0),   # high/low ratio per layer pair
        "nx_per_l0": 2,
        "ny_per_l0": 2,
        "max_nodes": 8_000,
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E_nominal = float(rng.uniform(*p["E_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc_nominal = float(rng.uniform(*p["Gc_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        n_lo, n_hi = p["n_layers_range"]
        n_layers = int(rng.integers(int(n_lo), int(n_hi) + 1))
        contrast = float(rng.uniform(*p["contrast_range"]))
        # 50/50 select whether E or Gc carries the contrast
        which = "E" if rng.integers(0, 2) == 0 else "Gc"

        h_target = l0 / float(p["nx_per_l0"])
        nx = max(2, int(round(W / h_target)))
        ny = max(2, int(round(H / h_target)))
        if (nx + 1) * (ny + 1) > p["max_nodes"]:
            scale = ((nx + 1) * (ny + 1) / p["max_nodes"]) ** 0.5
            nx = max(2, int(round(nx / scale)))
            ny = max(2, int(round(ny / scale)))
        nodes, elements = _structured_tri_mesh(W, H, nx, ny)
        n_elems = elements.shape[0]
        centroids = nodes[elements].mean(axis=1)

        # Layer index from y position: 0 at bottom, n_layers-1 at top.
        layer_h = H / n_layers
        layer_idx = np.clip((centroids[:, 1] / layer_h).astype(np.int64),
                            0, n_layers - 1)

        # Even layers get the LOW value, odd get HIGH; HIGH/LOW = contrast,
        # so geometric mean of HIGH and LOW is the nominal.
        high_mult = float(np.sqrt(contrast))   # so high*low = nominal^2
        low_mult = 1.0 / high_mult
        per_layer_mult = np.where(np.arange(n_layers) % 2 == 0,
                                   low_mult, high_mult)
        elem_mult = per_layer_mult[layer_idx]

        if which == "E":
            E_field = E_nominal * elem_mult
            Gc_field = np.full(n_elems, Gc_nominal, dtype=np.float64)
        else:
            E_field = np.full(n_elems, E_nominal, dtype=np.float64)
            Gc_field = Gc_nominal * elem_mult

        material_tag = layer_idx

        x = nodes[:, 0]; y = nodes[:, 1]
        eps = 1e-6 * max(W, H)
        sets = {
            "left":   np.where(x < eps)[0],
            "right":  np.where(x > W - eps)[0],
            "bottom": np.where(y < eps)[0],
            "top":    np.where(y > H - eps)[0],
        }
        boundary_set_names = sorted(sets.keys())
        boundary_tags = np.zeros(nodes.shape[0], dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        slit_y = 0.5 * H
        crack_band = max(0.5 * l0, 0.51 * H / ny)  # see spatial_gc.py
        pre_crack_mask = (
            (np.abs(y - slit_y) < crack_band)
            & (x >= 0.0) & (x <= a)
        ).astype(np.uint8)

        material = {
            "E":   E_field.astype(np.float64),
            "nu":  np.full(n_elems, nu, dtype=np.float64),
            "Gc":  Gc_field.astype(np.float64),
            "l0":  np.full(n_elems, l0, dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        bcs = {
            "left":   {"type": "fix", "component": 0},
            "top":    {"type": "traction", "component": 1, "value":  1.0},
            "bottom": {"type": "traction", "component": 1, "value": -1.0},
            "_params": {
                "W": W, "H": H, "a": a,
                "E_nominal": E_nominal, "nu": nu,
                "Gc_nominal": Gc_nominal, "l0": l0, "rho": rho,
                "nx": nx, "ny": ny,
                "n_layers": n_layers,
                "contrast": contrast,
                "contrast_field": which,    # "E" or "Gc"
            },
        }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
        }
        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


__all__ = ["LayeredGenerator"]
