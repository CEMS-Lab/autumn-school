"""Spatial random E(x) field — sum of K=5 Gaussian bumps.

PF-Hetero-Bench class #3 (issue #298).  The Young's modulus varies in
space according to

    E(x) = E_nominal * (1 + Σ_k A_k * exp(-||x - x_k||² / (2 σ_k²)))

with K = 5 random Gaussian bumps; everything else is identical to the
spatial-Gc generator (same K-bump approximation, same justification for
not using a true GP — see ``spatial_gc.py``).

Stiffness contrast is bounded the same way as Gc: amplitudes are signed
in U(-0.4, +0.4) and the per-element multiplier is floored at 0.05 to
keep E strictly positive.
"""
from __future__ import annotations

import numpy as np

from ._base import GeneratorOutput, SampleGenerator
from .homogeneous import _structured_tri_mesh


class SpatialEGenerator(SampleGenerator):
    """Random plate with an E(x) field built from K Gaussian bumps."""

    CLASS_NAME = "spatial_e"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_nominal_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        "K_bumps": 5,
        "sigma_frac_range": (0.05, 0.20),
        "amplitude_range": (-0.4, 0.4),
        "nx_per_l0": 2,
        "ny_per_l0": 2,
        "max_nodes": 8_000,
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E_nominal = float(rng.uniform(*p["E_nominal_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc = float(rng.uniform(*p["Gc_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        h_target = l0 / float(p["nx_per_l0"])
        nx = max(2, int(round(W / h_target)))
        ny = max(2, int(round(H / h_target)))
        if (nx + 1) * (ny + 1) > p["max_nodes"]:
            scale = ((nx + 1) * (ny + 1) / p["max_nodes"]) ** 0.5
            nx = max(2, int(round(nx / scale)))
            ny = max(2, int(round(ny / scale)))
        nodes, elements = _structured_tri_mesh(W, H, nx, ny)
        n_elems = elements.shape[0]
        centroids = nodes[elements].mean(axis=1)

        K = int(p["K_bumps"])
        sigma_min = float(p["sigma_frac_range"][0]) * min(W, H)
        sigma_max = float(p["sigma_frac_range"][1]) * min(W, H)
        bump_x = rng.uniform(0.0, W, size=K)
        bump_y = rng.uniform(0.0, H, size=K)
        bump_s = rng.uniform(sigma_min, sigma_max, size=K)
        bump_A = rng.uniform(*p["amplitude_range"], size=K)

        mult = np.zeros(n_elems, dtype=np.float64)
        for k in range(K):
            dx = centroids[:, 0] - bump_x[k]
            dy = centroids[:, 1] - bump_y[k]
            mult += bump_A[k] * np.exp(
                -(dx * dx + dy * dy) / (2.0 * bump_s[k] ** 2))
        E_field = E_nominal * np.maximum(1.0 + mult, 0.05)

        x = nodes[:, 0]; y = nodes[:, 1]
        eps = 1e-6 * max(W, H)
        sets = {
            "left":   np.where(x < eps)[0],
            "right":  np.where(x > W - eps)[0],
            "bottom": np.where(y < eps)[0],
            "top":    np.where(y > H - eps)[0],
        }
        boundary_set_names = sorted(sets.keys())
        boundary_tags = np.zeros(nodes.shape[0], dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        slit_y = 0.5 * H
        # Widen crack band when mesh is coarser than l0 -- guard
        # against an empty pre-crack mask after max_nodes capping.
        crack_band = max(0.5 * l0, 0.51 * H / ny)
        pre_crack_mask = (
            (np.abs(y - slit_y) < crack_band)
            & (x >= 0.0) & (x <= a)
        ).astype(np.uint8)

        material = {
            "E":   E_field.astype(np.float64),
            "nu":  np.full(n_elems, nu,  dtype=np.float64),
            "Gc":  np.full(n_elems, Gc,  dtype=np.float64),
            "l0":  np.full(n_elems, l0,  dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }
        material_tag = np.zeros(n_elems, dtype=np.int64)

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        bcs = {
            "left":   {"type": "fix", "component": 0},
            "top":    {"type": "traction", "component": 1, "value":  1.0},
            "bottom": {"type": "traction", "component": 1, "value": -1.0},
            "_params": {
                "W": W, "H": H, "a": a,
                "E_nominal": E_nominal, "nu": nu, "Gc": Gc,
                "l0": l0, "rho": rho,
                "nx": nx, "ny": ny, "K_bumps": K,
            },
            "_class_meta": {
                "bump_x": bump_x, "bump_y": bump_y,
                "bump_sigma": bump_s, "bump_amplitude": bump_A,
            },
        }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
        }
        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


__all__ = ["SpatialEGenerator"]
