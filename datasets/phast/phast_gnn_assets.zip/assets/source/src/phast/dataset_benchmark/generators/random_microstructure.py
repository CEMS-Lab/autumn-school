"""Random 2- or 3-phase microstructure with smoothed phase pattern.

PF-Hetero-Bench class #8 (issue #298).  Per-element phase index is
sampled from a coarse pixel grid and smoothed with a Gaussian filter,
then thresholded into ``n_phases ∈ {2, 3}`` regions.  Each phase is
assigned an ``(E, Gc)`` pair from a small library; per-element fields
take the value of the phase the centroid falls into.

Smoothing strategy
------------------
Drawing per-element phase iid uniformly produces salt-and-pepper noise
with no spatial coherence — physically meaningless and useless to a
DL model that wants to learn structure.  Instead we draw a coarse
``(n_blob_x, n_blob_y)`` random scalar field, bilinearly interpolate to
the element centroids, and threshold.  ``n_blob`` controls the typical
phase patch size relative to the plate.

Phase library
-------------
Per-phase (E_factor, Gc_factor) drawn independently from
U(0.5, 2.0) × U(0.5, 2.0).  Two phases are drawn every sample; if
``n_phases == 3`` the third is also drawn.  Phase 0 = matrix.
"""
from __future__ import annotations

import numpy as np

from ._base import GeneratorOutput, SampleGenerator
from .homogeneous import _structured_tri_mesh


def _bilinear_interp(grid: np.ndarray, xs: np.ndarray, ys: np.ndarray,
                      W: float, H: float) -> np.ndarray:
    """Bilinear interpolation of a (Ny, Nx) ``grid`` at points (xs, ys).

    The grid spans [0, W] × [0, H] with corner cells, so xs ∈ [0, W],
    ys ∈ [0, H]. Returns one float per (xs[i], ys[i]).
    """
    Ny, Nx = grid.shape
    # Map to grid coordinates [0, Nx-1] × [0, Ny-1]
    fx = xs / W * (Nx - 1)
    fy = ys / H * (Ny - 1)
    fx = np.clip(fx, 0.0, Nx - 1 - 1e-9)
    fy = np.clip(fy, 0.0, Ny - 1 - 1e-9)
    ix = fx.astype(np.int64); iy = fy.astype(np.int64)
    dx = fx - ix; dy = fy - iy
    g00 = grid[iy,     ix]
    g10 = grid[iy,     ix + 1]
    g01 = grid[iy + 1, ix]
    g11 = grid[iy + 1, ix + 1]
    return ((1 - dx) * (1 - dy) * g00 +
            dx * (1 - dy) * g10 +
            (1 - dx) * dy * g01 +
            dx * dy * g11)


class RandomMicrostructureGenerator(SampleGenerator):
    """Random plate with a smoothed multi-phase microstructure."""

    CLASS_NAME = "random_microstructure"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_nominal_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_nominal_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        "n_phases_choices": (2, 3),
        "blob_grid_x_range": (4, 12),
        "blob_grid_y_range": (3, 8),
        "phase_E_factor_range": (0.5, 2.0),
        "phase_Gc_factor_range": (0.5, 2.0),
        "nx_per_l0": 2,
        "ny_per_l0": 2,
        "max_nodes": 8_000,
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E_nominal = float(rng.uniform(*p["E_nominal_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc_nominal = float(rng.uniform(*p["Gc_nominal_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        choices = list(p["n_phases_choices"])
        n_phases = int(choices[rng.integers(0, len(choices))])
        n_blob_x = int(rng.integers(*p["blob_grid_x_range"]))
        n_blob_y = int(rng.integers(*p["blob_grid_y_range"]))

        # Per-phase (E, Gc) factors
        E_factors = rng.uniform(*p["phase_E_factor_range"], size=n_phases)
        Gc_factors = rng.uniform(*p["phase_Gc_factor_range"], size=n_phases)

        h_target = l0 / float(p["nx_per_l0"])
        nx = max(2, int(round(W / h_target)))
        ny = max(2, int(round(H / h_target)))
        if (nx + 1) * (ny + 1) > p["max_nodes"]:
            scale = ((nx + 1) * (ny + 1) / p["max_nodes"]) ** 0.5
            nx = max(2, int(round(nx / scale)))
            ny = max(2, int(round(ny / scale)))
        nodes, elements = _structured_tri_mesh(W, H, nx, ny)
        n_elems = elements.shape[0]
        centroids = nodes[elements].mean(axis=1)

        # Coarse blob field, bilinearly upsampled to centroids.  Range
        # of the smooth field is ~ U(0,1).
        blob = rng.uniform(0.0, 1.0, size=(n_blob_y, n_blob_x))
        smooth = _bilinear_interp(blob, centroids[:, 0], centroids[:, 1],
                                    W, H)

        # Threshold into n_phases bins of equal expected mass
        # (quantile-based -> per-sample fixed proportion).
        qs = np.quantile(smooth, np.linspace(0.0, 1.0, n_phases + 1)[1:-1])
        phase_idx = np.zeros(n_elems, dtype=np.int64)
        for q in qs:
            phase_idx += (smooth > q).astype(np.int64)
        # Now phase_idx in {0, ..., n_phases-1}

        E_field = E_nominal * E_factors[phase_idx]
        Gc_field = Gc_nominal * Gc_factors[phase_idx]
        material_tag = phase_idx

        x = nodes[:, 0]; y = nodes[:, 1]
        eps = 1e-6 * max(W, H)
        sets = {
            "left":   np.where(x < eps)[0],
            "right":  np.where(x > W - eps)[0],
            "bottom": np.where(y < eps)[0],
            "top":    np.where(y > H - eps)[0],
        }
        boundary_set_names = sorted(sets.keys())
        boundary_tags = np.zeros(nodes.shape[0], dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        slit_y = 0.5 * H
        crack_band = max(0.5 * l0, 0.51 * H / ny)  # see spatial_gc.py
        pre_crack_mask = (
            (np.abs(y - slit_y) < crack_band)
            & (x >= 0.0) & (x <= a)
        ).astype(np.uint8)

        material = {
            "E":   E_field.astype(np.float64),
            "nu":  np.full(n_elems, nu, dtype=np.float64),
            "Gc":  Gc_field.astype(np.float64),
            "l0":  np.full(n_elems, l0, dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        bcs = {
            "left":   {"type": "fix", "component": 0},
            "top":    {"type": "traction", "component": 1, "value":  1.0},
            "bottom": {"type": "traction", "component": 1, "value": -1.0},
            "_params": {
                "W": W, "H": H, "a": a,
                "E_nominal": E_nominal, "nu": nu,
                "Gc_nominal": Gc_nominal, "l0": l0, "rho": rho,
                "nx": nx, "ny": ny,
                "n_phases": n_phases,
                "n_blob_x": n_blob_x, "n_blob_y": n_blob_y,
            },
            "_class_meta": {
                "phase_E_factor": E_factors,
                "phase_Gc_factor": Gc_factors,
            },
        }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
        }
        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


__all__ = ["RandomMicrostructureGenerator"]
