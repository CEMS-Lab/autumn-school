"""Homogeneous-material rectangular plate with horizontal edge notch.

Simplest of nine PF-Hetero-Bench classes (issue #298).  Single material
across the entire domain — random draws cover plate dimensions, notch
length, and material parameters from a small, well-bounded
distribution.

Mesh
----
Structured triangular mesh built directly with numpy: a regular
``(nx+1) * (ny+1)`` node grid, each rectangular cell split into two
CCW triangles via the ``/`` diagonal.  No gmsh subprocess — keeps
generation byte-deterministic and fast (< 100 ms for the smoke tier).

Pre-crack
---------
A horizontal slit of length ``a`` from the left edge at ``y = H/2``,
realised by setting ``pre_crack_mask[i] = 1`` for every node within
``l0/2`` of the slit segment.  This is the COMSOL B7 / Borden 2012
convention (no physical lip, phase-field Dirichlet).

Distribution defaults (smoke tier)
----------------------------------
- W ~ U(50, 150) mm
- H ~ U(20, 60) mm
- a ~ U(0.4 W, 0.6 W)
- nx, ny chosen to keep h ≈ l0
- E ~ U(20 000, 50 000) MPa
- nu ~ U(0.18, 0.30)
- Gc ~ U(2e-3, 5e-3) N/mm
- l0 ~ U(0.5, 1.5) mm
- rho ~ U(2.0e-9, 3.0e-9) t/mm^3

These are deliberately tight — wide-distribution generators are
later #298 follow-ups (Voronoi polycrystal etc.).
"""
from __future__ import annotations

from typing import Any, Mapping

import numpy as np

from ._base import GeneratorOutput, SampleGenerator


class HomogeneousGenerator(SampleGenerator):
    """Random homogeneous-material rectangular plate with edge notch."""

    CLASS_NAME = "homogeneous"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        "nx_per_l0": 2,        # ~ h = l0 / 2 along x
        "ny_per_l0": 2,
        "max_nodes": 8_000,    # cap for smoke; we shrink nx,ny if exceeded
        "loading_mode": "tension",
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        # ---- random parameter draws ---------------------------------
        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E = float(rng.uniform(*p["E_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc = float(rng.uniform(*p["Gc_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        # ---- mesh ----------------------------------------------------
        # Target h ~ l0 / nx_per_l0.  Cap node count.
        h_target = l0 / float(p["nx_per_l0"])
        nx = max(2, int(round(W / h_target)))
        ny = max(2, int(round(H / h_target)))
        if (nx + 1) * (ny + 1) > p["max_nodes"]:
            scale = ((nx + 1) * (ny + 1) / p["max_nodes"]) ** 0.5
            nx = max(2, int(round(nx / scale)))
            ny = max(2, int(round(ny / scale)))

        nodes, elements = _structured_tri_mesh(W, H, nx, ny)

        # ---- boundary node-sets -------------------------------------
        x = nodes[:, 0]
        y = nodes[:, 1]
        eps = 1e-6 * max(W, H)
        sets = {
            "left":   np.where(x < eps)[0],
            "right":  np.where(x > W - eps)[0],
            "bottom": np.where(y < eps)[0],
            "top":    np.where(y > H - eps)[0],
        }
        boundary_set_names = sorted(sets.keys())
        boundary_tags = np.zeros(nodes.shape[0], dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        # ---- pre-crack mask: horizontal slit at y = H/2, x in [0, a] -
        # Coarse-mesh fix (PR #321 follow-up): when H/ny > l0 (mesh
        # coarser than l0, e.g. after the max_nodes cap shrinks ny)
        # the original 0.5*l0 band misses every node; use 0.51 *
        # mesh-spacing as a safe floor so at least one row of nodes
        # is captured. ny here is the already-scaled mesh-generation
        # ny from above.
        slit_y = 0.5 * H
        crack_band = max(0.5 * l0, 0.51 * H / max(ny, 1))
        pre_crack_mask = (
            (np.abs(y - slit_y) < crack_band)
            & (x >= 0.0) & (x <= a)
        ).astype(np.uint8)

        # ---- material fields (per-element, all uniform here) --------
        n_elems = elements.shape[0]
        material = {
            "E":   np.full(n_elems, E,   dtype=np.float64),
            "nu":  np.full(n_elems, nu,  dtype=np.float64),
            "Gc":  np.full(n_elems, Gc,  dtype=np.float64),
            "l0":  np.full(n_elems, l0,  dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }
        material_tag = np.zeros(n_elems, dtype=np.int64)

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        # ---- BC + pre-crack metadata (consumed by solver follow-up) -
        loading_mode = str(p.get("loading_mode", "tension")).lower()
        if loading_mode == "shear":
            # SENS-like single-edge-notch shear: bottom fixed, top sheared
            # horizontally and fixed vertically, side edges fixed vertically.
            # The dataset runner accepts a list of BC entries per boundary set.
            bcs = {
                "bottom": [
                    {"type": "fix", "component": 0},
                    {"type": "fix", "component": 1},
                ],
                "top": [
                    {"type": "traction", "component": 0, "value": 1.0},
                    {"type": "fix", "component": 1},
                ],
                "left": {"type": "fix", "component": 1},
                "right": {"type": "fix", "component": 1},
            }
        else:
            bcs = {
                "left":   {"type": "fix", "component": 0},
                "top":    {"type": "traction", "component": 1, "value":  1.0},
                "bottom": {"type": "traction", "component": 1, "value": -1.0},
            }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
        }

        # Inject the parameter draws into bcs so the packager records
        # them in cli_args (replayable). Also surface optional physics
        # overrides (energy_split, pf_model, plane_stress, gamma_correction)
        # from distribution_params if present, so the runner's
        # _build_material_from_generator picks them up. Defaults preserve
        # historical behaviour (spectral + AT2).
        params: dict = {
            "W": W, "H": H, "a": a,
            "E": E, "nu": nu, "Gc": Gc, "l0": l0, "rho": rho,
            "nx": nx, "ny": ny,
        }
        for k in ("energy_split", "pf_model", "plane_stress",
                  "gamma_correction", "loading_mode"):
            if k in p:
                params[k] = p[k]
        bcs.update({"_params": params})

        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


# ----------------------------------------------------------------------
# Mesh helper — structured triangular grid in pure numpy.
# ----------------------------------------------------------------------

def _structured_tri_mesh(W: float, H: float, nx: int, ny: int):
    """Regular ``(nx+1) * (ny+1)`` grid, each rectangle split into 2 tri."""
    xs = np.linspace(0.0, W, nx + 1, dtype=np.float64)
    ys = np.linspace(0.0, H, ny + 1, dtype=np.float64)
    X, Y = np.meshgrid(xs, ys, indexing="xy")
    nodes = np.column_stack([X.ravel(), Y.ravel()]).astype(np.float64)

    # Node index at (i, j) is j*(nx+1) + i (row-major, j outer)
    nx1 = nx + 1
    elems = []
    for j in range(ny):
        for i in range(nx):
            n00 = j * nx1 + i
            n10 = n00 + 1
            n01 = n00 + nx1
            n11 = n01 + 1
            # Two CCW triangles per cell
            elems.append((n00, n10, n11))
            elems.append((n00, n11, n01))
    elements = np.asarray(elems, dtype=np.int64)
    return nodes, elements


__all__ = ["HomogeneousGenerator"]
