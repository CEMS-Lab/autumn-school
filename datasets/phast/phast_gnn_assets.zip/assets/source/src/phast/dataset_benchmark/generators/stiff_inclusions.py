"""Discrete stiff Gaussian inclusions in a softer matrix.

PF-Hetero-Bench class #4 (issue #298).  The plate contains
``n_inclusions ∈ {1, 3, 5, 10}`` discrete stiff particles, each modelled
as a Gaussian E-field bump (after Ponnusami et al., EFM 268, 2022,
108431; see ``inverse_problems/demos/demo_inverse_stiff_inclusion.py``):

    E(x) = E_bulk * (1 + α * Σ_k exp(-||x - x_k||² / (2 σ_inc²)))

The local Gc field is left at the matrix nominal value (this is a
*stiff inclusion*, not a tougher one); the spec describes the class as
"Gaussian-bump inclusions of softer material" but the canonical
inverse-problem formulation in this repo is *stiffer* particles
deflecting the crack — we follow the existing demo (alpha > 0 ⇒
stiffer bump) and document it.

Inclusion centres are rejection-sampled to lie at least 3·σ_inc from
the plate boundaries, so the bump is fully contained in the domain.
"""
from __future__ import annotations

import numpy as np

from ._base import GeneratorOutput, SampleGenerator
from .homogeneous import _structured_tri_mesh


class StiffInclusionsGenerator(SampleGenerator):
    """Random plate with N discrete stiff Gaussian inclusions."""

    CLASS_NAME = "stiff_inclusions"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_bulk_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        "n_inclusions_choices": (1, 3, 5, 10),
        "alpha_range": (1.0, 4.0),          # 100% to 400% stiffer at peak
        "sigma_frac_range": (0.04, 0.10),   # sigma in fraction of min(W,H)
        "max_reject_attempts": 100,
        "nx_per_l0": 2,
        "ny_per_l0": 2,
        "max_nodes": 8_000,
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E_bulk = float(rng.uniform(*p["E_bulk_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc = float(rng.uniform(*p["Gc_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        # Inclusion-count drawn from the discrete set
        choices = list(p["n_inclusions_choices"])
        n_inc = int(choices[rng.integers(0, len(choices))])
        alpha = float(rng.uniform(*p["alpha_range"]))
        sigma_inc = float(rng.uniform(*p["sigma_frac_range"]) * min(W, H))

        # ---- mesh ----
        h_target = l0 / float(p["nx_per_l0"])
        nx = max(2, int(round(W / h_target)))
        ny = max(2, int(round(H / h_target)))
        if (nx + 1) * (ny + 1) > p["max_nodes"]:
            scale = ((nx + 1) * (ny + 1) / p["max_nodes"]) ** 0.5
            nx = max(2, int(round(nx / scale)))
            ny = max(2, int(round(ny / scale)))
        nodes, elements = _structured_tri_mesh(W, H, nx, ny)
        n_elems = elements.shape[0]
        centroids = nodes[elements].mean(axis=1)

        # Inclusion centres rejection-sampled inside [3σ, W-3σ] × [3σ, H-3σ]
        # so the Gaussian decays to the boundary edge.  Fall back to the
        # uniform box if 3σ exceeds half the domain.
        x_lo = min(3.0 * sigma_inc, 0.45 * W)
        x_hi = max(W - 3.0 * sigma_inc, 0.55 * W)
        y_lo = min(3.0 * sigma_inc, 0.45 * H)
        y_hi = max(H - 3.0 * sigma_inc, 0.55 * H)
        cx = rng.uniform(x_lo, x_hi, size=n_inc)
        cy = rng.uniform(y_lo, y_hi, size=n_inc)

        # Build E-field via summed bumps
        bump_sum = np.zeros(n_elems, dtype=np.float64)
        for k in range(n_inc):
            dx = centroids[:, 0] - cx[k]
            dy = centroids[:, 1] - cy[k]
            bump_sum += np.exp(-(dx * dx + dy * dy) / (2.0 * sigma_inc ** 2))
        E_field = E_bulk * (1.0 + alpha * bump_sum)

        # Material tag: 0 = matrix, 1 = inside any inclusion (mass > 0.5).
        # Tag is integer; useful as a categorical conditioning label.
        material_tag = (bump_sum > 0.5).astype(np.int64)

        # ---- boundary node-sets ----
        x = nodes[:, 0]; y = nodes[:, 1]
        eps = 1e-6 * max(W, H)
        sets = {
            "left":   np.where(x < eps)[0],
            "right":  np.where(x > W - eps)[0],
            "bottom": np.where(y < eps)[0],
            "top":    np.where(y > H - eps)[0],
        }
        boundary_set_names = sorted(sets.keys())
        boundary_tags = np.zeros(nodes.shape[0], dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        slit_y = 0.5 * H
        crack_band = max(0.5 * l0, 0.51 * H / ny)  # see spatial_gc.py
        pre_crack_mask = (
            (np.abs(y - slit_y) < crack_band)
            & (x >= 0.0) & (x <= a)
        ).astype(np.uint8)

        material = {
            "E":   E_field.astype(np.float64),
            "nu":  np.full(n_elems, nu,  dtype=np.float64),
            "Gc":  np.full(n_elems, Gc,  dtype=np.float64),
            "l0":  np.full(n_elems, l0,  dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        bcs = {
            "left":   {"type": "fix", "component": 0},
            "top":    {"type": "traction", "component": 1, "value":  1.0},
            "bottom": {"type": "traction", "component": 1, "value": -1.0},
            "_params": {
                "W": W, "H": H, "a": a,
                "E_bulk": E_bulk, "nu": nu, "Gc": Gc, "l0": l0, "rho": rho,
                "nx": nx, "ny": ny,
                "n_inclusions": n_inc,
                "alpha": alpha, "sigma_inc": sigma_inc,
            },
            "_class_meta": {
                "inclusion_x": cx, "inclusion_y": cy,
            },
        }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
        }
        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


__all__ = ["StiffInclusionsGenerator"]
