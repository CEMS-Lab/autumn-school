"""Abstract base class for PF-Hetero-Bench sample generators.

A generator owns a *parameter distribution* (rectangular plate
dimensions, notch length, material draws, etc.) and returns four
dictionaries the packager + downstream solver consume:

- ``mesh``: ``{nodes, elements, boundary_tags, boundary_set_names,
            material_tag, pre_crack_mask}`` — the geometric layout.
- ``material``: ``{E, nu, Gc, l0, rho}`` — per-element material
            fields (one float64 per element each).
- ``bcs``: free-form BC dict the solver-wiring follow-up will
            consume; the packager stores it verbatim in ``cli_args``.
- ``pre_crack``: free-form pre-crack metadata (start/end xy, mask
            indices) — also stored in ``cli_args``.

Determinism contract
--------------------
A generator subclass must produce **byte-identical** ``mesh`` and
``material`` arrays for the same ``seed``.  Use ``numpy.random.default_rng(seed)``
exclusively (no global ``np.random`` calls); avoid ``set``/``dict``
ordering hazards.  Tests assert this property.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass
from typing import Any, Mapping


@dataclass
class GeneratorOutput:
    """Bundle returned by every ``SampleGenerator.generate`` call."""
    mesh: Mapping[str, Any]
    material: Mapping[str, Any]
    bcs: Mapping[str, Any]
    pre_crack: Mapping[str, Any]


class SampleGenerator(abc.ABC):
    """Abstract sample generator interface.

    Subclasses must:
    - set ``CLASS_NAME`` (used as the ``generator_class`` metadata
      label and the registry key).
    - implement ``generate(seed)`` which is *deterministic and pure*
      with respect to ``seed``.
    """

    CLASS_NAME: str = "abstract"
    VERSION: str = "0.0.0"

    def __init__(self, **distribution_params):
        self.distribution_params = dict(distribution_params)

    @abc.abstractmethod
    def generate(self, seed: int) -> GeneratorOutput:
        """Return a GeneratorOutput for the given seed.

        Implementations must use ``numpy.random.default_rng(seed)``
        internally and return numpy arrays in float64 / int64.  The
        packager casts state-trajectory arrays to float32 at write
        time; geometry stays high-precision.
        """
        raise NotImplementedError


__all__ = ["SampleGenerator", "GeneratorOutput"]
