"""Standardised PFM-Bench validation metrics (issue #250).

A single vocabulary of validation metrics that any phase-field-fracture
solver, dataset sample, or neural surrogate trajectory can report. The
goal is twofold:

1. Cross-comparing solvers (us vs PhaFiDyn vs COMSOL vs Bleyer's code).
2. Downstream evaluation for PF-Hetero-Bench (#298): "does this neural
   surrogate produce trajectories that pass PFM-Bench metrics?"

Distinction from the existing :mod:`metrics` (root) module
==========================================================
``phast/metrics.py`` (root) provides
:class:`PFMBenchMetrics`, a torch-based *prediction-vs-reference*
evaluator (MSE, relative L2, dice). That answers "how close is the
surrogate trajectory to the reference trajectory?".

This module answers a different question: "what physical / morphological
quantities does this single trajectory exhibit, in absolute terms?".
It is pure NumPy / SciPy, never imports torch, and reads from on-disk
artefacts (Zarr/H5 + CSV + JSON) inside a run directory. Each metric returns
a JSON-serialisable :class:`MetricResult` so reports can be archived and
diff'd across runs / solvers.

Metric vocabulary
=================
- ``initiation_time_us``    : first ``t`` (us) where ``max(d) > 0.5``
  outside the preseed zone. Differs from B7's compare.py legacy 0.99
  threshold; 0.5 is the PFM-Bench convention (early-onset).
- ``branching_onset_us``    : first ``t`` (us) where the right-of-pre-
  crack region contains 2+ propagating arms (connected-component
  morphology check, PR #319). Backward-compat field
  ``branching_onset_energy_argmax_us`` records the legacy late-window
  argmax of the elastic-energy curve.
- ``n_arms_final``          : final arm count via the same morphology
  detector.
- ``crack_length_full_y_mm``: total crack length at the first step
  where ``n_arms == 2``; NaN if the crack never branched.
- ``total_dissipated_energy``: time-integrated fracture-energy rate,
  computed as the area under the dissipation-rate curve, with the
  rate taken as the time derivative of the cumulative ``energy_fracture``
  trace from the Zarr/H5 trajectory or energy.csv.
- ``crack_tip_velocity``    : peak and time-integrated mean of
  ``crack_vel_mms`` (from ``crack_tip.csv`` when available, else NaN).
- ``yoffe_breach_fraction`` : fraction of timesteps where the crack-tip
  velocity exceeds ``0.6 * c_R``. ``c_R`` is the Rayleigh-wave speed
  derived from the run's E, nu, rho via Freund's approximation
  ``c_R = c_s * (0.862 + 1.14*nu) / (1 + nu)`` with
  ``c_s = sqrt(mu/rho)``. Reference: Freund, "Dynamic Fracture
  Mechanics" (1990), eq. 2.4.13.
- ``path_tortuosity``       : total_crack_length / euclidean_distance
  from the notch tip to the global ``argmax(d)`` location.
- ``elastic_energy_peak``   : peak of the elastic-energy curve over
  the whole simulation.

Each metric is wrapped in a function with the signature
``metric_name(run_dir: Path, **kwargs) -> MetricResult`` returning a
dict-like ``{value, units, source, status}`` where:

- ``value``  : float | int | None — the numeric result (None if missing).
- ``units``  : str — physical units of the value, "" if dimensionless.
- ``source`` : str — provenance hint ("energy_argmax", "components",
  "trajectory", "crack_tip.csv", ...).
- ``status`` : "ok" | "missing_input" | "error".

The umbrella :func:`compute_pfm_bench_report` calls every metric and
returns a JSON-serialisable dict. It MUST NOT crash when inputs are
absent; missing inputs produce ``status="missing_input"`` and
``value=None``.

Morphology-detector reuse
=========================
The connected-component arm-counting helpers (``_grid_damage``,
``count_arms_in_region``, ``compute_morphology_timeseries``) are
intentionally duplicated from
``examples/dynamic/crack_branching_comsol/compare.py``
(merged in PR #319). They cannot be cleanly imported from a script
under ``examples/``; this module is now their canonical home. The
``compare.py`` copy is preserved unchanged so the existing public
acceptance gate is not modified (per #250 constraint).
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

import numpy as np

# ---------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------

# Initiation: PFM-Bench convention (#250) — first crossing of d>0.5
# outside the preseed zone. Distinct from compare.py's 0.99 (which
# detects saturation, not initiation onset).
INITIATION_THRESHOLD = 0.5

# Yoffe instability empirical threshold (Freund 1990 §6, Yoffe 1951);
# the principal-tension crack-tip Yoffe analysis predicts microbranch
# onset around v/c_R ~ 0.6. Used as a soft branching-likelihood proxy.
YOFFE_THRESHOLD_FRAC = 0.6

# Morphology defaults (mirrored from B7 compare.py / PR #319).
PRECRACK_LENGTH_DEFAULT_MM = 50.0
L0_DEFAULT_MM = 0.5
MORPH_DAMAGE_THRESH = 0.5
MORPH_MIN_ISLAND = 5
MORPH_GRID_PER_L0 = 2


# ---------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------


@dataclass
class MetricResult:
    """JSON-serialisable holder for a single metric value.

    Attributes
    ----------
    value : float | int | None
        Numeric result, ``None`` when status != "ok".
    units : str
        Physical units (e.g. ``"us"``, ``"mm"``, ``"m/s"``); ``""`` for
        dimensionless quantities.
    source : str
        Provenance hint, e.g. ``"energy_argmax"`` vs ``"components"``,
        ``"trajectory"``, ``"crack_tip.csv"``.
    status : str
        ``"ok"``, ``"missing_input"`` or ``"error"``.
    detail : str
        Human-readable note (error message, fallback rationale, ...).
    """
    value: float | int | None
    units: str = ""
    source: str = ""
    status: str = "ok"
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        # Coerce numpy scalars to Python natives for json.dump.
        v = d["value"]
        if v is not None and hasattr(v, "item"):
            d["value"] = v.item()
        return d


# ---------------------------------------------------------------------
# Run-dir I/O helpers
# ---------------------------------------------------------------------


def _read_run_metadata(run_dir: Path) -> dict | None:
    """Load run_metadata.json or return None."""
    p = run_dir / "run_metadata.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except Exception:
        return None


def _read_dt_seconds(run_dir: Path) -> float:
    """Return solver dt in seconds; defaults to 1.0 if metadata missing."""
    meta = _read_run_metadata(run_dir)
    if meta is None:
        return 1.0
    try:
        return float(meta.get("solver", {}).get("dt", 1.0))
    except Exception:
        return 1.0


def _read_material(run_dir: Path) -> dict:
    """Return the material block from run_metadata.json (empty dict on miss)."""
    meta = _read_run_metadata(run_dir)
    if meta is None:
        return {}
    return meta.get("material", {}) or {}


def _read_precrack_length_mm(run_dir: Path) -> float:
    """Try config.yaml -> geometry.parameters.a; fall back to 50 mm."""
    cfg = run_dir / "config.yaml"
    if cfg.exists():
        try:
            import yaml  # type: ignore
            doc = yaml.safe_load(cfg.read_text())
            a = (doc or {}).get("geometry", {}).get("parameters", {}).get("a")
            if a is not None:
                return float(a)
        except Exception:
            pass
    return PRECRACK_LENGTH_DEFAULT_MM


def _read_l0_mm(run_dir: Path) -> float:
    """Try run_metadata.json material.l0 -> config.yaml -> default 0.5 mm."""
    meta = _read_run_metadata(run_dir)
    if meta is not None:
        v = meta.get("material", {}).get("l0")
        if v is not None:
            try:
                return float(v)
            except (TypeError, ValueError):
                pass
    cfg = run_dir / "config.yaml"
    if cfg.exists():
        try:
            import yaml  # type: ignore
            doc = yaml.safe_load(cfg.read_text())
            v = (doc or {}).get("material", {}).get("overrides", {}).get("l0")
            if v is None:
                v = (doc or {}).get("material", {}).get("l0")
            if v is None:
                v = (doc or {}).get("geometry", {}).get(
                    "parameters", {}).get("l0")
            if v is not None:
                return float(v)
        except Exception:
            pass
    return L0_DEFAULT_MM


def _resolve_preseed_node_indices(run_dir: Path) -> np.ndarray | None:
    """Return preseed node indices from trajectory nodesets, or None.

    Looks at metadata's ``preseed_notch_nodesets`` first, then falls back
    to nodesets named ``notch_*``. Mirrors the lookup chain used by
    ``compare.py`` (issue #213).
    """
    meta = _read_run_metadata(run_dir) or {}
    bundle = _load_trajectory_bundle(run_dir)
    if bundle is None:
        return None
    names: list[str] = []
    v = (meta.get("preseed_notch_nodesets")
         or meta.get("user_preseed_notch_nodesets"))
    if isinstance(v, list):
        names = [str(x) for x in v]
    try:
        mesh = bundle.sd.get("mesh")
        ns_grp = None if mesh is None else mesh.get("node_sets")
        if ns_grp is None:
            return None
        if not names:
            names = [n for n in ns_grp.keys() if str(n).startswith("notch_")]
        idx_list = []
        for n in names:
            if n in ns_grp:
                idx_list.append(np.asarray(ns_grp[n], dtype=np.int64))
        if not idx_list:
            return None
        return np.unique(np.concatenate(idx_list))
    finally:
        bundle.close()


@dataclass
class _TrajectoryBundle:
    """Open trajectory handle shared by Zarr and legacy H5 readers."""

    root: Any
    sd: Any
    steps: Any
    source: str

    def close(self) -> None:
        close = getattr(self.root, "close", None)
        if close is not None:
            close()


def _load_trajectory_bundle(run_dir: Path) -> _TrajectoryBundle | None:
    """Open ``training_data.zarr`` first, then legacy ``training_data.h5``.

    New solver and dataset workflows are Zarr-first, but historical paper
    artifacts may still be H5-only. Callers must close the returned bundle;
    closing is a no-op for Zarr.
    """
    zarr_path = run_dir / "training_data.zarr"
    if zarr_path.is_dir():
        try:
            import zarr  # type: ignore
            root = zarr.open(str(zarr_path), mode="r")
            sd = root["simulation_data"] if "simulation_data" in root else root
            steps = sd.get("steps")
            if steps is not None:
                return _TrajectoryBundle(root, sd, steps, "Zarr")
        except Exception:
            # A partial/incompatible Zarr directory should not mask a valid
            # legacy H5 trajectory during artifact migration.
            pass

    h5_path = run_dir / "training_data.h5"
    if not h5_path.exists():
        return None
    try:
        import h5py  # type: ignore
    except ImportError:
        return None
    f = h5py.File(h5_path, "r")
    sd = f["simulation_data"] if "simulation_data" in f else f
    steps = sd.get("steps")
    if steps is None:
        f.close()
        return None
    return _TrajectoryBundle(f, sd, steps, "H5")


def _load_h5_handle(run_dir: Path):
    """Compatibility wrapper; new metric code should use the Zarr-aware
    ``_load_trajectory_bundle``.
    """
    bundle = _load_trajectory_bundle(run_dir)
    if bundle is None:
        return None
    return bundle.root, bundle.sd, bundle.steps


def _load_max_d_excluding_preseed(
    run_dir: Path,
) -> tuple[np.ndarray, np.ndarray, bool] | None:
    """Per-step max(d) over non-preseed nodes from trajectory snapshots.

    Returns ``(t_us, max_d, preseed_resolved)`` in float64 where
    ``preseed_resolved`` is True iff a non-empty preseed nodeset was
    found and applied. ``None`` if the trajectory is unavailable. When the
    nodeset cannot be resolved this function gracefully degrades to
    the all-node maximum, but the caller is signalled via
    ``preseed_resolved=False`` so it can warn (issue #213 fallback).
    """
    bundle = _load_trajectory_bundle(run_dir)
    if bundle is None:
        return None
    try:
        steps = bundle.steps
        preseed_idx = _resolve_preseed_node_indices(run_dir)
        preseed_resolved = bool(
            preseed_idx is not None and preseed_idx.size)
        times: list[float] = []
        maxd: list[float] = []
        for key in sorted(steps.keys()):
            if not key.startswith("step_"):
                continue
            grp = steps[key]
            if "damage_nodal" not in grp:
                continue
            d = np.asarray(grp["damage_nodal"], dtype=np.float64).ravel()
            if preseed_resolved:
                mask = np.ones(d.shape[0], dtype=bool)
                valid = preseed_idx[(preseed_idx >= 0) & (preseed_idx < d.shape[0])]
                mask[valid] = False
                d = d[mask]
            times.append(float(grp.attrs.get("time_s", 0.0)))
            maxd.append(float(d.max()) if d.size else 0.0)
        if not times:
            return None
        return (np.asarray(times, dtype=np.float64) * 1e6,
                np.asarray(maxd, dtype=np.float64),
                preseed_resolved)
    finally:
        bundle.close()


def _load_energy_curves(run_dir: Path) -> dict[str, np.ndarray] | None:
    """Return time-aligned elastic / kinetic / fracture / total energy traces.

    Order of preference:
      1. Zarr/H5 ``simulation_data/steps/*/`` attrs ``energy_elastic`` etc.
      2. ``energy.csv`` read by header name. This supports both the
         current writer schema
         ``step,time,elastic,fracture,kinetic,external,total`` and the
         legacy HPC schema ``step,t_s,elastic,kinetic,fracture,total``.
    Returns dict with keys ``t_us, elastic, kinetic, fracture, total``
    (any of the energy arrays may be empty if not in the source). All
    arrays float64. ``None`` when no source available.
    """
    bundle = _load_trajectory_bundle(run_dir)
    if bundle is not None:
        try:
            steps = bundle.steps
            t: list[float] = []
            e_el: list[float] = []
            e_ki: list[float] = []
            e_fr: list[float] = []
            e_to: list[float] = []
            for key in sorted(steps.keys()):
                if not key.startswith("step_"):
                    continue
                grp = steps[key]
                if "time_s" not in grp.attrs:
                    continue
                t.append(float(grp.attrs["time_s"]))
                e_el.append(float(grp.attrs.get("energy_elastic", np.nan)))
                e_ki.append(float(grp.attrs.get("energy_kinetic", np.nan)))
                e_fr.append(float(grp.attrs.get("energy_fracture", np.nan)))
                e_to.append(float(grp.attrs.get("energy_total", np.nan)))
            if t:
                return {
                    "t_us": np.asarray(t, dtype=np.float64) * 1e6,
                    "elastic": np.asarray(e_el, dtype=np.float64),
                    "kinetic": np.asarray(e_ki, dtype=np.float64),
                    "fracture": np.asarray(e_fr, dtype=np.float64),
                    "total": np.asarray(e_to, dtype=np.float64),
                }
        finally:
            bundle.close()
    csv_path = run_dir / "energy.csv"
    if csv_path.exists():
        try:
            data = np.genfromtxt(
                csv_path,
                delimiter=",",
                names=True,
                dtype=np.float64,
                encoding=None,
            )
            if data.size == 0 or data.dtype.names is None:
                return None
            if data.ndim == 0:
                data = data.reshape(1)
            names = set(data.dtype.names)
            if not {"elastic", "fracture", "kinetic", "total"} <= names:
                return None

            if "time" in names:
                t_s = data["time"]
            elif "t_s" in names:
                t_s = data["t_s"]
            else:
                return None

            return {
                "t_us": np.asarray(t_s, dtype=np.float64) * 1e6,
                "elastic": np.asarray(data["elastic"], dtype=np.float64),
                "fracture": np.asarray(data["fracture"], dtype=np.float64),
                "kinetic": np.asarray(data["kinetic"], dtype=np.float64),
                "total": np.asarray(data["total"], dtype=np.float64),
            }
        except Exception:
            pass
    return None


def _load_crack_tip(run_dir: Path) -> dict[str, np.ndarray] | None:
    """Return ``{t_us, x_mm, vel_mms}`` from ``crack_tip.csv`` or None.

    Schema: ``step,t_us,crack_tip_x_mm,n_crack_tips,crack_vel_mms,
    crack_vel_frac_cR,branched``.
    """
    p = run_dir / "crack_tip.csv"
    if not p.exists():
        return None
    try:
        arr = np.loadtxt(p, delimiter=",", skiprows=1, usecols=(1, 2, 4),
                         dtype=np.float64)
        if arr.ndim == 1:
            arr = arr[None, :]
        return {
            "t_us": arr[:, 0],
            "x_mm": arr[:, 1],
            "vel_mms": arr[:, 2],
        }
    except Exception:
        return None


# ---------------------------------------------------------------------
# Morphology helpers (lifted from PR #319 / B7 compare.py)
# ---------------------------------------------------------------------


def _grid_damage(
    coords: np.ndarray,
    elements: np.ndarray | None,
    damage: np.ndarray,
    x_lo: float,
    x_hi: float,
    y_lo: float,
    y_hi: float,
    dx: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Interpolate triangular nodal damage onto a uniform 2D grid.

    Returns ``(xs, ys, D)`` with ``D`` shape ``(ny, nx)``. NaN cells
    outside the convex hull are zeroed (so connected components don't
    split at sliver gaps).
    """
    import matplotlib.tri as mtri  # lazy: matplotlib is a heavy import
    nx = max(2, int(np.ceil((x_hi - x_lo) / dx)) + 1)
    ny = max(2, int(np.ceil((y_hi - y_lo) / dx)) + 1)
    xs = np.linspace(x_lo, x_hi, nx)
    ys = np.linspace(y_lo, y_hi, ny)
    XG, YG = np.meshgrid(xs, ys)
    if elements is not None and elements.size:
        tri = mtri.Triangulation(coords[:, 0], coords[:, 1], elements)
        interp = mtri.LinearTriInterpolator(tri, damage)
        D = np.asarray(interp(XG, YG), dtype=np.float64)
    else:
        from scipy.spatial import cKDTree
        tree = cKDTree(coords)
        flat = np.column_stack([XG.ravel(), YG.ravel()])
        _, idx = tree.query(flat)
        D = damage[idx].reshape(XG.shape).astype(np.float64)
    D = np.where(np.isnan(D), 0.0, D)
    return xs.astype(np.float64), ys.astype(np.float64), D


def count_arms_in_region(
    D: np.ndarray,
    xs: np.ndarray,
    x_min_arm: float,
    threshold: float = MORPH_DAMAGE_THRESH,
    min_island: int = MORPH_MIN_ISLAND,
) -> int:
    """Count distinct propagating arms in ``x > x_min_arm`` (mm).

    Lifted from PR #319 (B7 compare.py). Naively counting 2D connected
    components undercounts a Y-branch because the fork point keeps both
    arms in one CC; instead we (1) drop noise islands smaller than
    ``min_island`` cells, (2) for each column j in ``x > x_min_arm``,
    count maximal contiguous y-runs of cleaned True, return the column-
    wise max. Straight crack -> 1; Y -> 2; triple branch -> 3.
    """
    from scipy.ndimage import label
    if D.ndim != 2:
        raise ValueError(f"D must be 2D, got shape {D.shape}")
    if xs.ndim != 1 or xs.size != D.shape[1]:
        raise ValueError(
            f"xs shape {xs.shape} must match D columns {D.shape[1]}")

    mask = D > threshold
    if not mask.any():
        return 0
    labels, n_lab = label(mask)
    if n_lab == 0:
        return 0
    sizes = np.bincount(labels.ravel())[1:]
    if min_island > 1:
        small = np.where(sizes < min_island)[0] + 1
        if small.size:
            mask[np.isin(labels, small)] = False
    if not mask.any():
        return 0

    col_mask = xs > x_min_arm
    if not col_mask.any():
        return 0
    sub = mask[:, col_mask]
    if not sub.any():
        return 0
    cols = sub.astype(np.int8)
    starts = cols[0:1, :]
    transitions = (cols[1:, :] - cols[:-1, :]) == 1
    runs_per_col = starts.sum(axis=0) + transitions.sum(axis=0)
    return int(runs_per_col.max())


def _compute_morphology_timeseries(
    run_dir: Path,
    *,
    precrack_length_mm: float,
    l0_mm: float,
    grid_per_l0: int = MORPH_GRID_PER_L0,
    threshold: float = MORPH_DAMAGE_THRESH,
    min_island: int = MORPH_MIN_ISLAND,
) -> dict | None:
    """Walk the trajectory timeseries; return per-step right-side arm counts."""
    bundle = _load_trajectory_bundle(run_dir)
    if bundle is None:
        return None
    try:
        mesh = bundle.sd.get("mesh")
        if mesh is None or "node_coordinates" not in mesh:
            return None
        coords = np.asarray(mesh["node_coordinates"], dtype=np.float64)
        elements = None
        if "element_connectivity" in mesh:
            elements = np.asarray(mesh["element_connectivity"], dtype=np.int64)
        x_min_arm = float(precrack_length_mm + 2.0 * l0_mm)
        x_lo = float(coords[:, 0].min())
        x_hi = float(coords[:, 0].max())
        y_lo = float(coords[:, 1].min())
        y_hi = float(coords[:, 1].max())
        dx = float(l0_mm) / max(1, int(grid_per_l0))
        t_us_list: list[float] = []
        arm_counts: list[int] = []
        D_final = None
        xs_final = None
        ys_final = None
        for key in sorted(bundle.steps.keys()):
            if not key.startswith("step_"):
                continue
            grp = bundle.steps[key]
            if "damage_nodal" not in grp:
                continue
            d = np.asarray(grp["damage_nodal"], dtype=np.float64).ravel()
            if d.shape[0] != coords.shape[0]:
                continue
            t_us = float(grp.attrs.get("time_s", 0.0)) * 1e6
            xs, ys, D = _grid_damage(
                coords, elements, d, x_lo, x_hi, y_lo, y_hi, dx)
            n = count_arms_in_region(
                D, xs, x_min_arm, threshold=threshold, min_island=min_island)
            t_us_list.append(t_us)
            arm_counts.append(n)
            D_final = D
            xs_final = xs
            ys_final = ys
        if not t_us_list:
            return None
        t_arr = np.asarray(t_us_list, dtype=np.float64)
        n_arr = np.asarray(arm_counts, dtype=np.int64)
        idx = np.where(n_arr >= 2)[0]
        t_branch_us = float(t_arr[idx[0]]) if idx.size else float("nan")
        return {
            "t_us": t_arr,
            "arm_counts": n_arr,
            "n_arms_final": int(n_arr[-1]),
            "t_branch_us": t_branch_us,
            "D_final": D_final,
            "xs": xs_final,
            "ys": ys_final,
            "x_min_arm": x_min_arm,
        }
    finally:
        bundle.close()


# ---------------------------------------------------------------------
# Material / wave-speed helpers
# ---------------------------------------------------------------------


def rayleigh_wave_speed(E: float, nu: float, rho: float) -> float:
    """Freund (1990) approximation for the Rayleigh-wave speed.

    .. math::
        c_R \\approx c_s \\frac{0.862 + 1.14\\,\\nu}{1 + \\nu},
        \\quad c_s = \\sqrt{\\mu/\\rho}, \\;\\;
        \\mu = \\frac{E}{2(1+\\nu)}.

    Reference: Freund, "Dynamic Fracture Mechanics" (CUP, 1990),
    eq. 2.4.13. Inputs in consistent units; returns ``c_R`` in the
    matching length-over-time system.

    For the solver's mm-MPa-t convention (``E`` in MPa = N/mm² and
    ``rho`` in t/mm³), one MPa / (t/mm³) has the units of
    ``mm^2 / s^2``, so :math:`c_R` returns in **mm/s**. Equivalently,
    feeding ``E [Pa]`` and ``rho [kg/m^3]`` gives ``c_R [m/s]``.
    """
    if not (E and rho and rho > 0.0):
        return float("nan")
    mu = E / (2.0 * (1.0 + nu))
    if mu <= 0.0:
        return float("nan")
    cs = math.sqrt(mu / rho)
    return cs * (0.862 + 1.14 * nu) / (1.0 + nu)


def _rayleigh_wave_speed_mms(material: dict) -> float | None:
    """Compute c_R in mm/s from the metadata material block.

    The solver's mm-MPa-t convention places ``rayleigh_wave_speed``
    output directly in mm/s (see that function's docstring), and the
    velocity CSVs report mm/s, so no unit conversion is required.
    Returns ``None`` if E/nu/rho are not all available.
    """
    try:
        E = float(material.get("E"))
        nu = float(material.get("nu"))
        rho = float(material.get("rho"))
    except (TypeError, ValueError):
        return None
    c_mms = rayleigh_wave_speed(E, nu, rho)
    if not math.isfinite(c_mms):
        return None
    return c_mms


# =====================================================================
# Public metrics
# =====================================================================


def initiation_time(
    run_dir: Path,
    threshold: float = INITIATION_THRESHOLD,
) -> MetricResult:
    """First time (us) where ``max(d) > threshold`` outside the preseed zone.

    PFM-Bench convention threshold = 0.5 (early-onset, distinct from
    compare.py's 0.99 which detects saturation).
    """
    excl = _load_max_d_excluding_preseed(run_dir)
    if excl is None:
        return MetricResult(None, units="us", source="trajectory",
                            status="missing_input",
                            detail="training_data.zarr/H5 unavailable")
    t_us, max_d, preseed_resolved = excl
    above = np.where(max_d > threshold)[0]
    if not above.size:
        return MetricResult(float("nan"), units="us", source="trajectory",
                            status="ok",
                            detail=f"max(d) never crossed {threshold}")
    preseed_note = ("preseed-excluded" if preseed_resolved
                    else "preseed nodeset not found; raw all-node max(d) "
                         "(may include pf_dirichlet-locked notch nodes "
                         "-- issue #213)")
    return MetricResult(
        float(t_us[above[0]]), units="us", source="trajectory",
        detail=f"threshold={threshold} ({preseed_note})")


def branching_onset(
    run_dir: Path,
    *,
    precrack_length_mm: float | None = None,
    l0_mm: float | None = None,
) -> MetricResult:
    """First time (us) where the right-of-precrack region has 2+ arms.

    Uses the connected-component morphology detector from PR #319.
    Returns NaN value with status ok if the run never branched.
    """
    if precrack_length_mm is None:
        precrack_length_mm = _read_precrack_length_mm(run_dir)
    if l0_mm is None:
        l0_mm = _read_l0_mm(run_dir)
    morph = _compute_morphology_timeseries(
        run_dir, precrack_length_mm=precrack_length_mm, l0_mm=l0_mm)
    if morph is None:
        return MetricResult(None, units="us", source="components",
                            status="missing_input",
                            detail="trajectory / mesh unavailable")
    val = morph["t_branch_us"]
    return MetricResult(
        float(val), units="us", source="components",
        detail=f"x_min_arm={morph['x_min_arm']:.2f} mm")


def branching_onset_energy_argmax(run_dir: Path) -> MetricResult:
    """Late-window argmax of the elastic-energy curve (legacy detector).

    Kept for backward compatibility. Subject to false positives on
    wave-reflection peaks; prefer :func:`branching_onset` (components).
    """
    energies = _load_energy_curves(run_dir)
    if energies is None:
        return MetricResult(None, units="us", source="energy_argmax",
                            status="missing_input",
                            detail="no energy source")
    t = energies["t_us"]
    e = energies["elastic"]
    if t.size < 5 or not np.isfinite(e).any():
        return MetricResult(None, units="us", source="energy_argmax",
                            status="missing_input",
                            detail="too few elastic-energy samples")
    window = max(3, t.size // 50)
    kernel = np.ones(window, dtype=np.float64) / window
    e_smooth = np.convolve(e, kernel, mode="same")
    early_mask = t <= 20.0
    if early_mask.any():
        i_first = int(np.argmax(e_smooth[early_mask]))
        t_first = float(t[early_mask][i_first])
    else:
        t_first = 10.0  # generic initiation fallback
    late_mask = t > (t_first + 5.0)
    if not late_mask.any():
        return MetricResult(float("nan"), units="us",
                            source="energy_argmax", status="ok",
                            detail="no late-window samples")
    i_late = int(np.argmax(e_smooth[late_mask]))
    return MetricResult(
        float(t[late_mask][i_late]), units="us",
        source="energy_argmax",
        detail=f"smooth window={window}, after t_first={t_first:.2f} us")


def n_arms_final(
    run_dir: Path,
    *,
    precrack_length_mm: float | None = None,
    l0_mm: float | None = None,
) -> MetricResult:
    """Final-step arm count via the morphology detector."""
    if precrack_length_mm is None:
        precrack_length_mm = _read_precrack_length_mm(run_dir)
    if l0_mm is None:
        l0_mm = _read_l0_mm(run_dir)
    morph = _compute_morphology_timeseries(
        run_dir, precrack_length_mm=precrack_length_mm, l0_mm=l0_mm)
    if morph is None:
        return MetricResult(None, units="", source="components",
                            status="missing_input",
                            detail="trajectory / mesh unavailable")
    return MetricResult(
        int(morph["n_arms_final"]), units="", source="components",
        detail=f"final step at t={morph['t_us'][-1]:.2f} us")


def total_dissipated_energy(run_dir: Path) -> MetricResult:
    """Final cumulative fracture energy (J at COMSOL 1 m thickness conv.).

    Computed as the last value of the cumulative ``energy_fracture``
    trace stored in trajectory attrs. Equivalently, the area under the
    crack-tip dissipation-rate curve from t=0 to t_end (since the
    trajectory stores the running total).
    """
    energies = _load_energy_curves(run_dir)
    if energies is None:
        return MetricResult(None, units="J", source="trajectory",
                            status="missing_input",
                            detail="no energy source")
    e_fr = energies["fracture"]
    if not np.isfinite(e_fr).any():
        return MetricResult(None, units="J", source="trajectory",
                            status="missing_input",
                            detail="no fracture-energy attr")
    last = float(e_fr[np.isfinite(e_fr)][-1])
    return MetricResult(last, units="J", source="trajectory",
                        detail="final cumulative energy_fracture")


def crack_tip_velocity(run_dir: Path) -> MetricResult:
    """Peak and time-integrated mean crack-tip velocity.

    Returns the *peak* velocity as ``value`` (mm/s). The ``detail``
    field carries the mean. NaN if the run did not emit
    ``crack_tip.csv``.
    """
    ct = _load_crack_tip(run_dir)
    if ct is None:
        return MetricResult(None, units="mm/s", source="crack_tip.csv",
                            status="missing_input",
                            detail="crack_tip.csv unavailable")
    v = ct["vel_mms"]
    v_pos = v[v > 0]
    if not v_pos.size:
        return MetricResult(0.0, units="mm/s", source="crack_tip.csv",
                            status="ok", detail="no positive samples")
    peak = float(v_pos.max())
    mean = float(np.mean(v_pos))
    return MetricResult(peak, units="mm/s", source="crack_tip.csv",
                        detail=f"mean={mean:.3e} mm/s; n={v_pos.size}")


def yoffe_breach_fraction(run_dir: Path) -> MetricResult:
    """Fraction of timesteps where v_tip > YOFFE_THRESHOLD_FRAC * c_R.

    Uses the Rayleigh-wave speed derived from E, nu, rho via the
    Freund (1990) approximation. Returns NaN if either crack_tip.csv
    or the material block is incomplete.
    """
    ct = _load_crack_tip(run_dir)
    if ct is None:
        return MetricResult(None, units="", source="crack_tip.csv",
                            status="missing_input",
                            detail="crack_tip.csv unavailable")
    material = _read_material(run_dir)
    c_r = _rayleigh_wave_speed_mms(material)
    if c_r is None:
        return MetricResult(None, units="", source="material",
                            status="missing_input",
                            detail="missing E/nu/rho in run_metadata.json")
    v = ct["vel_mms"]
    v_pos = v[v > 0]
    if not v_pos.size:
        return MetricResult(0.0, units="", source="crack_tip.csv",
                            status="ok", detail="no positive velocities")
    threshold = YOFFE_THRESHOLD_FRAC * c_r
    frac = float(np.mean(v_pos > threshold))
    return MetricResult(
        frac, units="", source="crack_tip.csv",
        detail=(f"v_threshold={threshold:.3e} mm/s "
                f"(0.6*c_R={c_r:.3e} mm/s); "
                f"breach n={int(np.sum(v_pos > threshold))}/{v_pos.size}"))


def _crack_pixel_count_to_length_mm(
    n_pixels: int, dx_mm: float
) -> float:
    """Approximate total crack length from the number of d>thresh pixels.

    Treats the crack as a band of width ~ 2*l0 (dx_mm * grid_per_l0
    cells); divides total pixel count by the band's pixel-width to get
    an axial length. Rough but mesh-independent enough for tortuosity.
    """
    if n_pixels <= 0:
        return 0.0
    # Band half-width in pixels: roughly grid_per_l0 = MORPH_GRID_PER_L0.
    band_pixels = 2 * MORPH_GRID_PER_L0  # ~2*l0/dx
    return float(n_pixels) * dx_mm / float(band_pixels)


def crack_length_full_y(
    run_dir: Path,
    *,
    precrack_length_mm: float | None = None,
    l0_mm: float | None = None,
) -> MetricResult:
    """Total crack length (mm) at the first step where n_arms == 2.

    NaN when the crack never branched.
    """
    if precrack_length_mm is None:
        precrack_length_mm = _read_precrack_length_mm(run_dir)
    if l0_mm is None:
        l0_mm = _read_l0_mm(run_dir)
    bundle = _load_trajectory_bundle(run_dir)
    if bundle is None:
        return MetricResult(None, units="mm", source="components",
                            status="missing_input",
                            detail="training_data.zarr/H5 unavailable")
    try:
        mesh = bundle.sd.get("mesh")
        if mesh is None or "node_coordinates" not in mesh:
            return MetricResult(None, units="mm", source="components",
                                status="missing_input",
                                detail="mesh group missing")
        coords = np.asarray(mesh["node_coordinates"], dtype=np.float64)
        elements = (np.asarray(mesh["element_connectivity"], dtype=np.int64)
                    if "element_connectivity" in mesh else None)
        x_lo, x_hi = float(coords[:, 0].min()), float(coords[:, 0].max())
        y_lo, y_hi = float(coords[:, 1].min()), float(coords[:, 1].max())
        dx = l0_mm / float(MORPH_GRID_PER_L0)
        x_min_arm = float(precrack_length_mm + 2.0 * l0_mm)
        for key in sorted(bundle.steps.keys()):
            if not key.startswith("step_"):
                continue
            grp = bundle.steps[key]
            if "damage_nodal" not in grp:
                continue
            d = np.asarray(grp["damage_nodal"], dtype=np.float64).ravel()
            if d.shape[0] != coords.shape[0]:
                continue
            xs, ys, D = _grid_damage(coords, elements, d,
                                     x_lo, x_hi, y_lo, y_hi, dx)
            arms = count_arms_in_region(D, xs, x_min_arm)
            if arms >= 2:
                n_pixels = int(np.sum(D > MORPH_DAMAGE_THRESH))
                length = _crack_pixel_count_to_length_mm(n_pixels, dx)
                t_us = float(grp.attrs.get("time_s", 0.0)) * 1e6
                return MetricResult(
                    length, units="mm", source="components",
                    detail=(f"first arms>=2 at t={t_us:.2f} us; "
                            f"n_pixels={n_pixels}, dx={dx:.3f} mm"))
        return MetricResult(float("nan"), units="mm", source="components",
                            status="ok",
                            detail="run never reached arms>=2")
    finally:
        bundle.close()


def path_tortuosity(
    run_dir: Path,
    *,
    precrack_length_mm: float | None = None,
    l0_mm: float | None = None,
) -> MetricResult:
    """``total_crack_length / euclidean(notch_tip, far_crack_tip)``.

    Both lengths in mm. The numerator uses
    :func:`_crack_pixel_count_to_length_mm` on the final damage field.
    The denominator is the straight-line distance from the notch tip
    ``(precrack_length_mm, mid_y)`` to the *farthest* crack-zone node
    (the node maximising Euclidean distance to the notch tip among
    those with ``d > threshold`` and ``x > precrack_length_mm + 2*l0``).

    Two #213-related corrections vs the naive `argmax(d)` denominator:
      - the preseed mask (``x > x_min_arm``) prevents
        ``pf_dirichlet``-locked notch nodes (d=1 from t=0) from being
        picked as the "far tip";
      - argmax-by-distance instead of argmax-by-damage avoids the
        post-saturation tie-breaking artefact (many nodes share d=1
        once the crack is fully formed, so argmax(d) returns the
        smallest insertion index, not a meaningful spatial extremum).

    Returns NaN when no damage has formed beyond the preseed region.
    """
    if precrack_length_mm is None:
        precrack_length_mm = _read_precrack_length_mm(run_dir)
    if l0_mm is None:
        l0_mm = _read_l0_mm(run_dir)
    bundle = _load_trajectory_bundle(run_dir)
    if bundle is None:
        return MetricResult(None, units="", source="components",
                            status="missing_input",
                            detail="training_data.zarr/H5 unavailable")
    try:
        mesh = bundle.sd.get("mesh")
        if mesh is None or "node_coordinates" not in mesh:
            return MetricResult(None, units="", source="components",
                                status="missing_input",
                                detail="mesh group missing")
        coords = np.asarray(mesh["node_coordinates"], dtype=np.float64)
        elements = (np.asarray(mesh["element_connectivity"], dtype=np.int64)
                    if "element_connectivity" in mesh else None)
        keys = sorted(k for k in bundle.steps.keys() if k.startswith("step_"))
        if not keys:
            return MetricResult(None, units="", source="components",
                                status="missing_input",
                                detail="no step_* groups in trajectory")
        last = bundle.steps[keys[-1]]
        if "damage_nodal" not in last:
            return MetricResult(None, units="", source="components",
                                status="missing_input",
                                detail="last step has no damage_nodal")
        d = np.asarray(last["damage_nodal"], dtype=np.float64).ravel()
        if d.size != coords.shape[0] or not np.isfinite(d).any():
            return MetricResult(None, units="", source="components",
                                status="error",
                                detail="damage / mesh size mismatch")
        if d.max() <= MORPH_DAMAGE_THRESH:
            return MetricResult(float("nan"), units="",
                                source="components", status="ok",
                                detail="no damage above threshold")
        x_lo, x_hi = float(coords[:, 0].min()), float(coords[:, 0].max())
        y_lo, y_hi = float(coords[:, 1].min()), float(coords[:, 1].max())
        dx = l0_mm / float(MORPH_GRID_PER_L0)
        xs, ys, D = _grid_damage(coords, elements, d,
                                 x_lo, x_hi, y_lo, y_hi, dx)
        # Total length on the FULL grid above threshold.
        n_pixels = int(np.sum(D > MORPH_DAMAGE_THRESH))
        total_length = _crack_pixel_count_to_length_mm(n_pixels, dx)
        # The denominator is the euclidean distance from the notch tip
        # to the *farthest crack-zone node* (issue #213 fix). Plain
        # ``argmax(d)`` is wrong on two counts:
        #   1. ``pf_dirichlet`` preseeds notch nodes at d=1 from t=0,
        #      so a global argmax can hit x=0 and the euclidean
        #      denominator collapses to a constant.
        #   2. After saturation many nodes share d=1 exactly, so
        #      argmax becomes a tie-breaker on insertion order, not
        #      a meaningful spatial maximum.
        # We instead enumerate ``coords[d > thresh AND right_of_precrack]``
        # and pick the one farthest from the notch tip in Euclidean
        # distance. This is the canonical "tip-of-the-crack" position.
        x_min_arm = float(precrack_length_mm + 2.0 * l0_mm)
        crack_mask = (d > MORPH_DAMAGE_THRESH) & (coords[:, 0] > x_min_arm)
        if not crack_mask.any():
            return MetricResult(float("nan"), units="",
                                source="components", status="ok",
                                detail=("no damage > threshold past "
                                        f"x_min_arm={x_min_arm:.2f} mm"))
        notch_xy = (precrack_length_mm, 0.5 * (y_lo + y_hi))
        rx = coords[crack_mask, 0] - notch_xy[0]
        ry = coords[crack_mask, 1] - notch_xy[1]
        euclid_per_node = np.hypot(rx, ry)
        i_far = int(np.argmax(euclid_per_node))
        crack_indices = np.where(crack_mask)[0]
        far_node_idx = int(crack_indices[i_far])
        far_xy = (float(coords[far_node_idx, 0]),
                  float(coords[far_node_idx, 1]))
        euclid = float(euclid_per_node[i_far])
        if euclid <= 0.0:
            return MetricResult(float("nan"), units="",
                                source="components", status="ok",
                                detail="far crack node coincides with notch tip")
        return MetricResult(
            total_length / euclid, units="", source="components",
            detail=(f"total={total_length:.3f} mm; "
                    f"euclid={euclid:.3f} mm; far_xy={far_xy} "
                    f"(farthest crack node beyond x_min_arm={x_min_arm:.2f} mm)"))
    finally:
        bundle.close()


def elastic_energy_peak(run_dir: Path) -> MetricResult:
    """Peak of the elastic-energy curve over the simulation."""
    energies = _load_energy_curves(run_dir)
    if energies is None:
        return MetricResult(None, units="J", source="trajectory",
                            status="missing_input",
                            detail="no energy source")
    e = energies["elastic"]
    e_fin = e[np.isfinite(e)]
    if not e_fin.size:
        return MetricResult(None, units="J", source="trajectory",
                            status="missing_input",
                            detail="no finite elastic-energy samples")
    return MetricResult(
        float(e_fin.max()), units="J", source="trajectory",
        detail=("J at the COMSOL out-of-plane 1 m thickness convention"))


# ---------------------------------------------------------------------
# Umbrella report
# ---------------------------------------------------------------------


METRIC_FUNCS = {
    "initiation_time": initiation_time,
    "branching_onset": branching_onset,
    "branching_onset_energy_argmax": branching_onset_energy_argmax,
    "n_arms_final": n_arms_final,
    "total_dissipated_energy": total_dissipated_energy,
    "crack_tip_velocity": crack_tip_velocity,
    "yoffe_breach_fraction": yoffe_breach_fraction,
    "path_tortuosity": path_tortuosity,
    "elastic_energy_peak": elastic_energy_peak,
    "crack_length_full_y": crack_length_full_y,
}


def compute_pfm_bench_report(
    run_dir: Path,
    *,
    precrack_length_mm: float | None = None,
    l0_mm: float | None = None,
) -> dict[str, Any]:
    """Compute every PFM-Bench metric and return a JSON-serialisable dict.

    Layout::

        {
          "run_dir": "<absolute path>",
          "metrics": {
            "<metric_name>": {value, units, source, status, detail},
            ...
          },
          "metadata": { ... echo of run_metadata.json if present ... }
        }

    Never raises on missing inputs; metrics whose source data is
    unavailable carry ``status="missing_input"`` and ``value=None``.
    """
    run_dir = Path(run_dir)
    if precrack_length_mm is None:
        precrack_length_mm = _read_precrack_length_mm(run_dir)
    if l0_mm is None:
        l0_mm = _read_l0_mm(run_dir)
    out: dict[str, Any] = {
        "run_dir": str(run_dir.resolve()),
        "metrics": {},
        "metadata": _read_run_metadata(run_dir) or {},
    }
    for name, fn in METRIC_FUNCS.items():
        try:
            if name in ("branching_onset", "n_arms_final",
                        "path_tortuosity", "crack_length_full_y"):
                res = fn(run_dir,
                         precrack_length_mm=precrack_length_mm,
                         l0_mm=l0_mm)
            else:
                res = fn(run_dir)
        except Exception as exc:
            res = MetricResult(None, units="", source="error",
                               status="error", detail=str(exc))
        out["metrics"][name] = res.to_dict()
    return out


def report_to_markdown(report: dict[str, Any]) -> str:
    """Render a :func:`compute_pfm_bench_report` dict as a markdown table."""
    lines = [
        "# PFM-Bench validation report",
        "",
        f"**Run dir:** `{report.get('run_dir', '?')}`",
        "",
        "| Metric | Value | Units | Source | Status | Detail |",
        "|---|---|---|---|---|---|",
    ]
    for name, m in report.get("metrics", {}).items():
        v = m.get("value")
        if v is None:
            v_str = "n/a"
        elif isinstance(v, float):
            v_str = (f"{v:.4g}" if not (math.isnan(v) or math.isinf(v))
                     else str(v))
        else:
            v_str = str(v)
        lines.append(
            f"| `{name}` | {v_str} | {m.get('units', '')} | "
            f"{m.get('source', '')} | {m.get('status', '')} | "
            f"{m.get('detail', '')} |"
        )
    return "\n".join(lines) + "\n"


__all__ = [
    "MetricResult",
    "rayleigh_wave_speed",
    "count_arms_in_region",
    "initiation_time",
    "branching_onset",
    "branching_onset_energy_argmax",
    "n_arms_final",
    "total_dissipated_energy",
    "crack_tip_velocity",
    "yoffe_breach_fraction",
    "path_tortuosity",
    "elastic_energy_peak",
    "crack_length_full_y",
    "compute_pfm_bench_report",
    "report_to_markdown",
    "METRIC_FUNCS",
    "INITIATION_THRESHOLD",
    "YOFFE_THRESHOLD_FRAC",
]
