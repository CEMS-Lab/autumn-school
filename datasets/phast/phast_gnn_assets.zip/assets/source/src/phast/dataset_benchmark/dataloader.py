"""Lazy PyTorch-compatible loaders for PF-Hetero-Bench Zarr samples."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from pathlib import Path
import glob
from typing import Any

import numpy as np

DEFAULT_FIELDS: tuple[str, ...] = (
    "nodes",
    "elements",
    "E",
    "nu",
    "Gc",
    "l0",
    "rho",
    "keyframe_times",
    "u",
    "d",
    "psi_plus",
    "psi_minus",
    "step_times",
)


class ZarrSampleDataset:
    """Map-style dataset over PF-Hetero-Bench ``sample_*.zarr`` stores.

    The class intentionally returns NumPy arrays. Mesh sizes can vary across
    heterogeneous samples, so callers should either use ``collate_samples`` or
    provide a domain-specific collate function that pads, graphs, or batches by
    shape.
    """

    def __init__(
        self,
        paths: str | Path | Sequence[str | Path],
        *,
        fields: Sequence[str] | None = None,
        include_attrs: bool = True,
        validate: bool = False,
    ) -> None:
        self.paths = _resolve_paths(paths)
        if not self.paths:
            raise ValueError("no PF-Hetero-Bench Zarr samples matched")
        self.fields = tuple(fields) if fields is not None else DEFAULT_FIELDS
        self.include_attrs = include_attrs
        if validate:
            from .validator import validate_sample

            invalid = []
            for path in self.paths:
                report = validate_sample(path)
                if not report.is_valid:
                    invalid.append(f"{path}: {report.summary()}")
            if invalid:
                raise ValueError("invalid PF-Hetero-Bench samples:\n" + "\n".join(invalid))

    def __len__(self) -> int:
        return len(self.paths)

    def __getitem__(self, index: int) -> dict[str, Any]:
        import zarr

        path = self.paths[index]
        root = zarr.open(str(path), mode="r")
        sample: dict[str, Any] = {
            "path": str(path),
            "fields": {
                field: np.asarray(root[field])
                for field in self.fields
                if field in root
            },
        }
        if self.include_attrs:
            sample["attrs"] = dict(root.attrs)
        return sample


def collate_samples(batch: Sequence[dict[str, Any]]) -> list[dict[str, Any]]:
    """Ragged-safe collate function for ``torch.utils.data.DataLoader``.

    Returning a list keeps variable-node meshes intact. Training scripts that
    use fixed grids can replace this with a stacking collate once they know the
    sample shapes are compatible.
    """

    return list(batch)


def _resolve_paths(paths: str | Path | Sequence[str | Path]) -> list[Path]:
    if isinstance(paths, (str, Path)):
        raw: Iterable[str | Path] = [paths]
    else:
        raw = paths

    resolved: list[Path] = []
    for item in raw:
        text = str(item)
        if any(ch in text for ch in "*?[]"):
            resolved.extend(Path(p) for p in glob.glob(text))
        else:
            path = Path(item)
            if path.is_dir() and path.suffix != ".zarr":
                resolved.extend(path.glob("sample_*.zarr"))
            else:
                resolved.append(path)

    return sorted(dict.fromkeys(path for path in resolved if path.exists()))


__all__ = ["DEFAULT_FIELDS", "ZarrSampleDataset", "collate_samples"]
