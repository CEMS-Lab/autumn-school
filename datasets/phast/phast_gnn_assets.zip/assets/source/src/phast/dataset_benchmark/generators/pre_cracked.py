"""Plate with multiple pre-existing notch lines (1–3 pre-cracks).

PF-Hetero-Bench class #9 (issue #298).  Identical material distribution
to the homogeneous class, but the ``pre_crack_mask`` is the union of
1–3 line segments.  The first pre-crack is always the standard
left-edge horizontal notch at ``y = H / 2`` (matching the homogeneous
default); 0–2 *additional* random pre-crack lines may be added at random
angles and positions.

Additional pre-cracks are constrained to:
  - be wholly inside the plate (start, end ∈ [δ, W-δ] × [δ, H-δ] with
    δ = 5·l0)
  - not pass within 5·l0 of the standard left-edge notch (to keep the
    multi-crack interaction non-trivial)

The pre-crack mask is per-NODE (length n_nodes) and is the union of
``|distance-to-line-segment| < l0/2`` for every line.  This matches the
homogeneous-class convention.
"""
from __future__ import annotations

import numpy as np

from ._base import GeneratorOutput, SampleGenerator
from .homogeneous import _structured_tri_mesh


def _dist_to_segment(px: np.ndarray, py: np.ndarray,
                      ax: float, ay: float,
                      bx: float, by: float) -> np.ndarray:
    """Per-point distance from (px, py) to the segment (ax, ay)→(bx, by)."""
    ux = bx - ax; uy = by - ay
    L2 = ux * ux + uy * uy
    if L2 < 1e-30:
        return np.sqrt((px - ax) ** 2 + (py - ay) ** 2)
    t = ((px - ax) * ux + (py - ay) * uy) / L2
    t = np.clip(t, 0.0, 1.0)
    cx = ax + t * ux; cy = ay + t * uy
    return np.sqrt((px - cx) ** 2 + (py - cy) ** 2)


class PreCrackedGenerator(SampleGenerator):
    """Random homogeneous plate with 1–3 pre-existing notch lines."""

    CLASS_NAME = "pre_cracked"
    VERSION = "0.1.0"

    DEFAULT_DISTRIBUTION = {
        "W_range": (50.0, 150.0),
        "H_range": (20.0, 60.0),
        "a_frac_range": (0.4, 0.6),
        "E_range": (20_000.0, 50_000.0),
        "nu_range": (0.18, 0.30),
        "Gc_range": (2.0e-3, 5.0e-3),
        "l0_range": (0.5, 1.5),
        "rho_range": (2.0e-9, 3.0e-9),
        "n_extra_cracks_choices": (0, 1, 2),  # 0..2 extra lines
        "extra_crack_length_frac_range": (0.1, 0.3),  # of plate diagonal
        "min_clearance_l0": 5.0,
        "max_reject_attempts": 50,
        "nx_per_l0": 2,
        "ny_per_l0": 2,
        "max_nodes": 8_000,
    }

    def __init__(self, **distribution_params):
        merged = {**self.DEFAULT_DISTRIBUTION, **distribution_params}
        super().__init__(**merged)

    # ------------------------------------------------------------------
    def generate(self, seed: int) -> GeneratorOutput:
        rng = np.random.default_rng(seed)
        p = self.distribution_params

        W = float(rng.uniform(*p["W_range"]))
        H = float(rng.uniform(*p["H_range"]))
        a = float(W * rng.uniform(*p["a_frac_range"]))
        E = float(rng.uniform(*p["E_range"]))
        nu = float(rng.uniform(*p["nu_range"]))
        Gc = float(rng.uniform(*p["Gc_range"]))
        l0 = float(rng.uniform(*p["l0_range"]))
        rho = float(rng.uniform(*p["rho_range"]))

        h_target = l0 / float(p["nx_per_l0"])
        nx = max(2, int(round(W / h_target)))
        ny = max(2, int(round(H / h_target)))
        if (nx + 1) * (ny + 1) > p["max_nodes"]:
            scale = ((nx + 1) * (ny + 1) / p["max_nodes"]) ** 0.5
            nx = max(2, int(round(nx / scale)))
            ny = max(2, int(round(ny / scale)))
        nodes, elements = _structured_tri_mesh(W, H, nx, ny)
        n_elems = elements.shape[0]
        n_nodes = nodes.shape[0]

        x = nodes[:, 0]; y = nodes[:, 1]

        # ---- Pre-crack 1: standard left-edge notch ----
        slit_y = 0.5 * H
        crack_band = max(0.5 * l0, 0.51 * H / ny)  # see spatial_gc.py
        clearance = float(p["min_clearance_l0"]) * l0
        line_segs = [(0.0, slit_y, a, slit_y)]

        # ---- Optional additional pre-cracks ----
        choices = list(p["n_extra_cracks_choices"])
        n_extra = int(choices[rng.integers(0, len(choices))])
        diag = (W * W + H * H) ** 0.5
        len_lo = p["extra_crack_length_frac_range"][0] * diag
        len_hi = p["extra_crack_length_frac_range"][1] * diag
        max_attempts = int(p["max_reject_attempts"])

        accepted = 0
        attempt = 0
        while accepted < n_extra and attempt < max_attempts * max(1, n_extra):
            # Sample midpoint and angle.
            cx = rng.uniform(clearance, W - clearance)
            cy = rng.uniform(clearance, H - clearance)
            theta = rng.uniform(0.0, np.pi)
            length = rng.uniform(len_lo, len_hi)
            ax = cx - 0.5 * length * np.cos(theta)
            ay = cy - 0.5 * length * np.sin(theta)
            bx = cx + 0.5 * length * np.cos(theta)
            by = cy + 0.5 * length * np.sin(theta)
            attempt += 1
            # Reject if endpoints leave the inset domain
            if not (clearance <= ax <= W - clearance and
                    clearance <= ay <= H - clearance and
                    clearance <= bx <= W - clearance and
                    clearance <= by <= H - clearance):
                continue
            # Reject if too close to standard notch (sample a few points)
            ts = np.linspace(0.0, 1.0, 11)
            sx = ax + ts * (bx - ax); sy = ay + ts * (by - ay)
            d_to_notch = _dist_to_segment(sx, sy, 0.0, slit_y, a, slit_y)
            if d_to_notch.min() < clearance:
                continue
            line_segs.append((ax, ay, bx, by))
            accepted += 1

        # ---- Build the union pre-crack mask ----
        pre_crack_mask = np.zeros(n_nodes, dtype=np.uint8)
        for (ax, ay, bx, by) in line_segs:
            dist = _dist_to_segment(x, y, ax, ay, bx, by)
            pre_crack_mask = np.maximum(pre_crack_mask,
                                         (dist < crack_band).astype(np.uint8))

        # ---- Boundary node-sets ----
        eps = 1e-6 * max(W, H)
        sets = {
            "left":   np.where(x < eps)[0],
            "right":  np.where(x > W - eps)[0],
            "bottom": np.where(y < eps)[0],
            "top":    np.where(y > H - eps)[0],
        }
        boundary_set_names = sorted(sets.keys())
        boundary_tags = np.zeros(n_nodes, dtype=np.int64)
        for bit, name in enumerate(boundary_set_names):
            for idx in sets[name]:
                boundary_tags[int(idx)] |= (1 << bit)

        # ---- Material fields (uniform, like homogeneous) ----
        material = {
            "E":   np.full(n_elems, E,   dtype=np.float64),
            "nu":  np.full(n_elems, nu,  dtype=np.float64),
            "Gc":  np.full(n_elems, Gc,  dtype=np.float64),
            "l0":  np.full(n_elems, l0,  dtype=np.float64),
            "rho": np.full(n_elems, rho, dtype=np.float64),
        }
        material_tag = np.zeros(n_elems, dtype=np.int64)

        mesh = {
            "nodes": nodes,
            "elements": elements,
            "boundary_tags": boundary_tags,
            "boundary_set_names": boundary_set_names,
            "material_tag": material_tag,
            "pre_crack_mask": pre_crack_mask,
        }

        # All segments in a flat (n_segs, 4) array for replay/recording
        seg_array = np.array(line_segs, dtype=np.float64)

        bcs = {
            "left":   {"type": "fix", "component": 0},
            "top":    {"type": "traction", "component": 1, "value":  1.0},
            "bottom": {"type": "traction", "component": 1, "value": -1.0},
            "_params": {
                "W": W, "H": H, "a": a,
                "E": E, "nu": nu, "Gc": Gc, "l0": l0, "rho": rho,
                "nx": nx, "ny": ny,
                "n_pre_cracks": len(line_segs),
            },
            "_class_meta": {
                "pre_crack_segments": seg_array,
            },
        }
        pre_crack = {
            "start_xy": np.array([0.0, slit_y], dtype=np.float64),
            "end_xy":   np.array([a,    slit_y], dtype=np.float64),
            "band_half_width": crack_band,
            "n_pre_crack_nodes": int(pre_crack_mask.sum()),
            "all_segments": seg_array,
        }
        return GeneratorOutput(mesh=mesh, material=material,
                                bcs=bcs, pre_crack=pre_crack)


__all__ = ["PreCrackedGenerator"]
