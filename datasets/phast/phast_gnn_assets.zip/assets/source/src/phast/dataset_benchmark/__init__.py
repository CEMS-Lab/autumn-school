"""PF-Hetero-Bench — heterogeneous phase-field dataset infrastructure.

Issue #298 (epic).  This package is the *plumbing* used to package
phase-field-fracture trajectories into a uniform Zstd-Zarr dataset
that downstream DL architectures (FNO / GNN / Transformer / hybrid /
generative) can consume without re-generation.

Layout
------
``dataset_benchmark/schema.py``
    Locked v1 per-sample field layout (see issue #298 schema-lock
    comment dated 2026-05-08).  Read this first.
``dataset_benchmark/packager.py``
    ``SamplePackager`` — writes one ``.zarr`` directory per sample,
    casts state fields float64 -> float32, computes conditioning
    labels at write time. Dataset samples are Zarr-only; legacy solver
    HDF5 remains outside this package.
``dataset_benchmark/validator.py``
    ``validate_sample(zarr_path)`` — checks every required field
    exists with correct shape/dtype/units; returns a
    ``ValidationReport``.
``dataset_benchmark/dataloader.py``
    ``ZarrSampleDataset`` — lazy, PyTorch-compatible map-style reader
    for training scripts. It returns NumPy arrays and a ragged-safe
    collate helper because mesh sizes can vary across samples.
``dataset_benchmark/generators/``
    Sample generators.  ``_base.SampleGenerator`` is the abstract
    interface; ``homogeneous.HomogeneousGenerator`` is the simplest
    of nine planned heterogeneity classes (see #298 epic).

Tier targets (see #298)
-----------------------
- Smoke: 200 samples (~10 GB), schema validation only
- Dev: 5 000 samples (~250 GB), architecture iteration
- Production: 50 000 samples (~1.5 TB compressed), public release

This package ships *only* the infrastructure; smoke / dev / production
runs are HPC follow-ups.
"""

__version__ = "0.1.0"
