"""Neural Operator Warm Start (NOWS) for iterative solvers (#61).

Wraps a learned neural operator as a callable that produces an initial guess
for sparse iterative solves (CG / GMRES / Newton). Falls back to zero when no
model is loaded so callers can opt in without conditional plumbing.

This module is a research scaffold: it does not ship a trained model. The
``NOWSPredictor`` accepts any callable mapping ``(K_indices, K_values, b)``
to ``x_init``; the existing ``cg_mixed_precision`` already accepts an ``x0``
argument, so integration is as simple as ::

    predictor = make_warm_start("/path/to/model.pt")
    x0 = predictor.predict(K_idx, K_val, b, n=b.numel())
    x, iters, ok = cg_mixed_precision(matvec, b, x0=x0)
"""

from __future__ import annotations

from typing import Callable, Optional

import torch


class NOWSPredictor:
    """Wrap a torch model that maps ``(K_indices, K_values, b) -> x_init``.

    The model can be a ``torch.nn.Module``, a plain callable, or ``None``
    (zero fallback). A small cache keyed on the sparsity pattern of ``K`` is
    kept so successive Newton iterations sharing a pattern can reuse the
    bookkeeping; the prediction itself is re-evaluated because ``b`` typically
    changes step-to-step.
    """

    def __init__(self, model: Optional[Callable] = None, device: str = "cpu"):
        self._model = model
        self._device = device
        self._last_pattern_hash = None
        self._last_x_init = None

    def predict(
        self,
        K_indices: torch.Tensor,
        K_values: torch.Tensor,
        b: torch.Tensor,
        n: int,
    ) -> torch.Tensor:
        """Return an initial guess of length ``n`` matching ``b.dtype``/device."""
        if self._model is None:
            return torch.zeros(n, dtype=b.dtype, device=b.device)

        # Stable pattern hash for cache bookkeeping.
        try:
            ph = (
                tuple(K_indices.shape),
                hash(K_indices.detach().cpu().numpy().tobytes()),
            )
        except Exception:
            ph = None

        try:
            with torch.no_grad():
                x_init = self._model(
                    K_indices.to(self._device),
                    K_values.to(self._device),
                    b.to(self._device),
                )
            x_init = x_init.to(b.device).to(b.dtype).reshape(-1)
            if x_init.numel() != n:
                # Shape mismatch -- safer to fall back than to mis-warm CG.
                x_init = torch.zeros(n, dtype=b.dtype, device=b.device)
        except Exception as exc:  # pragma: no cover - defensive
            print(f"[NOWS] model call failed ({exc}); using zero fallback")
            x_init = torch.zeros(n, dtype=b.dtype, device=b.device)

        self._last_pattern_hash = ph
        self._last_x_init = x_init
        return x_init

    @property
    def has_model(self) -> bool:
        return self._model is not None


def make_warm_start(
    model_path: Optional[str] = None, device: str = "cpu"
) -> NOWSPredictor:
    """Factory: load a torch model from path, or return a zero-fallback predictor.

    A missing path or load failure logs and degrades to the zero fallback so
    production solves never crash because a warm-start checkpoint is absent.
    """
    if model_path is None:
        return NOWSPredictor(model=None, device=device)
    try:
        model = torch.load(model_path, map_location=device)
        if hasattr(model, "eval"):
            model.eval()
        return NOWSPredictor(model=model, device=device)
    except Exception as exc:
        print(f"[NOWS] Failed to load model from {model_path}: {exc}; using zero fallback")
        return NOWSPredictor(model=None, device=device)
