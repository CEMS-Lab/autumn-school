"""Reproducible manuscript demo entry points."""

