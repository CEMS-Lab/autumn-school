"""Paper-support utilities and reproducible demo drivers."""

