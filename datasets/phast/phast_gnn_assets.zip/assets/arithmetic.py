# Generated from the verified damage-cost benchmark; original counting class.
import collections
import numpy as np
import torch
from torch.utils._python_dispatch import TorchDispatchMode
from torch.utils._pytree import tree_flatten
class ArithmeticCount(TorchDispatchMode):
    """Estimated tensor arithmetic, not hardware performance counters.

    add/mul/div=1; FMA=2; reductions n-1; index_add one add/source.
    Non-arithmetic comparisons, indexing and copies are recorded separately.
    Transcendentals and unsupported floating operations are explicitly listed.
    """

    def __init__(self):
        super().__init__()
        self.flops = 0
        self.counts = collections.Counter()
        self.unresolved = collections.Counter()
        self.sparse = []

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        kwargs = kwargs or {}
        out = func(*args, **kwargs)
        name = func._schema.name.split('::')[-1]
        ts = [t for t in tree_flatten(out)[0] if isinstance(t, torch.Tensor) and t.is_floating_point()]
        n = sum((t.numel() for t in ts))
        self.counts[name] += 1
        a = args[0] if args else None
        v = 0
        if name in {'add', 'add_', 'sub', 'sub_', 'rsub', 'mul', 'mul_', 'div', 'div_', 'neg', 'reciprocal', 'abs'}:
            v = n
        elif name == 'linear':
            v = 2 * n * args[1].shape[-1] + (n if len(args) > 2 and args[2] is not None else 0)
        elif name in {'addmm', 'mm', 'bmm'}:
            (x, y) = (args[1], args[2]) if name == 'addmm' else (args[0], args[1])
            v = 2 * out.numel() * x.shape[-1] + (out.numel() if name == 'addmm' else 0)
        elif name in {'sum', 'mean'}:
            v = max(0, a.numel() - n) + (n if name == 'mean' else 0)
        elif name in {'dot'}:
            v = 2 * a.numel() - 1
        elif name in {'index_add', 'index_add_'}:
            v = args[3].numel()
        elif name in {'scatter_add', 'scatter_add_'}:
            v = args[3].numel()
        elif name in {'addcmul', 'addcdiv', 'addcmul_', 'addcdiv_'}:
            v = 3 * n
        elif name == 'pow' and isinstance(args[1], (int, float)) and (args[1] in (2, 3, 4)):
            v = (int(args[1]) - 1) * n
        elif name in {'native_layer_norm', 'layer_norm'}:
            width = int(np.prod(args[1]))
            groups = a.numel() // width
            v = 7 * a.numel() + 2 * groups
            self.unresolved['layer_norm_rsqrt_elements'] += groups
        elif name == 'linalg_vector_norm':
            v = 2 * a.numel() - 1
            self.unresolved['norm_sqrt_elements'] += n
        elif name in {'sqrt', 'rsqrt', 'log', 'log10', 'exp', 'pow'}:
            self.unresolved[name + '_output_elements'] += n
        elif n and name not in {'empty', 'empty_like', 'zeros', 'zeros_like', 'ones', 'ones_like', 'full', 'full_like', 'clone', 'copy_', '_to_copy', 'to', 'detach', 'view', '_unsafe_view', 'reshape', 'permute', 'transpose', 't', 'slice', 'select', 'index', 'index_select', 'expand', 'expand_as', 'cat', 'stack', 'unsqueeze', 'squeeze', 'lift_fresh', 'lift_fresh_copy', 'alias', 'as_strided', 'contiguous', 'where', 'clamp', 'clamp_', 'clamp_min', 'clamp_min_', 'clamp_max', 'clamp_max_', 'minimum', 'maximum', 'min', 'max', 'amin', 'amax', 'relu', 'relu_', 'threshold', 'masked_fill', 'masked_fill_', 'index_put_', 'new_zeros', 'new_empty', 'new_ones', 'scalar_tensor', 'split', 'unbind', 'split_with_sizes', 'resolve_conj', 'resolve_neg', '_local_scalar_dense', 'scatter_', 'scatter'}:
            self.unresolved[name + '_output_elements'] += n
        self.flops += v
        return out

def count_call(call):
    import scipy.sparse.linalg as spla
    counter = ArithmeticCount()
    original = spla.spsolve
    def counted(A, b, *args, **kwargs):
        result = original(A, b, *args, **kwargs)
        lu = spla.splu(A.tocsc())
        l = np.diff(lu.L.tocsc().indptr)-1
        u = np.diff(lu.U.tocsr().indptr)-1
        factor = int(np.sum(2*l.astype(np.int64)*u+l))
        solve = int(2*(lu.L.nnz+lu.U.nnz)-3*A.shape[0])
        counter.flops += factor+solve
        counter.sparse.append(dict(n=A.shape[0], nnz=A.nnz, factor_flops=factor, solve_flops=solve))
        return result
    spla.spsolve = counted
    try:
        with counter:
            call()
    finally:
        spla.spsolve = original
    return dict(estimated_flops=counter.flops, sparse=counter.sparse,
                special_operations=dict(counter.unresolved), operator_calls=dict(counter.counts))
